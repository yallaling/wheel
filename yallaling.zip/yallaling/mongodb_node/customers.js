var express = require('express');
var router = express.Router();
var Customers = require('../model/customer_model');

/* GET customers JSON. */
router.get('/', function(req, res, next) {
    Customers.find({}, function(err, docs) {
            res.json(docs);
    });
});


/* GET customer by ID  */
router.get('/:id', function(req, res, next) {
    Customers.find({id:req.params.id}, function(err, docs) {
            res.json(docs);
    });
});

/* GET customers JSON. */
router.post('/', function(req, res, next) {
    Customers.create(req.body, function(err, docs) {
            res.send("Customer added!!!");
    });
});


module.exports = router;
