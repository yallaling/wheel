describe('customer app tests', function() {
  
  beforeEach(function() {
    browser.get('http://localhost:8080/first.html');
  });

  it('should have five customers', function() {
    var customerList = element.all(by.repeater('customer in customers')); 
     expect(customerList.count()).toEqual(5);  
  });

 
  it('should filter customers', function() {
    var filter = element.all(by.model("searchText"));
    filter.sendKeys("Geller");
    var customerList = element.all(by.repeater('customer in customers')); 
    
     expect(customerList.count()).toEqual(2);  
      // browser.pause();
  });


  it('should delete a customer', function() {
    var customerList = element.all(by.repeater('customer in customers')); 
      customerList.get(2).element(by.css('.cardClose')).click();
     expect(customerList.count()).toEqual(4);  
     browser.pause();
  }); 
});