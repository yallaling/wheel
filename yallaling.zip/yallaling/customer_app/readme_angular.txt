
Angular JS
----------

Libarary : jQuery
Template: Underscore

Single Page Application[SPA] and RWD

Challenges:
1) Dependency of Modules
	Dependency Injection [ Inversion Of Control ]
2) Data binding
	jQuery / Templates like Underscore, Mustache, Handlebars support one-way binding

	We need some times - two way binding
3) Routing
	
	In single page app, we have one URL

	http://ge.com

	In traditional web application:
		Back and Next buttons of web browser takes you to different pages

	In SPA , back and next should still be in same page, but display different views

	We need different URLs for different views

	http://mywebsite.com/phones/iphone8

	http://mywebsite.com/phones

	http://mywebsite.com/phones/pixel

4) Cache
5) Basic Security features
------------------

Frameworks for SPA:
1) BackboneJS
2) AngularJS
3) EmberJS
4) ExtJS
5) ReactJS

--------------------------

AngularJS 1.5 is based on MVC architectural Pattern

M --> Model   V----> View C--->Controller

MVW*

Modules of AngularJS: Config, Controller, Service, filter, Factory, Provider


---------------

var ng = angular.module("sample_module",[]);

ng.controller("SampleController", function($scope){
	$scope.x = "Hello World";
});


HTML

<body ng-app="sample_module">
	
	<div ng-controller="SampleController">
			{{x}}
	</div>

</body>

-----------------

Protractor

$ webdriver-manager start

customer_app$ http-server

E2E$ protractor conf.js



$('.ng-scope').css({'border':'4px solid red'}).css({'margin':'2px'});

Browser keeps track of 100 inspect elements

$0 being the latest ---> $99

$($0).scope().customer.firstName
"Joey"

$($1).scope().customer.firstName = "Ronica"
$($1).scope().$digest()  // triggers the digest loop of the current controller
or
$($1).scope().$apply() // triggers digset loop of all the controllers

