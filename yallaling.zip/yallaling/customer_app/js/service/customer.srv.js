(function(){
	angular.module("service_module",[]);

 	angular.module("service_module").service("CustomerService",  function($http, $q){
		this.getCustomers = function() {
			var deferred = $q.defer();
			$http.get("/customers").then(function(result){
				deferred.resolve(result);
			},
			function(result) {
				deferred.reject(result);
			});

			return deferred.promise;
		};

		this.deleteCustomer = function(id) {
			$http.delete("/customers/" + id);
		};

		this.updateCustomer = function(id, customer) {
			$http.put("/customers/" + id, customer);
		};

		this.getOrders = function() {
			var deferred = $q.defer();
			$http.get("/orders").then(function(result){
				deferred.resolve(result);
			},
			function(result) {
				deferred.reject(result);
			});

			return deferred.promise;
		};

	});
})();