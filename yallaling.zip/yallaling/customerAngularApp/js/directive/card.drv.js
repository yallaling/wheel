(function () {
	angular.module("directive_module",[]);

	angular.module("directive_module").directive("cardView", function(){
		return {
			templateUrl: 'js/templ/card.templ.html',
			restrict: 'E',
			scope: {
				first: '=', /* same as =first*/
				second: '=',
				desc: '=',
				pic : '=image', /* image is used in html */
				delete: '&',
				openEdit: '&'
			}
		}
	});
})();