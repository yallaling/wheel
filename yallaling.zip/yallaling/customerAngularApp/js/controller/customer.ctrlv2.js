(function () {
	var ng = angular.module("customer_module",["directive_module"]);

  ng.controller("CustomerMenuController",function($rootScope, $scope){
    $scope.searchText = "";
    $scope.filterCustomers = function(){
        $rootScope.$broadcast("filter_event",$scope.searchText);
    }
  });

	ng.controller("CustomerListController", function($scope){
		$scope.customers = customers;
    $scope.editMode = false;

    $scope.$on("filter_event",function(evt,txt){
      var result = [];
      customers.forEach(function(c){
        if (c.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0 ||
             c.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0) {
              result.push(c);
        }
      });

      $scope.customers = result;
    });

    $scope.openEdit = function(customer){
      $scope.currentCustomer = customer;
      $scope.editMode=true;
    }

    $scope.update = function(){
      //server hit
      $scope.editMode = false;
    }

    $scope.deleteCustomer = function(id){
    //delete from server
    var idx = -1;
    $scope.customers.forEach(function(c,index){
        if (c.id == id) {
          idx = index;
        }
    });

    if (id != -1) {
      $scope.customers.splice(idx,1);
    }
  }
	});


	var customers = [{
      "id": 1,
      "firstName": "Ross",
      "lastName": "Geller",
      "address": "West Street",
      "gender": "female"
    },
    {
      "id": 2,
      "firstName": "Monica",
      "lastName": "Geller",
      "address": "Street",
      "gender": "female"
    },
    {
      "id": 3,
      "firstName": "Joe",
      "lastName": "Geller",
      "address": "West Street",
      "gender": "male"
    },
    {
      "id": 4,
      "firstName": "Yallaling",
      "lastName": "Geller",
      "address": "West",
      "gender": "male"
    },
    {
      "id": 5,
      "firstName": "Mishra",
      "lastName": "Geller",
      "address": "West Street",
      "gender": "female"
    }]
})();