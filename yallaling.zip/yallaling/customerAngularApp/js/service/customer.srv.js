(function () {
	angular.module("service_module",[]);

	angular.module("service_module").service("CustomerService", function($http, $q){
		this.getCustomers = function(){
			var deffered = $q.defer();
			$http.get("/customers").then(function(result){
				deffered.resolve(result);
			},
			function(result){
				deffered.reject(result);
			});

			return deffered.promise;
		};

		this.deleteCustomers = function(id){
			$http.delete("/customers/" + id); 
		};

		this.updateCustomers = function(id, customer){
			$http.put("/customers/" + id, customer); 
		};

		this.getOrders = function(){
			var deffered = $q.defer();
			$http.get("/orders").then(function(result){
				deffered.resolve(result);
			},
			function(result){
				deffered.reject(result);
			});

			return deffered.promise;
		};

	});
})();