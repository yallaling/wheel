$('.ng-scope').css({'border':'4px solid red'}).css({'margin':'2px'}) // To check the scopes

browsers can keep track of 100 inspect elements

$0 being the latest ---> $99

$($0).scope().customer.firstName

$($0).scope().customer.firstName= "Ronica"
$($0).scope().$digest() //triggers the digest loop of the current controller
or
$($0).scope().$apply() // triggers digest loop of all the controllers

Jasmine is a unit testing framework for javascript

bower install jasmine --save
-------------------------------

Controllers
Service/Factory/Provider
Directive
Config
Filter
----------------

Directive
	Built-in directives:
	ng-app, ng-controller, ng-show, ng-hide, ng-if, ng-repeat, ng-model, ng-click, ng-updateec
	-------------------

Custom Directives [like JSP custom tags]

<employee></employee>

Why custom Directives?

	a) Modularity
	b) testing
	c) Reusability

	<div ng-repeat="customer in customers">
		<card-vew></card-view> 
	</div>

	<div ng-repeat="product in products">
		<card-vew></card-view> 
	</div>

Custom Directives and scope:
	1) shared scope
	2) inherited scope
	3) isolated scope
------------------------------

Angular Service:

Service / Factory / Provider

Service is singleton
Factory is not singleton

$q is promise service wats comes from the server may be resolved or not resolved

-------------------------------

config module
a) Router
b) security
