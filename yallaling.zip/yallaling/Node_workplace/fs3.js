/**
	Node JS supports IO operations
	using blocking and non-blocking mode
*/

var fs = require("fs");

var content=""; 

var stream = fs.createReadStream("fs1.js"); //event based //stream based

stream.on('data', function (chunk) {
	console.log(chunk.toString());
});

stream.on('end', function (chunk) {
	console.log("Done");
});

stream.on('error', function (err, chunk) {
	console.log("Error");
});