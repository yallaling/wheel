/**
	Node JS supports IO operations
	using blocking and non-blocking mode
*/

var fs = require("fs");

var content = fs.readFileSync("fs1.js");

console.log(content.toString());