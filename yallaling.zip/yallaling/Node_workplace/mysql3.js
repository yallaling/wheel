var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'ge_node_db'
});

connection.connect();

var data = {
	"id": 5,
	"firstName": "Mota",
	"lastName": "Mishra",
	"gender": "male",
	"address": "Bagalkot"
};
 
connection.query('INSERT into customers (id, firstName, lastName, gender, address) values(?,?,?,?,?)', [data.id, data.firstName,data.lastName,data.gender,data.address], function(err, rows, fields) {
  if (err) throw err;
 
  console.log(rows);
});
 
connection.end();