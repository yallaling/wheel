var express = require('express');
var router = express.Router();

var CustomerDao = require('../dao/CustomerDao');
/* GET customer page. */

router.get('/', function(req, res, next) {
	var customerDao = new CustomerDao();
	// .then is invoked only after promise is resolved or rejected
	// you implement promise api using diffrent lib we hv choosen "bluebird" as a promise API
	customerDao.findAll().then(function(customers){
		res.render('customer', { customers: customers, title: "Customer App"});
	});
  	
});

module.exports = router;
