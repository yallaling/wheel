var Promise = require('bluebird');

var CustomerDao = function () {
	
}

module.exports = CustomerDao;

/*CustomerDao.prototype.findAll = function(){
	return new Promise(resolve, reject){
		pool.getConnection(function(err, connection){
			connection.query('SELECT id, firstName, lastName, gender, address FROM customers', 
				function(err, rows, fields){
				connection.release();
				if (err) reject(err);
				resolve(rows);
			});
		});
	}
}*/

CustomerDao.prototype.findAll = function(){
	return new Promise(function(resolve, reject){
		pool.getConnection(function(err, connection){
			connection.query('SELECT id, firstName, lastName, gender, address FROM customers', 
				function(err, rows, fields){
				connection.release();
				if (err) reject(err);
				resolve(rows);
			});
		});
	});
}