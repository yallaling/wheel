var converter = require('../app/converter');
var expect = require('chai').expect;
var request = require('request');

describe('color converter server test', function () {
	it("should converter rgbToHex", function (done) {
		// body...
		var url = 'http://localhost:3000/rgbToHex?red=255&green=0&blue=42';
		request(url,function(err, response, body){
			expect(body).to.equal('ff002a');
			done();
		});
	});
});