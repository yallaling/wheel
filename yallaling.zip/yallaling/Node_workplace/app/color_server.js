var converter = require('./converter');
var http= require('http');
var url = require('url');

//http://localhost:3000/rgbToHex?red=255&green=0&blue=42
//http://localhost:3000/hexToRgb?hex=ff3e00

var server = http.createServer(function (request, response) {
	var pathname = url.parse(request.url).pathname;
	var query = url.parse(request.url, true).query;

	if (pathname.substring(1) == 'rgbToHex') {
		var result = converter.rgbToHex(parseInt(query.red),parseInt(query.green),parseInt(query.blue));
		response.writeHead(200,{"content-type":"text/plain"});
		response.end(result.toString());
	}else if (pathname.substring(1) == 'hexToRgb') {
		var result = converter.hexToRgb(query.hex);
		response.writeHead(200,{"content-type":"text/plain"});
		response.end(result.toString());
	}else{
		response.writeHead(404,{"content-type":"text/plain"});
	}
});

server.listen(3000, function(){
	console.log("server Started on http://localhost:3000");
});
