exports.rgbToHex = function(red, green, blue){
	var r = red.toString(16);
	var g = green.toString(16);
	var b = blue.toString(16);
	return pad(r) + pad(g) + pad(b); //#EFC5A4
};

exports.hexToRgb = function(hex){ //#EFC5A4
	var r = parseInt(hex.substring(0,2), 16);//239
	var g = parseInt(hex.substring(2,4), 16);//197
	var b = parseInt(hex.substring(4,6), 16);//164

	return [r,g,b];
};

function pad(hex) {
	// body...
	return (hex.length == 1) ? "0" + hex : hex;
}