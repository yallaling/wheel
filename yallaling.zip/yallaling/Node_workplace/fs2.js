/**
	Node JS supports IO operations
	using blocking and non-blocking mode
*/

var fs = require("fs");

var content=""; 
fs.readFile("fs1.js", function (err, chunk) { // call back first arg is an error
	// body...
	content += chunk;
	console.log("INSIDE : " + content.toString());
}); //non-blocking Mode

console.log("OUTSIDE" + content.toString());