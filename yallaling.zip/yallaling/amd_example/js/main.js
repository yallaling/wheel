require.config({
	'baseUrl': 'js',
	'paths': {
		'jquery' :'../lib/jquery',
		'underscore' :'../lib/underscore-min',
		'text' :'../lib/text'
	} 
});

require(['text!../templ/customers.html',
		'repo/customer_repo','underscore','jquery'],
	function(templ,customerDAO, _, $){
		customerDAO.init();
		var compiledTeml = _.template(templ);
		$("body").append(compiledTeml({"customers": customerDAO.get()}));
});