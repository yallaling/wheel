module.exports = {
    "trust_proxy": true,
    "session_secret": "MC41MDgzNzAwNzg1ODQ4OTM5",
    "VCAP_APP_PORT": 5000,
    "base_dir": "../public",
    "base_dir_b2bdashboard": "../b2bDashboard/dist",
    "MM_API_BASE_URL": "https://eservices-dev-api.cloud.trans.ge.com",
    "MM_API_BASIC_AUTH_USER": "mm-internal",
    "MM_API_BASIC_AUTH_CRED": "mm-internal",
    "API_ENDPOINTS": {
        "user_profile": "/common/userProfile/getUserDetails",
        "servicetrack_byorg": "/reports/services/v1/servicetrack/reportbyorg",
        "servicetrack_max": "/reports/services/v1/servicetrack/report",
        "turnover_report": "/reports/services/v1/turnover/report",
        "update_turnover_report": "/reports/services/v1/turnover/updatereport",
		"print_to_report": "/reports/services/v1/turnover/print",
        "filter_to_report": "/reports/services/v1/turnover/filterreport",
        "view_history": "/reports/services/v1/turnover/history",
        "org_list": "/workorder/services/v1/cs/getOrgList",
        "multiple_orgs": "/reports/services/v1/turnover/reportfororgs",
        "reason_codes": "/workorder/services/v1/wo/reasonCodes",
        "tiers": "/workorder/services/v1/loco/getemissiontiers",
        "models": "/workorder/services/v1/loco/getallmodels",
        "statuses": "/workorder/services/v1/wo/getworkorderstatus",
        "getcustomers":"/workorder/services/v1/cs/customers",
        "getKcsKcsmDbdata": "/reports/services/v1/servicetrack/getKcsKcsmDbdata"
    }
}