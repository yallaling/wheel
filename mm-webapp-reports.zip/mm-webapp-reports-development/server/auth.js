const request = require('request');
const config = require('nconf');

const userData = {};
const Users = {};


Users.getProfile = function(ssoid, callback){
    const base_url = config.get('MM_API_BASE_URL');
    const user_profile_url = config.get('API_ENDPOINTS').user_profile;
    const url = base_url + user_profile_url;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    const requestOption = {
        "url": url,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
        },
        "auth": auth,
        "body": JSON.stringify({"loginId": ssoid})
    };
    request(requestOption, callback);
};


Users.findById = function(ssoid, forceReload, callback){
    if(!forceReload && userData.hasOwnProperty(ssoid)){
        callback(null, userData[ssoid]);
    }
    else {
        Users.getProfile(ssoid, function(err, response, body){
			console.log("Retrive user details: ", body);
            
            if(!err && response.statusCode == 200){
				const userResponse = JSON.parse(body);
                if(userResponse.status === 'SUCCESS'){
                    userData[ssoid] = {'user': userResponse.user, 'attributes':userResponse.userAttributeType};
                    callback(null, userData[ssoid]);
                }
                else {
                    console.log("User could not be found", ssoid, userResponse.status, userResponse.message);
                    callback(null, false);
                }
            }
            else{
                console.log('failed finding profile', ssoid, err, response, body);
                callback(err, null);
            }
        });
    }
};

Users.hasPermission = function(ssoid, permission, callback){
    var hasPermission = false;
    Users.findById(ssoid, false, function(err, user){
        if(err || !user){ //could not find user, so let's deny permission
            callback(true, hasPermission);
        }
        else {
            hasPermission = user.attributes && user.attributes.find(function(attr){
                return attr && (attr.uiCode===permission) && (attr.permit==='Y');
            });
            callback(false, hasPermission);
        }
    });
}


module.exports = Users;