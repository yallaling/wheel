const config = require('nconf');
const request = require('request');

const service = {};

service.fetchKCSServiceOrgs = function(ssoid, callback){
    const base_url = config.get('MM_API_BASE_URL');
    const service_track_url = config.get('API_ENDPOINTS').getKcsKcsmDbdata;
        const url = base_url + service_track_url;
        const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

        const requestOption = {
            "url": url,
            "method": "POST",
            "headers": {
                "Content-Type": "application/json",
                "SM_SSOID": ssoid
            },
            "auth": auth,
            "body": JSON.stringify([5510,5425])
        };
        console.log("service.fetchServiceOrgs:", url);
        request(requestOption, function(err, response, body){
            if(!err && response.statusCode == 200){
                return callback(null, JSON.parse(body));
            }
            console.log("Error fetching serviceOrgs", url, err, response.statusCode, body);
            callback(err);
        });
};

service.fetchServiceTrackData = function(orgId, ssoid, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const service_track_url = config.get('API_ENDPOINTS').servicetrack_byorg;
    const url = base_url + service_track_url + '?orgId=' + orgId;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
            "Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.fetchServiceTrackData:", url);
    request(requestOption, function(err, response, body){
        if(!err && response.statusCode == 200){
            return callback(null, JSON.parse(body));
        }
        console.log("Error fetching serviceTrackReport", url, err, response.statusCode, body);
        callback(err);
    });

};

service.fetchServiceTrackMaxData = function(orgId, woAge, maxDistance, ssoid, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const service_track_url = config.get('API_ENDPOINTS').servicetrack_max;
    const url = base_url + service_track_url + '?orgId=' + orgId + '&woAge=' + woAge + '&maxDistance=' + maxDistance;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
            "Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.fetchServiceTrackData:", url);
    request(requestOption, function(err, response, body){
        if(!err && response.statusCode == 200){
            return callback(null, JSON.parse(body));
        }
        console.log("Error fetching serviceTrackReport", url, err, response.statusCode, body);
        callback(err);
    });

};

service.fetchTurnOverReportData = function(ssoid, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const turn_over_url = config.get('API_ENDPOINTS').turnover_report;
    const url = base_url + turn_over_url;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
            "Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.fetchServiceTrackData:", url);
    request(requestOption, function(err, response, body){
        if(!err && response.statusCode == 200){
            return callback(null, JSON.parse(body));
        }
        console.log("Error fetching serviceTrackReport", url, err, response.statusCode, body);
        callback(err);
    });

};

service.postData = function(ssoid, reportAttr, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const update_turn_over_url = config.get('API_ENDPOINTS').update_turnover_report;
    const url = base_url + update_turn_over_url;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("service.fetchServiceTrackData:", url);
    request(requestOption, function(err, response, body){
        if(!err && response.statusCode == 200){
            return callback(null, JSON.parse(body));
        }
        console.log("Error fetching serviceTrackReport", url, err, response.statusCode, body);
        callback(err);
    });

};
service.printTurnOverReportData = function(ssoid, printAttrs, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const print_to_report = config.get('API_ENDPOINTS').print_to_report;
    const url = base_url + print_to_report;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "POST",
        "headers": {
			"Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
		"body": JSON.stringify(printAttrs),
        "auth": auth
    };
    console.log("service.printTurnOverReport:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error printing Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.filterTurnOverReportData = function(ssoid, filterAttrs, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const print_to_report = config.get('API_ENDPOINTS').filter_to_report;
    const url = base_url + print_to_report;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "POST",
        "headers": {
			"Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
		"body": JSON.stringify(filterAttrs),
        "auth": auth
    };
    console.log("service.printTurnOverReport:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error printing Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.viewHistoryReportData = function(orgList, ssoid, date, hrs, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const view_history = config.get('API_ENDPOINTS').view_history;
    var orgString = "";
    console.log(orgList);
    if(orgList != undefined && (orgList.constructor === Array) == false){
        orgString = orgString + "&org=" + orgList;
    }
    if(orgList != undefined && orgList.constructor === Array){
        orgList.forEach(function(item,index){
                orgString = orgString + "&org=" + item;
        });
    }
    const url = base_url + view_history + '?time=' + date + 'T' + hrs + orgString;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.viewHistoryReport:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error view history Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.getMultipleOrgs = function(customerid, ssoid, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const org_list = config.get('API_ENDPOINTS').org_list;
    const url = base_url + org_list + '?customerId=' + customerid;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.getMultipleOrgs:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getMultipleOrgs Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.multipleOrgs = function(orgList, ssoid, callback){

    const base_url = config.get('MM_API_BASE_URL');
    const multiple_orgs = config.get('API_ENDPOINTS').multiple_orgs;
    var orgString = "";
    if((orgList.constructor === Array) == false){
        orgString = orgString + "orgs=" + orgList;
    }
    if(orgList.constructor === Array){
        orgList.forEach(function(item,index){
            if(index == 0){
                orgString = orgString + "orgs=" + item;
            }else if(index > 0){
                orgString = orgString + "&orgs=" + item;  
            }
           
        });
    }
    console.log(orgString);
    const url = base_url + multiple_orgs + '?' + orgString;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json",
            "SM_SSOID": ssoid
        },
        "auth": auth
    };
    console.log("service.MultipleOrgs:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error MultipleOrgs Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.getReasonCodes = function(callback){

    const base_url = config.get('MM_API_BASE_URL');
    const reason_codes = config.get('API_ENDPOINTS').reason_codes;
    const url = base_url + reason_codes;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("service.getReasonCodes:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getReasonCodes Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.getTiers = function(customerid, callback){
    const base_url = config.get('MM_API_BASE_URL');
    const tiers = config.get('API_ENDPOINTS').tiers;
    const url = base_url + tiers + '?' + 'custid=' + customerid;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("service.getTiers:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getTiers Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.getModels = function(customerid, callback){
    const base_url = config.get('MM_API_BASE_URL');
    const models = config.get('API_ENDPOINTS').models;
    const url = base_url + models + '?' + 'custid=' + customerid;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("service.getModels:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getModels Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};
service.getStatuses = function(callback){
    const base_url = config.get('MM_API_BASE_URL');
    const statuses = config.get('API_ENDPOINTS').statuses;
    const url = base_url + statuses;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": url,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("service.getStatuses:", url);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getStatuses Turnover Report", url, err, response.statusCode, body);
        callback(err);
    });

};

service.getCustomers = function(callback){
    const customerUrl = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getcustomers;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": customerUrl,
        "method": "GET",
        "headers": {
			"Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("Get customers list URL:", customerUrl);
	
    request(requestOption, function(err, response, body){		
        if(!err && response.statusCode == 200){
            return callback(null, body);
        }
        console.log("Error getting customer list", customerUrl, err, response.statusCode, body);
        callback(err);
    });

};

module.exports = service;
