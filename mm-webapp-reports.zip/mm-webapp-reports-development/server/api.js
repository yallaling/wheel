const express = require('express');
const router = express.Router();
const services = require('./services');
const bodyParser = require('body-parser');
const config = require('nconf');
const request = require('request');
const https = require('https');
const async = require('async');

router.get('/assets/:assetId', function(req, res){
    const assetId = req.params.assetId;
    console.log('Fetch and return asset:'+assetId);
    services.fetchAsset(assetId, function(err, asset){
        if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.status(500).json({"error": err});
        }
        else {
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(asset);
        }
    });
});

router.get('/rxlist', function(req, res){
    const custfdbk = req.query.rxval;
    console.log('Fetch and return asset:',req.query.rxval);
    services.fetchRxlist(custfdbk, function(err, custfdbkres){
        if(custfdbkres){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(custfdbkres);
        }
        else if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.get('/incidentlist', function(req, res){
    const incidentToVehicleId = req.query.incidentval;
    console.log('Fetch and return asset:',req.query.incidentval);
    services.fetchIncidentlist(incidentToVehicleId, function(err, incidentToVehicleIdRes){
        if(incidentToVehicleIdRes){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(incidentToVehicleIdRes);
        }
        else if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.get('/servicetrack', function(req, res){
    const orgId = req.user.user.serviceOrgId;
    const ssoid = req.user.user.loginId;
    let orgList;

    services.fetchKCSServiceOrgs(ssoid, function(err, serviceorgresponse){
        if(serviceorgresponse){
            let orgFlag = false;
            for(let i = 0; i < serviceorgresponse.length; i++){
                if(serviceorgresponse[i] == orgId){
                    orgFlag = true
                }
            }
                if(orgFlag){
                    orgList = serviceorgresponse;

                    let funcsAll = [];
                    for(let i = 0; i < orgList.length; i++){
                        const base_url = config.get('MM_API_BASE_URL');
                        const service_track_url = config.get('API_ENDPOINTS').servicetrack_byorg;
                        const url = base_url + service_track_url + '?orgId=' + orgList[i];
                        const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
                    
                        const requestOption = {
                            "url": url,
                            "method": "GET",
                            "headers": {
                                "Content-Type": "application/json",
                                "SM_SSOID": ssoid
                            },
                            "auth": auth
                        }; 
                        let funcs = function(callback) {
                            request(requestOption, function(err, response, body){
                                if (!err && response.statusCode == 200) {
                                    callback(null, JSON.parse(body));
                                } else {
                                callback(true, {});
                                }
                            });
                        }
                        funcsAll.push(funcs);
                    }

                    async.parallel(funcsAll,
                    // optional callback
                    function(err, results) {
                        let serviceTrackdata = [];
                        let Strobj = {};
                        for(let i = 0; i < results.length; i++){
                            if(results[i].serviceTrackReports.length > 0){
                                serviceTrackdata.push(results[i].serviceTrackReports);                
                            }
                        }
                        for(let i = 0; i < results.length; i++){
                            if(results[i].selectedOrgId == orgId){
                                console.log("Results===================================",results[i]);
                                var merged = [].concat.apply([], serviceTrackdata);
                                Strobj.selectedOrgId = orgId;
                                Strobj.selectedDistance = results[i].selectedDistance;
                                Strobj.selectedWoAge = results[i].selectedWoAge;
                                Strobj.serviceTrackReports = merged;
                                Strobj.statusCode = 'SUCCESS';
                                Strobj.statusDescription = 'Ok';
                                Strobj.messageCode = [];
                                Strobj.errorMessages = [];
                                if(null != results[i].serviceTrackReports[0] && undefined != results[i].serviceTrackReports[0]){
                                    Strobj.selectedOrgName = results[i].serviceTrackReports[0].orgName;
                                }
                            }
                        }
                        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
                        res.end(JSON.stringify(Strobj));
                    });
                }else {
                    services.fetchServiceTrackData(orgId, ssoid, function(err, servicetrackresponse){
                        if(servicetrackresponse){
                            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
                            res.json(servicetrackresponse);
                        }
                        else if(err){
                            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
                            return res.status(500).json({"error": err});
                        }
                    });
                }
            }
            else if(err){
                console.log('servicetrackresponse',err);
                res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
                return res.status(500).json({"error": err});
            }
    });
});

router.get('/servicetrackmax', function(req, res){
    const woAge = req.query.woAge;
    const maxDistance = req.query.maxDistance;
    const orgId = req.user.user.serviceOrgId;
    const ssoid = req.user.user.loginId;
    services.fetchServiceTrackMaxData(orgId, woAge, maxDistance, ssoid, function(err, servicetrackresponse){
        if(servicetrackresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(servicetrackresponse);
        }
        else if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.get('/turnover', function(req, res){
    const ssoid = req.user.user.loginId;
    services.fetchTurnOverReportData(ssoid, function(err, turnoverresponse){
        if(turnoverresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(turnoverresponse);
        }
        else if(err){
            console.log('turnoverresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.post('/updatereport', function(req, res){
    const ssoid = req.user.user.loginId;
    const reportAttr = req.body;
    console.log('Fetch and return reportAttributes:',req.body.reportAttributes);
    services.postData(ssoid, reportAttr, function(err, reportAttrRes){
        if(reportAttrRes){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.json(reportAttrRes);
        }
        else if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.post('/printturnover', function(req, res){
    const ssoid = req.user.user.loginId;
	const printAttrs = req.body;
    console.log('Fetch and return print variables:', req.body.workscope);
    services.printTurnOverReportData(ssoid, printAttrs, function(err, toresponse){
        if(toresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
			res.send(toresponse);
        }
        else if(err){
           console.log('turnoverresponse',err);
           res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
           return res.status(500).json({"error": err});
        }
    });
});

router.post('/filterturnover', function(req, res){
    const ssoid = req.user.user.loginId;
	const filterAttrs = req.body;
    console.log('Fetch and return print variables:', req.body.workscope);
    services.filterTurnOverReportData(ssoid, filterAttrs, function(err, toresponse){
        if(toresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
			res.send(toresponse);
        }
        else if(err){
           console.log('turnoverresponse',err);
           res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
           return res.status(500).json({"error": err});
        }
    });
});

router.get('/viewhistory', function(req, res){
    const orglist = req.query.orglist;
    const ssoid = req.user.user.loginId;
    const date = req.query.date;
    const hrs = req.query.hrs;
    console.log(date,hrs);
    services.viewHistoryReportData(orglist, ssoid, date, hrs, function(err, viewhistoryresponse){
        if(viewhistoryresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(viewhistoryresponse);
        }
        else if(err){
            console.log('viewhistoryresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.get('/multipleorgslist', function(req, res){
    const ssoid = req.user.user.loginId;
    const customerid = req.query.customerId;
    console.log(req.query);
    services.getMultipleOrgs(customerid, ssoid, function(err, getMultipleOrgsresponse){
        if(getMultipleOrgsresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getMultipleOrgsresponse);
        }
        else if(err){
            console.log('getMultipleOrgsresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});
router.get('/multipleorgs', function(req, res){
    const ssoid = req.user.user.loginId;
    const orglist = req.query.orglist;
    console.log(req.query);
    services.multipleOrgs(orglist, ssoid, function(err, multipleOrgsresponse){
        if(multipleOrgsresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(multipleOrgsresponse);
        }
        else if(err){
            console.log('multipleOrgsresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});
router.get('/reasoncodes', function(req, res){
    services.getReasonCodes(function(err, getReasonCodesresponse){
        if(getReasonCodesresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getReasonCodesresponse);
        }
        else if(err){
            console.log('getReasonCodesresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});
router.get('/tiers', function(req, res){
    const customerid = req.query.customerId;
    console.log(customerid);
    services.getTiers(customerid, function(err, getTiersresponse){
        if(getTiersresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getTiersresponse);
        }
        else if(err){
            console.log('getTiersresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});
router.get('/models', function(req, res){
    const customerid = req.query.customerId;
    console.log(customerid);
    services.getModels(customerid, function(err, getModelsresponse){
        if(getModelsresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getModelsresponse);
        }
        else if(err){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            console.log('getModelsresponse',err);
            return res.status(500).json({"error": err});
        }
    });
});
router.get('/statuses', function(req, res){
    services.getStatuses(function(err, getStatusesresponse){
        if(getStatusesresponse){
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getStatusesresponse);
        }
        else if(err){
            console.log('getStatusesresponse',err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        }
    });
});

router.get('/getcustomers', function(req, res){
    services.getCustomers(function(err, getCustomerresponse){
        if (err) {
            console.log('getCustomerresponse', err);
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            return res.status(500).json({"error": err});
        } else {
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.send(getCustomerresponse);
        }
    });
});

module.exports = router;