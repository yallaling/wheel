"use strict";
require('newrelic');

const config = require('nconf'),
    express = require('express'),
    passport = require('passport'),
    ReverseProxyStrategy = require('passport-reverseproxy'),
    cookieParser = require('cookie-parser'),
    bodyParser = require('body-parser'),
    session = require('express-session'),
    path = require('path'),
    User = require('./auth'),
    defaultConfig = require('./config');

const node_env = process.env.node_env || 'development';
console.log('node_env:'+node_env);

config.argv()
    .env()
    .defaults(defaultConfig);

const app = express(),
    router = express.Router(),
    store = new session.MemoryStore();

passport.use(new ReverseProxyStrategy({
    headers: {
      'SM_SSOID': { alias: 'ssoid', required: true },
      'SM_USER': { alias: 'sm_user', required: false }
    }
  }, function(headers, user, done){
    var err = null,
        ssoid = headers['SM_SSOID'];
    User.findById(ssoid, true, function(err, userResponse){
        if(err){
            console.log("Error fetching user details for ", ssoid, err);
            done(err, false, 401);
        }
        if(userResponse){
            console.log("Logging in user", user);
            return done(err, user);
        }
        else {
            console.log("User could not be logged in", user);
            return done(err, false);
        }

    });
  })
);

passport.serializeUser(function(user, done) {
  done(null, user.ssoid);
});

passport.deserializeUser(function(ssoid, done) {
    User.findById(ssoid, false, function(err, user) {
        done(err, user);
    });
});

app.set('trust proxy', config.get('trust_proxy'));
app.use(cookieParser(config.get('session_secret')));
app.use(session({
    secret: config.get('session_secret'),
    name: 'mm-webapp-reports',
    store: store,
    proxy: config.get('trust_proxy'),
    resave: true,
    saveUninitialized: true
}));

// No reverse-proxy auth for static files
app.use('/', express.static(path.join(__dirname, config.get('base_dir'))));
app.use('/b2bDashboard', express.static(path.join(__dirname, config.get('base_dir_b2bdashboard'))));

app.use(passport.initialize());
app.use(passport.authenticate('reverseproxy', { session: true }));
app.use(passport.session());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false }));

app.get('/request', function(req, res){
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.send(req.user);
});

app.get('/b2bDashboard/userdetails', function(req, res){
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.send(req.user);
});

app.use('/api', require('./api'));
app.use('/b2bDashboard/api', require('./api'));

app.get('/favicon.ico', function (req, res) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    res.send('favicon.ico');
});


////// error handlers //////
// catch 404 and forward to error handler
app.use(function(err, req, res, next) {
  console.error(err.stack);
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// development error handler - prints stacktrace
if (node_env === 'development') {
    app.use(function(err, req, res, next) {
        if (!res.headersSent) {
            res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
            res.status(err.status || 500);
            res.send({
                message: err.message,
                error: err
            });
        }
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
    if (!res.headersSent) {
        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
        res.status(err.status || 500);
        res.send({
            message: err.message,
            error: {}
        });
    }
});

const server = app.listen(config.get('VCAP_APP_PORT'), function () {
    console.log ('Server started on port: ' + server.address().port);
});

module.exports = app;