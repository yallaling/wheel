'use strict';
const merge = require('merge-stream');

// ------------------------------------------------
//   Task: Copy all deployment files to Dist folder
// ------------------------------------------------

module.exports = function(gulp) {
  return function() {
    var publicFiles = gulp.src(['public/**/*']).pipe(gulp.dest('./dist/public'));
    var nodeFiles = gulp.src(['node_modules/**/*']).pipe(gulp.dest('./dist/node_modules'));
    var server = gulp.src(['server/**/*']).pipe(gulp.dest('./dist/server'))
    var packageFile = gulp.src(['package.json', 'bower.json']).pipe(gulp.dest('dist'));

    return merge(publicFiles, nodeFiles, server, packageFile);
  };
};
