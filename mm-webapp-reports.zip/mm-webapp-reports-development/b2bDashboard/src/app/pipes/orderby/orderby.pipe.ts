import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderbyPipe implements PipeTransform {

  transform(records: Array<any>, args?: any): any {
    args.sortDirection = args.sortDirection === 'asc' ? 1 : -1;
    records.sort(function(a, b){
      if(a[args.sortColumn] < b[args.sortColumn]){
        return -1 * args.sortDirection;
      }
      else if( a[args.sortColumn] > b[args.sortColumn]){
        return 1 * args.sortDirection;
      }
      else{
        return 0;
      }
    });
    return records;
  };

}
