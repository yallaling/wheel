import { SharedService } from './../../services/shared.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userDetails: Array<any> = [];

  constructor(
    private sharedService:SharedService
  ) { }

  ngOnInit() {
    this.sharedService.getUserDetails().subscribe((data:any) => {
      console.log(data);
      this.userDetails = data.user;
    });
  }

}
