import { Component, OnInit } from '@angular/core';
import { SharedService } from '../../services/shared.service';
import { PageFilterService } from './page-filer.service';

export interface Status {
  id: string,
  name: string
}
export interface Direction {
  id: string,
  name: string
}
export interface Action {
  id: string,
  name: string
}

@Component({
  selector: 'app-page-filter',
  templateUrl: './page-filter.component.html',
  styleUrls: ['./page-filter.component.css']
})
export class PageFilterComponent implements OnInit {
  customersList: Array<any> = [];
  selectedCustomer: any;
  filterList: any = {
    selectedStatus: null,
    selectedDirection: null,
    fromDateTime: new Date(),
    toDateTime: null
  };

  statusList: Status[] = [
    {
      id: 'SUCCESS',
      name: 'Success'
    },
    {
      id: 'FAILED',
      name: 'Failed'
    }
  ];

  directionList: Direction[] = [
    {
      id: 'INBOUND',
      name: 'Inbound'
    },
    {
      id: 'OUTBOUND',
      name: 'Outbound'
    }
  ];

  actionList: Action[] = [
    {
      id: 'STAGING',
      name: 'Staging'
    },
    {
      id: 'LANDING',
      name: 'Landing'
    }
  ];

  constructor(
    private sharedService: SharedService,
    private pageFilterService: PageFilterService
  ) {
  }

  searchTransactions(): void{
    console.log("search...");
    this.pageFilterService.sendFilteredQuery(this.filterList);
  }

  ngOnInit() {
  }
}
