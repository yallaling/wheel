import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class PageFilterService{
    private pageFilterSubject = new Subject<any>();
 
    getFilteredQuery$ = this.pageFilterSubject.asObservable();

    sendFilteredQuery(filter: any) {
        this.pageFilterSubject.next({ 
            query: filter 
        });
    }
}