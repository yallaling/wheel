import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-nav',
  templateUrl: './sidebar-nav.component.html',
  styleUrls: ['./sidebar-nav.component.css']
})
export class SidebarNavComponent implements OnInit {

  constructor() { }

  isIn:boolean = false;
  toggleState() {
      let bool = this.isIn;
      this.isIn = bool === false ? true : false;
  }

  ngOnInit() {
  }

}
