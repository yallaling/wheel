import { Component, OnInit, OnDestroy } from '@angular/core';
import { SharedService } from './../../services/shared.service';
import { OrderbyPipe } from '../../pipes/orderby/orderby.pipe';
import { PageFilterService } from './../page-filter/page-filer.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers:[OrderbyPipe]
})
export class DashboardComponent implements OnInit, OnDestroy {
  subscription: Subscription;
  transactionList:any = {};
  filteredQuery: any;
  totalNoOfRecords: number;
  currentPage:number = 1;
  pageSize:number = 10;

  constructor(
    private sharedService: SharedService,
    private orderBy: OrderbyPipe,
    private pageFilterService: PageFilterService
  ) { }

  onSorted($event){
    this.transactionList = this.orderBy.transform(this.transactionList, $event);
  }

  ngOnInit() {
    this.sharedService.getTransactionDetails().subscribe(
      data => {
        this.transactionList = data['transactions'];
        this.totalNoOfRecords = data['numberOfRecords'];
      }
    );

    this.subscription = this.pageFilterService.getFilteredQuery$.subscribe(filter => { 
      this.filteredQuery = filter;
      //console.log(this.filteredQuery);
    });
  }

  onPager(event: number): void {
    console.log("Pager event Is: ", event);//API Call
  }
 
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
