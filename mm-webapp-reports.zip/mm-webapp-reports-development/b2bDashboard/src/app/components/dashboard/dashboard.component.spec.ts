import { SharedService } from './../../services/shared.service';
import { PageFilterService } from './../page-filter/page-filer.service';
import { OrderbyPipe } from './../../pipes/orderby/orderby.pipe';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Pipe, PipeTransform } from '@angular/core';
import { DashboardComponent } from './dashboard.component';
import { of } from 'rxjs';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  let sharedService: SharedService;
  let pageFilterService: PageFilterService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [ DashboardComponent, OrderbyPipe ],
      //providers: [PageFilterService,  {provide: SharedService, useValue: dummySharedService}],
      providers: [SharedService, PageFilterService],
      schemas: [
        CUSTOM_ELEMENTS_SCHEMA
      ]
    })
    .compileComponents();

    sharedService = TestBed.get(SharedService);
    pageFilterService = TestBed.get(PageFilterService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch the transactions list', () => {
    const dummyTransactionList:Object = {
      transactions: [
      {
        "transactionId": "45299933",
        "date": "11/10/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "20412984",
        "date": "06/13/18",
        "direction": "Inbound",
        "fileName": "5",
        "fileSize": 7,
        "status": "Failed"
      }],
      numberOfRecords: 100
    };
    component.ngOnInit();
    sharedService.getTransactionDetails().subscribe(data => { 
      //console.log(data);
      console.log(component.transactionList.length);
      //expect().toEqual(data.transactions);
    });
    
  });

});
