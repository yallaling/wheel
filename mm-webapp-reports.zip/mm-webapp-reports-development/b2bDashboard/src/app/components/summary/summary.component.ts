import { Component, ViewChild, ChangeDetectorRef, ElementRef, AfterViewInit } from '@angular/core';
import { BaseChartDirective } from 'ng2-charts'
import 'chart.piecelabel.js';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements AfterViewInit {
  @ViewChild(BaseChartDirective) baseChart: BaseChartDirective;
  @ViewChild('legendIcon') legendIcon: ElementRef;

  public chartLabels:string[] = ['Files Transferred', 'Files Failed'];
  public chartData:number[] = [960, 90];
  public chartType:string = 'doughnut';

  public chartOptions: any = {
    legend: {
      position: 'right',
      display:false,
      labels: {
        boxWidth: 20
      }
    },
    pieceLabel: [{
      render: 'percentage',
      overlap: true,
      fontColor: ['white', 'white']
    }],
    legendCallback: (chart) => {
      var legendHtml = [];
      legendHtml.push('<ul class="legend-list">');
      var item = chart.data.datasets[0];
      for (var i=0; i < item.data.length; i++) {
          legendHtml.push('<li>');
          legendHtml.push('<span class="chart-legend" style="background-color:' + item.backgroundColor[i] +'"></span>');
          legendHtml.push('<span class="chart-legend-label-text">'+ chart.data.labels[i] +': <strong>' + item.data[i] + '</strong></span>');
          legendHtml.push('</li>');
      }

      legendHtml.push('</ul>');
      return legendHtml.join("");
    }
  };
  
  public chartColors: any[] = [{ backgroundColor: ["#009900", "#CC0000"] }];

  constructor(
    private cdRef: ChangeDetectorRef
  ) { }

  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }

  ngAfterViewInit() {
    this.cdRef.detectChanges();
    this.legendIcon.nativeElement.innerHTML = this.baseChart.chart.generateLegend();
  }

}
