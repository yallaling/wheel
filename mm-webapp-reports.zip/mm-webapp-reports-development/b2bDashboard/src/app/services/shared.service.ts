import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(
    private http: HttpClient
  ) { }

  public getTransactionDetails(): Observable<Object>{
    return of(this._transactionList);
  }

  private _transactionList = {
      transactions :[
      {
        "transactionId": "29255917",
        "date": "02/24/19",
        "direction": "Inbound",
        "fileName": "41",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "50189163",
        "date": "09/19/18",
        "direction": "Outbound",
        "fileName": "7",
        "fileSize": 6,
        "status": "Success"
      },
      {
        "transactionId": "36393838",
        "date": "04/24/18",
        "direction": "Inbound",
        "fileName": "47",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "20073059",
        "date": "02/26/18",
        "direction": "Inbound",
        "fileName": "7",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "49761058",
        "date": "08/08/18",
        "direction": "Outbound",
        "fileName": "29",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "34565529",
        "date": "03/24/19",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "48769687",
        "date": "01/30/19",
        "direction": "Inbound",
        "fileName": "35",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "13409887",
        "date": "11/07/18",
        "direction": "Inbound",
        "fileName": "3",
        "fileSize": 5,
        "status": "Success"
      },
      {
        "transactionId": "16766917",
        "date": "01/22/18",
        "direction": "Inbound",
        "fileName": "1",
        "fileSize": 6,
        "status": "Failed"
      },
      {
        "transactionId": "38018051",
        "date": "12/10/17",
        "direction": "Inbound",
        "fileName": "11",
        "fileSize": 4,
        "status": "Success"
      },
      {
        "transactionId": "20482041",
        "date": "12/29/18",
        "direction": "Outbound",
        "fileName": "39",
        "fileSize": 7,
        "status": "Failed"
      },
      {
        "transactionId": "12512597",
        "date": "10/04/17",
        "direction": "Outbound",
        "fileName": "37",
        "fileSize": 7,
        "status": "Failed"
      },
      {
        "transactionId": "24411463",
        "date": "08/22/17",
        "direction": "Inbound",
        "fileName": "43",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "50816900",
        "date": "05/23/19",
        "direction": "Inbound",
        "fileName": "31",
        "fileSize": 1,
        "status": "Failed"
      },
      {
        "transactionId": "16918173",
        "date": "01/01/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "39355701",
        "date": "09/23/18",
        "direction": "Inbound",
        "fileName": "29",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "17867949",
        "date": "06/24/19",
        "direction": "Outbound",
        "fileName": "5",
        "fileSize": 4,
        "status": "Success"
      },
      {
        "transactionId": "23673257",
        "date": "11/27/18",
        "direction": "Outbound",
        "fileName": "9",
        "fileSize": 8,
        "status": "Success"
      },
      {
        "transactionId": "39774774",
        "date": "05/06/19",
        "direction": "Inbound",
        "fileName": "19",
        "fileSize": 6,
        "status": "Success"
      },
      {
        "transactionId": "37887106",
        "date": "10/14/17",
        "direction": "Outbound",
        "fileName": "15",
        "fileSize": 5,
        "status": "Success"
      },
      {
        "transactionId": "14762871",
        "date": "02/05/18",
        "direction": "Outbound",
        "fileName": "15",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "6906934",
        "date": "09/26/18",
        "direction": "Outbound",
        "fileName": "23",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "40180558",
        "date": "09/12/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "50347357",
        "date": "12/28/18",
        "direction": "Inbound",
        "fileName": "35",
        "fileSize": 10,
        "status": "Failed"
      },
      {
        "transactionId": "34268035",
        "date": "04/28/18",
        "direction": "Inbound",
        "fileName": "13",
        "fileSize": 5,
        "status": "Success"
      },
      {
        "transactionId": "20194335",
        "date": "07/23/19",
        "direction": "Outbound",
        "fileName": "15",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "23236913",
        "date": "08/25/18",
        "direction": "Inbound",
        "fileName": "41",
        "fileSize": 10,
        "status": "Failed"
      },
      {
        "transactionId": "30860164",
        "date": "05/17/18",
        "direction": "Outbound",
        "fileName": "37",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "18555700",
        "date": "10/21/18",
        "direction": "Outbound",
        "fileName": "7",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "50966338",
        "date": "08/17/19",
        "direction": "Outbound",
        "fileName": "41",
        "fileSize": 10,
        "status": "Failed"
      },
      {
        "transactionId": "9988346",
        "date": "11/26/17",
        "direction": "Outbound",
        "fileName": "35",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "32766269",
        "date": "07/29/18",
        "direction": "Outbound",
        "fileName": "41",
        "fileSize": 2,
        "status": "Success"
      },
      {
        "transactionId": "37375608",
        "date": "02/19/18",
        "direction": "Inbound",
        "fileName": "21",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "13288174",
        "date": "06/07/19",
        "direction": "Outbound",
        "fileName": "15",
        "fileSize": 9,
        "status": "Failed"
      },
      {
        "transactionId": "36667641",
        "date": "09/25/18",
        "direction": "Outbound",
        "fileName": "9",
        "fileSize": 5,
        "status": "Success"
      },
      {
        "transactionId": "37287778",
        "date": "09/23/17",
        "direction": "Outbound",
        "fileName": "11",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "20297472",
        "date": "10/05/17",
        "direction": "Inbound",
        "fileName": "43",
        "fileSize": 1,
        "status": "Failed"
      },
      {
        "transactionId": "24982839",
        "date": "03/12/19",
        "direction": "Outbound",
        "fileName": "31",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "37860813",
        "date": "04/24/19",
        "direction": "Outbound",
        "fileName": "11",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "17904017",
        "date": "06/13/18",
        "direction": "Inbound",
        "fileName": "9",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "45981929",
        "date": "10/06/17",
        "direction": "Outbound",
        "fileName": "11",
        "fileSize": 8,
        "status": "Success"
      },
      {
        "transactionId": "37258914",
        "date": "03/15/18",
        "direction": "Outbound",
        "fileName": "47",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "8455510",
        "date": "01/08/19",
        "direction": "Outbound",
        "fileName": "33",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "24056622",
        "date": "03/14/19",
        "direction": "Inbound",
        "fileName": "45",
        "fileSize": 9,
        "status": "Failed"
      },
      {
        "transactionId": "33370949",
        "date": "09/01/17",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "17256093",
        "date": "12/21/17",
        "direction": "Outbound",
        "fileName": "3",
        "fileSize": 4,
        "status": "Failed"
      },
      {
        "transactionId": "38767098",
        "date": "03/20/19",
        "direction": "Outbound",
        "fileName": "23",
        "fileSize": 8,
        "status": "Success"
      },
      {
        "transactionId": "34112072",
        "date": "03/06/18",
        "direction": "Outbound",
        "fileName": "43",
        "fileSize": 4,
        "status": "Success"
      },
      {
        "transactionId": "35460173",
        "date": "06/18/18",
        "direction": "Inbound",
        "fileName": "1",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "44036190",
        "date": "12/23/18",
        "direction": "Inbound",
        "fileName": "21",
        "fileSize": 6,
        "status": "Success"
      },
      {
        "transactionId": "22522763",
        "date": "10/19/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "9151168",
        "date": "07/09/19",
        "direction": "Outbound",
        "fileName": "29",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "42743171",
        "date": "12/11/18",
        "direction": "Outbound",
        "fileName": "17",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "21575580",
        "date": "05/01/18",
        "direction": "Inbound",
        "fileName": "23",
        "fileSize": 6,
        "status": "Success"
      },
      {
        "transactionId": "37436611",
        "date": "07/22/19",
        "direction": "Inbound",
        "fileName": "23",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "8488060",
        "date": "10/27/17",
        "direction": "Outbound",
        "fileName": "27",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "39339256",
        "date": "01/05/19",
        "direction": "Inbound",
        "fileName": "5",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "9298337",
        "date": "09/19/17",
        "direction": "Inbound",
        "fileName": "19",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "45712105",
        "date": "11/20/18",
        "direction": "Inbound",
        "fileName": "29",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "12079688",
        "date": "10/10/17",
        "direction": "Outbound",
        "fileName": "7",
        "fileSize": 8,
        "status": "Success"
      },
      {
        "transactionId": "35399983",
        "date": "11/23/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 5,
        "status": "Failed"
      },
      {
        "transactionId": "39076920",
        "date": "06/07/18",
        "direction": "Outbound",
        "fileName": "47",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "19666229",
        "date": "05/15/18",
        "direction": "Inbound",
        "fileName": "33",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "8665219",
        "date": "09/08/18",
        "direction": "Inbound",
        "fileName": "41",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "20445792",
        "date": "09/25/17",
        "direction": "Inbound",
        "fileName": "5",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "28776948",
        "date": "01/02/18",
        "direction": "Inbound",
        "fileName": "25",
        "fileSize": 4,
        "status": "Success"
      },
      {
        "transactionId": "34563377",
        "date": "11/26/18",
        "direction": "Inbound",
        "fileName": "43",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "5747557",
        "date": "05/06/18",
        "direction": "Outbound",
        "fileName": "33",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "32274305",
        "date": "12/03/18",
        "direction": "Inbound",
        "fileName": "27",
        "fileSize": 9,
        "status": "Success"
      },
      {
        "transactionId": "44695698",
        "date": "08/04/18",
        "direction": "Inbound",
        "fileName": "11",
        "fileSize": 10,
        "status": "Success"
      },
      {
        "transactionId": "38201577",
        "date": "02/09/18",
        "direction": "Outbound",
        "fileName": "47",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "45520507",
        "date": "07/19/19",
        "direction": "Outbound",
        "fileName": "11",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "33084836",
        "date": "01/30/19",
        "direction": "Inbound",
        "fileName": "31",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "28354082",
        "date": "03/22/19",
        "direction": "Outbound",
        "fileName": "49",
        "fileSize": 7,
        "status": "Failed"
      },
      {
        "transactionId": "49224337",
        "date": "04/02/19",
        "direction": "Outbound",
        "fileName": "5",
        "fileSize": 9,
        "status": "Failed"
      },
      {
        "transactionId": "10385542",
        "date": "03/01/19",
        "direction": "Inbound",
        "fileName": "3",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "37456367",
        "date": "09/04/18",
        "direction": "Inbound",
        "fileName": "23",
        "fileSize": 8,
        "status": "Success"
      },
      {
        "transactionId": "5922325",
        "date": "05/09/19",
        "direction": "Inbound",
        "fileName": "11",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "13410142",
        "date": "08/13/18",
        "direction": "Inbound",
        "fileName": "25",
        "fileSize": 9,
        "status": "Failed"
      },
      {
        "transactionId": "47213434",
        "date": "06/10/19",
        "direction": "Inbound",
        "fileName": "21",
        "fileSize": 2,
        "status": "Failed"
      },
      {
        "transactionId": "49206957",
        "date": "11/08/17",
        "direction": "Inbound",
        "fileName": "27",
        "fileSize": 3,
        "status": "Success"
      },
      {
        "transactionId": "9441016",
        "date": "02/22/19",
        "direction": "Inbound",
        "fileName": "11",
        "fileSize": 2,
        "status": "Success"
      },
      {
        "transactionId": "9812091",
        "date": "11/24/18",
        "direction": "Inbound",
        "fileName": "33",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "33503207",
        "date": "01/30/19",
        "direction": "Outbound",
        "fileName": "9",
        "fileSize": 2,
        "status": "Success"
      },
      {
        "transactionId": "45299933",
        "date": "11/10/18",
        "direction": "Inbound",
        "fileName": "17",
        "fileSize": 7,
        "status": "Success"
      },
      {
        "transactionId": "20412984",
        "date": "06/13/18",
        "direction": "Inbound",
        "fileName": "5",
        "fileSize": 7,
        "status": "Failed"
      },
      {
        "transactionId": "37770216",
        "date": "05/17/18",
        "direction": "Inbound",
        "fileName": "37",
        "fileSize": 5,
        "status": "Success"
      },
      {
        "transactionId": "27113086",
        "date": "05/27/19",
        "direction": "Outbound",
        "fileName": "35",
        "fileSize": 1,
        "status": "Success"
      },
      {
        "transactionId": "6737984",
        "date": "03/27/19",
        "direction": "Outbound",
        "fileName": "21",
        "fileSize": 4,
        "status": "Failed"
      },
      {
        "transactionId": "23815791",
        "date": "12/08/18",
        "direction": "Inbound",
        "fileName": "13",
        "fileSize": 6,
        "status": "Failed"
      },
      {
        "transactionId": "19142699",
        "date": "01/10/19",
        "direction": "Inbound",
        "fileName": "39",
        "fileSize": 7,
        "status": "Failed"
      },
      {
        "transactionId": "18495798",
        "date": "02/13/18",
        "direction": "Outbound",
        "fileName": "1",
        "fileSize": 4,
        "status": "Failed"
      },
      {
        "transactionId": "50589449",
        "date": "08/17/17",
        "direction": "Inbound",
        "fileName": "37",
        "fileSize": 4,
        "status": "Failed"
      },
      {
        "transactionId": "42543743",
        "date": "02/22/19",
        "direction": "Outbound",
        "fileName": "27",
        "fileSize": 8,
        "status": "Failed"
      },
      {
        "transactionId": "39354884",
        "date": "01/08/18",
        "direction": "Inbound",
        "fileName": "9",
        "fileSize": 9,
        "status": "Failed"
      },
      {
        "transactionId": "20173028",
        "date": "08/23/18",
        "direction": "Outbound",
        "fileName": "3",
        "fileSize": 6,
        "status": "Failed"
      },
      {
        "transactionId": "15091751",
        "date": "02/17/19",
        "direction": "Outbound",
        "fileName": "19",
        "fileSize": 2,
        "status": "Success"
      },
      {
        "transactionId": "15404960",
        "date": "08/16/19",
        "direction": "Inbound",
        "fileName": "25",
        "fileSize": 1,
        "status": "Failed"
      },
      {
        "transactionId": "19619913",
        "date": "07/23/18",
        "direction": "Outbound",
        "fileName": "49",
        "fileSize": 6,
        "status": "Success"
      },
      {
        "transactionId": "43169663",
        "date": "07/05/18",
        "direction": "Outbound",
        "fileName": "15",
        "fileSize": 1,
        "status": "Success"
      }
    ],
    numberOfRecords: 100
  };

  getUserDetails() {
    return this.http.get('userdetails');
  }

  getCustomers() {
    return this.http.get('api/getcustomers');
  }

}
