import { SharedService } from './services/shared.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgHttpLoaderModule } from 'ng-http-loader';
import { NgSelectModule } from '@ng-select/ng-select';
import { ChartsModule } from 'ng2-charts';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SortService } from './components/sortable-table/sort.service';
import { PageFilterService } from './components/page-filter/page-filer.service';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { SidebarNavComponent } from './components/sidebar-nav/sidebar-nav.component';
import { PageHeaderComponent } from './components/page-header/page-header.component';
import { PageFilterComponent } from './components/page-filter/page-filter.component';
import { SortableTableDirective } from './components/sortable-table/sortable-table.directive';
import { SortableColumnComponent } from './components/sortable-table/sortable-column.component';
import { OrderbyPipe } from './pipes/orderby/orderby.pipe';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SummaryComponent } from './components/summary/summary.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarNavComponent,
    PageHeaderComponent,
    PageFilterComponent,
    DashboardComponent,
    SummaryComponent,
    SortableTableDirective,
    SortableColumnComponent,
    OrderbyPipe
  ],
  imports: [
    HttpClientModule,
    NgHttpLoaderModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    NgSelectModule,
    ChartsModule,
    NgbPaginationModule,
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
    BrowserAnimationsModule
  ],
  providers: [
    SharedService,
    SortService,
    PageFilterService,
    OrderbyPipe
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
