# mm-webapp-reporting
A NodeJs app for MM reports.



## webapp components

#### server
* ExpressJS framework
* Passport

#### public




## how to build and run

`npm install`

`bower install`

`gulp` #starts a local dev server

`gulp dist` #creates `dist` folder that is uploaded to cloud on running `cf push`





## todo
* Configure logging
* Production/development configuration



## to explore


