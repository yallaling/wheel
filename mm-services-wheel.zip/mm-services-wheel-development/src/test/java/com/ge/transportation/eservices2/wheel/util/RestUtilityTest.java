package com.ge.transportation.eservices2.wheel.util;

import java.text.ParseException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationRequest;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationResponse;
import com.ge.transportation.eservices2.wheel.config.AppConfig;

@RunWith(MockitoJUnitRunner.class)
public class RestUtilityTest {
	
	@Mock
 	RestTemplate restTemplate;

	@Mock
	AppConfig appConfig;
	
    @InjectMocks
    RestUtility restUtility;
    
    @Mock
	private RestTemplateFactory restTemplateFactory;

    @Before
    public void setUp() throws ParseException, DatatypeConfigurationException {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testRestTemplateExchange() {
    	String json = "{\r\n" + 
    			"  \"locomotiveId\" : \"433657\",\r\n" + 
    			"  \"statusCode\" : \"SUCCESS\"\r\n" + 
    			"}";
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.POST, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNotNull(restUtility.callCorePostService(request, new RoadNumberValidationResponse(), uri, ""));
    }
    
    @SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
    public void testRestTemplateExchangeException() {
    	String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.POST, entity, String.class)).thenThrow(Exception.class);
        Assert.assertNotNull(restUtility.callCorePostService(request, new RoadNumberValidationResponse(), uri, ""));
    }
    
    @Test(expected = Exception.class)
    public void testRestTemplateExchangeIOException() {
    	String json = "{\r\n" + 
    			"  \"locomotiveId\" : \"433657\",\r\n" + 
    			"  \"statusCode\" : \"SUCCESS\"\r\n" + 
    			"}";
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.POST, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNotNull(restUtility.callCorePostService(request, null, uri, ""));
    }
    @Test
    public void testRestTemplateExchangeEmpty() {
    	String json = null;
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.POST, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNull(restUtility.callCorePostService(request, new RoadNumberValidationResponse(), uri, ""));
    }

    
    @Test
    public void testRestTemplateExchangeForGET() {
    	String json = "{\r\n" + 
    			"  \"locomotiveId\" : \"433657\",\r\n" + 
    			"  \"statusCode\" : \"SUCCESS\"\r\n" + 
    			"}";
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNotNull(restUtility.callCoreGetService(request, new RoadNumberValidationResponse(), uri, "", headers));
    }
    
    @SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
    public void testRestTemplateExchangeForGETException() {
    	String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, String.class)).thenThrow(Exception.class);
        Assert.assertNotNull(restUtility.callCoreGetService(request, new RoadNumberValidationResponse(), uri, "", headers));
    }
    
    @Test(expected = Exception.class)
    public void testRestTemplateExchangeForGETIOException() {
    	String json = "{\r\n" + 
    			"  \"locomotiveId\" : \"433657\",\r\n" + 
    			"  \"statusCode\" : \"SUCCESS\"\r\n" + 
    			"}";
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNotNull(restUtility.callCoreGetService(request, null, uri, "", headers));
    }
    @Test
    public void testRestTemplateExchangeForGETEmpty() {
    	String json = null;
    	ResponseEntity<String> responseEntity = new ResponseEntity<String>(json, HttpStatus.OK);
        String uri = "https://test";
        RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
        HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<RoadNumberValidationRequest> entity = new HttpEntity<>(request, headers);
        Mockito.when(appConfig.getUsername()).thenReturn("mm-internal");
        Mockito.when(appConfig.getPassword()).thenReturn("mm-internal");
        Mockito.when(restTemplateFactory.getRestTemplate("mm-internal", "mm-internal")).thenReturn(restTemplate);
        Mockito.when(restTemplate.exchange(uri, HttpMethod.GET, entity, String.class)).thenReturn(responseEntity);
        Assert.assertNull(restUtility.callCoreGetService(request, new RoadNumberValidationResponse(), uri, "", headers));
    }

}
