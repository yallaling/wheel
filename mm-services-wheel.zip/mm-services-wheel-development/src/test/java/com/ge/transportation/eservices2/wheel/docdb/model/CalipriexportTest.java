package com.ge.transportation.eservices2.wheel.docdb.model;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.domainobjects.Calipriexport;
import com.ge.transportation.eservices2.domainobjects.Dimension;
import com.ge.transportation.eservices2.domainobjects.Meta;
import com.ge.transportation.eservices2.domainobjects.Object;
import com.ge.transportation.eservices2.domainobjects.Objects;
import com.ge.transportation.eservices2.domainobjects.Point;
import com.ge.transportation.eservices2.domainobjects.Properties;
import com.ge.transportation.eservices2.domainobjects.Property;
import com.ge.transportation.eservices2.domainobjects.StructureLevel;
import com.ge.transportation.eservices2.domainobjects.StructureLevels;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.serviceimpl.WheelDataInjectServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class CalipriexportTest {

	@Mock
	private AppConfig appConfig;

	@InjectMocks
	private WheelDataInjectServiceImpl wheelDataInjectServiceImpl;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		Mockito.when(appConfig.getProcessing()).thenReturn("processing");
		Mockito.when(appConfig.getError()).thenReturn("error");
		Mockito.when(appConfig.getProcessed()).thenReturn("processed");
	}
	
	@Test
	public void parseXmlCalipriExportTest() throws Exception {
		String fileName = "GELoco_20190416_124413_V3_no_RoadNumber.xml";
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
		Calipriexport calipriexport = new Calipriexport();
		calipriexport.setLastmodified(new BigInteger("123"));
		calipriexport.setMeta(new Meta());
		calipriexport.setName("");
		calipriexport.setObjects(new Objects());
		calipriexport.setProperties(new Properties());
		calipriexport.setRating(new BigInteger("0"));
		calipriexport.setStructureLevels(new StructureLevels());
		calipriexport.setVersion(new BigDecimal(0.0));
		calipriexport = wheelDataInjectServiceImpl.parseXmlFile(inputStream, inputStream,  fileName, null, null);
		assertNotNull(calipriexport);
		assertNotNull(calipriexport.getLastmodified());
		assertNotNull(calipriexport.getMeta());
		assertNotNull(calipriexport.getName());
		assertNotNull(calipriexport.getObjects());
		assertNotNull(calipriexport.getProperties());
		assertNotNull(calipriexport.getRating());
		assertNotNull(calipriexport.getStructureLevels());
		assertNotNull(calipriexport.getVersion());
	}

	@Test
	public void parseXmlTest() throws Exception {
		String fileName = "GELoco_20190416_124413_V3_no_RoadNumber.xml";
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
		Calipriexport calipriexport = wheelDataInjectServiceImpl.parseXmlFile(inputStream, inputStream,  fileName, null, null);
		assertNotNull(calipriexport.getObjects().getObject());
		Object object = calipriexport.getObjects().getObject().get(0);
		Point point = object.getPoints().getPoint().get(0);
		assertNotNull(point.getMethodId());
		assertNotNull(point.getName());
		assertNotNull(point.getProperties());
		assertNotNull(point.getSensortemperature());
		assertNotNull(point.getStructureLevel());
		assertNotNull(point.isMeasured());
		assertNotNull(point.getDimensions());
		Dimension dimension = point.getDimensions().getDimension().get(0);
		assertNotNull(dimension.getClassification());
		assertNotNull(dimension.getId());
		assertNotNull(dimension.getName());
		assertNotNull(dimension.getNominalValue());
		assertNotNull(dimension.getUnit());
		assertNotNull(dimension.getValue());
		assertNotNull(dimension.isManualInput());

	}

	@Test
	public void parseXmlPropertyNotNullTest() throws Exception {
		String fileName = "GELoco_20190416_124413_V3_no_RoadNumber.xml";
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
		Calipriexport calipriexport = wheelDataInjectServiceImpl.parseXmlFile(inputStream, inputStream,  fileName, null, null);
		assertNotNull(calipriexport.getProperties().getProperty());
	}

	@Test
	public void parseXmlPropertesTest() throws Exception {
		String fileName = "GELoco_20190416_124413_V3_no_RoadNumber.xml";
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
		Calipriexport calipriexport = wheelDataInjectServiceImpl.parseXmlFile(inputStream, inputStream,  fileName, null, null);
		List<Property> properties = calipriexport.getProperties().getProperty();
		StructureLevel structureLevel = calipriexport.getStructureLevels().getStructureLevel().get(0);
		assertNotNull(properties);
		Property property = properties.get(0);
		assertNotNull(calipriexport.getStructureLevels().getStructureLevel());
		assertNotNull(property.getId());
		assertNotNull(property.getLabelText());
		assertNull(property.getStructureLevel());
		assertNotNull(property.getType());
		assertNotNull(property.getValue());
		assertNotNull(calipriexport.getObjects().getObject());
		assertNotNull(structureLevel.getId());
		assertNotNull(structureLevel.getLabelText());
		assertNotNull(structureLevel.getType());
		assertNotNull(structureLevel.getStructureLevel());
	}
	
	@Test
	public void parseXmlCalipriexportTest() throws Exception {
		String fileName = "GELoco_20190416_124413_V3_no_RoadNumber.xml";
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
		Calipriexport calipriexport = wheelDataInjectServiceImpl.parseXmlFile(inputStream, inputStream,  fileName, null, null);
		List<Property> properties = calipriexport.getProperties().getProperty();
		StructureLevel structureLevel = calipriexport.getStructureLevels().getStructureLevel().get(0);
		assertNotNull(properties);
		Property property = properties.get(0);
		assertNotNull(calipriexport.getStructureLevels().getStructureLevel());
		assertNotNull(property.getId());
		assertNotNull(property.getLabelText());
		assertNull(property.getStructureLevel());
		assertNotNull(property.getType());
		assertNotNull(property.getValue());
		assertNotNull(calipriexport.getObjects().getObject());
		assertNotNull(structureLevel.getId());
		assertNotNull(structureLevel.getLabelText());
		assertNotNull(structureLevel.getType());
		assertNotNull(structureLevel.getStructureLevel());
	}
}
