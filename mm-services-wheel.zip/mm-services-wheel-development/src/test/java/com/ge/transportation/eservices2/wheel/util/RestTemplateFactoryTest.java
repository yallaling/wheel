/**
 * 
 */
package com.ge.transportation.eservices2.wheel.util;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;


@RunWith(MockitoJUnitRunner.class)
public class RestTemplateFactoryTest {
	
	@InjectMocks
	RestTemplateFactory restTemplateFactory = new RestTemplateFactory();

	/**
	 * Test method for {@link com.ge.transportation.eservices2.wheel.util.RestTemplateFactory#getRestTemplate(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testGetRestTemplate() throws Exception {
		assertNotNull(restTemplateFactory.getRestTemplate("test", "test"));
	}

}
