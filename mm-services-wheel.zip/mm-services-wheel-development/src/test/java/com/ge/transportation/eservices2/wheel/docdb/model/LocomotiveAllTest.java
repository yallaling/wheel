package com.ge.transportation.eservices2.wheel.docdb.model;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class LocomotiveAllTest {

	@InjectMocks
	LocomotiveAll locomotiveAll;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void saveMetaDataTest() {
		assertNull(locomotiveAll.getAarNumber());
		assertNull(locomotiveAll.getAarRoad());
		assertNull(locomotiveAll.getLocomotiveId());
		assertNull(locomotiveAll.getLocomotiveStatusCode());
		assertNull(locomotiveAll.getCustomerId());
	}

}
