package com.ge.transportation.eservices2.wheel.docdb.model;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;

@RunWith(MockitoJUnitRunner.class)
public class WheelFileDetailTest {

	@InjectMocks
	WheelFileDetail wheelFileDetail;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		wheelFileDetail.setId("12345");
		wheelFileDetail.setFileName("abc.txt");
		wheelFileDetail.setLocomotiveId(1058l);
		wheelFileDetail.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setFileCreationDate("");
		wheelFileDetail.setLastUpdatedDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setStatus(FileStatus.VALID);
	}

	@Test
	public void saveMetaDataTest() {
		assertNotNull(wheelFileDetail.getId());
		assertNotNull(wheelFileDetail.getLocomotiveId());
		assertNotNull(wheelFileDetail.getFileName());
		assertNotNull(wheelFileDetail.getCreationDate());
		assertNotNull(wheelFileDetail.getFileCreationDate());
		assertNotNull(wheelFileDetail.getLastUpdatedDate());
		assertNotNull(wheelFileDetail.getStatus().value());
		
	}
	
}
