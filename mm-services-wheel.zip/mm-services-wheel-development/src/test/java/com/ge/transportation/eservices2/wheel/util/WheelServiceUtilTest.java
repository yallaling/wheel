package com.ge.transportation.eservices2.wheel.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.wheel.exception.WheelsException;

@RunWith(MockitoJUnitRunner.class)
public class WheelServiceUtilTest {

	@InjectMocks
	WheelServiceUtil wheelServiceUtil;
	
	@Test(expected = WheelsException.class)
	public void testConvertEmptyDateToString() {
		assertEquals("Date is Empty", WheelServiceUtil.convertDateToString(null));
	}
	
}
