package com.ge.transportation.eservices2.wheel.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.domainobjects.DeleteParamRequest;
import com.ge.transportation.eservices2.domainobjects.DeleteParamResponse;
import com.ge.transportation.eservices2.domainobjects.GetLmsEmployeeResponse;
import com.ge.transportation.eservices2.domainobjects.GetsLMSUser;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryRequest;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParamResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimits;
import com.ge.transportation.eservices2.domainobjects.WheelParams;
import com.ge.transportation.eservices2.domainobjects.WheelparamLimits;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.docdb.model.ParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamKey;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParameters;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelParamLimitsRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamRepository;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;

@RunWith(MockitoJUnitRunner.class)
public class AdminServiceImplTest {

	@Mock
	WheelPersistanceService wheelPersistanceService;

	@Mock
	WheelParamRepository wheelParamRepo;
	
	@Mock
	WheelParamLimitsRepository wheelParamLimitsRepo;

	@Mock
	WheelServiceValidator wheelServiceValidator;

	@InjectMocks
	AdminServiceImpl adminServiceImpl;
	
	@Mock
	AppConfig appConfig;
	@Mock
	RestUtility restUtility;


	WheelConfigRequest wheelConfigRequest;
	WheelParamLimits wheelParamLimit;
	WheelParamLimits wheelParamLimit2;
	LimitHistoryRequest limitHistoryRequest;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		setWheelConfigRequest();
		setWheelParamLimits();
		setWheelParamLimits2();
		setLimitHistoryRequest();
		Mockito.when(appConfig.getBaseUrl()).thenReturn("https://eservices-dev-api.cloud.trans.ge.com");
		Mockito.when(appConfig.getUserProfileUrl()).thenReturn("/common/userProfile/getMultipleUsers");
	}

	@Test
	public void testPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setAarRoad("KTZ");
		wheelParamLimits.setCustomerId(1058L);
		wheelParamLimits.getLocoType().addAll(Arrays.asList("D7", "D7"));
		wheelParamLimits.setLowerLimit(1.5);
		wheelParamLimits.setUpperLimit(2.9);
		wheelParamLimits.setWheelParameter("Flange Height");
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		
		WheelParameters wParam = new WheelParameters();
		wParam.setId("1058");
		wParam.setMethodId("WheelProfile");
		wParam.setDimesnionId("Wheel_W");
		wParam.setWheelAdminId("Flange Height");

		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.add(wParam);
		Mockito.when(wheelParamRepo.findByCustomerId(wheelParamLimits.getCustomerId()+"")).thenReturn(wheelsParams);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenReturn(null);
		
		WheelparamLimits wheelLimits = new WheelparamLimits();
		wheelLimits.setId("123");
		Mockito.when(wheelPersistanceService.saveParamLimits(any())).thenReturn(wheelLimits);
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}

	@Test
	public void testNullStatusPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setAarRoad("KTZ");
		wheelParamLimits.setCustomerId(1058L);
		wheelParamLimits.getLocoType().addAll(Arrays.asList("D7"));
		wheelParamLimits.setLowerLimit(1.5);
		wheelParamLimits.setUpperLimit(2.9);
		wheelParamLimits.setWheelParameter("Flange Height");
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		StatusType statusType = null;
		
		WheelParameters wParam = new WheelParameters();
		wParam.setId("1058");
		wParam.setMethodId("WheelProfile");
		wParam.setDimesnionId("Wheel_W");
		wParam.setWheelAdminId("Flange Height");

		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.add(wParam);
		Mockito.when(wheelParamRepo.findByCustomerId(wheelParamLimits.getCustomerId()+"")).thenReturn(wheelsParams);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenReturn(statusType);
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testInvalidStatusPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenThrow(Exception.class);
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}
	@Test
	public void testStatusPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenReturn(new StatusType());
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}

	
	@Test
	public void testEmptyLocoPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setAarRoad("KTZ");
		wheelParamLimits.setCustomerId(1058L);
		wheelParamLimits.setLowerLimit(1.5);
		wheelParamLimits.setUpperLimit(2.9);
		wheelParamLimits.setWheelParameter("Flange Height");
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		WheelParameters wParam = new WheelParameters();
		wParam.setId("1058");
		wParam.setMethodId("WheelProfile");
		wParam.setDimesnionId("Wheel_W");
		wParam.setWheelAdminId("Flange Height");

		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.add(wParam);
		Mockito.when(wheelParamRepo.findByCustomerId(wheelParamLimits.getCustomerId()+"")).thenReturn(wheelsParams);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenReturn(null);
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}

	@Test
	public void testInvalidparamPersistWheelParameterLimits() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setAarRoad("KTZ");
		wheelParamLimits.setCustomerId(1058L);
		wheelParamLimits.setLowerLimit(1.5);
		wheelParamLimits.setUpperLimit(2.9);
		wheelParamLimits.setWheelParameter("invalid");
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		WheelParameters wParam = new WheelParameters();
		wParam.setId("1058");
		wParam.setMethodId("WheelProfile");
		wParam.setDimesnionId("Wheel_W");
		wParam.setWheelAdminId("Flange Height");

		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.add(wParam);
		Mockito.when(wheelParamRepo.findByCustomerId(wheelParamLimits.getCustomerId()+"")).thenReturn(wheelsParams);
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"))
				.thenReturn(null);
		assertNotNull(adminServiceImpl.persistWheelParameterLimits(wheelParameterLimitsRequest, "123"));
	}
	
	@Test
	public void testUpdateWheelParamLimits() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		WheelParamLimits paramColleLimits = new WheelParamLimits();
		paramColleLimits.setWheelParamKey(wheelParamKey);
		paramColleLimits.getParamLimits().add(paramLimits);
		Mockito.when(wheelPersistanceService.findByWheelParamKey(wheelParamKey)).thenReturn(paramColleLimits);
		Mockito.when(wheelPersistanceService.saveParamLimits(paramColleLimits)).thenReturn(new WheelparamLimits());
		assertNotNull(adminServiceImpl.updateWheelParamLimits(wheelParamKey, paramLimits, "123"));
	}
	
	@Test
	public void testDeleteUpdateWheelParamLimits() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		wheelParamKey.setDelete(true);
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		WheelParamLimits paramColleLimits = new WheelParamLimits();
		paramColleLimits.setWheelParamKey(wheelParamKey);
		paramColleLimits.getParamLimits().add(paramLimits);
		Mockito.when(wheelPersistanceService.findByWheelParamKey(wheelParamKey)).thenReturn(paramColleLimits);
		Mockito.when(wheelPersistanceService.saveParamLimits(paramColleLimits)).thenReturn(new WheelparamLimits());
		assertNotNull(adminServiceImpl.updateWheelParamLimits(wheelParamKey, paramLimits, "123"));
	}

	@Test(expected = WheelsException.class)
	public void testExceptionUpdateWheelParamLimits() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		WheelParamLimits paramColleLimits = new WheelParamLimits();
		Mockito.when(wheelPersistanceService.findByWheelParamKey(wheelParamKey)).thenReturn(paramColleLimits);
		Mockito.when(wheelPersistanceService.saveParamLimits(paramColleLimits)).thenReturn(new WheelparamLimits());
		assertNotNull(adminServiceImpl.updateWheelParamLimits(wheelParamKey, paramLimits, "123"));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testExceptionNullUpdateWheelParamLimits() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		Mockito.when(wheelPersistanceService.findByWheelParamKey(wheelParamKey)).thenReturn(null);
		Mockito.when(wheelPersistanceService.saveParamLimits(any())).thenThrow(Exception.class);
		assertNotNull(adminServiceImpl.updateWheelParamLimits(wheelParamKey, paramLimits, "123"));
	}
	
	@SuppressWarnings("unchecked")
	@Test(expected = Exception.class)
	public void testExceptionNotNullUpdateWheelParamLimits() {
		WheelParamLimits wheelParamLimits = new WheelParamLimits();
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		wheelParamLimits.setWheelParamKey(wheelParamKey);
		wheelParamLimits.setParamLimits(Arrays.asList(paramLimits));
		Mockito.when(wheelPersistanceService.findByWheelParamKey(wheelParamKey)).thenReturn(wheelParamLimits);
		Mockito.when(wheelPersistanceService.saveParamLimits(any())).thenThrow(Exception.class);
		assertNotNull(adminServiceImpl.updateWheelParamLimits(wheelParamKey, paramLimits, "123"));
	}

	@Test
	public void testWheelParametersWithValidCustomer() {
		WheelParamResponse wheelParamResponse = new WheelParamResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		wheelParamResponse.setStatus(type);

		WheelParameters wParam = new WheelParameters();
		wParam.setId("2313");
		wParam.setMethodId("WheelProfile");
		wParam.setDimesnionId("Wheel_W");
		wParam.setWheelAdminId("Flange Height");

		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.add(wParam);
		wheelsParams.stream().forEach(param -> wheelParamResponse.getWheelParamList().add(mapWheelParam(param)));
		Mockito.when(wheelParamRepo.findByCustomerId("1058")).thenReturn(wheelsParams);
		WheelParamResponse response = adminServiceImpl.getWheelParameters("1058", any());
		assertEquals(wheelParamResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	@Test
	public void testWheelParametersWithInValidCustomer() {
		WheelParamResponse wheelParamResponse = new WheelParamResponse();
		String custId = "1000";
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("No wheel parameters set for customer " + custId);
		wheelParamResponse.setStatus(type);
		List<WheelParameters> wheelsParams = new ArrayList<WheelParameters>();
		wheelsParams.stream().forEach(param -> wheelParamResponse.getWheelParamList().add(mapWheelParam(param)));
		Mockito.when(wheelParamRepo.findByCustomerId(custId)).thenReturn(wheelsParams);
		WheelParamResponse response = adminServiceImpl.getWheelParameters(custId, any());
		assertEquals(wheelParamResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	@Test
	public void testWheelParametersWithNullCustomerList() {
		WheelParamResponse wheelParamResponse = new WheelParamResponse();
		String custId = "1000";
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("No wheel parameters set for customer " + custId);
		wheelParamResponse.setStatus(type);
		List<WheelParameters> wheelsParams = null;
		Mockito.when(wheelParamRepo.findByCustomerId(custId)).thenReturn(wheelsParams);
		WheelParamResponse response = adminServiceImpl.getWheelParameters(custId, any());
		assertEquals(wheelParamResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	private WheelParams mapWheelParam(WheelParameters wheelParam) {
		WheelParams params = new WheelParams();
		params.setMethodId(wheelParam.getMethodId());
		params.setDimensionId(wheelParam.getDimesnionId());
		params.setWheelAdminId(wheelParam.getWheelAdminId());
		return params;
	}

	@Test
	public void testDeleteWheelParamEmpty() throws Exception {
		DeleteParamResponse deleteParmResponse = new DeleteParamResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.FAILED);
		deleteParmResponse.setStatusType(statusType);
		DeleteParamRequest deleteParamRequest=new DeleteParamRequest();
		deleteParamRequest.setAarRoad("KTZ");
		deleteParamRequest.setCustomerId(1058);
		deleteParamRequest.setWheelParameter("Fl");
		deleteParamRequest.getLocoType().add("D8");
		List<WheelParamLimits> paramLimitsList=new ArrayList<>();
		WheelParamLimits wheelParamLimits=new WheelParamLimits();
		WheelParamKey wheelParamKey=new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamLimits.setWheelParamKey(wheelParamKey);
		paramLimitsList.add(wheelParamLimits);
		Mockito.when(wheelParamLimitsRepo.
				findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoTypeIn
				(any(),any(),any(),any())).thenReturn(paramLimitsList);
	    DeleteParamResponse resp = new DeleteParamResponse();
		resp=adminServiceImpl.deleteWheelParam(deleteParamRequest, "123");
		Mockito.when(wheelServiceValidator.validateRequestParams(deleteParamRequest, "123"))
		.thenReturn(statusType);
		
        assertNotNull(adminServiceImpl.deleteWheelParam(deleteParamRequest, "123")); 
        assertEquals(resp.getStatusType().getStatusCode(), deleteParmResponse.getStatusType().getStatusCode());
		
	}
	
	@Test
	public void testDeleteWheeelParamSuccess() throws Exception {
		DeleteParamResponse deleteParmResponse = new DeleteParamResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		deleteParmResponse.setStatusType(statusType);
		DeleteParamRequest deleteParamRequest=new DeleteParamRequest();
		deleteParamRequest.setAarRoad("KTZ");
		deleteParamRequest.setCustomerId(1058);
		deleteParamRequest.setWheelParameter("Fl");
		deleteParamRequest.getLocoType().add("D8");
		List<WheelParamLimits> paramLimitsList=new ArrayList<>();
		WheelParamLimits wheelParamLimits=new WheelParamLimits();
		WheelParamKey wheelParamKey=new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamLimits.setWheelParamKey(wheelParamKey);
		paramLimitsList.add(wheelParamLimits);
		
		List<WheelparamLimits> wheelList=new ArrayList<>();
		WheelparamLimits wheelparam=new WheelparamLimits();
		wheelparam.setAarRoad("KTZ");
		wheelList.add(wheelparam);
		Mockito.when(wheelParamLimitsRepo.
				findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoTypeIn
				(any(),any(),any(),any())).thenReturn(paramLimitsList);
		Mockito.when(wheelPersistanceService.saveParamLimitsList(any())).thenReturn(wheelList);
	    DeleteParamResponse resp = new DeleteParamResponse();
		resp=adminServiceImpl.deleteWheelParam(deleteParamRequest, "123");
		Mockito.when(wheelServiceValidator.validateRequestParams(deleteParamRequest, "123"))
		.thenReturn(statusType);
		
        assertNotNull(adminServiceImpl.deleteWheelParam(deleteParamRequest, "123")); 
        assertEquals(resp.getStatusType().getStatusCode(), deleteParmResponse.getStatusType().getStatusCode());
		
	}
	
	@Test
	public void testDeleteWheeelParamWithDeleteFlagAlreadyTrue() throws Exception {
		DeleteParamResponse deleteParmResponse = new DeleteParamResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		deleteParmResponse.setStatusType(statusType);
		DeleteParamRequest deleteParamRequest=new DeleteParamRequest();
		deleteParamRequest.setAarRoad("KTZ");
		deleteParamRequest.setCustomerId(1058);
		deleteParamRequest.setWheelParameter("Fl");
		deleteParamRequest.getLocoType().add("D8");
		List<WheelParamLimits> paramLimitsList=new ArrayList<>();
		WheelParamLimits wheelParamLimits=new WheelParamLimits();
		WheelParamKey wheelParamKey=new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setDelete(true);
		wheelParamLimits.setWheelParamKey(wheelParamKey);
		paramLimitsList.add(wheelParamLimits);
		Mockito.when(wheelParamLimitsRepo.
				findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoTypeIn
				(any(),any(),any(),any())).thenReturn(paramLimitsList);
	    DeleteParamResponse resp = new DeleteParamResponse();
		resp=adminServiceImpl.deleteWheelParam(deleteParamRequest, "123");
		Mockito.when(wheelServiceValidator.validateRequestParams(deleteParamRequest, "123"))
		.thenReturn(statusType);
		
        assertNotNull(adminServiceImpl.deleteWheelParam(deleteParamRequest, "123")); 
        assertEquals(resp.getStatusType().getStatusCode(), deleteParmResponse.getStatusType().getStatusCode());
		
	}
	



@SuppressWarnings("unchecked")
@Test
public void testExceptionDeleteWheeelParam() throws Exception {
	Mockito.when(wheelServiceValidator.validateRequestParams(any(), any())).thenThrow(WheelsException.class);
	assertNotNull(adminServiceImpl.deleteWheelParam(new DeleteParamRequest(), "123"));
}

	@Test
	public void testGetAdminConfigforMultiLocoMatch() {
		WheelConfigResponse wheelConfigResponse = new WheelConfigResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("OK");
		wheelConfigResponse.setStatus(type);
		List<WheelParamLimits> wParamLimits = new ArrayList<WheelParamLimits>();
		wParamLimits.add(wheelParamLimit);
		wParamLimits.add(wheelParamLimit2);
		Mockito.when(wheelParamLimitsRepo
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(
						1058L, "KTZ", false, wheelConfigRequest.getLocoType()))
				.thenReturn(wParamLimits);
		WheelConfigResponse response = adminServiceImpl.getAdminConfiguration(wheelConfigRequest, "758");
		assertEquals(wheelConfigResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	private WheelParamLimits setWheelParamLimits2() {
		wheelParamLimit2 = new WheelParamLimits();
		WheelParamKey wheelParamKey2 = new WheelParamKey();
		wheelParamKey2.setAarRoad("KTZ");
		wheelParamKey2.setCustomerId(1058L);
		wheelParamKey2.setLocoType("D8");
		wheelParamKey2.setWheelParameter("Flange Height");
		wheelParamKey2.setDelete(false);
		ParamLimits paramLimits2 = new ParamLimits();
		paramLimits2.setLowerLimit(1.5);
		paramLimits2.setUpperLimit(2.9);
		paramLimits2.setDelete(false);
		wheelParamLimit2.setWheelParamKey(wheelParamKey2);
		wheelParamLimit2.getParamLimits().add(paramLimits2);
		return wheelParamLimit2;
	}

	private WheelParamLimits setWheelParamLimits() {
		wheelParamLimit = new WheelParamLimits();
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		wheelParamKey.setDelete(false);
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		paramLimits.setDelete(false);
		paramLimits.setLastUpdateDate("12/03/2005");
		paramLimits.setLastUpdatedBy("503085");
		wheelParamLimit.setWheelParamKey(wheelParamKey);
		wheelParamLimit.getParamLimits().add(paramLimits);
		return wheelParamLimit;
	}

	private WheelConfigRequest setWheelConfigRequest() {
		wheelConfigRequest = new WheelConfigRequest();
		wheelConfigRequest.setCustId(1058);
		wheelConfigRequest.setAarRoad("KTZ");
		wheelConfigRequest.getLocoType().add("D7");
		wheelConfigRequest.getLocoType().add("D8");
		return wheelConfigRequest;
	}

	@Test
	public void testGetAdminConfigforUnmatchLimits() {
		WheelConfigResponse wheelConfigResponse = new WheelConfigResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("OK");
		wheelConfigResponse.setStatus(type);
		List<WheelParamLimits> wParamLimits = new ArrayList<WheelParamLimits>();
		wParamLimits.add(wheelParamLimit);
		WheelParamLimits wheelParamLimit2 = new WheelParamLimits();
		WheelParamKey wheelParamKey2 = new WheelParamKey();
		wheelParamKey2.setAarRoad("KTZ");
		wheelParamKey2.setCustomerId(1058L);
		wheelParamKey2.setLocoType("D8");
		wheelParamKey2.setWheelParameter("Flange Height");
		wheelParamKey2.setDelete(false);
		ParamLimits paramLimits2 = new ParamLimits();
		paramLimits2.setLowerLimit(1.9);
		paramLimits2.setUpperLimit(2.9);
		paramLimits2.setDelete(false);
		wheelParamLimit2.setWheelParamKey(wheelParamKey2);
		wheelParamLimit2.getParamLimits().add(paramLimits2);
		wParamLimits.add(wheelParamLimit2);
		Mockito.when(wheelParamLimitsRepo
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(
						1058L, "KTZ", false, wheelConfigRequest.getLocoType()))
				.thenReturn(wParamLimits);
		WheelConfigResponse response = adminServiceImpl.getAdminConfiguration(wheelConfigRequest, "758");
		assertEquals(wheelConfigResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	@Test
	public void testGetAdminConfigforMultiLocoUnmatch() {
		WheelConfigResponse wheelConfigResponse = new WheelConfigResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("OK");
		wheelConfigResponse.setStatus(type);
		List<WheelParamLimits> wParamLimits = new ArrayList<WheelParamLimits>();
		wParamLimits.add(wheelParamLimit);
		WheelParamLimits wheelParamLimit2 = new WheelParamLimits();
		WheelParamKey wheelParamKey2 = new WheelParamKey();
		wheelParamKey2.setAarRoad("KTZ");
		wheelParamKey2.setCustomerId(1058L);
		wheelParamKey2.setLocoType("D8");
		wheelParamKey2.setWheelParameter("Flange width");
		wheelParamKey2.setDelete(false);
		ParamLimits paramLimits2 = new ParamLimits();
		paramLimits2.setLowerLimit(1.5);
		paramLimits2.setUpperLimit(2.9);
		paramLimits2.setDelete(false);
		wheelParamLimit2.setWheelParamKey(wheelParamKey2);
		wheelParamLimit2.getParamLimits().add(paramLimits2);
		wParamLimits.add(wheelParamLimit2);
		Mockito.when(wheelParamLimitsRepo
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(
						1058L, "KTZ", false, wheelConfigRequest.getLocoType()))
				.thenReturn(wParamLimits);
		WheelConfigResponse response = adminServiceImpl.getAdminConfiguration(wheelConfigRequest, "758");
		assertEquals(wheelConfigResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}

	@Test
	public void testGetAdminConfigforSigleLoco() {
		WheelConfigResponse wheelConfigResponse = new WheelConfigResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("OK");
		wheelConfigResponse.setStatus(type);
		WheelConfigRequest wheelConfigRequest = new WheelConfigRequest();
		wheelConfigRequest.setCustId(1058);
		wheelConfigRequest.setAarRoad("KTZ");
		wheelConfigRequest.getLocoType().add("D7");
		List<WheelParamLimits> wheelParamLimits = new ArrayList<WheelParamLimits>();
		wheelParamLimits.add(wheelParamLimit);
		Mockito.when(wheelParamLimitsRepo
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(
						1058L, "KTZ", false, wheelConfigRequest.getLocoType()))
				.thenReturn(wheelParamLimits);
		WheelConfigResponse response = adminServiceImpl.getAdminConfiguration(wheelConfigRequest, "758");
		assertEquals(wheelConfigResponse.getStatus().getStatusCode(), response.getStatus().getStatusCode());
	}
	
	@Test
	public void testGetParamHistory() {
		LimitHistoryResponse limitHistoryResponse = new LimitHistoryResponse();
		StatusType type = new StatusType();
		type.setStatusCode(StatusCode.SUCCESS);
		type.setMessage("OK");
		limitHistoryResponse.setStatus(type);
		List<WheelParamLimits> wheelParamLimits = new ArrayList<WheelParamLimits>();
		wheelParamLimits.add(wheelParamLimit);
		Mockito.when(wheelParamLimitsRepo
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadInAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeInAndWheelParamKeyWheelParameter(
						1058L,limitHistoryRequest.getAarRoad(), false, limitHistoryRequest.getLocoType(),limitHistoryRequest.getWheelParam()))
				.thenReturn(wheelParamLimits);
		GetLmsEmployeeResponse resp = new GetLmsEmployeeResponse();
		GetsLMSUser user = new GetsLMSUser();
		user.setFirstName("Dayni");
		user.setLastName("Mathew");
		user.setUserId("503085");
		resp.getGetsLMSUsers().add(user);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(),
				any())).thenReturn(resp);
		assertNotNull(adminServiceImpl.getParamHistory(limitHistoryRequest, "758"));
		
	}

	private void setLimitHistoryRequest() {
		limitHistoryRequest = new LimitHistoryRequest();
		limitHistoryRequest.setCustId(1058);
		limitHistoryRequest.getAarRoad().add("KTZ");
		limitHistoryRequest.getLocoType().add("D7");
		limitHistoryRequest.setWheelParam("Flange Height");
	}
}
