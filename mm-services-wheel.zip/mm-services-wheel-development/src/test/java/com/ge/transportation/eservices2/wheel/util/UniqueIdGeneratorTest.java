package com.ge.transportation.eservices2.wheel.util;

import static org.junit.Assert.assertNotNull;

import java.text.ParseException;

import javax.xml.datatype.DatatypeConfigurationException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UniqueIdGeneratorTest {

	@InjectMocks
	private UniqueIdGenerator uniquIdGenerator;

	@Before
	public void setUp() throws ParseException, DatatypeConfigurationException {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetUUID() {
		assertNotNull(uniquIdGenerator.getUUID());
	}


}
