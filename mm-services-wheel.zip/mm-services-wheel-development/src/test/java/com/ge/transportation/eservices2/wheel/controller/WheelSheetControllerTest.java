package com.ge.transportation.eservices2.wheel.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ge.transportation.eservices2.domainobjects.ShimDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.VisibleDefectsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWOResponse;
import com.ge.transportation.eservices2.wheel.serviceimpl.WheelSheetServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class WheelSheetControllerTest {

	@Mock
	WheelSheetServiceImpl wheelSheetService;

	@InjectMocks
	WheelSheetController wheelSheetController;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(wheelSheetController).build();
	}

	@Test
	public void testLoadMeasurements() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/wheelsheet/measurements")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n"
						+ "\"fileName\": \"GELoco_20190416_124413_V3.xml,\",\r\n" + "\"customerName\": \"IR\"\r\n" + "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}
	
	@Test
	public void testFetchFileDetails() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/wheelsheet/filedetails")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n" + 
						"  \"locomotiveId\": 0\r\n" + 
						"}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}
	
	@Test
	public void testFetchShimDetails() {
		ShimDetailsResponse shimDetailsResponse=new ShimDetailsResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		shimDetailsResponse.setStatus(statusType);
		Mockito.when(wheelSheetService.retrieveShimDetails(any())).thenReturn(shimDetailsResponse);
		ShimDetailsResponse actualResponse=wheelSheetController.fetchShimDetails();
		assertEquals(shimDetailsResponse.getStatus().getStatusCode(), actualResponse.getStatus().getStatusCode());
	}
	
	@Test
	public void testFetchVisibleDefectsDetails() {
		VisibleDefectsResponse visibleDefectsResponse=new VisibleDefectsResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		visibleDefectsResponse.setStatus(statusType);
		Mockito.when(wheelSheetService.retrieveVisDefectsDetails(any())).thenReturn(visibleDefectsResponse);
		VisibleDefectsResponse actualResponse=wheelSheetController.fetchVisibleDefectsDetails();
		assertEquals(visibleDefectsResponse.getStatus().getStatusCode(), actualResponse.getStatus().getStatusCode());
	}

	@Test
	public void testGetWheelSheetDetails() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/wheelsheet/getwheelsheetsforwo")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n"
						+ "\"aarRoad\": \"IR,\",\r\n" + "\"roadNumber\": \"1058\",\r\n" + "\"workOrderId\": \"1058\"\r\n"+ "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}

	@Test
	public void testGetWheelSheet() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1//wheelsheet/getwheelsheetdataforwo")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n"
						+ "\"aarRoad\": \"IR,\",\r\n" + "\"roadNumber\": \"1058\",\r\n" + "\"wheelSheetID\": \"d-1058\"\r\n"+ "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}
	
	
	@Test
	public void testFetchPastWheelSheetDetails() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1//wheelsheet/pastwheelsheet")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n"
						+ "\"aarRoad\": \"IR,\",\r\n" + "\"roadNumber\": \"1058\",\r\n" + "\"wheelSheetID\": \"d-1058\"\r\n"+ "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}
	
	
	@Test
	public void testValidateWheelSheetName() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/wheelsheet/validateandsavewheelsheetname")
				.contentType(MediaType.APPLICATION_JSON).content("{\r\n"
						+ "\"aarRoad\": \"IR,\",\r\n" + "\"roadNumber\": \"1058\",\r\n" + "\"wheelSheetID\": \"d-1058\""
								+ ",\r\n"+"\"wheelSheetName\": \"Wheel Sheet - Inbound\",\r\n" + "\"workorderId\": \"2581190\"\r\n"+ "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();

		assertNotNull(result.getResponse().getContentAsString());
	}
	
}
