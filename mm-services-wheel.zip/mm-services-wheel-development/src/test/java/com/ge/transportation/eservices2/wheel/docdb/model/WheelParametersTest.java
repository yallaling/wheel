package com.ge.transportation.eservices2.wheel.docdb.model;

import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;

@RunWith(MockitoJUnitRunner.class)
public class WheelParametersTest {

	@InjectMocks
	WheelParameters wheelParameters;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		wheelParameters.setId("12345");
		wheelParameters.setCreatedBy("5030");
		wheelParameters.setLastUpdatedBy("5030");
		wheelParameters.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelParameters.setCustomerId("2015");
		wheelParameters.setDimesnionId("abc");
		wheelParameters.setMeasuredAxleL("Y");
		wheelParameters.setMeasuredBogieL("Y");
		wheelParameters.setMeasuredLocoL("Y");
		wheelParameters.setMeasuredWheelL("N");
		wheelParameters.setLastUpdatedDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelParameters.setMethodId("flange Height");
		wheelParameters.setWheelAdminId("flange Heigt");
	}

	@Test
	public void saveMetaDataTest() {
		assertNotNull(wheelParameters.getId());
		assertNotNull(wheelParameters.getClass());
		assertNotNull(wheelParameters.getCreatedBy());
		assertNotNull(wheelParameters.getCreationDate());
		assertNotNull(wheelParameters.getCustomerId());
		assertNotNull(wheelParameters.getLastUpdatedDate());
		assertNotNull(wheelParameters.getDimesnionId());
		assertNotNull(wheelParameters.getLastUpdatedBy());
		assertNotNull(wheelParameters.getMeasuredAxleL());
		assertNotNull(wheelParameters.getMeasuredBogieL());
		assertNotNull(wheelParameters.getMeasuredLocoL());
		assertNotNull(wheelParameters.getMeasuredWheelL());
		assertNotNull(wheelParameters.getMethodId());
		assertNotNull(wheelParameters.getWheelAdminId());

	}

}
