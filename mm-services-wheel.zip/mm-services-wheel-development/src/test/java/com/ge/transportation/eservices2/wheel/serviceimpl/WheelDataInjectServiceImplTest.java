package com.ge.transportation.eservices2.wheel.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.UploadFileResponse;
import com.ge.transportation.eservices2.domainobjects.Workorder;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailResponse;
import com.ge.transportation.eservices2.wheel.awss3.service.AWSFileHandlerService;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.util.UniqueIdGenerator;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;

@RunWith(MockitoJUnitRunner.class)
public class WheelDataInjectServiceImplTest {

	@Mock
	private AppConfig appConfig;

	@Mock
	WheelFileDetailRepository wheelRepository;

	@Mock
	private AWSFileHandlerService awsFileHandlerService;
	@Mock
	WheelServiceValidator wheelServiceValidator;

	@Mock
	private RestUtility restUtility;

	@InjectMocks
	private WheelDataInjectServiceImpl wheelDataInjectServiceImpl;

	@Mock
	private WheelPersistanceServiceImpl wheelPersistanceService;

	RoadNumberValidationResponse roadNumberValidationResponse = null;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		Mockito.when(appConfig.getProcessing()).thenReturn("processing");
		Mockito.when(appConfig.getError()).thenReturn("error");
		Mockito.when(appConfig.getProcessed()).thenReturn("processed");
		Mockito.when(appConfig.getUnProcessed()).thenReturn("unprocessed");
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");
		setRoadNumberValiResp();
	}

	private RoadNumberValidationResponse setRoadNumberValiResp() {
		roadNumberValidationResponse = new RoadNumberValidationResponse();
		roadNumberValidationResponse.setCustomerId(1123L);
		roadNumberValidationResponse.setLocomotiveId("6366");
		roadNumberValidationResponse.setStatusCode(StatusCode.SUCCESS);
		return roadNumberValidationResponse;
	}

	@Test
	public void testMoveCustomerFile() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(wheelServiceValidator.validateRequestParams(any(), any())).thenReturn(null);
		assertNotNull(wheelDataInjectServiceImpl.moveCustomerFile(new MoveFileRequest(), uuId));
	}

	@Test
	public void testInvalidMoveCustomerFile() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(wheelServiceValidator.validateRequestParams(any(), any())).thenReturn(new StatusType());
		assertNotNull(wheelDataInjectServiceImpl.moveCustomerFile(new MoveFileRequest(), uuId));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testExceptionMoveCustomerFile() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(wheelServiceValidator.validateRequestParams(any(), any())).thenThrow(Exception.class);
		assertNotNull(wheelDataInjectServiceImpl.moveCustomerFile(new MoveFileRequest(), uuId));
	}

	@Test
	public void moveFileProcessingToErrorTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "processing";
		String to = "error";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "processing", "error", uuId));
	}

	@Test
	public void moveFileUnProcessingToprocessingTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "unprocessed";
		String to = "processing";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", from, to, uuId));
	}
	
	@Test
	public void moveFileProcessingToUnprocessingTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "processing";
		String to = "unprocessed";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", from, to, uuId));
	}

	@Test
	public void moveFileTestToInvalidTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "test";
		String to = "invalid";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", from, to, uuId));
	}

	
	@Test
	public void moveFileErrorToProcessedTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "error";
		String to = "processed";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "error", "processed", uuId));
	}

	@Test
	public void moveFileProcessedToProcessingTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");
		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "processed";
		String to = "processing";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "processed", "processing", uuId));
	}
	
	@Test
	public void moveFileProcessingToProcessedTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");
		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		String from = "processing";
		String to = "processed";
		assertEquals("File Successfully moved from: " + from + ", to: " + to,
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", from, to, uuId));
	}

	@Test
	public void moveFileEmptyTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "", null, uuId));
	}

	@Test
	public void moveFileNULLTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.moveFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", null, "error", uuId));
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "error", null, uuId));
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "", "", uuId));
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "error", "", uuId));
		assertEquals("Failed - folder name should not empty or same ",
				wheelDataInjectServiceImpl.moveFile("GELoco_20190416_124413_V3.xml", "error", "error", uuId));
	}
	
	
	@Test
	public void testListOfFiles() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("wheels/");

		Mockito.when(awsFileHandlerService.listOfFiles(any())).thenReturn(new ArrayList<>());
		assertNotNull(wheelDataInjectServiceImpl.listOfFiles(uuId));
	}

	@Test
	public void uploadFileTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.xml");
		MultipartFile multipartFile = null;
		try {
			multipartFile = new MockMultipartFile("data", "GELoco_20190416_124413_V3_49002.xml",
					MediaType.MULTIPART_FORM_DATA_VALUE, inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void uploadFileForErrorTest() throws IOException {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_error.xml");
		MultipartFile multipartFile = null;
		multipartFile = new MockMultipartFile("data", "GELoco_20190416_124413_V3_error.xml",
				MediaType.MULTIPART_FORM_DATA_VALUE, inputStream);

		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void uploadFileForInvalidFileTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("GELoco_20190416_124413_V3.xml");
		MultipartFile multipartFile = null;
		roadNumberValidationResponse.setStatusCode(StatusCode.FAILED);
		try {
			multipartFile = new MockMultipartFile("data", "GELoco_20190416_124413_V3.xml",
					MediaType.MULTIPART_FORM_DATA_VALUE, inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void uploadFileForInvalidFormatTest() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("wheelDetail.properties");
		MultipartFile multipartFile = null;
		roadNumberValidationResponse.setStatusCode(StatusCode.FAILED);
		try {
			multipartFile = new MockMultipartFile("data", "wheelDetail.properties", MediaType.MULTIPART_FORM_DATA_VALUE,
					inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}

		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void uploadFileForNoRoadNumberFileTest() throws IOException {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_no_RoadNumber.xml");
		MultipartFile multipartFile = null;
		roadNumberValidationResponse.setStatusCode(StatusCode.FAILED);
		multipartFile = new MockMultipartFile("data", "GELoco_20190416_124413_V3_no_RoadNumber.xml",
				MediaType.MULTIPART_FORM_DATA_VALUE, inputStream);
		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void uploadFileForRoadNumberAndAARRoadNullFileTest() throws IOException {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_RoadNumber_AAR_Null.xml");
		MultipartFile multipartFile = null;
		roadNumberValidationResponse.setStatusCode(StatusCode.FAILED);
		multipartFile = new MockMultipartFile("data", "GELoco_20190416_124413_V3_RoadNumber_AAR_Null.xml",
				MediaType.MULTIPART_FORM_DATA_VALUE, inputStream);
		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}
	
	@Test
	public void uploadFileForNullTest() throws IOException {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		roadNumberValidationResponse.setStatusCode(StatusCode.FAILED);
		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, null));

	}
	
	@Test
	public void uploadFileForStreamNullTest() throws IOException {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		InputStream inputStream = null;
		MultipartFile multipartFile = new MockMultipartFile("hi.txt", inputStream);
		UploadFileResponse response = new UploadFileResponse();
		response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Success"));
		Mockito.when(restUtility.callCorePostService(Mockito.any(), Mockito.any(), Mockito.any(), any()))
				.thenReturn(roadNumberValidationResponse);
		assertNotNull(wheelDataInjectServiceImpl.uploadFile(uuId, multipartFile));

	}

	@Test
	public void moveUnprocessedFilesFailureTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(new StatusType());

		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	@Test
	public void moveUnprocessedFilesFailureForInvalidTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(null);
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("Closed");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.FAILED);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	@SuppressWarnings("unchecked")
	@Test
	public void moveUnprocessedFilesFailureForExceptionTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(null);
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("Closed");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.FAILED);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		Mockito.when(awsFileHandlerService.moveFile(any(), any(), any())).thenThrow(Exception.class);
		Mockito.when(appConfig.getUnProcessed()).thenThrow(Exception.class);
		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	@Test
	public void moveUnprocessedFilesFailureForNotClosedTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();

		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(null);
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("open");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.SUCCESS);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	@Test
	public void moveUnprocessedFilesSuccessTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("Closed");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.SUCCESS);

		List<WheelFileDetail> wheelFileDetails = new ArrayList<>();
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setFileName("abc.xml");
		wheelFileDetail.setStatus(FileStatus.VALID);
		wheelFileDetails.add(wheelFileDetail);
		Mockito.when(wheelRepository.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(), any()))
				.thenReturn(wheelFileDetails);
		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(null);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	@SuppressWarnings("unchecked")
	@Test
	public void moveUnprocessedFilesExceptioWhileMoveTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("Closed");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.SUCCESS);

		List<WheelFileDetail> wheelFileDetails = new ArrayList<>();
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setFileName("abc.xml");
		wheelFileDetail.setStatus(FileStatus.VALID);
		wheelFileDetails.add(wheelFileDetail);
		Mockito.when(wheelRepository.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(), any()))
				.thenReturn(wheelFileDetails);
		Mockito.when(wheelServiceValidator.validateRequestParams("123", uuId)).thenReturn(null);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		Mockito.when(awsFileHandlerService.moveFile(any(), any(), any())).thenThrow(Exception.class);
		Mockito.when(appConfig.getUnProcessed()).thenThrow(Exception.class);
		assertNotNull(wheelDataInjectServiceImpl.moveUnprocessedFiles(uuId, "123"));

	}

	
	@Test(expected = WheelsException.class)
	public void getWorkorderAndMoveFilesFailureTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("Closed");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.FAILED);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		wheelDataInjectServiceImpl.getWorkorderAndMoveFiles(uuId, "123");
	}
	
	@Test(expected = WheelsException.class)
	public void getWorkorderAndMoveFilesWorkorderNULLTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		response.setWorkorder(null);
		response.setStatus(StatusCode.SUCCESS);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(response);
		wheelDataInjectServiceImpl.getWorkorderAndMoveFiles(uuId, "123");

	}
	
	@Test(expected = WheelsException.class)
	public void getWorkorderAndMoveFilesTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(null);
		assertNotNull(wheelDataInjectServiceImpl.getWorkorderAndMoveFiles(uuId, "123"));
	}
	
	@Test
	public void checkAndMoveUnprocessedFilesFailureTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("open");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.SUCCESS);
		List<WheelFileDetail> wheelFileDetails = new ArrayList<>();
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setFileName("abc.xml");
		wheelFileDetail.setStatus(FileStatus.VALID);
		wheelFileDetails.add(wheelFileDetail);
		Mockito.when(wheelRepository.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(), any()))
				.thenReturn(wheelFileDetails);
		Mockito.when(awsFileHandlerService.moveFile(any(), any(), any())).thenThrow(new WheelsException("null"));
		assertNotNull(wheelDataInjectServiceImpl.checkAndMoveUnprocessedFiles(uuId, response));
	}
	
	@Test
	public void checkAndMoveUnprocessedFilesTest() throws Exception {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WorkorderDetailResponse response = new WorkorderDetailResponse();
		Workorder workorder = new Workorder();
		workorder.setLocomotiveId(123L);
		workorder.setStatusMeaning("open");
		response.setWorkorder(workorder);
		response.setStatus(StatusCode.SUCCESS);
		List<WheelFileDetail> wheelFileDetails = new ArrayList<>();
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setFileName("abc.xml");
		wheelFileDetail.setStatus(FileStatus.VALID);
		wheelFileDetails.add(wheelFileDetail);
		Mockito.when(wheelRepository.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(), any()))
				.thenReturn(wheelFileDetails);
		Mockito.when(awsFileHandlerService.moveFile(any(), any(), any())).thenThrow(new WheelsException("The specified key does not exist"));
		assertNotNull(wheelDataInjectServiceImpl.checkAndMoveUnprocessedFiles(uuId, response));
	}

}
