package com.ge.transportation.eservices2.wheel.config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class AppConfigTest {

	@InjectMocks
	AppConfig appConfig;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAwsS3Path() {
		assertNull(appConfig.getAwsS3Path());
	}

	@Test
	public void testGetAwsAccessKeyId() {
		assertNull(appConfig.getAwsAccessKeyId());
	}

	@Test
	public void testGetAwsBucketName() {
		assertNull(appConfig.getAwsBucketName());
	}

	@Test
	public void testGetAwsRoleARN() {
		assertNull(appConfig.getAwsRoleARN());
	}

	@Test
	public void testGetAwsSessionName() {
		assertNull(appConfig.getAwsSessionName());
	}

	@Test
	public void testGetAwsEnv() {
		assertNull(appConfig.getAwsEnv());
	}

	@Test
	public void testIsAwsProxyEnabled() {
		assertEquals(false, appConfig.isAwsProxyEnabled());
	}

	@Test
	public void testGetAwsProxyHost() {
		assertNull(appConfig.getAwsProxyHost());
	}

	@Test
	public void testGetBaseUrl() {
		assertNull(appConfig.getBaseUrl());
	}

	@Test
	public void testGetUsername() {
		assertNull(appConfig.getUsername());
	}

	@Test
	public void testGetPassword() {
		assertNull(appConfig.getPassword());
	}

	@Test
	public void testGetWorkorderDetailsUrl() {
		assertNull(appConfig.getWorkorderDetails());
	}
	@Test
	public void testGetRoadnumberValidation() {
		assertNull(appConfig.getRoadnumberValidation());
	}
		
	@Test
	public void testGetError() {
		assertNull(appConfig.getError());
	}

	
}
