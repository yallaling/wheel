package com.ge.transportation.eservices2.wheel.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ge.transportation.eservices2.domainobjects.ErrorType;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsRequest;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimits;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;

@RunWith(MockitoJUnitRunner.class)
public class WheelServiceValidatorTest {

	@InjectMocks
	WheelServiceValidator wheelServiceValidator;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void testValidateRequestParams() throws Exception {
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setId("string");
		wheelParamLimits.getLocoType().addAll(Arrays.asList("D7"));
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		StatusType statusType = wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123");
		assertNotNull(statusType);
	}

	@Test
	public void testValidateMeasurementsParams() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		StatusType statusType = wheelServiceValidator.validateMeasurementsParams(request, "123");
		assertNotNull(statusType);
	}
	
	@Test
	public void testValidateMeasurementsParamsForEmptyErrors() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setLocomotiveId(433657l);
		StatusType statusType = wheelServiceValidator.validateMeasurementsParams(request, "123");
		assertNull(statusType);
	}
	
	@Test
	public void testEmptyValidateRequestParams()  throws Exception{
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_49002.xml");
		request.setLocomotiveId(433657L);
		StatusType statusType = wheelServiceValidator.validateRequestParams(request, "123");
		assertNull(statusType);
	}
	@Test
	public void testInvalidateRequestParams()  throws Exception{
		WheelParameterLimitRequest wheelParameterLimitsRequest = new WheelParameterLimitRequest();
		WheelParameterLimits wheelParamLimits = new WheelParameterLimits();
		wheelParamLimits.setUpperLimit(1.0);
		wheelParamLimits.getLocoType().addAll(Arrays.asList("D7",null,"string"));
		wheelParamLimits.setWheelParameter("Flange Height");
		wheelParameterLimitsRequest.getWheelParameterLimits().add(wheelParamLimits);
		assertNotNull(wheelServiceValidator.validateRequestParams(wheelParameterLimitsRequest, "123"));
	}
	
	@Test
	public void testForEach()  throws Exception{
		List<Object> numbers = Arrays.asList(1,1.2,0.0f);
		numbers.addAll(new ArrayList<>());
		assertNotNull(wheelServiceValidator.forEach(numbers, new ErrorType(), "123", "numbers"));
	}
	
	@Test
	public void testErrorResponse() {
		assertNotNull(WheelServiceUtil.sendErrorStatusType(new Exception(), "123"));
	}
	
	@Test
	public void testCheckNullZeroOrString() {
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", new ArrayList<>());
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", new ArrayList<>(Arrays.asList(1,2)));
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", 0l);
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", "");
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", 0.0);
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "test", null);
		wheelServiceValidator.checkNullOrEmpty("123", new ErrorType(), "id", "");
		
		assertNotNull(wheelServiceValidator.checkNullZeroOrString(null, "test"));
		assertNotNull(wheelServiceValidator.checkNullZeroOrString(0, "cust"));
		assertNotNull(wheelServiceValidator.checkNullZeroOrString(0, "test"));
		assertNotNull(wheelServiceValidator.checkNullZeroOrString("string", "test"));
	}
	
	@Test
	public void testCheckNullOrEmpty() {
		
		assertNotNull(wheelServiceValidator.checkNullZeroOrString(null, "test"));
		
	}
	
}
