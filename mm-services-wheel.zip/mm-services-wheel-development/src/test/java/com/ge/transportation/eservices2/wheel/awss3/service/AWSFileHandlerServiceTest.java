package com.ge.transportation.eservices2.wheel.awss3.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;

import java.io.File;
import java.io.InputStream;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CopyObjectResult;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;

@RunWith(MockitoJUnitRunner.class)
public class AWSFileHandlerServiceTest {
	@Mock
	private AppConfig appConfig;

	@Mock
	AmazonS3 s3Client;

	@InjectMocks
	private AWSFileHandlerServiceImpl awsFileHandlerService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void moveFileTest() {
		File file = new File("src//test//resources//GELoco_20190416_124413_V3_no_RoadNumber.xml");
		Mockito.when(s3Client.copyObject(any())).thenReturn(new CopyObjectResult());
		assertTrue(awsFileHandlerService.putFile("loaders/INC/inbound/BNSF/wheels/customer/IR/input/", file, "1234"));
		assertTrue(awsFileHandlerService.moveFile(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml",
				"loaders/INC/inbound/BNSF/wheels/processing/GELoco_20190416_124413_V3_49002.xml", "1234"));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void deleteFileUsingKeyTest() {
		Mockito.when(appConfig.getAwsBucketName()).thenThrow(Exception.class);
		assertTrue(awsFileHandlerService.deleteFileUsingKey("abc", "1234"));
	}

	@Test
	public void testMoveFileException() {
		Mockito.when(s3Client.copyObject(any())).thenReturn(null);
		assertTrue(awsFileHandlerService.putFile("loaders/INC/inbound/BNSF/wheels/customer/IR/input/", null, "1234"));
		assertFalse(awsFileHandlerService.moveFile(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml",
				"loaders/INC/inbound/BNSF/wheels/processing", "1234"));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void putFileInvalidTest() {
		Mockito.when(appConfig.getAwsBucketName()).thenThrow(Exception.class);
		assertTrue(awsFileHandlerService.putFile("1234", new File("abc"), "1234"));
	}

	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void testMoveFileInvalid() {
		Mockito.when(s3Client.copyObject(any())).thenThrow(Exception.class);
		assertTrue(awsFileHandlerService.putFile("loaders/INC/inbound/BNSF/wheels/customer/IR/input/", null, "1234"));
		assertTrue(awsFileHandlerService.moveFile(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml",
				"loaders/INC/inbound/BNSF/wheels/processing", "1234"));
	}

	@Test
	public void testGetFileAsInputStream() {
		S3Object s3Object = new S3Object();
		Mockito.when(s3Client.getObject(any())).thenReturn(s3Object);
		assertEquals(null, awsFileHandlerService.getFileAsInputStream(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml", "1234"));
	}

	@Test(expected = WheelsException.class)
	public void testGetFileAsInputStreamException() {
		assertEquals(null, awsFileHandlerService.getFileAsInputStream(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml", "1234"));
	}

	@Test
	public void testGetS3Object() {
		S3Object s3Object = new S3Object();
		Mockito.when(s3Client.getObject(any())).thenReturn(s3Object);
		assertEquals(s3Object, awsFileHandlerService.getS3Object(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml", "1234"));
	}

	@Test(expected = WheelsException.class)
	public void testGetS3ObjectInvalid() {
		S3Object s3Object = new S3Object();
		Mockito.when(s3Client.getObject(any())).thenThrow(new WheelsException());
		assertEquals(s3Object, awsFileHandlerService.getS3Object(
				"loaders/INC/inbound/BNSF/wheels/customer/IR/input/GELoco_20190416_124413_V3_49002.xml", "1234"));
	}

	@Test
	public void testGetListOfFiles() {
		ObjectListing objectListing = new ObjectListing();
		objectListing.setTruncated(true);
		Mockito.when(s3Client.listNextBatchOfObjects(any(ObjectListing.class))).thenReturn(new ObjectListing());
		Mockito.when(s3Client.listObjects(any(), any())).thenReturn(objectListing);
		assertNotNull(awsFileHandlerService.listOfFiles("1234"));
	}
	
	@Test
	public void testUploadFileAsInputStream() {
		PutObjectResult putObjectResult = new PutObjectResult();
		Mockito.when(s3Client.putObject(any())).thenReturn(putObjectResult);
		Mockito.when(appConfig.getAwsBucketName()).thenReturn("");
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("");
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.xml");
		assertNotNull(awsFileHandlerService.uploadFileAsInputStream("1234", "GELoco_20190416_124413_V3_49002.xml", inputStream, "processing"));
	}
	
	
	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void testUploadEmptyFileAsInputStream() {
		Mockito.when(s3Client.putObject(any())).thenThrow(Exception.class);
		Mockito.when(appConfig.getAwsBucketName()).thenReturn("");
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("");
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.xml");
		assertNull(awsFileHandlerService.uploadFileAsInputStream("1234", "GELoco_20190416_124413_V3_49002.xml", inputStream, "processing"));
	}
	
	@Test
	public void testUploadInvalidFileAsInputStream() {
		PutObjectResult putObjectResult = new PutObjectResult();
		Mockito.when(s3Client.putObject(any())).thenReturn(putObjectResult);
		Mockito.when(appConfig.getAwsBucketName()).thenReturn("");
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("");
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.txt");
		assertNull(awsFileHandlerService.uploadFileAsInputStream("1234", "GELoco_20190416_124413_V3_49002.xml", inputStream, "processing"));
	}

}
