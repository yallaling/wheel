package com.ge.transportation.eservices2.wheel.serviceimpl;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.wheel.docdb.model.ParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamKey;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamLimitsRepository;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;

@RunWith(MockitoJUnitRunner.class)
public class WheelPersistanceServiceImplTest {

	@Mock
	WheelFileDetailRepository wheelFileDetailRepository;

	@Mock
	WheelParamLimitsRepository wheelParamLimitsRepository;

	@Mock
	private MongoTemplate mongoTemplate;

	@InjectMocks
	WheelPersistanceServiceImpl wheelPersistanceServiceImpl;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void saveMetaDataTest() {
		wheelPersistanceServiceImpl.saveMetadata("123", "abc.123", FileStatus.VALID, "123", null);
	}
	@Test
	public void saveMetaDataNullTest() {
		wheelPersistanceServiceImpl.saveMetadata("123", "abc.123", FileStatus.VALID, null, null);
	}

	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void testSaveMetaDataInvalid() {
		Mockito.when(wheelFileDetailRepository.save(Mockito.any(WheelFileDetail.class))).thenThrow(Exception.class);
		wheelPersistanceServiceImpl.saveMetadata("123", "abc.123", FileStatus.VALID, "123", null);
	}

	@Test
	public void testIsValidFile() {
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setFileCreationDate("");
		wheelFileDetail.setStatus(FileStatus.VALID);
		List<WheelFileDetail> wheelFileDetails = Arrays.asList(wheelFileDetail);
		Mockito.when(wheelFileDetailRepository.findByLocomotiveIdAndFileName(Mockito.any(), Mockito.any())).thenReturn(wheelFileDetails);
		assertNotNull(wheelPersistanceServiceImpl.isValidFile(123l, "abc.xml", "123"));
	}
	
	@Test
	public void testIsInValidFile() {
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setStatus(FileStatus.VALID);
		List<WheelFileDetail> wheelFileDetails = Arrays.asList(wheelFileDetail);
		Mockito.when(wheelFileDetailRepository.findByLocomotiveIdAndFileName(Mockito.any(), Mockito.any())).thenReturn(wheelFileDetails);
		assertNull(wheelPersistanceServiceImpl.isValidFile(123l, "abc.xml", "123"));
	}
	
	@Test
	public void testInvalidIsValidFile() {
		WheelFileDetail wheelFileDetail = new WheelFileDetail();
		wheelFileDetail.setStatus(FileStatus.ERROR);
		List<WheelFileDetail> wheelFileDetails = Arrays.asList(wheelFileDetail);
		Mockito.when(wheelFileDetailRepository.findByLocomotiveIdAndFileName(Mockito.any(), Mockito.any())).thenReturn(wheelFileDetails);
		assertNotNull(wheelPersistanceServiceImpl.isValidFile(123l, "abc.xml", "123"));
		Mockito.when(wheelFileDetailRepository.findByLocomotiveIdAndFileName(Mockito.any(), Mockito.any())).thenReturn(null);
		assertNotNull(wheelPersistanceServiceImpl.isValidFile(123l, "abc.xml", "123"));
	}

	@Test
	public void testFindByWheelParamKey() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		assertNull(wheelPersistanceServiceImpl.findByWheelParamKey(wheelParamKey));
	}

	@Test
	public void testNullSaveParamLimits() {
		assertNull(wheelPersistanceServiceImpl.saveParamLimits(null));
	}
	@Test
	public void testSaveParamLimits() {
		WheelParamKey wheelParamKey = new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		WheelParamLimits paramColleLimits = new WheelParamLimits();
		paramColleLimits.setWheelParamKey(wheelParamKey);
		paramColleLimits.getParamLimits().add(paramLimits);
		Mockito.when(wheelParamLimitsRepository.save(paramColleLimits)).thenReturn(paramColleLimits);
		assertNotNull(wheelPersistanceServiceImpl.saveParamLimits(paramColleLimits));
	}
	
	@Test
	public void testSaveParamLimitsList()
	{
		WheelParamKey wheelParamKey=new WheelParamKey();
		wheelParamKey.setAarRoad("KTZ");
		wheelParamKey.setCustomerId(1058L);
		wheelParamKey.setLocoType("D7");
		wheelParamKey.setWheelParameter("Flange Height");
		ParamLimits paramLimits = new ParamLimits();
		paramLimits.setLowerLimit(1.5);
		paramLimits.setUpperLimit(2.9);
		WheelParamLimits wheelParamLimits=new WheelParamLimits();
		wheelParamLimits.setWheelParamKey(wheelParamKey);
		wheelParamLimits.getParamLimits().add(paramLimits);
		List<WheelParamLimits> wheelParamLimitsList=new ArrayList<>();
		wheelParamLimitsList.add(wheelParamLimits);
		Mockito.when(wheelParamLimitsRepository.save(wheelParamLimitsList)).thenReturn(wheelParamLimitsList);
		assertNotNull(wheelPersistanceServiceImpl.saveParamLimitsList(wheelParamLimitsList));
	}


}
