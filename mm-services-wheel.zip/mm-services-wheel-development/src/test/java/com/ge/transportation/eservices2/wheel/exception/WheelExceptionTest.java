package com.ge.transportation.eservices2.wheel.exception;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class WheelExceptionTest {

	@Test
	public void wheelExceptionTest() {
		WheelsException exception = new WheelsException();
		WheelsException exception2 = new WheelsException("Exception Occured");
		WheelsException exception3 = new WheelsException(exception2);
		Throwable t = new Throwable("Throwable Excp");
		WheelsException throwableException = new WheelsException(t);
		WheelsException causeMessageExcpetion = new WheelsException("Exception occured", exception2);
//		exception2.setErrorCode("Error-1101");
		assertFalse("Error-1101".equals(exception2.getErrorCode()));
//		exception2.setDetail("Exception Details Added");
		assertFalse("Exception Details Added".equals(exception2.getDetail()));
		assertNotNull(exception);
		assertNotNull(exception2);
		assertNotNull(exception3);
		assertNotNull(throwableException);
		assertNotNull(causeMessageExcpetion);
	}

	@Test
	public void wheelExceptionNullTest() {
		Exception e = null;
		assertNotNull(new WheelsException(e));
	}
}
