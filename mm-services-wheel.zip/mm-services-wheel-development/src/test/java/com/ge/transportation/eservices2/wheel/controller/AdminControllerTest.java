package com.ge.transportation.eservices2.wheel.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ge.transportation.eservices2.domainobjects.DeleteParamRequest;
import com.ge.transportation.eservices2.domainobjects.DeleteParamResponse;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryRequest;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParamRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParamResponse;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.service.AdminService;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;

@RunWith(MockitoJUnitRunner.class)
public class AdminControllerTest {

	@Mock
	AdminService adminService;

	@Mock
	WheelServiceValidator wheelServiceValidator;

	@InjectMocks
	AdminController adminController;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
	}

	@Test
	public void persistByCustomerTest() throws Exception {

		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/admin/wheelparamlimits")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\r\n" + "  \"wheelParameterLimits\": [\r\n" + "    {\r\n" + "      \"aarRoad\": \"IR\",\r\n"
						+ "    \"customerId\": 1059,\r\n" + "    \"locoTypes\": [\r\n" + "\r\n" + "\"D8\", \"D7\"\r\n"
						+ "\r\n" + "],\r\n" + "    \"lowerLimit\": 2.5,\r\n" + "    \"upperLimit\": 3.49,\r\n"
						+ "    \"wheelParameter\": \"Flange Defeet\",\r\n" + "    \"lastUpdatedBy\": \"503122191\"\r\n"
						+ "\r\n" + "    }\r\n" + "  ]\r\n" + "}")
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		assertNotNull(result.getResponse().getContentAsString());
	}

	@Test
	public void testRetrieveWheelParams() throws Exception {
		WheelParamRequest wheelParamRequest = new WheelParamRequest();
		wheelParamRequest.setCustId("1058");
		WheelParamResponse response = new WheelParamResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		response.setStatus(statusType);
		Mockito.when(adminService.getWheelParameters(any(), any())).thenReturn(response);
		WheelParamResponse resp = adminController.retrieveWheelParams(wheelParamRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());
	}

	@Test
	public void testRetrieveWheelParamsWithNullData() throws Exception {
		WheelParamRequest wheelParamRequest = new WheelParamRequest();
		WheelParamResponse response = new WheelParamResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.FAILED);
		statusType.setMessage(WheelConstants.INVALID_INPUT);
		response.setStatus(statusType);
		Mockito.when(adminService.getWheelParameters(any(), any())).thenReturn(response);
		WheelParamResponse resp = adminController.retrieveWheelParams(wheelParamRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());

	}

	@Test
	public void testRetrieveWheelParamsWithEmptyData() throws Exception {
		WheelParamRequest wheelParamRequest = new WheelParamRequest();
		wheelParamRequest.setCustId("");
		WheelParamResponse response = new WheelParamResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.FAILED);
		statusType.setMessage(WheelConstants.INVALID_INPUT);
		response.setStatus(statusType);
		Mockito.when(adminService.getWheelParameters(any(), any())).thenReturn(response);
		WheelParamResponse resp = adminController.retrieveWheelParams(wheelParamRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());

	}
	@SuppressWarnings("unchecked")
	@Test(expected = WheelsException.class)
	public void testRetrieveWheelParamsException() throws Exception {
		WheelParamRequest wheelParamRequest = new WheelParamRequest();
		wheelParamRequest.setCustId("1058");
		WheelParamResponse response = new WheelParamResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.FAILED);
		response.setStatus(statusType);
		Mockito.when(adminService.getWheelParameters(any(), any())).thenThrow(Exception.class);
		WheelParamResponse resp = adminController.retrieveWheelParams(wheelParamRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());
	}

	@Test
	public void testRetrieveWheelParamLimits() throws Exception {
		WheelConfigRequest wheelConfigRequest = new WheelConfigRequest();
		wheelConfigRequest.setCustId(1058);
		wheelConfigRequest.setAarRoad("KTZ");
		wheelConfigRequest.getLocoType().add("D7");
		WheelConfigResponse response = new WheelConfigResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		response.setStatus(statusType);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(response);
		WheelConfigResponse resp = adminController.retrieveWheelConfiguration(wheelConfigRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());
	}


	@Test
	public void testDeleteWheelParamLimits()throws Exception{
		DeleteParamRequest deleteParamRequest=new DeleteParamRequest();
		deleteParamRequest.setAarRoad("KTZ");
		deleteParamRequest.setCustomerId(1058);
		deleteParamRequest.setWheelParameter("Flange Width");
		deleteParamRequest.getLocoType().add("D7");
		DeleteParamResponse deleteParamResponse=new DeleteParamResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		deleteParamResponse.setStatusType(statusType);
		Mockito.when(adminService.deleteWheelParam(any(), any())).thenReturn(deleteParamResponse);
		DeleteParamResponse resp = adminController.deleteWheelParamLimits(deleteParamRequest);
		assertEquals(deleteParamResponse.getStatusType().getStatusCode(), resp.getStatusType().getStatusCode());
	}
	
	@Test
	public void testRetrieveWheelParamHistory() throws Exception {
		LimitHistoryRequest limitHistoryRequest = new LimitHistoryRequest();
		limitHistoryRequest.setCustId(1058);
		limitHistoryRequest.getAarRoad().add("KTZ");
		limitHistoryRequest.getLocoType().add("D7");
		LimitHistoryResponse response = new LimitHistoryResponse();
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		response.setStatus(statusType);
		Mockito.when(adminService.getParamHistory(any(), any())).thenReturn(response);
		LimitHistoryResponse resp = adminController.retrieveParamHistory(limitHistoryRequest);
		assertEquals(response.getStatus().getStatusCode(), resp.getStatus().getStatusCode());
	}
}
