package com.ge.transportation.eservices2.wheel.serviceimpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.transportation.eservices2.domainobjects.AxleProperties;
import com.ge.transportation.eservices2.domainobjects.FileDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.FileDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsRequest;
import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.MoveFileResponse;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetRequestDetails;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationRequest;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationResponse;
import com.ge.transportation.eservices2.domainobjects.Side;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRecord;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelProfile;
import com.ge.transportation.eservices2.domainobjects.WheelSheet;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetails;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWORequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsResponse;
import com.ge.transportation.eservices2.wheel.awss3.service.AWSFileHandlerService;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.config.WheelDetailConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.LocomotiveAll;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParameters;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.model.DefectDTO;
import com.ge.transportation.eservices2.wheel.model.TimeCardDTO;
import com.ge.transportation.eservices2.wheel.model.UserDetailsDTO;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelSheetRepository;
import com.ge.transportation.eservices2.wheel.service.AdminService;
import com.ge.transportation.eservices2.wheel.service.WheelDataInjectService;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;






@RunWith(MockitoJUnitRunner.class)
public class WheelSheetServiceImplTest {

	@Mock
	WheelServiceValidator wheelServiceValidator;

	@Mock
	WheelPersistanceService wheelPersistanceService;

	@Mock
	AWSFileHandlerService awsFileHandlerService;

	@Mock
	AppConfig appConfig;
	
	@Mock
	WheelDetailConfig wheelDetConfig;

	@InjectMocks
	WheelSheetServiceImpl wheelSheetServiceImpl;
	
	@Mock
	WheelFileDetailRepository wheelFileDetailRepo;
	
	@Mock
	RestUtility restUtility;
	@Mock
	AdminService adminService;
	
	@Mock
	WheelParamRepository wheelParamRepo;
	
	@Mock
	WheelDataInjectService	wheelDataInjectService;
	
	@Mock
	WheelSheetRepository wheelSheetRepository;
	
	List<WheelParameters> wheelParamList;
	WheelConfigResponse wheelConfigResponse;
	RoadNumberValidationResponse roadNumberValidationResponse;
	WheelSheetDataCollection wheelSheetDataCollection;


	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		Mockito.when(appConfig.getAwsS3Path()).thenReturn("loaders/INC/inbound/BNSF/wheels/");
		Mockito.when(appConfig.getProcessing()).thenReturn("processing");
		Mockito.when(appConfig.getBaseUrl()).thenReturn("https://eservices-dev-api.cloud.trans.ge.com");
		Mockito.when(appConfig.getRoadnumberValidation()).thenReturn("/workoder/details");
		Mockito.when(appConfig.getXmlParamDiameter()).thenReturn("Diam_Drc");
		Mockito.when(appConfig.getXmlParamRimThickness()).thenReturn("Wheel_Fw2");
		Mockito.when(appConfig.getDBParamWheelDiameter()).thenReturn("Wheel Diameter");
		Mockito.when(appConfig.getAxleName()).thenReturn("Diameter Difference - Axle");
		Mockito.when(appConfig.getWheelDecimalPrecision()).thenReturn(2);
		Mockito.when(appConfig.getLocoName()).thenReturn("Diameter Difference - Loco");
		Mockito.when(appConfig.getTruckName()).thenReturn("Diameter Difference - Truck");
		setWheelParamBean();
		setWheelConfigResponse();
		setRoadNumberValiResp();
		getWheelSheetDataCollection();
	}

	@Test
	public void testLoadFileMeasurements() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_49002.xml");
		request.setLocomotiveId(433657L);
		StatusType statusType = null;
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.xml");
		Mockito.when(wheelServiceValidator.validateMeasurementsParams(request, "123")).thenReturn(statusType);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		Mockito.when(awsFileHandlerService.getFileAsInputStream(any(), any())).thenReturn(inputStream);
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId("123")).thenReturn(wheelParamList);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn("");
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
	}
	
	@Test
	public void testLoadFileMeasurementsForKTZ() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_186A_KTZ.xml");
		request.setLocomotiveId(433658L);
		StatusType statusType = null;
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_186A_KTZ.xml");
		Map<String, String> shimMap = getShimMap();
		Mockito.when(wheelDetConfig.getShimMap()).thenReturn(shimMap);
		Mockito.when(wheelServiceValidator.validateMeasurementsParams(request, "1058")).thenReturn(statusType);
		Mockito.when(wheelPersistanceService.isValidFile(433658L, request.getFileName(), "1058")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		Mockito.when(awsFileHandlerService.getFileAsInputStream(any(), any())).thenReturn(inputStream);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "1058"));
	}

	@Test
	public void testInvalidLoadFileMeasurements() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_49002.xml");
		request.setLocomotiveId(433657L);
		StatusType statusType = new StatusType();
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(statusType);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testExceptionLoadFileMeasurements() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_49002.xml");
		request.setLocomotiveId(433657L);
		StatusType statusType = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(statusType);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenThrow(WheelsException.class);
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
	}
	
	@Test
	public void testRetrieveFileDetailsWithFileAgeLessThanEightHours()
	{
		FileDetailsResponse response = new FileDetailsResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		response.setStatusType(statusType);
		FileDetailsRequest fileDetailsRequest=new FileDetailsRequest();
		fileDetailsRequest.setLocomotiveId(1058L);
		List<WheelFileDetail> wheelFileList=new ArrayList<WheelFileDetail>();
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileList.add(wheelFileDetail);
		Mockito.when(wheelFileDetailRepo.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(),any())).thenReturn(wheelFileList);
		
		FileDetailsResponse actualResponse=new FileDetailsResponse();
		actualResponse=wheelSheetServiceImpl.retrieveFileDetails(fileDetailsRequest, "123");
		assertEquals(response.getStatusType().getStatusCode(), actualResponse.getStatusType().getStatusCode());
	}
	
	@Test
	public void testRetrieveFileDetailsWithFileAgeGrtThanEightHours()
	{
		FileDetailsResponse response = new FileDetailsResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		response.setStatusType(statusType);
		FileDetailsRequest fileDetailsRequest=new FileDetailsRequest();
		fileDetailsRequest.setLocomotiveId(1058L);
		List<WheelFileDetail> wheelFileList=new ArrayList<WheelFileDetail>();
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate("2019-08-13 11:57:00");
		wheelFileList.add(wheelFileDetail);
		Mockito.when(wheelFileDetailRepo.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(),any())).thenReturn(wheelFileList);
		
		FileDetailsResponse actualResponse=new FileDetailsResponse();
		actualResponse=wheelSheetServiceImpl.retrieveFileDetails(fileDetailsRequest, "123");
		assertEquals(response.getStatusType().getStatusCode(), actualResponse.getStatusType().getStatusCode());
	}
	
	
	@Test
	public void testRetrieveFileDetailsWithNoFileAvailable()
	{
		FileDetailsResponse response = new FileDetailsResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		statusType.setMessage(WheelConstants.NO_FILE_AVAILABLE);
		response.setStatusType(statusType);
		FileDetailsRequest fileDetailsRequest=new FileDetailsRequest();
		fileDetailsRequest.setLocomotiveId(1058L);
		List<WheelFileDetail> wheelFileList=new ArrayList<WheelFileDetail>();
		
		Mockito.when(wheelFileDetailRepo.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(),any())).thenReturn(wheelFileList);
		
		FileDetailsResponse actualResponse=new FileDetailsResponse();
		actualResponse=wheelSheetServiceImpl.retrieveFileDetails(fileDetailsRequest, "123");
		assertEquals(response.getStatusType().getMessage(), actualResponse.getStatusType().getMessage());
	}

	@Test
	public void testRetrieveFileDetailsFailedRequest() throws Exception
	{
		FileDetailsResponse response = new FileDetailsResponse();
		StatusType statusType =new StatusType();
		statusType.setStatusCode(StatusCode.FAILED);
		response.setStatusType(statusType);
		FileDetailsRequest fileDetailsRequest=new FileDetailsRequest();
		fileDetailsRequest.setLocomotiveId(1058L);
		Mockito.when(wheelServiceValidator.validateRequestParams(any(),any())).thenReturn(statusType);
		FileDetailsResponse actualResponse=new FileDetailsResponse();
		actualResponse=wheelSheetServiceImpl.retrieveFileDetails(fileDetailsRequest, "123");
		assertEquals(response.getStatusType().getStatusCode(), actualResponse.getStatusType().getStatusCode());
	}
	

	@SuppressWarnings("unchecked")
	@Test
	public void testRetrieveFileDetailsException()
	{
		Mockito.when(wheelFileDetailRepo.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(any(),any())).thenThrow(WheelsException.class);
		assertNotNull(wheelSheetServiceImpl.retrieveFileDetails(new FileDetailsRequest(), "123"));
	}
	
	
	@Test
	public void testRetrieveShimDetails()
	{
		Map<String, String> shimMap = getShimMap();
		Mockito.when(wheelDetConfig.getShimMap()).thenReturn(shimMap);
		assertNotNull(wheelSheetServiceImpl.retrieveShimDetails("123"));
	}

	private Map<String, String> getShimMap() {
		Map<String, String> shimMap = new HashMap<String, String>() ;
		shimMap.put("00", "No");
		shimMap.put("01", "Yes");
		return shimMap;
	}
	
	@Test
	public void testRetrieveShimDetailsWithEmptyShimValues()
	{
		assertNotNull(wheelSheetServiceImpl.retrieveShimDetails("123"));
	}
	
	@Test
	public void testRetrieveVisDefectsDetailsWithEmptyValues()
	{
		assertNotNull(wheelSheetServiceImpl.retrieveVisDefectsDetails("123"));
	}
	
	@Test
	public void testRetrieveVisDefectsDetails()
	{
		Map<String, String> viMap = new HashMap<String, String>() ;
		viMap.put("00", "None");
		viMap.put("01", "Broken wheel");
		Mockito.when(wheelDetConfig.getVisualDefectMap()).thenReturn(viMap);
		assertNotNull(wheelSheetServiceImpl.retrieveVisDefectsDetails("123"));
	}
	
	private RoadNumberValidationResponse setRoadNumberValiResp() {
		roadNumberValidationResponse = new RoadNumberValidationResponse();
		roadNumberValidationResponse.setCustomerId(1123L);
		roadNumberValidationResponse.setLocomotiveId("6366");
		roadNumberValidationResponse.setStatusCode(StatusCode.SUCCESS);
		return roadNumberValidationResponse;
	}

	private WheelConfigResponse setWheelConfigResponse() {
		wheelConfigResponse = new WheelConfigResponse();
		WheelConfigRecord wheelConfigRecord1 = new WheelConfigRecord();
		wheelConfigRecord1.setWheelParameter("Flange height");
		wheelConfigRecord1.setLowerLimit(1);
		wheelConfigRecord1.setUpperLimit(2);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord1);
		WheelConfigRecord wheelConfigRecord = new WheelConfigRecord();
		wheelConfigRecord.setWheelParameter("Flange Wear");
		wheelConfigRecord.setLowerLimit(1);
		wheelConfigRecord.setUpperLimit(2);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord);
		WheelConfigRecord wheelConfigRecord11 = new WheelConfigRecord();
		wheelConfigRecord11.setWheelParameter("Flange wear2");
		wheelConfigRecord11.setLowerLimit(1);
		wheelConfigRecord11.setUpperLimit(2);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord11);
		WheelConfigRecord wheelConfigRecord2 = new WheelConfigRecord();
		wheelConfigRecord2.setWheelParameter("Tread wear");
		wheelConfigRecord2.setLowerLimit(1);
		wheelConfigRecord2.setUpperLimit(2);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord2);
		WheelConfigRecord wheelConfigRecord21 = new WheelConfigRecord();
		wheelConfigRecord21.setWheelParameter("Wheel Width (WW)");
		wheelConfigRecord21.setLowerLimit(1);
		wheelConfigRecord21.setUpperLimit(2);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord21);
		WheelConfigRecord wheelConfigRecord3 = new WheelConfigRecord();
		wheelConfigRecord3.setWheelParameter("Wheel Diameter");
		wheelConfigRecord3.setLowerLimit(1000);
		wheelConfigRecord3.setUpperLimit(2000);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord3);
		WheelConfigRecord wheelConfigRecord4 = new WheelConfigRecord();
		wheelConfigRecord4.setWheelParameter("Rim Thickness");
		wheelConfigRecord4.setLowerLimit(1000);
		wheelConfigRecord4.setUpperLimit(2000);
		wheelConfigResponse.getLimitRecords().add(wheelConfigRecord4);
		return wheelConfigResponse;
	}
	

	private List<WheelParameters> setWheelParamBean() {
		wheelParamList = new ArrayList<>();
		WheelParameters wheelparam = new WheelParameters();
		wheelparam.setCustomerId("123");
		wheelparam.setDimesnionId("Wheel_Fh");
		wheelparam.setWheelAdminId("Flange height");
		wheelparam.setMeasuredWheelL("Y");
		wheelParamList.add(wheelparam);
		WheelParameters wheelparam2 = new WheelParameters();
		wheelparam2.setCustomerId("123");
		wheelparam2.setDimesnionId("Wheel_Fw");
		wheelparam2.setWheelAdminId("Flange Wear");
		wheelparam2.setMeasuredAxleL("Y");
		wheelParamList.add(wheelparam2);
		WheelParameters wheelparam4 = new WheelParameters();
		wheelparam4.setCustomerId("123");
		wheelparam4.setDimesnionId("Wheel_HT");
		wheelparam4.setWheelAdminId("Tread wear");
		wheelParamList.add(wheelparam4);
		WheelParameters wheelparam5 = new WheelParameters();
		wheelparam5.setCustomerId("123");
		wheelparam5.setDimesnionId("Wheel_W");
		wheelparam5.setWheelAdminId("Wheel Width (WW)");
		wheelParamList.add(wheelparam5);
		WheelParameters wheelparam6 = new WheelParameters();
		wheelparam6.setCustomerId("123");
		wheelparam6.setDimesnionId("Diam_Drc");
		wheelparam6.setWheelAdminId("Wheel Diameter");
		wheelParamList.add(wheelparam6);
		WheelParameters wheelparam7 = new WheelParameters();
		wheelparam7.setCustomerId("1058");
		wheelparam7.setDimesnionId("Wheel_Fw2");
		wheelparam7.setWheelAdminId("Rim Thickness");
		wheelParamList.add(wheelparam7);
		return wheelParamList;
	}
	
	@Test
	public void testRoadNumberValidation() {
		roadNumberValidationResponse = new RoadNumberValidationResponse();
		RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		RoadNumberValidationResponse validateRoadnumberFromWorkOrderService = wheelSheetServiceImpl.validateRoadnumberFromWorkOrderService("123", request);
		assertNotNull(validateRoadnumberFromWorkOrderService);
	}
	
	@Test
	public void testLoadFileMeasurementsSuccess() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("GELoco_20190416_124413_V3_49002.xml");
		request.setLocomotiveId(433657L);
		StatusType statusType = null;
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("GELoco_20190416_124413_V3_49002.xml");
		Map<String, String> shimMap = getShimMap();
		Mockito.when(wheelDetConfig.getShimMap()).thenReturn(shimMap);
		Map<String, String> viMap = new HashMap<String, String>() ;
		viMap.put("00", "None");
		viMap.put("01", "Broken wheel");
		Mockito.when(wheelDetConfig.getVisualDefectMap()).thenReturn(viMap);
		Mockito.when(wheelServiceValidator.validateMeasurementsParams(request, "123")).thenReturn(statusType);
		Mockito.when(awsFileHandlerService.getFileAsInputStream(any(), any())).thenReturn(inputStream);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
	}
	
	@Test
	public void testLoadFileMeasurementsForFileNameEmpty() throws Exception {
		FileMeasurementsRequest request = new FileMeasurementsRequest();
		request.setFileName("");
		request.setLocomotiveId(433657L);
		StatusType statusType = null;
		Map<String, String> shimMap = getShimMap();
		Mockito.when(wheelDetConfig.getShimMap()).thenReturn(shimMap);
		Map<String, String> viMap = new HashMap<String, String>() ;
		viMap.put("00", "None");
		viMap.put("01", "Broken wheel");
		Mockito.when(wheelDetConfig.getVisualDefectMap()).thenReturn(viMap);
		LocomotiveAll locomotiveAll = new LocomotiveAll();
		locomotiveAll.setAarRoad("IR");
		locomotiveAll.setRoadNumber("49002");
		locomotiveAll.setCustomerId(1049949l);
		Mockito.when(wheelServiceValidator.validateMeasurementsParams(request, "123")).thenReturn(statusType);
		Mockito.when(restUtility.callCoreGetService(any(), any(), any(), any(), any())).thenReturn(locomotiveAll);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(wheelPersistanceService.isValidFile(433657L, request.getFileName(), "123")).thenReturn(WheelServiceUtil.convertDateToString(new Date()));
		assertNotNull(wheelSheetServiceImpl.loadFileMeasurements(request, "123"));
	}
	
	@Test
	public void testSaveWheelSheetDetails() throws Exception {
		WheelSheetDetailsRequest request = new WheelSheetDetailsRequest();
		ObjectMapper objectMapper = new ObjectMapper();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("wheelsheetdataRequest.json");
		WheelSheetDetails wheelSheetDetails = objectMapper.readValue(inputStream, WheelSheetDetails.class);
		request.setWheelSheetDetails(wheelSheetDetails);
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setStatus(FileStatus.VALID);
		MoveFileResponse moveFileResponse = new MoveFileResponse();
		moveFileResponse.setStatusType(new StatusType());
		WheelSheetDataCollection collection = new WheelSheetDataCollection();
		collection.setWheelSheet(new ArrayList<>());
		UserDetailsDTO userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setWorkShift("1");
		DefectDTO defectDTO = new DefectDTO();
		TimeCardDTO timeCardDTO = new TimeCardDTO();
		timeCardDTO.setDefectId(23456);
		defectDTO.setTimeCard(timeCardDTO);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(restUtility.callTDServiceToCreateWheelSheetDefect(any(), any(), any(), any(), any())).thenReturn(defectDTO);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(restUtility.callCoreGetServiceForUserDetails(any(UserDetailsDTO.class), any(), any(), any())).thenReturn(userDetailsDTO);
		Mockito.when(wheelPersistanceService.getWheelSheetDetiails(any())).thenReturn(null);
		Mockito.when(wheelFileDetailRepo.findByFileNameAndFileCreationDateAndStatus(any(), any(), any())).thenReturn(wheelFileDetail);
		Mockito.when(wheelDataInjectService.moveCustomerFile(any(MoveFileRequest.class), any())).thenReturn(moveFileResponse);
		assertNotNull(wheelSheetServiceImpl.saveWheelSheetDetails("123", request));
	}
	
	@Test
	public void testSaveWheelSheetDetailsForUpdate() throws Exception {
		WheelSheetDetailsRequest request = new WheelSheetDetailsRequest();
		ObjectMapper objectMapper = new ObjectMapper();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("wheelsheetdataRequest.json");
		WheelSheetDetails wheelSheetDetails = objectMapper.readValue(inputStream, WheelSheetDetails.class);
		request.setWheelSheetDetails(wheelSheetDetails);
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setStatus(FileStatus.VALID);
		MoveFileResponse moveFileResponse = new MoveFileResponse();
		moveFileResponse.setStatusType(new StatusType());
		WheelSheetDataCollection collection = new WheelSheetDataCollection();
		collection.setWheelSheet(new ArrayList<>());
		UserDetailsDTO userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setWorkShift("1");
		DefectDTO defectDTO = new DefectDTO();
		TimeCardDTO timeCardDTO = new TimeCardDTO();
		timeCardDTO.setDefectId(23456);
		defectDTO.setTimeCard(timeCardDTO);
		Mockito.when(restUtility.callTDServiceToCreateWheelSheetDefect(any(), any(), any(), any(), any())).thenReturn(defectDTO);
		Mockito.when(restUtility.callCoreGetServiceForUserDetails(any(UserDetailsDTO.class), any(), any(), any())).thenReturn(userDetailsDTO);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(wheelPersistanceService.getWheelSheetDetiails(any())).thenReturn(collection);
		Mockito.when(wheelFileDetailRepo.findByFileNameAndFileCreationDateAndStatus(any(), any(), any())).thenReturn(wheelFileDetail);
		Mockito.when(wheelDataInjectService.moveCustomerFile(any(MoveFileRequest.class), any())).thenReturn(moveFileResponse);
		assertNotNull(wheelSheetServiceImpl.saveWheelSheetDetails("123", request));
	}
	
	@Test
	public void testSaveWheelSheetDetailsForNoDefect() throws Exception {
		WheelSheetDetailsRequest request = new WheelSheetDetailsRequest();
		ObjectMapper objectMapper = new ObjectMapper();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("wheelsheetdataRequest.json");
		WheelSheetDetails wheelSheetDetails = objectMapper.readValue(inputStream, WheelSheetDetails.class);
		WheelSheet wheelSheet = wheelSheetDetails.getWheelSheet().get(0);
		AxleProperties axleProperties = wheelSheet.getAxleProperties().get(0);
		WheelProfile wheelProfile = axleProperties.getWheelProfiles().get(0);
		wheelProfile.setLeft(null);
		wheelProfile.setRight(null);
		WheelProfile wheelProfile2 = axleProperties.getWheelProfiles().get(1);
		Side left = wheelProfile2.getLeft();
		left.setValue("");
		Side right = wheelProfile2.getRight();
		right.setValue("");
		request.setWheelSheetDetails(wheelSheetDetails);
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setStatus(FileStatus.VALID);
		MoveFileResponse moveFileResponse = new MoveFileResponse();
		moveFileResponse.setStatusType(new StatusType());
		WheelSheetDataCollection collection = new WheelSheetDataCollection();
		collection.setWheelSheet(new ArrayList<>());
		UserDetailsDTO userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setWorkShift("1");
		DefectDTO defectDTO = new DefectDTO();
		TimeCardDTO timeCardDTO = new TimeCardDTO();
		timeCardDTO.setDefectId(23456);
		defectDTO.setTimeCard(timeCardDTO);
		Mockito.when(restUtility.callTDServiceToCreateWheelSheetDefect(any(), any(), any(), any(), any())).thenReturn(defectDTO);
		Mockito.when(restUtility.callCoreGetServiceForUserDetails(any(UserDetailsDTO.class), any(), any(), any())).thenReturn(userDetailsDTO);
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(wheelPersistanceService.getWheelSheetDetiails(any())).thenReturn(collection);
		Mockito.when(wheelFileDetailRepo.findByFileNameAndFileCreationDateAndStatus(any(), any(), any())).thenReturn(wheelFileDetail);
		Mockito.when(wheelDataInjectService.moveCustomerFile(any(MoveFileRequest.class), any())).thenReturn(moveFileResponse);
		assertNotNull(wheelSheetServiceImpl.saveWheelSheetDetails("123", request));
	}
	
	@Test
	public void testSaveWheelSheetDetailsForException() throws Exception {
		assertNotNull(wheelSheetServiceImpl.saveWheelSheetDetails("123", new WheelSheetDetailsRequest()));
	}
	
	@Test
	public void testSaveWheelSheetDetailsForEmptyParams() throws Exception {
		WheelSheetDetailsRequest wheelSheetDetailsRequest = new WheelSheetDetailsRequest();
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetDetailsRequest, "123")).thenReturn(new StatusType());
		assertNotNull(wheelSheetServiceImpl.saveWheelSheetDetails("123", wheelSheetDetailsRequest));
	}
	
	@Test
	public void testGetWheelSheetDetails() throws Exception{
		WheelSheetForWORequest request = new WheelSheetForWORequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		request.setWorkOrderId(6565656L);
		StatusType sts = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(sts);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getWheelSheetDetails("123", request));
	}

	private void getWheelSheetDataCollection() {
		wheelSheetDataCollection = new WheelSheetDataCollection();
		WheelSheetKey wheelSheetKey =new WheelSheetKey();
		wheelSheetKey.setAarRoad("IR");
		wheelSheetKey.setRoadNumber("49002");
		List<WheelSheetCollection> wheelSheets = new ArrayList<>();
		WheelSheetCollection wheelSheet = new WheelSheetCollection();
		wheelSheet.setWheelsheetId("6565656");
		wheelSheet.setWheelSheetName("Wheel Inbound1");
		wheelSheet.setWorkorderId(6565656L);
		wheelSheet.setCreatedDate("2019-10-07 15:20:00");
		wheelSheet.setCreatedBy("12345");
		wheelSheets.add(wheelSheet);
		
		WheelSheetCollection wheelSheet1 = new WheelSheetCollection();
		wheelSheet1.setWheelsheetId("2323232");
		wheelSheet1.setWheelSheetName("Wheel Inbound2");
		wheelSheet1.setWorkorderId(2323232L);
		wheelSheet1.setCreatedDate("2019-10-08 10:20:00");
		wheelSheet.setCreatedBy("12345");
		wheelSheets.add(wheelSheet1);
		
		wheelSheetDataCollection.setWheelSheetKey(wheelSheetKey);
		wheelSheetDataCollection.setId("12232");
		wheelSheetDataCollection.setWheelSheet(wheelSheets);
		
		
	}
	
	@Test
	public void testGetWheelSheetDetailsForNoData() throws Exception{
		WheelSheetForWORequest request = new WheelSheetForWORequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		request.setWorkOrderId(6565656L);
		StatusType sts = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(sts);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getWheelSheetDetails("123", request));
	}
	
	@Test
	public void testGetWheelSheetDetailsforValidator() throws Exception{
		WheelSheetForWORequest request = new WheelSheetForWORequest();
		request.setRoadNumber("49002");
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(new StatusType());
		WheelSheetDataCollection wheelSheetDataCollection = new WheelSheetDataCollection();
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(new WheelSheetKey())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getWheelSheetDetails("123", request));
	}
	
	@Test
	public void testGetWheelSheet() throws Exception{
		WheelSheetRequest request = new WheelSheetRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		request.setWheelSheetID("6565656");
		StatusType sts = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(sts);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getWheelSheet("123", request));
	}
	@Test
	public void testGetWheelSheetForValidator() throws Exception{
		WheelSheetRequest request = new WheelSheetRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		request.setWheelSheetID("6565656");
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(new StatusType());
		assertNotNull(wheelSheetServiceImpl.getWheelSheet("123", request));
	}
	@Test
	public void testGetWheelSheetForNoData() throws Exception{
		WheelSheetRequest request = new WheelSheetRequest();
		request.setRoadNumber("49002");
		request.setAarRoad("IR");
		request.setWheelSheetID("656565654");
		StatusType sts = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(sts);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getWheelSheet("123", request));
	}
	
	
	@Test
	public void testGetPastWheelSheetDetailsForNoData()throws Exception
	{
		PastWheelSheetRequestDetails request=new PastWheelSheetRequestDetails();
		request.setAarRoad("IR");
		request.setRoadNumber("49002");
		request.setWorkorderId(6565657L);
		StatusType status = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getPastWheelSheetDetails("123", request));
	}
	
	@Test
	public void testGetPastWheelSheetDetails()throws Exception
	{
		PastWheelSheetRequestDetails request=new PastWheelSheetRequestDetails();
		request.setAarRoad("IR");
		request.setRoadNumber("49002");
		request.setWorkorderId(2323232L);
		StatusType status = null;
		Mockito.when(wheelServiceValidator.validateRequestParams(request, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		assertNotNull(wheelSheetServiceImpl.getPastWheelSheetDetails("123", request));
	}
	
	@Test
	public void testValidateWheelSheetDetailsForInvalidRequest()throws Exception
	{
		WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest=new WheelSheetNameDetailsRequest();
		WheelSheetNameDetailsResponse actualResponse=new WheelSheetNameDetailsResponse();
		WheelSheetDataCollection wheelSheetDataCollection1=null;
		
		wheelSheetNameDetailsRequest.setAarRoad("IRA");
		wheelSheetNameDetailsRequest.setRoadNumber("49002");
		wheelSheetNameDetailsRequest.setWorkorderId(2581190);
		wheelSheetNameDetailsRequest.setWheelSheetName("Wheel Inbound");
		wheelSheetNameDetailsRequest.setWheelSheetID("6565656");
		StatusType status =null;
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection1);
		actualResponse=wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", wheelSheetNameDetailsRequest);
		assertEquals(WheelConstants.NO_RECORD_AVAILABLE, actualResponse.getStatusType().getMessage());
		
	}
	
	@Test
	public void testValidateWheelSheetDetailsForAlreadyExistingFilename()throws Exception
	{
		WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest=new WheelSheetNameDetailsRequest();
		WheelSheetNameDetailsResponse actualResponse=new WheelSheetNameDetailsResponse();
		wheelSheetNameDetailsRequest.setAarRoad("IR");
		wheelSheetNameDetailsRequest.setRoadNumber("49002");
		wheelSheetNameDetailsRequest.setWorkorderId(6565656L);
		wheelSheetNameDetailsRequest.setWheelSheetName("Wheel Inbound1");
		wheelSheetNameDetailsRequest.setWheelSheetID("6565656");
		StatusType status =null;
		
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		actualResponse=wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", wheelSheetNameDetailsRequest);
		assertEquals(WheelConstants.WHEEL_NAME_ALREADY_EXIST, actualResponse.getStatusType().getMessage());
		
		
	}
	
	
	@Test
	public void testValidateWheelSheetDetailsForValidFilename()throws Exception
	{
		WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest=new WheelSheetNameDetailsRequest();
		WheelSheetNameDetailsResponse actualResponse=new WheelSheetNameDetailsResponse();
		wheelSheetNameDetailsRequest.setAarRoad("IR");
		wheelSheetNameDetailsRequest.setRoadNumber("49002");
		wheelSheetNameDetailsRequest.setWorkorderId(6565656L);
		wheelSheetNameDetailsRequest.setWheelSheetName("Wheel Inbound5");
		wheelSheetNameDetailsRequest.setWheelSheetID("6565656");
		StatusType status =null;
		
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		Mockito.when(wheelPersistanceService.saveWheelSheetDetails(any())).thenReturn(wheelSheetDataCollection);
		actualResponse=wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", wheelSheetNameDetailsRequest);
		assertEquals(WheelConstants.WHEEL_NAME_SAVED, actualResponse.getStatusType().getMessage());
		
		
	}
	
	@Test
	public void testValidateWheelSheetDetailsForUpdateFailure()throws Exception
	{
		WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest=new WheelSheetNameDetailsRequest();
		WheelSheetNameDetailsResponse actualResponse=new WheelSheetNameDetailsResponse();
		WheelSheetDataCollection wheelSheetDataCollection1=null;
		wheelSheetNameDetailsRequest.setAarRoad("IR");
		wheelSheetNameDetailsRequest.setRoadNumber("49002");
		wheelSheetNameDetailsRequest.setWorkorderId(6565656L);
		wheelSheetNameDetailsRequest.setWheelSheetName("Wheel Inbound5");
		wheelSheetNameDetailsRequest.setWheelSheetID("6565656");
		StatusType status =null;
		
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		Mockito.when(wheelPersistanceService.saveWheelSheetDetails(any())).thenReturn(wheelSheetDataCollection1);
		actualResponse=wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", wheelSheetNameDetailsRequest);
		assertEquals(WheelConstants.WHEEL_NAME_SAVED_FAILED, actualResponse.getStatusType().getMessage());
		
		
	}
	
	@Test
	public void testValidateWheelSheetDetailsForInvalidWheelSheetId()throws Exception
	{
		WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest=new WheelSheetNameDetailsRequest();
		WheelSheetNameDetailsResponse actualResponse=new WheelSheetNameDetailsResponse();
		WheelSheetDataCollection wheelSheetDataCollection1=null;
		wheelSheetNameDetailsRequest.setAarRoad("IR");
		wheelSheetNameDetailsRequest.setRoadNumber("49002");
		wheelSheetNameDetailsRequest.setWorkorderId(6565656L);
		wheelSheetNameDetailsRequest.setWheelSheetName("Wheel Inbound5");
		wheelSheetNameDetailsRequest.setWheelSheetID("11111");
		StatusType status =null;
		
		Mockito.when(wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, "123")).thenReturn(status);
		Mockito.when(wheelSheetRepository.findByWheelSheetKey(any())).thenReturn(wheelSheetDataCollection);
		Mockito.when(wheelPersistanceService.saveWheelSheetDetails(any())).thenReturn(wheelSheetDataCollection1);
		actualResponse=wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", wheelSheetNameDetailsRequest);
		assertEquals(WheelConstants.WHEEL_NAME_SAVED_FAILED, actualResponse.getStatusType().getMessage());
		
		
	}
	
	
	@Test
	public void testValidateWheelSheetDetailsInvalidRequest() throws Exception {
		StatusType status =new StatusType();
		Mockito.when(wheelServiceValidator.validateRequestParams(any(),any())).thenReturn(status);
		assertNotNull(wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", new WheelSheetNameDetailsRequest()));
	}
	
	
	@SuppressWarnings("unchecked")
	@Test
	public void testValidateWheelSheetDetailsException()
	{
		Mockito.when( wheelSheetRepository.findByWheelSheetKey(any())).thenThrow(WheelsException.class);
		assertNotNull(wheelSheetServiceImpl.validateAndSaveWheelSheetDetails("123", new WheelSheetNameDetailsRequest()));
	}
	
	
	@Test
	public void testGetDiameterCalculation() throws Exception {
		WheelSheetDetailsRequest request = new WheelSheetDetailsRequest();
		ObjectMapper objectMapper = new ObjectMapper();
		InputStream inputStream = this.getClass().getClassLoader()
				.getResourceAsStream("wheelsheetdataRequest.json");
		WheelSheetDetails wheelSheetDetails = objectMapper.readValue(inputStream, WheelSheetDetails.class);
		request.setWheelSheetDetails(wheelSheetDetails);
		WheelFileDetail wheelFileDetail=new WheelFileDetail();
		wheelFileDetail.setFileName("text.xml");
		wheelFileDetail.setFileCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelFileDetail.setStatus(FileStatus.VALID);
		WheelSheetDataCollection collection = new WheelSheetDataCollection();
		collection.setWheelSheet(new ArrayList<>());
		UserDetailsDTO userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setWorkShift("1");
		Mockito.when(restUtility.callCorePostService(any(), any(), any(), any())).thenReturn(roadNumberValidationResponse);
		Mockito.when(adminService.getAdminConfiguration(any(), any())).thenReturn(wheelConfigResponse);
		Mockito.when(wheelParamRepo.findByCustomerId(any())).thenReturn(wheelParamList);
		Mockito.when(restUtility.callCoreGetServiceForUserDetails(any(UserDetailsDTO.class), any(), any(), any())).thenReturn(userDetailsDTO);
		Mockito.when(wheelPersistanceService.getWheelSheetDetiails(any())).thenReturn(null);
		Mockito.when(wheelFileDetailRepo.findByFileNameAndFileCreationDateAndStatus(any(), any(), any())).thenReturn(wheelFileDetail);
		assertNotNull(wheelSheetServiceImpl.getDiameterCalculation("123", request));
	}
}
