package com.ge.transportation.eservices2.wheel.controller;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.service.WheelDataInjectService;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;

@RunWith(MockitoJUnitRunner.class)
public class WheelDataInjectControllerTest {

	@Mock
	private AppConfig appConfig;

	@Mock
	WheelServiceValidator wheelServiceValidator;
	
	@Mock
	private WheelDataInjectService wheelService;

	@InjectMocks
	private WheelDataInjectController wheelsController;

	private MockMvc mockMvc;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(wheelsController).build();
	}

	@Test
	public void moveFileTest() throws Exception {
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/v1/file/movefile")
				.contentType(MediaType.APPLICATION_JSON)
				.content("{\r\n" + "\"fileName\": \"GELoco_20190416_124413_V3.xml,\",\r\n" + "\"from\": \"processing\",\r\n"
						+ "\"to\": \"error\"\r\n" + "}")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
		assertNotNull(result.getResponse().getContentAsString());
	}
	
}
