package com.ge.transportation.eservices2.wheel.service;

import org.springframework.stereotype.Service;

import com.ge.transportation.eservices2.domainobjects.DeleteParamRequest;
import com.ge.transportation.eservices2.domainobjects.DeleteParamResponse;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryRequest;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryResponse;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParamResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitResponse;

@Service
public interface AdminService {

	WheelParamResponse getWheelParameters(String custId, String uuId);

	LimitHistoryResponse getParamHistory(LimitHistoryRequest limitHistoryRequest, String uuId);

	WheelParameterLimitResponse persistWheelParameterLimits(WheelParameterLimitRequest parametersList, String uuId);

	WheelConfigResponse getAdminConfiguration(WheelConfigRequest limitRequest, String uuId);

	DeleteParamResponse deleteWheelParam(DeleteParamRequest deleteParmRequest, String uuId);
}


