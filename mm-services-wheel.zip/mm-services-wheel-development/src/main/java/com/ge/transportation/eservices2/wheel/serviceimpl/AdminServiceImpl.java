package com.ge.transportation.eservices2.wheel.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.transportation.eservices2.domainobjects.AarRoads;
import com.ge.transportation.eservices2.domainobjects.DeleteParamRequest;
import com.ge.transportation.eservices2.domainobjects.DeleteParamResponse;
import com.ge.transportation.eservices2.domainobjects.GetLmsEmployeeRequest;
import com.ge.transportation.eservices2.domainobjects.GetLmsEmployeeResponse;
import com.ge.transportation.eservices2.domainobjects.History;
import com.ge.transportation.eservices2.domainobjects.HistoryRecord;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryRequest;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryResponse;
import com.ge.transportation.eservices2.domainobjects.LocoTypes;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRecord;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParamResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimits;
import com.ge.transportation.eservices2.domainobjects.WheelParams;
import com.ge.transportation.eservices2.domainobjects.WheelparamLimits;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.ParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamKey;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParameters;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelParamLimitsRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamRepository;
import com.ge.transportation.eservices2.wheel.service.AdminService;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;



@Component
public class AdminServiceImpl implements AdminService {

	private static final Logger logger = Logger.getLogger(AdminServiceImpl.class);

	@Autowired
	AppConfig appConfig;

	@Autowired
	WheelPersistanceService wheelPersistanceService;

	@Autowired
	WheelServiceValidator wheelServiceValidator;

	@Autowired
	WheelParamRepository wheelParamRepository;

	@Autowired
	WheelParamLimitsRepository wheelParamLimitsRepository;

	@Autowired
	RestUtility restUtility;

	@Override
	public WheelParamResponse getWheelParameters(String custId, String uuId) {
		logger.info(uuId + " getWheelParameters for Customer id : " + custId );
		WheelParamResponse wheelResp = new WheelParamResponse();
		StatusType statusType = new StatusType();
		List<WheelParameters> wheelsParams = wheelParamRepository.findByCustomerId(custId);
		if (null != wheelsParams && !wheelsParams.isEmpty()) {
			logger.info(uuId + " Customer id : " + custId + "No of wheelsParams " + wheelsParams.size());
			wheelsParams.stream().forEach(wheelParam -> wheelResp.getWheelParamList().add(mapWheelParam(wheelParam)));
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
			wheelResp.setStatus(statusType);
		} else {
			logger.info(uuId + " No wheel parameters set for customer " + custId);
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage("No wheel parameters set for customer " + custId);
			wheelResp.setStatus(statusType);
		}
		logger.info(uuId + " Completed getWheelParameters");
		return wheelResp;
	}

	public WheelParams mapWheelParam(WheelParameters wheelParam) {
		WheelParams params = new WheelParams();
		params.setMethodId(wheelParam.getMethodId());
		params.setDimensionId(wheelParam.getDimesnionId());
		params.setWheelAdminId(wheelParam.getWheelAdminId());
		return params;
	}

	@Override
	public LimitHistoryResponse getParamHistory(LimitHistoryRequest limitHistoryRequest, String uuId) {
		LimitHistoryResponse limitHistoryResponse = new LimitHistoryResponse();
		StatusType statusType = null;
		try {
			logger.info(uuId + " validateRequestParams for limitHistoryRequest" );
			statusType = wheelServiceValidator.validateRequestParams(limitHistoryRequest, uuId);
			if (Objects.nonNull(statusType)) {
				limitHistoryResponse.setStatus(statusType);
				logger.info(uuId + " validation failed for limitHistoryRequest " );
			} else {
				limitHistoryResponse = fetchHistoryDetails(limitHistoryRequest,uuId);
			}
		} catch (Exception e) {
			statusType = WheelServiceUtil.sendErrorStatusType(e, uuId);
			limitHistoryResponse.setStatus(statusType);
			return limitHistoryResponse;
		}
		return limitHistoryResponse;
	}

	private LimitHistoryResponse fetchHistoryDetails(LimitHistoryRequest limitHistoryRequest, String uuId) {
		LimitHistoryResponse limitHistoryResp = new LimitHistoryResponse();
		long custId = limitHistoryRequest.getCustId();
		List<String> aar = limitHistoryRequest.getAarRoad();
		List<String> locoTypes = limitHistoryRequest.getLocoType();
		String wheelparam = limitHistoryRequest.getWheelParam();
		logger.info(uuId + "getParameterHistory for Customer id : " + custId + " wheelsParams " +wheelparam+ "aarRoads ");
		aar.forEach(aarRoad -> logger.info(uuId + " " +aarRoad+" "));
		locoTypes.forEach(locoType -> logger.info(uuId +" loco " +locoType+" "));
		StatusType statusType = new StatusType();
		List<WheelParamLimits> paramLimits = wheelParamLimitsRepository.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadInAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeInAndWheelParamKeyWheelParameter(custId,
				aar,false, locoTypes,wheelparam);
		if (!paramLimits.isEmpty()) {
			populateHistoryResponse(uuId, limitHistoryResp, statusType, paramLimits);
		} else {
			logger.info(uuId + " ParamLimits empty, No history available");
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage("No history available ");
			limitHistoryResp.setStatus(statusType);
		}
		return limitHistoryResp;
	}

	private void populateHistoryResponse(String uuId, LimitHistoryResponse limitHistoryResp, StatusType statusType,
			List<WheelParamLimits> paramLimits) {
		logger.info(uuId + " ParamLimits not empty " + paramLimits.size() );
		findUserNames(paramLimits,uuId);
		HistoryRecord historyRec = new HistoryRecord();
		historyRec.setCustomerId(paramLimits.get(0).getWheelParamKey().getCustomerId());
		historyRec.setWheelParameter(paramLimits.get(0).getWheelParamKey().getWheelParameter());
		List<String> distinctAarRoads = paramLimits.stream().map(limit -> limit.getWheelParamKey().getAarRoad()).distinct()
				.collect(Collectors.toList());
		distinctAarRoads.forEach(aarRoad -> {
		AarRoads aarRoads  = new AarRoads();
		aarRoads.setAarRoad(aarRoad);
		setLocoTypeHistory(uuId, paramLimits, historyRec, aarRoad, aarRoads);
		});
		limitHistoryResp.setParamLimitHistorys(historyRec);
		statusType.setStatusCode(StatusCode.SUCCESS);
		statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
		limitHistoryResp.setStatus(statusType);
		logger.info(uuId + " populateHistoryResponse completed" );
	}

	private void setLocoTypeHistory(String uuId, List<WheelParamLimits> paramLimits, HistoryRecord historyRec,
			String aarRoad, AarRoads aarRoads) {
		logger.info(uuId + " Setting  details for AAR : " + aarRoad );
		List<WheelParamLimits> aarRecords = paramLimits.stream().filter(limitRecord -> aarRoad.equalsIgnoreCase(limitRecord.getWheelParamKey().getAarRoad())).collect(Collectors.toList());
		List<String> aarLocoTypes = aarRecords.stream().map(limit -> limit.getWheelParamKey().getLocoType()).distinct()
				.collect(Collectors.toList());
		aarLocoTypes.stream()
				.forEach(locoType -> {
					LocoTypes locoTypeBean = new LocoTypes();
					locoTypeBean.setLocoType(locoType);
					logger.info(uuId + " Setting  details for LOCO : " + locoType + " for AAR " +aarRoad);
					populateHistoryObject(aarRecords, locoType, locoTypeBean);
					aarRoads.getLocoType().add(locoTypeBean);	
				});
		historyRec.getAarRoad().add(aarRoads);
		logger.info(uuId + " Set details for AAR : " + aarRoad );
	}

	private void populateHistoryObject(List<WheelParamLimits> aarRecords, String locoType, LocoTypes locoTypeBean) {
		List<WheelParamLimits> locoRecords = aarRecords.stream().filter(aarRecord -> locoType.equalsIgnoreCase(aarRecord.getWheelParamKey().getLocoType())).collect(Collectors.toList());
		locoRecords.stream().forEach(locoRec -> {
			List<ParamLimits> limitRecs = locoRec.getParamLimits();
			limitRecs.forEach(limitRec -> {
			if(!limitRec.isDelete()){
				History history = new History();
				history.setLowerLimit(limitRec.getLowerLimit());
				history.setUpperLimit(limitRec.getUpperLimit());
				history.setCreatedBy(limitRec.getCreatedBy());
				history.setCreationDate(limitRec.getCreationDate());
				history.setLastUpdateDate(limitRec.getLastUpdateDate());
				history.setLastUpdatedBy(limitRec.getLastUpdatedBy());
				locoTypeBean.getHistorys().add(history);
			}
		});
		});
	}

	@Override
	public WheelParameterLimitResponse persistWheelParameterLimits(WheelParameterLimitRequest wheelParameterRequest,
			String uuId) {
		WheelParameterLimitResponse response = new WheelParameterLimitResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelParameterRequest, uuId);
			if (Objects.nonNull(statusType)) {
				response.setStatusType(statusType);
			} else {
				response = insertWheelLimits(wheelParameterRequest, uuId);
				response.setStatusType(WheelServiceUtil.sendSuccessStatusType(WheelConstants.STATUS_MESSAGE_OK));
			}
		} catch (Exception e) {
			logger.error(new WheelsException(e));
			response.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
			return response;
		}
		return response;
	}

	private WheelParameterLimitResponse insertWheelLimits(WheelParameterLimitRequest request, String uuId) {
		WheelParameterLimitResponse response = new WheelParameterLimitResponse();
		for (WheelParameterLimits parameterLimits : request.getWheelParameterLimits()) {
			List<WheelParameters> wheelparams = wheelParamRepository.findByCustomerId(parameterLimits.getCustomerId()+"");
			List<String> wheelparamsList = wheelparams.stream().map(WheelParameters::getWheelAdminId).collect(Collectors.toList());
			if(!wheelparamsList.contains(parameterLimits.getWheelParameter())) {
				logger.error("Given WheelParameter does not exist by customer id: "+parameterLimits.getCustomerId());
				throw new WheelsException("Given WheelParameter does not exist by customer id: "+parameterLimits.getCustomerId());
			}
			else if (parameterLimits.getLocoType().isEmpty()) {
				logger.error(uuId + " : LocoType values Empty");
				throw new WheelsException("LocoType values Empty");
			} else {
				for (String locoType : parameterLimits.getLocoType()) {
					WheelParamKey wheelParamKey = mapWheelParamKey(parameterLimits, locoType);
					ParamLimits paramLimits = mapParamLimits(parameterLimits);
					WheelparamLimits wheelParamLimits = updateWheelParamLimits(wheelParamKey, paramLimits, uuId);
					isObjExist(response, wheelParamLimits);
				}
			}
		}
		return response;
	}

	public WheelparamLimits updateWheelParamLimits(WheelParamKey wheelParamKey, ParamLimits paramLimits, String uuId) {
		WheelParamLimits paramLimitsCollection = null;
		try {
			paramLimitsCollection = wheelPersistanceService.findByWheelParamKey(wheelParamKey);
			if (Objects.nonNull(paramLimitsCollection)) {
				ParamLimits docParamLimits = paramLimitsCollection.getParamLimits().get(0);
				if (paramLimitsCollection.getWheelParamKey().isDelete()) {
					paramLimits.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
					paramLimits.setCreatedBy(paramLimits.getLastUpdatedBy());
				} else {
					paramLimits.setCreationDate(docParamLimits.getCreationDate());
					paramLimits.setCreatedBy(docParamLimits.getCreatedBy());
				}
				paramLimits.setLastUpdateDate(WheelServiceUtil.convertDateToString(new Date()));
				paramLimitsCollection.setWheelParamKey(wheelParamKey);
				paramLimitsCollection.getParamLimits().add(0, paramLimits);
				return wheelPersistanceService.saveParamLimits(paramLimitsCollection);
			} else {
				return insertWheelParamLimits(wheelParamKey, paramLimits);
			}

		} catch (Exception e) {
			logger.error(uuId + " : Exception While insert or update limits " + e);
			paramLimitsCollection = wheelPersistanceService.findByWheelParamKey(wheelParamKey);
			if (Objects.nonNull(paramLimitsCollection)) {
				if (!paramLimitsCollection.getParamLimits().isEmpty()) {
					ParamLimits docParamLimits = paramLimitsCollection.getParamLimits().get(0);
					docParamLimits.setDelete(true);
					docParamLimits.setLastUpdateDate(WheelServiceUtil.convertDateToString(new Date()));
					wheelPersistanceService.saveParamLimits(paramLimitsCollection);
				}
			} else {
				paramLimits.setDelete(true);
				insertWheelParamLimits(wheelParamKey, paramLimits);
			}
			throw new WheelsException("Exception While insert or update limits");
		}
	}

	public WheelparamLimits insertWheelParamLimits(WheelParamKey wheelParamKey, ParamLimits paramLimits) {
		WheelParamLimits paramLimitsCollection = new WheelParamLimits();
		paramLimitsCollection.setWheelParamKey(wheelParamKey);
		paramLimits.setCreatedBy(paramLimits.getLastUpdatedBy());
		paramLimits.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
		paramLimits.setLastUpdateDate(WheelServiceUtil.convertDateToString(new Date()));
		paramLimitsCollection.getParamLimits().add(0, paramLimits);
		return wheelPersistanceService.saveParamLimits(paramLimitsCollection);
	}

	public WheelParamKey mapWheelParamKey(WheelParameterLimits request, String locoType) {
		WheelParamKey key = new WheelParamKey();
		key.setAarRoad(request.getAarRoad());
		key.setCustomerId(request.getCustomerId());
		key.setLocoType(locoType);
		key.setWheelParameter(request.getWheelParameter());
		return key;
	}

	public ParamLimits mapParamLimits(WheelParameterLimits parameterLimits) {
		ParamLimits limits = new ParamLimits();
		limits.setUpperLimit(parameterLimits.getUpperLimit());
		limits.setLowerLimit(parameterLimits.getLowerLimit());
		limits.setLastUpdatedBy(parameterLimits.getLastUpdatedBy());
		return limits;
	}

	public void isObjExist(WheelParameterLimitResponse response, WheelparamLimits saveParamLimits) {
		if (Objects.nonNull(saveParamLimits)) {
			Optional<WheelparamLimits> findAny = response.getWheelparamLimits().stream()
					.filter(limit -> limit.getId().equalsIgnoreCase(saveParamLimits.getId())).findAny();
			if (!findAny.isPresent()) {
				response.getWheelparamLimits().add(saveParamLimits);
			}
		}
	}
	
	@Override
	public WheelConfigResponse getAdminConfiguration(WheelConfigRequest wheelConfigRequest, String uuId) {
		WheelConfigResponse response = new WheelConfigResponse();
		StatusType statusType = null;
		logger.info(uuId + " validateRequestParams for wheelConfigRequest" );
		try {
			statusType = wheelServiceValidator.validateRequestParams(wheelConfigRequest, uuId);
			if (Objects.nonNull(statusType)) {
				response.setStatus(statusType);
				logger.info(uuId + " validation failed for wheelConfigRequest" );

			} else {
				response = populateAdminData(wheelConfigRequest, uuId);
			}
		} catch (Exception e) {
			statusType = WheelServiceUtil.sendErrorStatusType(e, uuId);
			response.setStatus(statusType);
			return response;
		}
		return response;
	}

	private WheelConfigResponse populateAdminData(WheelConfigRequest wheelConfigRequest, String uuId) {
		WheelConfigResponse wheelConfigResponse = new WheelConfigResponse();
		Long custId = wheelConfigRequest.getCustId();
		String aar = wheelConfigRequest.getAarRoad();
		List<String> locoType = wheelConfigRequest.getLocoType();
		logger.info(uuId + "populateAdminData for Customer id : " + custId + " aar  " + aar);
		locoType.forEach(loco -> logger.info(uuId + " loco " + loco));
		int locoCount = locoType.size();
		StatusType statusType = new StatusType();
		List<WheelParamLimits> paramLimits = wheelParamLimitsRepository
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(
						custId, aar, false, locoType);
		if (!paramLimits.isEmpty()) {
			populateWheelConfigResp(uuId, wheelConfigResponse, custId, aar, locoCount, statusType, paramLimits);

		} else {
			setResponseStatus(wheelConfigResponse, statusType);
		}
		if (!wheelConfigResponse.getLimitRecords().isEmpty()) {
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
			wheelConfigResponse.setStatus(statusType);
		}
		return wheelConfigResponse;
	}

	private void populateWheelConfigResp(String uuId, WheelConfigResponse wheelConfigResponse, Long custId, String aar,
			int locoCount, StatusType statusType, List<WheelParamLimits> paramLimits) {
		logger.info(uuId + " Customer id : " + custId + " aar " + aar + " locoCount " + locoCount
				+ " No of wheelsParams " + paramLimits.size());
		if (locoCount > 1) {
			logger.info(uuId + " More than one loco");
			List<String> wheelParams = paramLimits.stream().map(limit -> limit.getWheelParamKey().getWheelParameter()).distinct()
					.collect(Collectors.toList());
			logger.info(uuId + " No of distinct wheel parameters " + wheelParams.size());
			for (String wheelParam : wheelParams) {
				compareConfigforEachParam(uuId, wheelConfigResponse, locoCount, statusType, paramLimits, wheelParam);
			}
		} else {
			logger.info(uuId + " Single loco seleted");
			List<WheelParamLimits> limitParam = paramLimits.stream().map(limit -> {
			List<ParamLimits> activeLimits = limit.getParamLimits().stream().filter(limit1 -> Boolean.compare(limit1.isDelete(),false) == 0).collect(Collectors.toList());
			limit.setParamLimits(activeLimits);
			return limit;
			}).collect(Collectors.toList());
			limitParam.stream()
					.forEach(limit -> wheelConfigResponse.getLimitRecords().add(mapWheelParameters(limit)));
		}
	}

	private void compareConfigforEachParam(String uuId, WheelConfigResponse wheelConfigResponse, int locoCount,
			StatusType statusType, List<WheelParamLimits> paramLimits, String wheelParam) {
		List<WheelParamLimits> currentWheelParam = paramLimits.stream()
				.filter(param -> (wheelParam.equalsIgnoreCase(param.getWheelParamKey().getWheelParameter()))).collect(Collectors.toList());
		List<WheelParamLimits> limitParam = currentWheelParam.stream().map(limit -> {						
			List<ParamLimits> activeLimits = limit.getParamLimits().stream().filter(limit1 -> Boolean.compare(limit1.isDelete(),false) == 0).collect(Collectors.toList());
			limit.setParamLimits(activeLimits);
			return limit;
			}).collect(Collectors.toList());					
		if (!limitParam.isEmpty()) {
			int wParamCount = limitParam.size();
			logger.info(uuId + " No of rows for  " + wheelParam + " : " + wParamCount);
			if (wParamCount == locoCount) {
				compareForEach(uuId, wheelConfigResponse, statusType, wheelParam, limitParam);
			} else {
				logger.info(uuId + " " + wheelParam + " exists for some of the locos");
				setResponseStatus(wheelConfigResponse, statusType);
			}
		}
	}

	public void compareForEach(String uuId, WheelConfigResponse wheelConfigResponse, StatusType statusType,
			String wheelParam, List<WheelParamLimits> limitParam) {
		logger.info(uuId + " Records available in db for all locos for param: " + wheelParam);
		for (int index = 0; index < limitParam.size() - 1; index++) {
			if (Double.compare(limitParam.get(index).getParamLimits().get(0).getLowerLimit(),
					limitParam.get(index + 1).getParamLimits().get(0).getLowerLimit()) == 0
					&& Double.compare(limitParam.get(index).getParamLimits().get(0).getUpperLimit(),
							limitParam.get(index + 1).getParamLimits().get(0).getUpperLimit()) == 0) {
				logger.info(uuId + " Matching limits for: " + wheelParam);
				if (index == limitParam.size() - 2) {
					logger.info(uuId + " Limits matching for all locos for : " + wheelParam);
					wheelConfigResponse.getLimitRecords().add(mapWheelParameters(limitParam.get(index)));
				}
			} else {
				logger.info(uuId + " " + wheelParam
						+ " exists for all locos, but with different lower and upper limits");
				setResponseStatus(wheelConfigResponse, statusType);
				break;
			}
		}
	}

	private void setResponseStatus(WheelConfigResponse wheelConfigResponse, StatusType statusType) {
		statusType.setStatusCode(StatusCode.SUCCESS);
		statusType.setMessage("No matching configuration");
		wheelConfigResponse.setStatus(statusType);
	}

	private WheelConfigRecord mapWheelParameters(WheelParamLimits limitRecord) {
		WheelConfigRecord wheelConfigRecord = new WheelConfigRecord();
		wheelConfigRecord.setWheelParameter(limitRecord.getWheelParamKey().getWheelParameter());
		wheelConfigRecord.setLowerLimit(limitRecord.getParamLimits().get(0).getLowerLimit());
		wheelConfigRecord.setUpperLimit(limitRecord.getParamLimits().get(0).getUpperLimit());
		return wheelConfigRecord;
	}


	@Override
	public DeleteParamResponse deleteWheelParam(DeleteParamRequest deleteParamRequest, String uuId) {
		DeleteParamResponse deleteParmResponse = new DeleteParamResponse();
		StatusType statusType = null;
		try {
			logger.info(uuId + " starting service to delete wheelparam");
			statusType = wheelServiceValidator.validateRequestParams(deleteParamRequest, uuId);
			if (Objects.nonNull(statusType)) {
				deleteParmResponse.setStatusType(statusType);
			} else {
				deleteParmResponse = updateDeleteWheelParamFlag(deleteParamRequest, uuId);
			}
		} catch (Exception e) {
			statusType = WheelServiceUtil.sendErrorStatusType(e, uuId);
			deleteParmResponse.setStatusType(statusType);
		}
		logger.info(uuId + " service to delete wheelparam is executed ");
		return deleteParmResponse;
	}

	public DeleteParamResponse updateDeleteWheelParamFlag(DeleteParamRequest deleteParamRequest, String uuId) {
		List<WheelParamLimits> paramLimitsList = null;
		List<WheelParamLimits> updatedLimitsList = new ArrayList<>();
		StatusType statusType = new StatusType();
		DeleteParamResponse deleteParamResponse = new DeleteParamResponse();
		logger.info(uuId + " Inside updateDeleteWheelParamFlag() ");
		Long custId = deleteParamRequest.getCustomerId();
		String aarRoad = deleteParamRequest.getAarRoad();
		List<String> locoType = deleteParamRequest.getLocoType();
		String wheelParam = deleteParamRequest.getWheelParameter();
		logger.info(uuId + " Before fetching the wheeldetails");
		paramLimitsList = wheelParamLimitsRepository
				.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoTypeIn(
						custId, aarRoad, wheelParam, locoType);

		for (WheelParamLimits wheelParamLimits : paramLimitsList) {
			if (!wheelParamLimits.getWheelParamKey().isDelete()) {
				wheelParamLimits.getWheelParamKey().setDelete(true);
				updatedLimitsList.add(wheelParamLimits);
			}
		}
		if (updatedLimitsList.isEmpty()) {
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage(WheelConstants.NO_RECORD_AVAILABLE);
		} else {
			List<WheelparamLimits> wheelList = wheelPersistanceService.saveParamLimitsList(updatedLimitsList);
			if (!wheelList.isEmpty())
			{
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
			}
			else
			{
				statusType.setStatusCode(StatusCode.FAILED);
				statusType.setMessage(WheelConstants.UNABLE_TO_DELETE_DATA);
			}

		}
		deleteParamResponse.setStatusType(statusType);
		logger.info(uuId + " After setting the response");
		return deleteParamResponse;
	}
	
	private void findUserNames(List<WheelParamLimits> paramLimits, String uuId) {
		List<Long> userNames = new ArrayList<>();
		paramLimits.stream().forEach(param -> {
			List<String> users = param.getParamLimits().stream().map(ParamLimits::getLastUpdatedBy).distinct()
					.collect(Collectors.toList());
			List<Long> userIds = users.stream().map(user -> Long.valueOf(user)).collect(Collectors.toList());
			userNames.addAll(userIds);
		});
		logger.info(uuId + " Calling common service to fetch userdetails");
		GetLmsEmployeeResponse resp = getNameforUser(userNames);
		paramLimits.stream().forEach(param -> param.getParamLimits().stream().forEach(limit -> 
			resp.getGetsLMSUsers().forEach(user -> {
				if (user.getUserId().equalsIgnoreCase(limit.getLastUpdatedBy())) {
					limit.setLastUpdatedBy(user.getFirstName() + " " + user.getLastName());
				}
			}
		)));
		logger.info(uuId + " After getting the response from common service");
	}

	private GetLmsEmployeeResponse getNameforUser(List<Long> userNames) {
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getUserProfileUrl());
		GetLmsEmployeeRequest request = new GetLmsEmployeeRequest();
		request.getUserId().addAll(userNames);
		GetLmsEmployeeResponse resp =  restUtility.callCorePostService(request, new GetLmsEmployeeResponse(), stringbuilder.toString(),
				"AdminServiceImpl: ");
		return resp;
	}
}
