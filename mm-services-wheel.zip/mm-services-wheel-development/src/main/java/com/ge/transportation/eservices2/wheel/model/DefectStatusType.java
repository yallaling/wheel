package com.ge.transportation.eservices2.wheel.model;


public enum DefectStatusType {
	OPEN("OPEN"),
	COMPLETED("COMPLETED");

	private final String typeShortName;

	DefectStatusType(String typeShortName) {
		this.typeShortName = typeShortName;
	}

	public String getValue() {
		return this.typeShortName;
	}

	@Override
	public String toString() {
		return this.getValue();
	}
}
