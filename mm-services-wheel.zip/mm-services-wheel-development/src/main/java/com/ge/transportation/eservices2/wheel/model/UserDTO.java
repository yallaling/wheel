package com.ge.transportation.eservices2.wheel.model;

import java.util.Date;

public class UserDTO {

	private Date createdAt;
	private Date updatedAt;
	private UserProfileDTO createdBy;
	private UserProfileDTO updatedBy;
	
	public UserDTO() {
		// Default Constructor
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public UserProfileDTO getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(UserProfileDTO createdBy) {
		this.createdBy = createdBy;
	}

	public UserProfileDTO getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(UserProfileDTO updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	
}
