package com.ge.transportation.eservices2.wheel.docdb.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class WheelParameters {

	@Id
	private String id;
	private String customerId;
	private String methodId;
	private String dimensionId;
	private String wheelAdminId;
	private String measuredWheelL;
	private String measuredAxleL;
	private String measuredBogieL;
	private String measuredLocoL;
	private String createdBy;
	private String creationDate;
	private String lastUpdatedBy;
	private String lastUpdatedDate;

	public WheelParameters() {
		// Default Constructor
	}
	
	public String getWheelAdminId() {
		return wheelAdminId;
	}

	public void setWheelAdminId(String wheelAdminId) {
		this.wheelAdminId = wheelAdminId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMethodId() {
		return methodId;
	}

	public void setMethodId(String methodId) {
		this.methodId = methodId;
	}

	public String getDimesnionId() {
		return dimensionId;
	}

	public void setDimesnionId(String dimesnionId) {
		this.dimensionId = dimesnionId;
	}

	public String getMeasuredWheelL() {
		return measuredWheelL;
	}

	public void setMeasuredWheelL(String measuredWheelL) {
		this.measuredWheelL = measuredWheelL;
	}

	public String getMeasuredAxleL() {
		return measuredAxleL;
	}

	public void setMeasuredAxleL(String measuredAxleL) {
		this.measuredAxleL = measuredAxleL;
	}

	public String getMeasuredBogieL() {
		return measuredBogieL;
	}

	public void setMeasuredBogieL(String measuredBogieL) {
		this.measuredBogieL = measuredBogieL;
	}

	public String getMeasuredLocoL() {
		return measuredLocoL;
	}

	public void setMeasuredLocoL(String measuredLocoL) {
		this.measuredLocoL = measuredLocoL;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	@Override
	public String toString() {
		return "WheelParameters [id=" + id + ", customerId=" + customerId + ", methodId=" + methodId + ", dimesnionId="
				+ dimensionId + ", wheelAdminId=" + wheelAdminId + ", measuredWheelL=" + measuredWheelL
				+ ", measuredAxleL=" + measuredAxleL + ", measuredBogieL=" + measuredBogieL + ", measuredLocoL="
				+ measuredLocoL + ", createdBy=" + createdBy + ", creationDate=" + creationDate + ", lastUpdatedBy="
				+ lastUpdatedBy + ", lastUpdatedDate=" + lastUpdatedDate + "]";
	}

	

}
