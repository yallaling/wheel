package com.ge.transportation.eservices2.wheel.util;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.log4j.Logger;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class RestTemplateFactory {

	private static final Logger logger = Logger.getLogger(RestTemplateFactory.class);

	private static final String TL_SV1_1 = "TLSv1.1";
	private static final String TL_SV1_2 = "TLSv1.2";

	public RestTemplate getRestTemplate(String userName, String password) {
		return new RestTemplate(setAuthenticationParameters(userName, password));
	}

	private ClientHttpRequestFactory setAuthenticationParameters(String userName, String password) {
		Credentials credentials;
		SSLContext sslContext;
		SSLConnectionSocketFactory sslConnectionSocketFactory = null;
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
		try {
			sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
			sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext, new String[] { TL_SV1_2, TL_SV1_1 },
					null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
			logger.error("Error while SSL Connection Socket " + e);
		}
		// Set credentials
		credentials = new UsernamePasswordCredentials(userName, password);
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(AuthScope.ANY, credentials);

		// Bind credentialsProvider to httpClient
		HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
		httpClientBuilder.setDefaultCredentialsProvider(credsProvider);
		if (null != sslConnectionSocketFactory)
			httpClientBuilder.setSSLSocketFactory(sslConnectionSocketFactory);
		httpClientBuilder.setSSLHostnameVerifier(new NoopHostnameVerifier());
		CloseableHttpClient httpClient = httpClientBuilder.build();
		return new HttpComponentsClientHttpRequestFactory(httpClient);
	}
}
