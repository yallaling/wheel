package com.ge.transportation.eservices2.wheel.config;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.securitytoken.AWSSecurityTokenServiceClientBuilder;
import com.amazonaws.services.securitytoken.model.AssumeRoleRequest;
import com.amazonaws.services.securitytoken.model.AssumeRoleResult;
import com.amazonaws.services.securitytoken.model.Credentials;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;

@Configuration
public class AWSConnectionManagerBean {
	private static final Logger logger = Logger.getLogger(AWSConnectionManagerBean.class);

	@Autowired
	private AppConfig appConfig;

	@Bean(name = "s3Client")
	@Scope(value=WebApplicationContext.SCOPE_REQUEST, proxyMode=ScopedProxyMode.TARGET_CLASS)
	public AmazonS3 getS3Client() {
		ClientConfiguration clientConfiguration = getClientConfiguration();
		BasicSessionCredentials sessionCredentials = getSessionCredentials(clientConfiguration,
				appConfig.getAwsRoleARN());
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(sessionCredentials)).withRegion(Regions.US_EAST_1)
				.withClientConfiguration(clientConfiguration).build();
		logger.info("AWS s3Client Instance Created..");
		return s3Client;
	}

	
	public BasicSessionCredentials getSessionCredentials(ClientConfiguration clientConfiguration, String roleArn) {
		AssumeRoleResult assumeRoleResult =  AWSSecurityTokenServiceClientBuilder
				.standard().withClientConfiguration(clientConfiguration).withRegion(Regions.US_EAST_1).build()
						.assumeRole((new AssumeRoleRequest()).withRoleArn(roleArn)
								.withRoleSessionName(appConfig.getAwsSessionName()));
		Credentials credentials = assumeRoleResult.getCredentials();
		return new BasicSessionCredentials(credentials.getAccessKeyId(), credentials.getSecretAccessKey(),
				credentials.getSessionToken());

	}

	public ClientConfiguration getClientConfiguration() {
		Properties sysProp = System.getProperties();
		sysProp.setProperty(appConfig.getAwsAccessKey(), appConfig.getAwsAccessKeyId());
		sysProp.setProperty(appConfig.getAwsSecretAccess(), appConfig.getAwsSecretAccessKey());
		sysProp.setProperty(WheelConstants.DIASABLE_CERT_CHECKING, Boolean.TRUE.toString());

		ClientConfiguration clientConfiguration = new ClientConfiguration();
		clientConfiguration.setProtocol(Protocol.HTTPS);
		if (appConfig.isAwsProxyEnabled()) {
			clientConfiguration.setProxyHost(appConfig.getAwsProxyHost());
			clientConfiguration.setProxyPort(80);
		}
		return clientConfiguration;
	}

}
