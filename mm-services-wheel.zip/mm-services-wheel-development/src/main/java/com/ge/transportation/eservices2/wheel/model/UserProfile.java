package com.ge.transportation.eservices2.wheel.model;

public class UserProfile {

	private Integer userId;
	private String  firstName;
	private String  lastName;
	private String  loginId;
	private String  emailAddress;
	private Integer defaultLanguageId;
	private String  defaultLanguage;	
	private Integer defaultLocaleId;
	private String  defaultLocale;
	private Integer levelThreeTenancyId;
	private String  dateFormat;
	private String  numberFormat;
	private String  currencyFormat;
	private String  calanderStart;
	private String  timeZone;
	private String  timeFormat;
	private String  status;
	private Integer levelTwoTenancyId;
	private Integer levelOneTenacyId;
	private Integer serviceOrganizationId;
	private String employeeClass;

	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public Integer getDefaultLanguageId() {
		return defaultLanguageId;
	}
	public void setDefaultLanguageId(Integer defaultLanguageId) {
		this.defaultLanguageId = defaultLanguageId;
	}
	public String getDefaultLanguage() {
		return defaultLanguage;
	}
	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}
	public Integer getDefaultLocaleId() {
		return defaultLocaleId;
	}
	public void setDefaultLocaleId(Integer defaultLocaleId) {
		this.defaultLocaleId = defaultLocaleId;
	}
	public String getDefaultLocale() {
		return defaultLocale;
	}
	public void setDefaultLocale(String defaultLocale) {
		this.defaultLocale = defaultLocale;
	}
	public Integer getLevelThreeTenancyId() {
		return levelThreeTenancyId;
	}
	public void setLevelThreeTenancyId(Integer levelThreeTenancyId) {
		this.levelThreeTenancyId = levelThreeTenancyId;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	public String getNumberFormat() {
		return numberFormat;
	}
	public void setNumberFormat(String numberFormat) {
		this.numberFormat = numberFormat;
	}
	public String getCurrencyFormat() {
		return currencyFormat;
	}
	public void setCurrencyFormat(String currencyFormat) {
		this.currencyFormat = currencyFormat;
	}
	public String getCalanderStart() {
		return calanderStart;
	}
	public void setCalanderStart(String calanderStart) {
		this.calanderStart = calanderStart;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getTimeFormat() {
		return timeFormat;
	}
	public void setTimeFormat(String timeFormat) {
		this.timeFormat = timeFormat;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getLevelTwoTenancyId() {
		return levelTwoTenancyId;
	}
	public void setLevelTwoTenancyId(Integer levelTwoTenancyId) {
		this.levelTwoTenancyId = levelTwoTenancyId;
	}
	public Integer getLevelOneTenacyId() {
		return levelOneTenacyId;
	}
	public void setLevelOneTenacyId(Integer levelOneTenacyId) {
		this.levelOneTenacyId = levelOneTenacyId;
	}
    public Integer getServiceOrganizationId() {
        return serviceOrganizationId;
    }

    public void setServiceOrganizationId(Integer serviceOrganizationId) {
        this.serviceOrganizationId = serviceOrganizationId;
    }

    /**
	 * @return the employeeClass
	 */
	public String getEmployeeClass() {
		return employeeClass;
	}
	/**
	 * @param employeeClass the employeeClass to set
	 */
	public void setEmployeeClass(String employeeClass) {
		this.employeeClass = employeeClass;
	}
        
}
