package com.ge.transportation.eservices2.wheel.util;

import java.util.UUID;

public class UniqueIdGenerator {

	public String getUUID() {
        return Long.toString(UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE);
    }
	
}
