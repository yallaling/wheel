package com.ge.transportation.eservices2.wheel.service;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.WheelparamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamKey;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey;

@Service
public interface WheelPersistanceService {

	public void saveMetadata(String uuId, String file, FileStatus error, String locomotiveId, String lastModifiedDate);

	String isValidFile(Long locomotiveID, String fileName, String uuId);

	public WheelParamLimits findByWheelParamKey(WheelParamKey wheelParamKey);

	public WheelparamLimits saveParamLimits(WheelParamLimits limitsCollection);
	
	public List<WheelparamLimits> saveParamLimitsList(List<WheelParamLimits> paramLimitsList);

	public WheelSheetDataCollection getWheelSheetDetiails(WheelSheetKey wheelSheetKey);

	public WheelSheetDataCollection saveWheelSheetDetails(WheelSheetDataCollection docWheelSheetDetails);

}
