package com.ge.transportation.eservices2.wheel.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey;

@Repository
public interface WheelSheetRepository extends MongoRepository<WheelSheetDataCollection, String>{

	WheelSheetDataCollection findByWheelSheetKey(WheelSheetKey wheelSheetKey);
	WheelSheetDataCollection findByWheelSheetWorkorderId(Long workorderId);
	WheelSheetDataCollection findByWheelSheetKeyAndWheelSheetWorkorderId(WheelSheetKey wheelSheetKey,Long workorderId);
	
	
}
