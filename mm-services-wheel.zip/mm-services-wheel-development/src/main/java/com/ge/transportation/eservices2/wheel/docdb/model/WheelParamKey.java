package com.ge.transportation.eservices2.wheel.docdb.model;

import java.io.Serializable;

public class WheelParamKey implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long customerId;
	private String aarRoad;
	private String locoType;
	private String wheelParameter;
	private boolean delete;

	public WheelParamKey() {
		// Default constructor
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getAarRoad() {
		return aarRoad;
	}

	public void setAarRoad(String aarRoad) {
		this.aarRoad = aarRoad;
	}

	public String getLocoType() {
		return locoType;
	}

	public void setLocoType(String locoType) {
		this.locoType = locoType;
	}

	public String getWheelParameter() {
		return wheelParameter;
	}

	public void setWheelParameter(String wheelParameter) {
		this.wheelParameter = wheelParameter;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}
	
}