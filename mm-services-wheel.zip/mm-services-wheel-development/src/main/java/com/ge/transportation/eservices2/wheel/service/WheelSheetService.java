package com.ge.transportation.eservices2.wheel.service;

import org.springframework.stereotype.Service;

import com.ge.transportation.eservices2.domainobjects.FileDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.FileDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsRequest;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsResponse;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetRequestDetails;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetResponse;
import com.ge.transportation.eservices2.domainobjects.ShimDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.VisibleDefectsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWORequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWOResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetResponse;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailRequest;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailResponse;


@Service
public interface WheelSheetService {

	FileMeasurementsResponse loadFileMeasurements(FileMeasurementsRequest fileMeasurementsRequest, String uuId);

	FileDetailsResponse retrieveFileDetails(FileDetailsRequest fileDetailsRequest, String uuId);

	ShimDetailsResponse retrieveShimDetails(String uuId);

	VisibleDefectsResponse retrieveVisDefectsDetails(String uuId);

	WheelSheetDetailsResponse saveWheelSheetDetails(String uuId, WheelSheetDetailsRequest wheelSheetDetailsRequest);

	WheelSheetForWOResponse getWheelSheetDetails(String uuId, WheelSheetForWORequest wheelSheetHistoryRequest);

	WheelSheetResponse getWheelSheet(String uuId, WheelSheetRequest wheelSheetRequest);

	PastWheelSheetResponse getPastWheelSheetDetails(String uuId,PastWheelSheetRequestDetails pastWheelSheetRequestDetails);

	WheelSheetDetailsResponse getDiameterCalculation(String uuId, WheelSheetDetailsRequest wheelSheetDetailsRequest);
	
	WheelSheetNameDetailsResponse validateAndSaveWheelSheetDetails(String uuId,WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest);
	
	
}
