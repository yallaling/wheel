package com.ge.transportation.eservices2.wheel.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.mongodb.MongoClientOptions;

@Configuration
public class MongoConfiguration {

	private static final Logger LOG = LoggerFactory.getLogger(MongoConfiguration.class);

	public MongoConfiguration(Environment env) {
		super();
		LOG.info("Setting system property: {}", env.getProperty("mm.mongo.truthstore.path"));

		System.setProperty("javax.net.ssl.trustStore", env.getProperty("mm.mongo.truthstore.path"));
		System.setProperty("javax.net.ssl.trustStorePassword", env.getProperty("wheel.mongo.security.truthstore_pwd"));
		System.setProperty("https.protocols", "TLSv1.2,TLSv1.1,TLSv1");
	}

	@Bean
	public MongoClientOptions mongoClientOptions() {
		return MongoClientOptions.builder().sslEnabled(true).sslInvalidHostNameAllowed(true).build();
	}

}