package com.ge.transportation.eservices2.wheel.awss3.service;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public interface AWSFileHandlerService {

	public InputStream getFileAsInputStream(String s3ObjectKey, String uuId);
	
	public boolean putFile(String s3ObjectKey, File fileToUpload, String uuId);
	
	public boolean moveFile(String from, String to, String uuid);
	
	public boolean copyFileFromKey(String from, String to, String uuId);

	boolean deleteFileUsingKey(String from, String uuId);

	S3Object getS3Object(String s3ObjectKey, String uuId);

	public List<S3ObjectSummary> listOfFiles(String uuId);

	public PutObjectResult uploadFileAsInputStream(String uuId, String key, InputStream multiPartStream, String folderName);

}
