package com.ge.transportation.eservices2.wheel.docdb.model;

public class LocomotiveAll {

	private Long locomotiveId;

	private String aarNumber;

	private String aarRoad;

	private Long customerId;

	private Long fleetId;

	private String roadNumber;
	
	private String locomotiveStatusCode;

	private String locomotiveTypeCode;

	public LocomotiveAll() {
		/* 
		 * No-argument constructor
		 * 
		 */
	}

	public Long getLocomotiveId() {
		return locomotiveId;
	}

	public void setLocomotiveId(Long locomotiveId) {
		this.locomotiveId = locomotiveId;
	}

	public String getAarNumber() {
		return aarNumber;
	}

	public void setAarNumber(String aarNumber) {
		this.aarNumber = aarNumber;
	}

	public String getAarRoad() {
		return aarRoad;
	}

	public void setAarRoad(String aarRoad) {
		this.aarRoad = aarRoad;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getFleetId() {
		return fleetId;
	}

	public void setFleetId(Long fleetId) {
		this.fleetId = fleetId;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public String getLocomotiveStatusCode() {
		return locomotiveStatusCode;
	}

	public void setLocomotiveStatusCode(String locomotiveStatusCode) {
		this.locomotiveStatusCode = locomotiveStatusCode;
	}

	public String getLocomotiveTypeCode() {
		return locomotiveTypeCode;
	}

	public void setLocomotiveTypeCode(String locomotiveTypeCode) {
		this.locomotiveTypeCode = locomotiveTypeCode;
	}
	
	

}