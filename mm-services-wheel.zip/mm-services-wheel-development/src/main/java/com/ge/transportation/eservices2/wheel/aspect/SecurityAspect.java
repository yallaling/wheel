package com.ge.transportation.eservices2.wheel.aspect;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.datatype.XMLGregorianCalendar;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;
import org.springframework.web.multipart.MultipartFile;

import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;

@Aspect
@Component
public class SecurityAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(SecurityAspect.class);
	private static final String errorMessage = "Malicious input found in the request!!!!, Request cannot be processed";

	@Autowired
	private AppConfig appConfig;

	private static Pattern[] patterns = new Pattern[] {
			// Script fragments
			Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE),
			// src='...'
			Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
			Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
					Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
			// lonely script tags
			Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
			Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
			// eval(...)
			Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
			// expression(...)
			Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
			// javascript:...
			Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
			// vbscript:...
			Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
			// onload(...)=...
			Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL) };

	@SuppressWarnings("rawtypes")
	@Before(value = "execution(* com.ge.transportation.eservices2.wheel.controller.*.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {

		long start = System.currentTimeMillis();
		final Signature signature = joinPoint.getSignature();
		try {
			if (null != appConfig.getSecurityEnabled() && "true".equalsIgnoreCase(appConfig.getSecurityEnabled())
					&& signature instanceof MethodSignature) {
				LOGGER.info("Before method::" + signature.getName());
				LOGGER.info("Signature:::" + signature);
				LOGGER.info("Value : " + Arrays.toString(joinPoint.getArgs()));
				LOGGER.info("Target class : " + joinPoint.getTarget().getClass().getName());
				LOGGER.info("This class : " + joinPoint.getThis().getClass().getName());

				String className = joinPoint.getSignature().getDeclaringTypeName();
				String methodName = joinPoint.getSignature().getName();

				MethodSignature ms = (MethodSignature) signature;
				Method method = ms.getMethod();
				Annotation[][] parameterAnnotations = method.getParameterAnnotations();
				String[] parameterNames = ms.getParameterNames();
				Class[] parameterTypes = method.getParameterTypes();
				for (int i = 0; i < parameterAnnotations.length; i++) {
					validateParameter(parameterNames[i], joinPoint.getArgs()[i], parameterTypes[i]);
				}

				long elapsedTime = System.currentTimeMillis() - start;
				LOGGER.info(
						"Method " + className + "." + methodName + " ()" + " execution time : " + elapsedTime + " ms");
			}

		} catch (IllegalArgumentException | IllegalAccessException e) {
			LOGGER.error("Illegal argument " + Arrays.toString(joinPoint.getArgs()) + " in "
					+ joinPoint.getSignature().getName() + "()");
			throw new WheelsException(e);
		}
	}

	private void validateParameter(String paramName, Object object, Class parameterTypes)
			throws IllegalAccessException {
		LOGGER.info("paramName:: " + paramName + "::object::" + object + "::parameterTypes::" + parameterTypes);

		if (null != parameterTypes
				&& (parameterTypes.equals(java.lang.String.class) || ClassUtils.isPrimitiveOrWrapper(parameterTypes))) {
			sanatizeHeadersAndParameters(parameterTypes, object);
		}
		if (null != parameterTypes && null != object && !parameterTypes.equals(java.lang.String.class)
				&& !ClassUtils.isPrimitiveOrWrapper(parameterTypes)) {
			sanatizedAllFields(object);
		}
	}

	private void sanatizeHeadersAndParameters(Class parameterTypes, Object object) {

		LOGGER.info(":Canonical name of parameter types:" + parameterTypes);
		if (null != parameterTypes && null != object && parameterTypes.equals(java.lang.String.class)
				&& stripXSS(object.toString())) {
			LOGGER.error(errorMessage);
			throw new WheelsException(errorMessage);
		} else if (null != parameterTypes && null != object && ClassUtils.isPrimitiveOrWrapper(parameterTypes)
				&& stripXSS(object.toString())) {
			LOGGER.error(errorMessage);
			throw new WheelsException(errorMessage);
		}
	}

	private Boolean stripXSS(String value) {
		if (value != null) {
			String newValue = ESAPI.encoder().canonicalize(value);
			newValue = newValue.replaceAll("\0", "");

			// Remove all sections that match a pattern
			for (Pattern scriptPattern : patterns) {
				if (scriptPattern.matcher(newValue).matches()) {
					return true;
				}
			}
		}
		return false;
	}

	private void sanatizedAllFields(Object object) throws IllegalAccessException {
		Class c1 = object.getClass();
		LOGGER.info("Class name got is:: " + c1.getName());
		Field[] valueObjFields = c1.getDeclaredFields();
		if (null != valueObjFields) {
			sanitizeBodyAttributes(valueObjFields, object);
		}

	}

	private void sanitizeBodyAttributes(Field[] valueObjFields, Object object) throws IllegalAccessException {

		if(!(object instanceof MultipartFile)) {
		for (Field field : valueObjFields) {
			field.setAccessible(true);
			Object key = field.getName();
			Object value = field.get(object);
			LOGGER.info("key::" + key + "::value::" + value);
			if (null != value) {
				LOGGER.info("::value class::" + value.getClass());
			}
			if (field.getType().getEnumConstants() != null) {
				String enums = Arrays.toString(field.getType().getEnumConstants());
				LOGGER.info("enums::" + enums);
			}
			if (null != value && stripXSS(value.toString())) {
				LOGGER.error(errorMessage);
				throw new WheelsException(errorMessage);
			}
			if (isPrimitiveOrCollection(value) && field.getType().getEnumConstants() == null) {
				sanitizeBodyAttributes(value.getClass().getDeclaredFields(), value);
			}

			if (null != value && Collection.class.isInstance(value)) {
				sanitize(value);
			}
		}
		}
	}

	private String sanitize(String value) {
		String sanitizedStr = null;

		if (null != value) {
			sanitizedStr = value.toLowerCase();
		}
		if (null != value && stripXSS(value)) {
			LOGGER.error(errorMessage);
			throw new WheelsException(errorMessage);
		}
		return sanitizedStr;
	}

	private Object sanitize(Object value) {
		if (value instanceof String) {
			return sanitize((String) value);
		}
		return value;
	}

	private Boolean isPrimitiveOrCollection(Object value) {
		if (null != value && !ClassUtils.isPrimitiveWrapper(value.getClass())
				&& !XMLGregorianCalendar.class.isInstance(value) && instanceCheck1(value)) {

			return true;
		}
		return false;
	}

	private boolean instanceCheck1(Object value) {
		if (!String.class.isInstance(value) && !ArrayList.class.isInstance(value) && instanceCheck2(value)) {
			return true;
		}
		return false;
	}

	private boolean instanceCheck2(Object value) {
		return !Map.class.isInstance(value) && !List.class.isInstance(value) && !Collection.class.isInstance(value);
	}

}
