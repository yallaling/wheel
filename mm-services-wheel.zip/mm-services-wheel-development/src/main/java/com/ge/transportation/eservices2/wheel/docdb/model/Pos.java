package com.ge.transportation.eservices2.wheel.docdb.model;

public class Pos {

	private PositionDetails pilotHeightLeft;
    private PositionDetails pilotHeightRight;
    private PositionDetails couplerHeight;
    
    public Pos() {
		// Default Constructor
	}

	public PositionDetails getPilotHeightLeft() {
		return pilotHeightLeft;
	}

	public void setPilotHeightLeft(PositionDetails pilotHeightLeft) {
		this.pilotHeightLeft = pilotHeightLeft;
	}

	public PositionDetails getPilotHeightRight() {
		return pilotHeightRight;
	}

	public void setPilotHeightRight(PositionDetails pilotHeightRight) {
		this.pilotHeightRight = pilotHeightRight;
	}

	public PositionDetails getCouplerHeight() {
		return couplerHeight;
	}

	public void setCouplerHeight(PositionDetails couplerHeight) {
		this.couplerHeight = couplerHeight;
	}
    
    
}
