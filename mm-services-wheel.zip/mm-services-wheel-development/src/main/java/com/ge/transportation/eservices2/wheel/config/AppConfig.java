package com.ge.transportation.eservices2.wheel.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class AppConfig {

	@Autowired
	Environment env;
	
	@Value("${mm.api.base_url}")
	private String baseUrl;

	@Value("${mm.api.td_base_url}")
	private String tdBaseUrl;

	
	@Value("${mm.api.user}")
	private String username;

	@Value("${mm.api.password}")
	private String password;

	@Value("${mm.api.wo.roadnumberValidation}")
	private String roadnumberValidation;
	
	@Value("${mm.api.wo.getwodetails}")
	private String workorderDetails;

	@Value("${mm.api.wo.getLocomotiveAllByLocomotiveId}")
	private String locomotiveAllByLocomotiveId;

	@Value("${mm.api.common.getMultipleUsers}")
	private String userProfileUrl;
	
	@Value("${mm.api.td.defect.createWheelSheetAutoDefect}")
	private String createWheelSheetDefectUrl;
	
	@Value("${mm.api.td.getUserDetails}")
	private String tdUserDetails;
	
	@Value("${aws.s3.cfg.awsAccessKeyId}")
	private String awsAccessKeyId;

	@Value("${aws.s3.cfg.awsBucketName}")
	private String awsBucketName;

	@Value("${aws.s3.cfg.awsRoleARN}")
	private String awsRoleARN;

	@Value("${aws.s3.cfg.awsSessionName}")
	private String awsSessionName;

	@Value("${aws.s3.environment}")
	private String awsEnv;

	@Value("${aws.s3.cfg.awsProxyEnabled}")
	private boolean awsProxyEnabled;

	@Value("${aws.s3.folder.awsS3WheelsPath}")
	private String awsS3Path;

	@Value("${aws.s3.cfg.awsProxyHost}")
	private String awsProxyHost;

	@Value("${aws.s3.folder.processing}")
	private String processing;

	@Value("${aws.s3.folder.error}")
	private String error;

	@Value("${aws.s3.folder.processed}")
	private String processed;
	
	@Value("${aws.s3.folder.unprocessed}")
	private String unProcessed;

	@Value("${wheel.security.enabled}")
	private String securityEnabled;
	
	@Value("${wheel.param.loconame}")
	private String locoName;
	
	@Value("${wheel.param.truckname}")
	private String truckName;
	
	@Value("${wheel.param.axlename}")
	private String axleName;
	
	@Value("${wheel.decimal.precision}")
	private int wheelDecimalPrecision;
	
	@Value("${wheel.xml.param.diameter}")
	private String xmlParamDiameter;
	
	@Value("${wheel.xml.param.rim.thickness}")
	private String xmlParamRimThickness;
	
	@Value("${wheel.db.param.diameter}")
	private String dbParamDiameter;
	
	public String getDBParamWheelDiameter() {
		return dbParamDiameter;
	}
	public String getXmlParamDiameter() {
		return xmlParamDiameter;
	}

	public String getXmlParamRimThickness() {
		return xmlParamRimThickness;
	}
	
	public String getLocoName() {
		return locoName;
	}

	public String getTruckName() {
		return truckName;
	}

	public String getAxleName() {
		return axleName;
	}


	public String getSecurityEnabled() {
		return securityEnabled;
	}

	public String getProcessing() {
		return processing;
	}

	public String getError() {
		return error;
	}

	public String getUnProcessed() {
		return unProcessed;
	}
	public String getAwsS3Path() {
		return awsS3Path;
	}

	public String getAwsAccessKeyId() {
		return awsAccessKeyId;
	}

	public String getAwsBucketName() {
		return awsBucketName;
	}

	public String getAwsRoleARN() {
		return awsRoleARN;
	}

	public String getAwsSessionName() {
		return awsSessionName;
	}

	public String getAwsEnv() {
		return awsEnv;
	}

	public boolean isAwsProxyEnabled() {
		return awsProxyEnabled;
	}

	public String getAwsSecretAccessKey() {
		return env.getProperty("aws.s3.cfg.awsSecretAccessKey");
	}

	public String getAwsProxyHost() {
		return awsProxyHost;
	}

	public String getBaseUrl() {
		return baseUrl;
	}
	
	public String getTdBaseUrl() {
		return tdBaseUrl;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getWorkorderDetails() {
		return workorderDetails;
	}

	public String getUserProfileUrl() {
		return userProfileUrl;
	}
	public String getAwsAccessKey() {
		return env.getProperty("aws.s3.cfg.awsAccessKey");
	}

	public String getAwsSecretAccess() {
		return env.getProperty("aws.s3.cfg.awsSecretAccess");
	}

	public String getLocomotiveAllByLocomotiveId() {
		return locomotiveAllByLocomotiveId;
	}

	public String getCreateWheelSheetDefectUrl() {
		return createWheelSheetDefectUrl;
	}

	public String getTdUserDetails() {
		return tdUserDetails;
	}

	public int getWheelDecimalPrecision() {
		return wheelDecimalPrecision;
	}

	public String getProcessed() {
		return processed;
	}
	public String getRoadnumberValidation() {
		return roadnumberValidation;
	}
	
}