/**
 * 
 */
package com.ge.transportation.eservices2.wheel.model;

/**
 * @author 212365823
 *
 */
public enum Flag {
	Y, 
	N, 
	L, 
	E2;
}
