package com.ge.transportation.eservices2.wheel.docdb.model;

import java.util.List;

import org.springframework.data.annotation.Transient;


/**
 * @author Shareef.TC
 *
 */
public class AxleProperties {

	private String axleName;
	@Transient
	private Integer axleNumber;
	private List<WheelProfile> wheelProfiles;
	
	public AxleProperties() {
		// Default Constructor
	}

	public String getAxleName() {
		return axleName;
	}

	public void setAxleName(String axleName) {
		this.axleName = axleName;
	}
	
	public Integer getAxleNumber() {
		return axleNumber;
	}

	public void setAxleNumber(Integer axleNumber) {
		this.axleNumber = axleNumber;
	}

	public List<WheelProfile> getWheelProfiles() {
		return wheelProfiles;
	}

	public void setWheelProfiles(List<WheelProfile> wheelProfiles) {
		this.wheelProfiles = wheelProfiles;
	}
	
}
