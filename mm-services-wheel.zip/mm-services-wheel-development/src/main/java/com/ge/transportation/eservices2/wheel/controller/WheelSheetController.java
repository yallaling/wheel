package com.ge.transportation.eservices2.wheel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.transportation.eservices2.domainobjects.FileDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.FileDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsRequest;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsResponse;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetRequestDetails;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetResponse;
import com.ge.transportation.eservices2.domainobjects.ShimDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.VisibleDefectsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWORequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWOResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetResponse;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailRequest;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailResponse;
import com.ge.transportation.eservices2.wheel.service.WheelSheetService;
import com.ge.transportation.eservices2.wheel.util.UniqueIdGenerator;

@RestController
@RequestMapping("/v1")
public class WheelSheetController {

	@Autowired
	WheelSheetService wheelSheetService;

	@PostMapping(value = "/wheelsheet/measurements")
	public FileMeasurementsResponse loadMeasurements(@RequestBody FileMeasurementsRequest fileMeasurementsRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.loadFileMeasurements(fileMeasurementsRequest, uuId);
	}
	
	@PostMapping(value = "/wheelsheet/filedetails")
	public FileDetailsResponse fetchFileDetails(@RequestBody FileDetailsRequest fileDetailsRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.retrieveFileDetails(fileDetailsRequest, uuId);
	}
	
	@GetMapping(value = "/wheelsheet/shimdetails")
	public ShimDetailsResponse fetchShimDetails() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.retrieveShimDetails(uuId);
	}

	@GetMapping(value = "/wheelsheet/visibledefectsdetails")
	public VisibleDefectsResponse fetchVisibleDefectsDetails() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.retrieveVisDefectsDetails(uuId);
	}

	@PostMapping(value = "/wheelsheet/wheelsheetdata")
	public WheelSheetDetailsResponse saveWheelSheetDetails(@RequestBody WheelSheetDetailsRequest wheelSheetDetailsRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.saveWheelSheetDetails(uuId,wheelSheetDetailsRequest);
	}
	
	@PostMapping(value = "/wheelsheet/getwheelsheetsforwo")
	public WheelSheetForWOResponse getWheelSheetDetails(@RequestBody WheelSheetForWORequest wheelSheetForWORequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.getWheelSheetDetails(uuId,wheelSheetForWORequest);
	}
	
	@PostMapping(value = "/wheelsheet/getwheelsheetdataforwo")
	public WheelSheetResponse getWheelSheet(@RequestBody WheelSheetRequest wheelSheetRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.getWheelSheet(uuId,wheelSheetRequest);
	}
	
	@PostMapping(value = "/wheelsheet/pastwheelsheet")
	public PastWheelSheetResponse fetchPastWheelSheetDetails(@RequestBody PastWheelSheetRequestDetails pastWheelSheetRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.getPastWheelSheetDetails(uuId,pastWheelSheetRequest);
	}
	
	@PostMapping(value = "/wheelsheet/diametercalculation")
	public WheelSheetDetailsResponse getDiameterCalculation(@RequestBody WheelSheetDetailsRequest wheelSheetDetailsRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.getDiameterCalculation(uuId,wheelSheetDetailsRequest);
	}
	
	@PostMapping(value = "/wheelsheet/validateandsavewheelsheetname")
	public WheelSheetNameDetailsResponse validateAndSaveWheelSheetName(@RequestBody WheelSheetNameDetailsRequest wheelSheetNameRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelSheetService.validateAndSaveWheelSheetDetails(uuId,wheelSheetNameRequest);
	}
	

}
