package com.ge.transportation.eservices2.wheel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.transportation.eservices2.domainobjects.DeleteParamRequest;
import com.ge.transportation.eservices2.domainobjects.DeleteParamResponse;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryRequest;
import com.ge.transportation.eservices2.domainobjects.LimitHistoryResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParamRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParamResponse;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitRequest;
import com.ge.transportation.eservices2.domainobjects.WheelParameterLimitResponse;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.service.AdminService;
import com.ge.transportation.eservices2.wheel.util.UniqueIdGenerator;

@RestController
@RequestMapping("/v1")
public class AdminController {

	@Autowired
	private AdminService adminService;

	@PostMapping(value = "/admin/wheelparams")
	public WheelParamResponse retrieveWheelParams(@RequestBody WheelParamRequest wheelParamRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		WheelParamResponse wheelParamResponse = new WheelParamResponse();
		StatusType statusType = new StatusType();
		try {
			if (null != wheelParamRequest.getCustId() && !("".equalsIgnoreCase(wheelParamRequest.getCustId()))) {
				wheelParamResponse = adminService.getWheelParameters(wheelParamRequest.getCustId(), uuId);
			} else {
				statusType.setStatusCode(StatusCode.FAILED);
				statusType.setMessage("Provide valid customer id");
				wheelParamResponse.setStatus(statusType);
			}
		} catch (Exception e) {
			statusType.setStatusCode(StatusCode.FAILED);
			statusType.setMessage("Unable to fetch wheel parameters");
			wheelParamResponse.setStatus(statusType);
			throw new WheelsException(e);
		}
		return wheelParamResponse;

	}

	@PostMapping(value = "/admin/history")
	public LimitHistoryResponse retrieveParamHistory(@RequestBody LimitHistoryRequest limitHistoryRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return adminService.getParamHistory(limitHistoryRequest, uuId);
		}

	@PostMapping(value = "/admin/wheelparamlimits")
	public WheelParameterLimitResponse persistByCustomer(
			@RequestBody WheelParameterLimitRequest wheelParameterRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return adminService.persistWheelParameterLimits(wheelParameterRequest, uuId);

	}

	@PostMapping(value = "/admin/wheelconfig")
	public WheelConfigResponse retrieveWheelConfiguration(@RequestBody WheelConfigRequest wheelConfigRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return adminService.getAdminConfiguration(wheelConfigRequest, uuId);
	}
	
	@PostMapping(value = "/admin/deletewheelparam")
	public DeleteParamResponse deleteWheelParamLimits(@RequestBody DeleteParamRequest deleteParamRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return adminService.deleteWheelParam(deleteParamRequest, uuId);
	}
}
