package com.ge.transportation.eservices2.wheel.docdb.model;

public class PositionDetails {

	private Side front;
	private Side back;
	    
	public PositionDetails() {
		// Default Constructor
	}

	public Side getFront() {
		return front;
	}

	public void setFront(Side front) {
		this.front = front;
	}

	public Side getBack() {
		return back;
	}

	public void setBack(Side back) {
		this.back = back;
	}
	
}
