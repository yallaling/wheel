/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2013 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *     
 ********************************************************************************/

package com.ge.transportation.eservices2.wheel.model;

/**
 * @author 502189821
 *
 */
public class Parent {
	public enum Type {
		WorkOrder, ServiceSheet, QualityPlan, Task;
	}
	
	private  Type type;
	private  Long id;
	private  String description;
	private  ServiceTypeCode serviceTypeCode;
	private  Parent grandParent;
	
	public Parent() {
		super();
	}
	
	public Parent(Type type, Long id) {
		this(type, id, null);
	}
	
	public Parent(Type type, Long id, String description) {
		this(type, id, description, null);
	}
	
	public Parent(Type type, Long id, String description, ServiceTypeCode serviceTypeCode) {
		this(type, id, description, serviceTypeCode, null);
	}
	
	public Parent(Type type, Long id, String description, ServiceTypeCode serviceTypeCode, Parent grandParent) {
		this.type = type;
		this.id = id;
		this.description = description;
		this.serviceTypeCode = serviceTypeCode;
		this.grandParent = grandParent;
	}
	
	public Type getType() {
		return type;
	}
	public Long getId() {
		return id;
	}
	public String getDescription() {
		return this.description;
	}
	public ServiceTypeCode getServiceSheetType() {
		return this.serviceTypeCode;
	}
	
	public Parent getGrandParent() {
		return this.grandParent;
	}

	public ServiceTypeCode getServiceTypeCode() {
		return serviceTypeCode;
	}

	public void setServiceSheetType(ServiceTypeCode serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setGrandParent(Parent grandParent) {
		this.grandParent = grandParent;
	}
	
}
