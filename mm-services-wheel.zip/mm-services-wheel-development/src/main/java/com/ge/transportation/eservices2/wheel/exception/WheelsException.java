package com.ge.transportation.eservices2.wheel.exception;

import java.io.StringWriter;

public class WheelsException extends RuntimeException {

	private static final long serialVersionUID = -958848778630176141L;
	private final String errorCode;
	private final String detail;

	public WheelsException() {
		// default method
		errorCode = null;
		detail = null;
	}

	/**
	 * The constructor takes a string message.
	 *
	 * @param aMessage Exception message
	 */
	public WheelsException(String aMessage) {
		super(aMessage);
		errorCode = null;
		detail = null;
	}

	/**
	 * The constructor takes an exception.
	 *
	 * @param aCause cause of the exception
	 */
	public WheelsException(Exception aCause) {
		super(aCause);
		errorCode = null;
		detail = convertException(aCause);
	}

	public WheelsException(Throwable t) {
		super(t);
		errorCode = null;
		detail = null;
		t.getMessage();
	}

	/**
	 * The constructor takes a string message and an exception.
	 *
	 * @param aMessage exception message
	 * @param aCause   exception cause
	 */
	public WheelsException(String aMessage, Exception aCause) {
		super(aMessage, aCause);
		errorCode = null;
		detail = convertException(aCause);
	}

	/**
	 * get error code
	 * 
	 * @return error code as String
	 */

	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * get error detail
	 * 
	 * @return exception detail
	 */
	public String getDetail() {
		return detail;
	}

	/**
	 * convert an exception to a string
	 * 
	 * @param e
	 * @return
	 */
	private String convertException(Exception e) {
		if (e == null) {
			return null;
		}
		StringWriter sw = new StringWriter();
		e.printStackTrace();
		return sw.toString();

	}

}
