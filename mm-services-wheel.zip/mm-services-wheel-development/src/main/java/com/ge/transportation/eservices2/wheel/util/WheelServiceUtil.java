package com.ge.transportation.eservices2.wheel.util;

import java.io.InputStream;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.UnmarshallerHandler;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.xml.sax.InputSource;
import org.xml.sax.XMLFilter;
import org.xml.sax.XMLReader;

import com.ge.transportation.eservices2.domainobjects.AxleProperties;
import com.ge.transportation.eservices2.domainobjects.Calipriexport;
import com.ge.transportation.eservices2.domainobjects.Error;
import com.ge.transportation.eservices2.domainobjects.ErrorType;
import com.ge.transportation.eservices2.domainobjects.ParamDefination;
import com.ge.transportation.eservices2.domainobjects.Pos;
import com.ge.transportation.eservices2.domainobjects.Side;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.WheelProfile;
import com.ge.transportation.eservices2.domainobjects.WheelSheet;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetails;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;

public class WheelServiceUtil {

	private static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	private static final Logger logger = Logger.getLogger(WheelServiceUtil.class);
	private WheelServiceUtil() {
		// Default Constructor
	}

	public static String convertDateToString(Date date) {
		if (null != date) {
			return new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS).format(date);
		}
		throw new WheelsException("Date is Null or Empty");
	}

	public static Date convertStringToDate(String strDate) {
		try {
			if (Objects.nonNull(strDate) && !strDate.isEmpty()) {
				return new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS).parse(strDate);
			}
			throw new WheelsException("Date is Empty");
		} catch (Exception e) {
			throw new WheelsException(e);
		}
	}

	public static StatusType sendSuccessStatusType(String successMsg) {
		StatusType statusType = new StatusType();
		statusType.setMessage(successMsg);
		statusType.setStatusCode(StatusCode.SUCCESS);
		return statusType;
	}

	public static StatusType setNoContentStatusType(String msg, String uuId) {
		StatusType statusType = new StatusType();
		ErrorType errorType = new ErrorType();
		Error error = new Error();
		error.setErrorCode(HttpStatus.NO_CONTENT.toString());
		error.setErrorMsg(msg);
		error.setUuid(uuId);
		errorType.getError().add(error);
		statusType.setErrors(errorType);
		statusType.setMessage(msg);
		statusType.setStatusCode(StatusCode.SUCCESS);
		return statusType;
	}

	public static StatusType sendErrorStatusType(Exception e, String uuId) {
		StatusType statusType = new StatusType();
		ErrorType errorType = new ErrorType();
		Error error = new Error();
		error.setErrorMsg(e.getMessage());
		error.setUuid(uuId);
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		errorType.getError().add(error);
		statusType.setErrors(errorType);
		statusType.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		return statusType;
	}
	
	public static StatusType sendFailedStatusType(String failedMsg, String uuId) {
		StatusType statusType = new StatusType();
		ErrorType errorType = new ErrorType();
		Error error = new Error();
		error.setErrorMsg(failedMsg);
		error.setUuid(uuId);
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
		errorType.getError().add(error);
		statusType.setErrors(errorType);
		statusType.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		return statusType;
	}

	public static Calipriexport parseXmlFile(InputStream inputStream) {
		try {
			InputSource inputSource = new InputSource(inputStream);
			XMLFilter filter = new NamespaceFilter();
			SAXParserFactory spf = SAXParserFactory.newInstance();
			spf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
			SAXParser sp = spf.newSAXParser();
			XMLReader xr = sp.getXMLReader();
			filter.setParent(xr);
			JAXBContext jc = JAXBContext.newInstance(Calipriexport.class);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			UnmarshallerHandler unmarshallerHandler = unmarshaller.getUnmarshallerHandler();
			filter.setContentHandler(unmarshallerHandler);
			filter.parse(inputSource);
			Calipriexport calipriexport = (Calipriexport) unmarshallerHandler.getResult();
			if (Objects.nonNull(calipriexport)) {
				return calipriexport;
			} else {
				throw new WheelsException();
			}
		} catch (Exception e) {
			throw new WheelsException(e);
		}
	}

	public static WheelSheetDataCollection mapDomainObjectToDocumentObject(WheelSheetDetails wheelSheetDetails) {
		com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelsheetKey = new com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey();
		wheelsheetKey.setAarRoad(wheelSheetDetails.getWheelSheetKey().getAarRoad());
		wheelsheetKey.setRoadNumber(wheelSheetDetails.getWheelSheetKey().getRoadNumber());
		
		String wheelSheetId = new UniqueIdGenerator().getUUID();
		
		WheelSheet wheelSheet = wheelSheetDetails.getWheelSheet().get(0);
		WheelSheetCollection wheelSheetCollection = new WheelSheetCollection();
		wheelSheetCollection.setWheelsheetId(wheelSheetId);
		wheelSheetCollection.setCreatedDate(WheelServiceUtil.convertDateToString(new Date()));
		wheelSheetCollection.setCreatedBy(wheelSheet.getCreatedBy());
		wheelSheetCollection.setFileName(wheelSheet.getFileName());
		wheelSheetCollection.setFileCreationDate(wheelSheet.getFileCreationDate());
		wheelSheetCollection.setGaugeType(wheelSheet.getGaugeType());
		wheelSheetCollection.setUom(wheelSheet.getUom());
		wheelSheetCollection.setWheelSheetName(wheelSheet.getWheelSheetName());
		wheelSheetCollection.setWorkorderId(wheelSheet.getWorkorderId());
		wheelSheetCollection.setServiceOrgId(wheelSheet.getServiceOrgId());
		wheelSheetCollection.setUserId(wheelSheet.getUserId());
		wheelSheetCollection.setWorkshift(wheelSheet.getWorkshift());
		wheelSheetCollection.setCustomerId(wheelSheet.getCustomerId());
		wheelSheetCollection.setOperator(wheelSheet.getOperator());
		List<AxleProperties> requestAxleProperties = wheelSheet.getAxleProperties();
		List<com.ge.transportation.eservices2.wheel.docdb.model.AxleProperties> docAxlePropertiesList = new ArrayList<>();
		for (AxleProperties axleProperties : requestAxleProperties) {
			char charAt = axleProperties.getAxleName().charAt(axleProperties.getAxleName().length()-1);
			com.ge.transportation.eservices2.wheel.docdb.model.AxleProperties docAxleProperties = new com.ge.transportation.eservices2.wheel.docdb.model.AxleProperties();
			docAxleProperties.setAxleName(axleProperties.getAxleName());
			docAxleProperties.setAxleNumber(Integer.valueOf(Character.toString(charAt)));
			List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> wheelProfiles = new ArrayList<>();
			axleProperties.getWheelProfiles().stream().forEach(profile -> {
				com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile wheelProfile = new com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile();
				wheelProfile.setName(profile.getName());
				wheelProfile.setVisible(profile.isVisible());
				
				com.ge.transportation.eservices2.wheel.docdb.model.Side left = mapDomainParamSideToDocParamSide(profile.getLeft());
				wheelProfile.setLeft(left);
				
				com.ge.transportation.eservices2.wheel.docdb.model.Side right = mapDomainParamSideToDocParamSide(profile.getRight());
				wheelProfile.setRight(right);
				wheelProfile.setRimThickness(profile.isRimThickness());
				wheelProfile.setWheelDiameter(profile.isWheelDiameter());
				wheelProfile.setCalculated(profile.isCalculated());
				wheelProfiles.add(wheelProfile);
			});
			List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> sortedWheelProfiles = new ArrayList<>();
			sortedWheelProfiles = sortWheelProfiles(wheelProfiles, sortedWheelProfiles);
			docAxleProperties.setWheelProfiles(sortedWheelProfiles);
			docAxlePropertiesList.add(docAxleProperties);
		}
		wheelSheetCollection.setAxleProperties(docAxlePropertiesList);
		
		List<com.ge.transportation.eservices2.wheel.docdb.model.Pos> docPosList = new ArrayList<>();
		
		wheelSheet.getPos().stream().forEach(pos -> mapDomainPostoDocPos(docPosList, pos));
		wheelSheetCollection.setPos(docPosList);
		WheelSheetDataCollection wheelSheetDataCollection = new WheelSheetDataCollection();
		wheelSheetDataCollection.setWheelSheetKey(wheelsheetKey);
		wheelSheetDataCollection.setWheelSheet(Arrays.asList(wheelSheetCollection));
		
		return wheelSheetDataCollection;
	}

	private static List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> sortWheelProfiles(
			List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> wheelProfiles,
			List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> sortedWheelProfiles) {
		List<com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile> calcWheelDia = wheelProfiles.stream()
				.filter(wheelProfile -> wheelProfile.getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER))
				.collect(Collectors.toList());
		if (!calcWheelDia.isEmpty()) {
			for (int i = 0; i < wheelProfiles.size(); i++) {
				if (wheelProfiles.get(i).getName().contains(WheelConstants.AXLE)) {
					sortedWheelProfiles.add(calcWheelDia.get(0));
					sortedWheelProfiles.add(wheelProfiles.get(i));
				} 
				else if (!(wheelProfiles.get(i).getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER))) {
					sortedWheelProfiles.add(wheelProfiles.get(i));
				} 
			} 
			return sortedWheelProfiles;
		} else {
			return wheelProfiles;
		}
	}

	public static void mapDomainPostoDocPos(List<com.ge.transportation.eservices2.wheel.docdb.model.Pos> docPosList, Pos pos) {
		com.ge.transportation.eservices2.wheel.docdb.model.Pos docPos = new com.ge.transportation.eservices2.wheel.docdb.model.Pos();
		
		com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails docCouplerHeight = new com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails();
		com.ge.transportation.eservices2.wheel.docdb.model.Side couplerFront = getParamDefinitioForPos( pos.getCouplerHeight().getFront());
		docCouplerHeight.setFront(couplerFront);
		
		com.ge.transportation.eservices2.wheel.docdb.model.Side couplerBack = getParamDefinitioForPos( pos.getCouplerHeight().getBack());
		docCouplerHeight.setBack(couplerBack);
		docPos.setCouplerHeight(docCouplerHeight);
		
		com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails docPilotHeightLeft = new com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails();
		com.ge.transportation.eservices2.wheel.docdb.model.Side pilotLeftFront =  getParamDefinitioForPos( pos.getPilotHeightLeft().getFront());
		docPilotHeightLeft.setFront(pilotLeftFront);
		
		com.ge.transportation.eservices2.wheel.docdb.model.Side pilotLeftBack =  getParamDefinitioForPos( pos.getPilotHeightLeft().getBack());
		docPilotHeightLeft.setBack(pilotLeftBack);
		docPos.setPilotHeightLeft(docPilotHeightLeft);
		
		com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails docPilotHeightRight = new com.ge.transportation.eservices2.wheel.docdb.model.PositionDetails();
		com.ge.transportation.eservices2.wheel.docdb.model.Side pilotRightFront =  getParamDefinitioForPos( pos.getPilotHeightRight().getFront());
		docPilotHeightRight.setFront(pilotRightFront);
		
		com.ge.transportation.eservices2.wheel.docdb.model.Side pilotRightBack =  getParamDefinitioForPos( pos.getPilotHeightRight().getBack());
		docPilotHeightRight.setBack(pilotRightBack);
		docPos.setPilotHeightRight(docPilotHeightRight);
		
		docPosList.add(docPos);
	}

	public static com.ge.transportation.eservices2.wheel.docdb.model.Side mapDomainParamSideToDocParamSide(Side side) {
		com.ge.transportation.eservices2.wheel.docdb.model.Side left = new com.ge.transportation.eservices2.wheel.docdb.model.Side();
		com.ge.transportation.eservices2.wheel.docdb.model.ParamDefination docParamDefination = new com.ge.transportation.eservices2.wheel.docdb.model.ParamDefination();
		if (Objects.nonNull(side)) {
			ParamDefination leftParamDef = side.getDef();
			left.setValue(side.getValue());
			docParamDefination.setSpan(leftParamDef.getSpan());
			docParamDefination.setType(leftParamDef.getType());
			docParamDefination.setValues(leftParamDef.getValues());
		}
		left.setDef(docParamDefination);
		return left;
	}

	public static com.ge.transportation.eservices2.wheel.docdb.model.Side getParamDefinitioForPos(Side side) {
		com.ge.transportation.eservices2.wheel.docdb.model.Side couplerFront = new com.ge.transportation.eservices2.wheel.docdb.model.Side();
		com.ge.transportation.eservices2.wheel.docdb.model.ParamDefination docCouplerFrontParamDef = new com.ge.transportation.eservices2.wheel.docdb.model.ParamDefination();
		ParamDefination couplerFrontParamDef = side.getDef();
		couplerFront.setValue(side.getValue());
		docCouplerFrontParamDef.setSpan(couplerFrontParamDef.getSpan());
		docCouplerFrontParamDef.setType(couplerFrontParamDef.getType());
		docCouplerFrontParamDef.setValues(couplerFrontParamDef.getValues());
		couplerFront.setDef(docCouplerFrontParamDef);
		return couplerFront;
	}

	public static Date convertIntegerToDate(BigInteger lastmodified) {
		Date date = null;
		try {
			DateFormat fmt = new SimpleDateFormat("yyMMddhhmmss");
			date = fmt.parse(lastmodified.toString());
		} catch (Exception e) {
			logger.info("Exception in convertIntegerToDate ",e);
		}
		return date;
	}
	
}
