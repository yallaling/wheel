package com.ge.transportation.eservices2.wheel.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class DefectDTO {

	private DefectStatusType status;
	private String description;
	private Set<ActionDTO> actions = new HashSet<>();
	private UserDTO userDTO;
	private DefectMaterialStatus materialStatus;
	private String serialNumberIn;
	private String serialNumberOut;
	private Flag serialRequired;
	
	private Flag shopSummary;
	private String originType;
	private Parent parent;
	private String serviceTypeCode;
	private String remedyCode;
	private String causeCode;
	private String problemCode;
	private String defectType;
	private String columnValue;
	private Integer defectOriginId;
	private UserProfileDTO lastUpdatedBy;
	private String lastRepairedBy;

	private TimeCardDTO timeCard;
	
	// cause and remedy list for CSX B2B defect
	private List<String> causes;
	private List<String> remedies;
	
	private String openCode;
	private Flag deferIndication = Flag.N;
	private Flag causeRemedyIndication = Flag.N;
	private Flag recordUDRIndication = Flag.N;
	
	private Flag convertToPendingSSIndication;
	private Flag editSSIndication;
	
	private ButtonType buttonType = ButtonType.NOSHOW;
	private String autoAttachFlag;

	private List<DefectSignOffDTO> signOffList;
	
	private Flag locoAvailabilityFlag;
	private Flag cpDeallocationFlag;
	private String custIncidentDesc;
	
    private String programName;
    
    private Flag timeCardOnly;

    private List<DefectActionTakenHisDTO> defectActionTakenHis;
    
    private UserAction userAction;
    
    private List<ActionDTO> actionHistories = new ArrayList<>();
    
    private String mode;
    
    private List<DefectAttachment> defectAttachments;
    
	/**
	 * @return the timeCardOnly
	 */
	public Flag getTimeCardOnly() {
		return timeCardOnly;
	}

	
	/**
	 * @param timeCardOnly the timeCardOnly to set
	 */
	public void setTimeCardOnly(Flag timeCardOnly) {
		this.timeCardOnly = timeCardOnly;
	}

	public DefectDTO() {	
		// Dafault constructor
	}
	

	public UserDTO getUserDTO() {
		return userDTO;
	}


	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}


	public DefectStatusType getStatus() {
		return status;
	}

	public void setStatus(DefectStatusType status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<ActionDTO> getActions() {
		return actions;
	}

	public void setActions(Set<ActionDTO> actions) {
		this.actions = actions;
	}

	

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}

	
	/**
	 * @return the materialStatus
	 */
	public DefectMaterialStatus getMaterialStatus() {
		return materialStatus;
	}

	
	/**
	 * @param materialStatus the materialStatus to set
	 */
	public void setMaterialStatus(DefectMaterialStatus materialStatus) {
		this.materialStatus = materialStatus;
	}

	/**
	 * @return the serialNumberIn
	 */
	public String getSerialNumberIn() {
		return serialNumberIn;
	}

	/**
	 * @param serialNumberIn the serialNumberIn to set
	 */
	public void setSerialNumberIn(String serialNumberIn) {
		this.serialNumberIn = serialNumberIn;
	}

	public String getSerialNumberOut() {
		return this.serialNumberOut;
	}
	public void setSerialNumberOut(String serialNumberOut) {
		this.serialNumberOut = serialNumberOut;
	}
	
	/**
	 * @return the serialRequired
	 */
	public Flag getSerialRequired() {
		return serialRequired;
	}
	
	/**
	 * @param serialRequired the serialRequired to set
	 */
	public void setSerialRequired(Flag serialRequired) {
		this.serialRequired = serialRequired;
	}
	
	/**
	 * @return the shopSummary
	 */
	public Flag getShopSummary() {
		return shopSummary;
	}

	/**
	 * @param shopSummary the shopSummary to set
	 */
	public void setShopSummary(Flag shopSummary) {
		this.shopSummary = shopSummary;
	}

	
	/**
	 * @return the originType
	 */
	public String getOriginType() {
		return originType;
	}

	
	/**
	 * @param originType the originType to set
	 */
	public void setOriginType(String originType) {
		this.originType = originType;
	}

	
	/**
	 * @return the serviceTypeCode
	 */
	public String getServiceTypeCode() {
		return serviceTypeCode;
	}

	
	/**
	 * @param serviceTypeCode the serviceTypeCode to set
	 */
	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
	
	/**
	 * @return the remedyCode
	 */
	public String getRemedyCode() {
		return remedyCode;
	}

	
	/**
	 * @param remedyCode the remedyCode to set
	 */
	public void setRemedyCode(String remedyCode) {
		this.remedyCode = remedyCode;
	}

	
	/**
	 * @return the causeCode
	 */
	public String getCauseCode() {
		return causeCode;
	}

	
	/**
	 * @param causeCode the causeCode to set
	 */
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}

	
	/**
	 * @return the problemCode
	 */
	public String getProblemCode() {
		return problemCode;
	}

	
	/**
	 * @param problemCode the problemCode to set
	 */
	public void setProblemCode(String problemCode) {
		this.problemCode = problemCode;
	}

	
	/**
	 * @return the belongTo
	 */
	public String getDefectType() {
		return defectType;
	}

	
	/**
	 * @param belongTo the belongTo to set
	 */
	public void setDefectType(String defectType) {
		this.defectType = defectType;
	}

	
	/**
	 * @return the columnValue
	 */
	public String getColumnValue() {
		return columnValue;
	}

	
	/**
	 * @param columnValue the columnValue to set
	 */
	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}
	
	
	public TimeCardDTO getTimeCard() {
		return timeCard;
	}

	public void setTimeCard(TimeCardDTO timeCard) {
		this.timeCard = timeCard;
	}

	
	/**
	 * @return the causes
	 */
	public List<String> getCauses() {
		return causes;
	}

	
	/**
	 * @param causes the causes to set
	 */
	public void setCauses(List<String> causes) {
		this.causes = causes;
	}

	
	/**
	 * @return the remedies
	 */
	public List<String> getRemedies() {
		return remedies;
	}

	
	/**
	 * @param remedies the remedies to set
	 */
	public void setRemedies(List<String> remedies) {
		this.remedies = remedies;
	}

	
	/**
	 * @return the openCode
	 */
	public String getOpenCode() {
		return openCode;
	}

	
	/**
	 * @param openCode the openCode to set
	 */
	public void setOpenCode(String openCode) {
		this.openCode = openCode;
	}

	
	/**
	 * @return the deferIndication
	 */
	public Flag getDeferIndication() {
		return deferIndication;
	}

	
	/**
	 * @param deferIndication the deferIndication to set
	 */
	public void setDeferIndication(Flag deferIndication) {
		this.deferIndication = deferIndication;
	}

	/**
	 * @return the causeRemedyIndication
	 */
	public Flag getCauseRemedyIndication() {
		return causeRemedyIndication;
	}

	
	/**
	 * @param causeRemedyIndication the causeRemedyIndication to set
	 */
	public void setCauseRemedyIndication(Flag causeRemedyIndication) {
		this.causeRemedyIndication = causeRemedyIndication;
	}

	
	/**
	 * @return the recordUDRIndication
	 */
	public Flag getRecordUDRIndication() {
		return recordUDRIndication;
	}

	
	/**
	 * @param recordUDRIndication the recordUDRIndication to set
	 */
	public void setRecordUDRIndication(Flag recordUDRIndication) {
		this.recordUDRIndication = recordUDRIndication;
	}

	
	/**
	 * @return the defectOriginId
	 */
	public Integer getDefectOriginId() {
		return defectOriginId;
	}

	
	/**
	 * @param defectOriginId the defectOriginId to set
	 */
	public void setDefectOriginId(Integer defectOriginId) {
		this.defectOriginId = defectOriginId;
	}

	
	/**
	 * @return the convertToPendingSSIndication
	 */
	public Flag getConvertToPendingSSIndication() {
		return convertToPendingSSIndication;
	}

	
	/**
	 * @param convertToPendingSSIndication the convertToPendingSSIndication to set
	 */
	public void setConvertToPendingSSIndication(Flag convertToPendingSSIndication) {
		this.convertToPendingSSIndication = convertToPendingSSIndication;
	}

	
	/**
	 * @return the editSSIndication
	 */
	public Flag getEditSSIndication() {
		return editSSIndication;
	}

	
	/**
	 * @param editSSIndication the editSSIndication to set
	 */
	public void setEditSSIndication(Flag editSSIndication) {
		this.editSSIndication = editSSIndication;
	}

	/**
	 * @return the signOffList
	 */
	public List<DefectSignOffDTO> getSignOffList() {
		return signOffList;
	}

	/**
	 * @param signOffList the signOffList to set
	 */
	public void setSignOffList(List<DefectSignOffDTO> signOffList) {
		this.signOffList = signOffList;
	}

	
	/**
	 * @return the buttonType
	 */
	public ButtonType getButtonType() {
		return buttonType;
	}

	
	/**
	 * @param buttonType the buttonType to set
	 */
	public void setButtonType(ButtonType buttonType) {
		this.buttonType = buttonType;
	}
	
	/**
	 * @return the autoAttachFlag
	 */
	public String getAutoAttachFlag() {
		return autoAttachFlag;
	}
	
	/**
	 * @param autoAttachFlag the autoAttachFlag to set
	 */
	public void setAutoAttachFlag(String autoAttachFlag) {
		this.autoAttachFlag = autoAttachFlag;
	}

	
	/**
	 * @return the lastUpdatedBy
	 */
	public UserProfileDTO getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	
	/**
	 * @param lastUpdatedBy the lastUpdatedBy to set
	 */
	public void setLastUpdatedBy(UserProfileDTO lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	
	/**
	 * @return the lastRepairedBy
	 */
	public String getLastRepairedBy() {
		return lastRepairedBy;
	}

	
	/**
	 * @param lastRepairedBy the lastRepairedBy to set
	 */
	public void setLastRepairedBy(String lastRepairedBy) {
		this.lastRepairedBy = lastRepairedBy;
	}

	
	/**
	 * @return the locoAvailabilityFlag
	 */
	public Flag getLocoAvailabilityFlag() {
		return locoAvailabilityFlag;
	}

	
	/**
	 * @param locoAvailabilityFlag the locoAvailabilityFlag to set
	 */
	public void setLocoAvailabilityFlag(Flag locoAvailabilityFlag) {
		this.locoAvailabilityFlag = locoAvailabilityFlag;
	}

	
	/**
	 * @return the cpDeallocationFlag
	 */
	public Flag getCpDeallocationFlag() {
		return cpDeallocationFlag;
	}

	
	/**
	 * @param cpDeallocationFlag the cpDeallocationFlag to set
	 */
	public void setCpDeallocationFlag(Flag cpDeallocationFlag) {
		this.cpDeallocationFlag = cpDeallocationFlag;
	}

	
	/**
	 * @return the custIncidentDesc
	 */
	public String getCustIncidentDesc() {
		return custIncidentDesc;
	}

	
	/**
	 * @param custIncidentDesc the custIncidentDesc to set
	 */
	public void setCustIncidentDesc(String custIncidentDesc) {
		this.custIncidentDesc = custIncidentDesc;
	}

	
	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}

	
	/**
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}


	
	/**
	 * @return the defectActionTakenHis
	 */
	public List<DefectActionTakenHisDTO> getDefectActionTakenHis() {
		return defectActionTakenHis;
	}


	
	/**
	 * @param defectActionTakenHis the defectActionTakenHis to set
	 */
	public void setDefectActionTakenHis(
			List<DefectActionTakenHisDTO> defectActionTakenHis) {
		this.defectActionTakenHis = defectActionTakenHis;
	}


	
	/**
	 * @return the userAction
	 */
	public UserAction getUserAction() {
		return userAction;
	}


	
	/**
	 * @param userAction the userAction to set
	 */
	public void setUserAction(UserAction userAction) {
		this.userAction = userAction;
	}


	
	/**
	 * @return the actionHistories
	 */
	public List<ActionDTO> getActionHistories() {
		return actionHistories;
	}


	
	/**
	 * @param actionHistories the actionHistories to set
	 */
	public void setActionHistories(List<ActionDTO> actionHistories) {
		this.actionHistories = actionHistories;
	}


	
	/**
	 * @return the mode
	 */
	public String getMode() {
		return mode;
	}


	
	/**
	 * @param mode the mode to set
	 */
	public void setMode(String mode) {
		this.mode = mode;
	}


	public List<DefectAttachment> getDefectAttachments() {
		return defectAttachments;
	}


	public void setDefectAttachments(List<DefectAttachment> defectAttachments) {
		this.defectAttachments = defectAttachments;
	}

}
