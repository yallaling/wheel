package com.ge.transportation.eservices2.wheel.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;

@Repository
public interface WheelParamLimitsRepository extends MongoRepository<WheelParamLimits, String> {
	
	WheelParamLimits findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoType(
			Long customerId, String aarRoad, String wheelParameter, String locoType);
	List<WheelParamLimits> findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeIn(Long customerId,String aarRoad,Boolean delete,List<String> locoType);

	List<WheelParamLimits> findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoTypeIn(
			Long customerId, String aarRoad, String wheelParameter, List<String> locoType);
	
	List<WheelParamLimits> findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadInAndWheelParamKeyDeleteAndWheelParamKeyLocoTypeInAndWheelParamKeyWheelParameter(
			long custId, List<String> aar, boolean b, List<String> locoType, String wheelparam);
}
