package com.ge.transportation.eservices2.wheel.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.MoveFileResponse;
import com.ge.transportation.eservices2.domainobjects.UnProcessedFilesResponse;
import com.ge.transportation.eservices2.domainobjects.UploadFileResponse;

@Service
public interface WheelDataInjectService {

	UploadFileResponse uploadFile(String uuId, MultipartFile multipartFile);
	
	MoveFileResponse moveCustomerFile(MoveFileRequest moveFileRequest, String uuId);

	List<S3ObjectSummary> listOfFiles(String uuId);

	UnProcessedFilesResponse moveUnprocessedFiles(String uuId, String workOrderNumber);

}
