package com.ge.transportation.eservices2.wheel.docdb.model;

import java.util.List;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "wheelsheetdata")
public class WheelSheetDataCollection{

	@Id
	private String id;
	private WheelSheetKey wheelSheetKey;
	private List<WheelSheetCollection> wheelSheet;
	
	public WheelSheetDataCollection() {
		// Default Constructor
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public WheelSheetKey getWheelSheetKey() {
		return wheelSheetKey;
	}

	public void setWheelSheetKey(WheelSheetKey wheelSheetKey) {
		this.wheelSheetKey = wheelSheetKey;
	}

	public List<WheelSheetCollection> getWheelSheet() {
		return wheelSheet;
	}

	public void setWheelSheet(List<WheelSheetCollection> wheelSheet) {
		this.wheelSheet = wheelSheet;
	}

}
