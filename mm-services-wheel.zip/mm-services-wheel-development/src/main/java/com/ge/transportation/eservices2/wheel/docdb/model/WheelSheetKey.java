package com.ge.transportation.eservices2.wheel.docdb.model;

public class WheelSheetKey{

	private String aarRoad;
	private String roadNumber;
	
	public WheelSheetKey() {
		// Default Constructor
	}

	public String getAarRoad() {
		return aarRoad;
	}

	public void setAarRoad(String aarRoad) {
		this.aarRoad = aarRoad;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	
}
