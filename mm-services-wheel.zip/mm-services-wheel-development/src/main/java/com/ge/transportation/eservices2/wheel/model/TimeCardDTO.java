package com.ge.transportation.eservices2.wheel.model;

public class TimeCardDTO {

	// refer to estwos-195
	private Integer totalTimeHours;
	private Integer totalTimeMinutes;
	private Integer totalNormalTimeHours;
	private Integer totalNormalTimeMins;
	private Integer totalOverTimeHours;
	private Integer totalOverTimeMins;
	private String overTimeType;
	private Integer workorderId;	
	private Long serviceSheetId;
	private Integer defectId;
	private Integer normalTimeHours;
	private Integer normalTimeMins;
	private Integer overTimeHours;
	private Integer overTimeMins;
	
	
	public Integer getWorkorderId() {
		return workorderId;
	}
	public void setWorkorderId(Integer workorderId) {
		this.workorderId = workorderId;
	}
	public Long getServiceSheetId() {
		return serviceSheetId;
	}
	public void setServiceSheetId(Long serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
	public Integer getDefectId() {
		return defectId;
	}
	public void setDefectId(Integer defectId) {
		this.defectId = defectId;
	}
	public Integer getTotalTimeHours() {
		return totalTimeHours;
	}
	public void setTotalTimeHours(Integer totalTimeHours) {
		this.totalTimeHours = totalTimeHours;
	}
	public Integer getTotalTimeMinutes() {
		return totalTimeMinutes;
	}
	public void setTotalTimeMinutes(Integer totalTimeMinutes) {
		this.totalTimeMinutes = totalTimeMinutes;
	}
	
	public Integer getNormalTimeHours() {
		return normalTimeHours;
	}
	public void setNormalTimeHours(Integer normalTimeHours) {
		this.normalTimeHours = normalTimeHours;
	}
	public Integer getNormalTimeMins() {
		return normalTimeMins;
	}
	public void setNormalTimeMins(Integer normalTimeMins) {
		this.normalTimeMins = normalTimeMins;
	}
	public Integer getOverTimeHours() {
		return overTimeHours;
	}
	public void setOverTimeHours(Integer overTimeHours) {
		this.overTimeHours = overTimeHours;
	}
	public Integer getOverTimeMins() {
		return overTimeMins;
	}
	public void setOverTimeMins(Integer overTimeMins) {
		this.overTimeMins = overTimeMins;
	}
	
	public String getOverTimeType() {
		return overTimeType;
	}
	public void setOverTimeType(String overTimeType) {
		this.overTimeType = overTimeType;
	}
	public Integer getTotalNormalTimeHours() {
		return totalNormalTimeHours;
	}
	public void setTotalNormalTimeHours(Integer totalNormalTimeHours) {
		this.totalNormalTimeHours = totalNormalTimeHours;
	}
	public Integer getTotalNormalTimeMins() {
		return totalNormalTimeMins;
	}
	public void setTotalNormalTimeMins(Integer totalNormalTimeMins) {
		this.totalNormalTimeMins = totalNormalTimeMins;
	}
	public Integer getTotalOverTimeHours() {
		return totalOverTimeHours;
	}
	public void setTotalOverTimeHours(Integer totalOverTimeHours) {
		this.totalOverTimeHours = totalOverTimeHours;
	}
	public Integer getTotalOverTimeMins() {
		return totalOverTimeMins;
	}
	public void setTotalOverTimeMins(Integer totalOverTimeMins) {
		this.totalOverTimeMins = totalOverTimeMins;
	}
	
	public void setDefaultValues(){
		// Set the NULL values of TimeCard as zero (easier for parsing on
					// U.I)
		if (this.getTotalTimeHours() == null)
			this.setTotalTimeHours(0);
		if (this.getTotalTimeMinutes() == null){
			this.setTotalTimeMinutes(0);
			this.setOverTimeType("0");
		}
		if (this.getNormalTimeHours() == null)
			this.setNormalTimeHours(0);
		if (this.getNormalTimeMins() == null)
			this.setNormalTimeMins(0);
		if (this.getOverTimeHours() == null)
			this.setOverTimeHours(0);
		if (this.getOverTimeMins() == null)
			this.setOverTimeMins(0);
		if (this.getDefectId() == null)
			this.setDefectId(0);
		if (this.getWorkorderId() == null)
			this.setWorkorderId(0);
		if (this.getServiceSheetId() == null)
			this.setServiceSheetId(0L);
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((defectId == null) ? 0 : defectId.hashCode());
		result = prime * result
				+ ((normalTimeHours == null) ? 0 : normalTimeHours.hashCode());
		result = prime * result
				+ ((normalTimeMins == null) ? 0 : normalTimeMins.hashCode());
		result = prime * result
				+ ((overTimeHours == null) ? 0 : overTimeHours.hashCode());
		result = prime * result
				+ ((overTimeMins == null) ? 0 : overTimeMins.hashCode());
		result = prime * result
				+ ((overTimeType == null) ? 0 : overTimeType.hashCode());
		result = prime * result
				+ ((serviceSheetId == null) ? 0 : serviceSheetId.hashCode());
		result = prime
				* result
				+ ((totalNormalTimeHours == null) ? 0 : totalNormalTimeHours
						.hashCode());
		result = prime
				* result
				+ ((totalNormalTimeMins == null) ? 0 : totalNormalTimeMins
						.hashCode());
		result = prime * result
				+ ((totalOverTimeHours == null) ? 0 : totalOverTimeHours.hashCode());
		result = prime * result
				+ ((totalOverTimeMins == null) ? 0 : totalOverTimeMins.hashCode());
		result = prime * result
				+ ((totalTimeHours == null) ? 0 : totalTimeHours.hashCode());
		result = prime * result
				+ ((totalTimeMinutes == null) ? 0 : totalTimeMinutes.hashCode());
		result = prime * result
				+ ((workorderId == null) ? 0 : workorderId.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TimeCardDTO other = (TimeCardDTO) obj;
		if (defectId == null) {
			if (other.defectId != null)
				return false;
		}
		else if (!defectId.equals(other.defectId))
			return false;
		if (normalTimeHours == null) {
			if (other.normalTimeHours != null)
				return false;
		}
		else if (!normalTimeHours.equals(other.normalTimeHours))
			return false;
		if (normalTimeMins == null) {
			if (other.normalTimeMins != null)
				return false;
		}
		else if (!normalTimeMins.equals(other.normalTimeMins))
			return false;
		if (overTimeHours == null) {
			if (other.overTimeHours != null)
				return false;
		}
		else if (!overTimeHours.equals(other.overTimeHours))
			return false;
		if (overTimeMins == null) {
			if (other.overTimeMins != null)
				return false;
		}
		else if (!overTimeMins.equals(other.overTimeMins))
			return false;
		if (overTimeType == null) {
			if (other.overTimeType != null)
				return false;
		}
		else if (!overTimeType.equals(other.overTimeType))
			return false;
		if (serviceSheetId == null) {
			if (other.serviceSheetId != null)
				return false;
		}
		else if (!serviceSheetId.equals(other.serviceSheetId))
			return false;
		if (totalNormalTimeHours == null) {
			if (other.totalNormalTimeHours != null)
				return false;
		}
		else if (!totalNormalTimeHours.equals(other.totalNormalTimeHours))
			return false;
		if (totalNormalTimeMins == null) {
			if (other.totalNormalTimeMins != null)
				return false;
		}
		else if (!totalNormalTimeMins.equals(other.totalNormalTimeMins))
			return false;
		if (totalOverTimeHours == null) {
			if (other.totalOverTimeHours != null)
				return false;
		}
		else if (!totalOverTimeHours.equals(other.totalOverTimeHours))
			return false;
		if (totalOverTimeMins == null) {
			if (other.totalOverTimeMins != null)
				return false;
		}
		else if (!totalOverTimeMins.equals(other.totalOverTimeMins))
			return false;
		if (totalTimeHours == null) {
			if (other.totalTimeHours != null)
				return false;
		}
		else if (!totalTimeHours.equals(other.totalTimeHours))
			return false;
		if (totalTimeMinutes == null) {
			if (other.totalTimeMinutes != null)
				return false;
		}
		else if (!totalTimeMinutes.equals(other.totalTimeMinutes))
			return false;
		if (workorderId == null) {
			if (other.workorderId != null)
				return false;
		}
		else if (!workorderId.equals(other.workorderId))
			return false;
		return true;
	}

}
