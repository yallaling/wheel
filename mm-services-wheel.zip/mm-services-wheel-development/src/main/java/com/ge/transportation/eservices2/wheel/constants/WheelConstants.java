package com.ge.transportation.eservices2.wheel.constants;

public class WheelConstants {
	
	public static final String TITLE                           = "Wheel Management";
	public static final String VERSION                         = "1.0";
	
	public static final String FORWARD                         = "/";
	
	public static final String DIASABLE_CERT_CHECKING          = "com.amazonaws.sdk.disableCertChecking";
	
	public static final String REST_SERVICE                    = "calling rest webservice";
	public static final String UTF8_ENCODING                   = "UTF-8";
	public static final String EXCEPTION_OCCURED_MESSAGE       = "Exception occured while ";

	public static final String LOCOID                          = "LOCOID";
	public static final String AAR		                       = "AAR";
	public static final String NAME                            = "name";
	
	public static final String FILE_NAME_EMPTY                 = "File name is invalid or empty";
	public static final String FILE_STORE_FAIL                 = "File Storage failed";
	public static final String CUSTOMER_NAME_EMPTY             = "Customer name is invalid or empty";
	public static final String FILE_STORE_SUCCESS              = "File Successfully stored";
	public static final String CUSTOMER_FOLDER_NAME            = "customer";
	public static final String STATUS_MESSAGE_OK               = "Ok";
	public static final String UNABLE_TO_FETCH_DATA            = "Unable to fetch data";
	public static final String INVALID_INPUT                   = "Invalid input";
	public static final String FAILE_TO_STORE                  = "Failed To store Wheel Parameter Limits";
	public static final String REQUEST_FAILED                  = "Request Failed";
	public static final String VALUE_IS_NULL_OR_EMPTY          = "' parameter name/value should not in (NULL, Empty, ZERO, String, Invalid)";
	public static final String WHEEL_PARAM_NOT_EXISTS          = "Given WheelParam Limits not-exists in the master table";
	public static final String HISTORY_UPDATED                 = "History Table Updated with id";
	public static final String WHEEL_PARAM_EXISTS              = "Given WheelParam Limits exists in the master table";
	public static final String LIMITS_UPDATED                  = "new WheelParam Limits inserted in the master table successfully";
	public static final String HISTORY_INSERTED                = "updated History table with the wheel param limits successfully with id ";
	public static final String LIMITS_ALREADY_EXISTS           = " wheel param already exists";
	public static final String EXCEPTION_DB                    = " : Exception while save Metadata in DocumentDB ";
	public static final String PARAM_LIMITS_UPDATED            = "create/updated master table with the wheel param limits successfullywith id ";
	public static final String UNABLE_TO_DELETE_DATA           = "Unable to delete the record";
	public static final String NO_RECORD_AVAILABLE             = "No record found for the provided request";
	public static final String NO_FILE_AVAILABLE               = "No File available";
	public static final String NO_DATA_AVAILABLE               = "No Data available";
	public static final String VALID_STATUS                    = "VALID";
	public static final String INACTIVE                        = "N";
	public static final String ACTIVE                          = "Y";
	public static final String VISIBLE_DEFECT 				   = "Visible Defect";
	public static final String LOCO 						   = "Loco";
	public static final String TRUCK_1 						   = "Truck 1";
	public static final String TRUCK_2						   = "Truck 2";
	public static final String TRUCK 						   = "Truck";
	public static final String UNIT_OF_MEASUREMENT 			   = "mm";
	public static final String RIGHT						   = "Right";
	public static final String LEFT 						   = "Left";
	public static final String AXLE 						   = "Axle";
	public static final String XML 							   = ".xml";
	public static final String AAR_KTZ 						   = "KTZ";
	public static final String AAR_KTZC 					   = "KTZC";
	public static final String AAR_KTZP						   = "KTZP";
	public static final String CALC_WHEEL_DIAMTER 			   = "Calculated Wheel Diameter";
	public static final String WHEEL_NAME_SAVED			  	   = "Wheel sheet name updated successfully";
	public static final String WHEEL_NAME_SAVED_FAILED		   = "Error while updating wheel sheet name";
	public static final String WHEEL_NAME_ALREADY_EXIST	  	   = "Wheel sheet name already exist.";
	public static final String KTZ_CUSTOMER	  				   = "1058";
	

	
	private WheelConstants() {
		// Default Method
	}
	
}
