package com.ge.transportation.eservices2.wheel.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class HealthController {

	@GetMapping(value = "/heartbeat")
	public ResponseEntity<String> getWheesResponse()  {
		return new ResponseEntity<>("I am Alive", HttpStatus.OK);
	}
}
