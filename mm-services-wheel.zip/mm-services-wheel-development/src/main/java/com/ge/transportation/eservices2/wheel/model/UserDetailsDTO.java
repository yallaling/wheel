package com.ge.transportation.eservices2.wheel.model;


public class UserDetailsDTO {

	private Integer userId;

	private Integer serviceEmployeeId;

	private String responsibilityId;

	private String languageCode;

	private String userRole;

	private String serviceOrgId;

	private String customerId;

	private String timeZone;

	private Flag timeCardRibbon;

	private String workShift;

	private String toolBoxLevel;

    private Boolean enhancedSignoff;
	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getServiceEmployeeId() {
		return serviceEmployeeId;
	}

	public void setServiceEmployeeId(Integer serviceEmployeeId) {
		this.serviceEmployeeId = serviceEmployeeId;
	}

	public String getResponsibilityId() {
		return responsibilityId;
	}

	public void setResponsibilityId(String responsibilityId) {
		this.responsibilityId = responsibilityId;
	}

	public String getLanguageCode() {
		return languageCode;
	}

	public void setLanguageCode(String languageCode) {
		this.languageCode = languageCode;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getServiceOrgId() {
		return serviceOrgId;
	}

	public void setServiceOrgId(String serviceOrgId) {
		this.serviceOrgId = serviceOrgId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public Flag getTimeCardRibbon() {
		return timeCardRibbon;
	}

	public void setTimeCardRibbon(Flag timeCardRibbon) {
		this.timeCardRibbon = timeCardRibbon;
	}

	/**
	 * @return the workShift
	 */
	public String getWorkShift() {
		return workShift;
	}
	
	/**
	 * @param workShift the workShift to set
	 */
	public void setWorkShift(String workShift) {
		this.workShift = workShift;
	}

	public String getToolBoxLevel() {
		return toolBoxLevel;
	}

	public void setToolBoxLevel(String toolBoxLevel) {
		this.toolBoxLevel = toolBoxLevel;
	}

    public Boolean isEnhancedSignoff() {
        return enhancedSignoff;
    }

    public void setEnhancedSignoff(Boolean enhancedSignoff) {
        this.enhancedSignoff = enhancedSignoff;
    }
}
