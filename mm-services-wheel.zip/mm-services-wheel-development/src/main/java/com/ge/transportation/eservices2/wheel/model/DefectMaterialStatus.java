/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2013 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *     
 ********************************************************************************/

package com.ge.transportation.eservices2.wheel.model;


/**
 * Enum class to defect material status
 *
 * @author Lin Han
 * @version 1.0 Nov 5, 2013
 * @since 1.0
 */
public enum DefectMaterialStatus {
	
	Picked("Picked"), 
	Requested("Requested"), 
	None("None"),
	Error("Error");
	
	private final String status;
	
	DefectMaterialStatus(String status) {
		this.status = status;
	}
	
	public String getValue() {
		return this.status;
	}
	
	@Override
	public String toString() {
		return this.getValue();
	}

}
