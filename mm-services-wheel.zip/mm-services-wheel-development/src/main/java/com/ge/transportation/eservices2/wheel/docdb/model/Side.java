package com.ge.transportation.eservices2.wheel.docdb.model;

import org.springframework.data.annotation.Transient;

public class Side {

	private String value;
	private Integer defectId;
	@Transient
	private boolean isDefect;
    private ParamDefination def;
    
    public Side() {
		// Default Constructor
	}

	public Integer getDefectId() {
		return defectId;
	}

	public void setDefectId(Integer defectId) {
		this.defectId = defectId;
	}

	
	public boolean isIsDefect() {
		return isDefect;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public ParamDefination getDef() {
		return def;
	}

	public void setDef(ParamDefination def) {
		this.def = def;
	}

	public void setIsDefect(boolean isDefect) {
		this.isDefect = isDefect;
	}
    
	
	
}
