package com.ge.transportation.eservices2.wheel.model;

import java.util.Comparator;


public class UserProfileDTO implements Comparator<UserProfileDTO>{

	private Integer userId;
	private String loginId;
	private String firstName;
	private String lastName;
	private String defaultLanguage;
	private String dateTime;
	private String employeeClass;
	
	public UserProfileDTO() {
	}

	public UserProfileDTO(UserProfile userProfile) {
		this.userId = userProfile.getUserId();
		this.loginId = userProfile.getLoginId();
		this.firstName = userProfile.getFirstName();
		this.lastName = userProfile.getLastName();		
		this.defaultLanguage = userProfile.getDefaultLanguage();
		this.employeeClass = userProfile.getEmployeeClass();
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDefaultLanguage() {
		return defaultLanguage;
	}

	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserProfileDTO other = (UserProfileDTO) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

	
	/**
	 * @return the dataTime
	 */
	public String getDateTime() {
		return dateTime;
	}

	
	/**
	 * @param dataTime the dataTime to set
	 */
	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	/**
	 * @return the employeeClass
	 */
	public String getEmployeeClass() {
		return employeeClass;
	}

	/**
	 * @param employeeClass the employeeClass to set
	 */
	public void setEmployeeClass(String employeeClass) {
		this.employeeClass = employeeClass;
	}

	@Override
	public int compare(UserProfileDTO o1, UserProfileDTO o2) {
		 return o1.getDateTime().compareTo(o2.getDateTime());
	}
	
	
}