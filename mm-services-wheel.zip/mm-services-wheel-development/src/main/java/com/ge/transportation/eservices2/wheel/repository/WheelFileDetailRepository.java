package com.ge.transportation.eservices2.wheel.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;

@Repository
public interface WheelFileDetailRepository extends MongoRepository<WheelFileDetail, String> {

	List<WheelFileDetail> findByLocomotiveIdAndFileName(Long locomotiveID, String fileName);
	List <WheelFileDetail> findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(Long locomotiveID, String status);
	WheelFileDetail findByFileNameAndFileCreationDateAndStatus(String fileName, String fileCreationDate, FileStatus valid);
	WheelFileDetail findByFileNameAndStatus(String fileName, FileStatus status );

}
