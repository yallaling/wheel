package com.ge.transportation.eservices2.wheel.docdb.model;

import javax.xml.bind.annotation.XmlElement;

import org.springframework.data.annotation.Transient;

public class WheelProfile {

	private String name;
    private boolean visible;
    private Side left;
    private Side right;
    @Transient
    private boolean rimThickness;
    @Transient
    private boolean wheelDiameter;
    @Transient
    private boolean calculated;
    
	public WheelProfile() {
		// Default Constructor
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

	public Side getLeft() {
		return left;
	}

	public void setLeft(Side left) {
		this.left = left;
	}

	public Side getRight() {
		return right;
	}

	public void setRight(Side right) {
		this.right = right;
	}

	public boolean isRimThickness() {
		return rimThickness;
	}

	public void setRimThickness(boolean rimThickness) {
		this.rimThickness = rimThickness;
	}

	public boolean isWheelDiameter() {
		return wheelDiameter;
	}

	public void setWheelDiameter(boolean wheelDiameter) {
		this.wheelDiameter = wheelDiameter;
	}

	public boolean isCalculated() {
		return calculated;
	}

	public void setCalculated(boolean calculated) {
		this.calculated = calculated;
	}

}
