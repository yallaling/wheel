package com.ge.transportation.eservices2.wheel.util;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.model.DefectDTO;

@Component("restUtility")
public class RestUtility {

	@Autowired
	private AppConfig appConfig;

	@Autowired
	private RestTemplateFactory restTemplateFactory;

	private static final Logger LOG = LoggerFactory.getLogger(RestUtility.class);

	public <R, S> S callCorePostService(R r, S s, String serviceUrl, String source) {

		ResponseEntity<String> responseEntity;

		RestTemplate restTemplate = restTemplateFactory.getRestTemplate(appConfig.getUsername(),
				appConfig.getPassword());

		restTemplate.getMessageConverters().add(0,
				new StringHttpMessageConverter(StandardCharsets.UTF_8));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<R> request = new HttpEntity<>(r, headers);
		try {
			responseEntity = restTemplate.exchange(serviceUrl, HttpMethod.POST, request, String.class);
		} catch (Exception e) {
			LOG.error(WheelConstants.EXCEPTION_OCCURED_MESSAGE + source + WheelConstants.REST_SERVICE, e);
			throw new WheelsException("Exception While calling WorkOrder service ==> "+e.getLocalizedMessage(), e);
		}

		return convertJsonToObject(responseEntity.getBody(), s);
	}
	
	public <R, S> S callCoreGetService(R r, S s, String serviceUrl, String source, HttpHeaders headers) {

		ResponseEntity<String> responseEntity;

		RestTemplate restTemplate = restTemplateFactory.getRestTemplate(appConfig.getUsername(),
				appConfig.getPassword());

		restTemplate.getMessageConverters().add(0,
				new StringHttpMessageConverter(StandardCharsets.UTF_8));
		
		HttpEntity<R> request = new HttpEntity<>(r,headers);
		try {
			responseEntity = restTemplate.exchange(serviceUrl, HttpMethod.GET, request, String.class);
		} catch (Exception e) {
			LOG.error(WheelConstants.EXCEPTION_OCCURED_MESSAGE + source + WheelConstants.REST_SERVICE, e);
			throw new WheelsException("Exception While calling service ==> "+e.getLocalizedMessage(), e);
		}

		return convertJsonToObject(responseEntity.getBody(), s);
	}
	
	public <R, S> S callCoreGetServiceForUserDetails(S s, String serviceUrl, String source, HttpHeaders headers) {

		ResponseEntity<String> responseEntity;

		RestTemplate restTemplate = restTemplateFactory.getRestTemplate(appConfig.getUsername(),
				appConfig.getPassword());

		restTemplate.getMessageConverters().add(0,
				new StringHttpMessageConverter(StandardCharsets.UTF_8));
		
		HttpEntity<R> request = new HttpEntity<>(headers);
		try {
			responseEntity = restTemplate.exchange(serviceUrl, HttpMethod.GET, request, String.class);
		} catch (Exception e) {
			LOG.error(WheelConstants.EXCEPTION_OCCURED_MESSAGE + source + WheelConstants.REST_SERVICE, e);
			throw new WheelsException("Exception While calling service ==> "+e.getLocalizedMessage(), e);
		}

		return convertJsonToObject(responseEntity.getBody(), s);
	}

	@SuppressWarnings("unchecked")
	private <S> S convertJsonToObject(String jsonStr, S s) {
		ObjectMapper mapperObj = new ObjectMapper();
		mapperObj.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		S dto = null;
		try {
			if (jsonStr != null) {
				dto = (S) mapperObj.readValue(jsonStr, s.getClass());
			}
		} catch (Exception e) {
			LOG.error("Exception while convertJsonToObject ==>" + e);
			throw new WheelsException("Exception in convertJsonToObject ==>"+e.getLocalizedMessage(), e);		}
		return dto;
	}

	public DefectDTO callTDServiceToCreateWheelSheetDefect(DefectDTO defectDTO ,String uri, HttpHeaders headers, MultiValueMap<String, String> mpParams, String uuId) {
		
		RestTemplate restTemplate = restTemplateFactory.getRestTemplate(appConfig.getUsername(), appConfig.getPassword()); 
		restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
		
		HttpEntity<List<DefectDTO>> request = new HttpEntity<>(headers);
		
//		@QueryParam(Constants.PARAM_WORKORDERID) Integer workOrderId, @QueryParam(Constants.PARAM_SERVICESHEETID) Long serviceSheetId, @QueryParam("custName") String custName, @QueryParam("wheelPos") String wheelPos, @Context HttpHeaders headers
		DefectDTO respDefectDTO = null;
		try {
			UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(uri).queryParams(mpParams).build();
			URI completeURI = uriComponents.toUri();
			String format = String.format("%s: Complete URI: %s", uuId, completeURI);
			LOG.info(format);
			ResponseEntity<String> response = restTemplate.exchange(uriComponents.toUri(), HttpMethod.POST, request, String.class);
			respDefectDTO = convertJsonToObject(response.getBody(), defectDTO);
		} catch (Exception e) {
			LOG.error(uuId+": Exception Occured while Connecting to TD defects task Service:"+e, e);
			throw e;
		}
		return respDefectDTO;
	}

}
