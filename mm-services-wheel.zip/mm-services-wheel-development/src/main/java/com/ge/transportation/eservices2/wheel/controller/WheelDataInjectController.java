package com.ge.transportation.eservices2.wheel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.MoveFileResponse;
import com.ge.transportation.eservices2.domainobjects.UnProcessedFilesResponse;
import com.ge.transportation.eservices2.domainobjects.UploadFileResponse;
import com.ge.transportation.eservices2.wheel.service.WheelDataInjectService;
import com.ge.transportation.eservices2.wheel.util.UniqueIdGenerator;

@RestController
@RequestMapping("/v1")
public class WheelDataInjectController {

	@Autowired
	private WheelDataInjectService wheelDataInjectService;
	
	@PostMapping(value = "/file/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public UploadFileResponse singleFileUpload(@RequestParam("file") MultipartFile multipartFile) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelDataInjectService.uploadFile(uuId, multipartFile);
    }

	@PostMapping(value = "/file/movefile")
	public MoveFileResponse moveFile(@RequestBody MoveFileRequest moveFileRequest) {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelDataInjectService.moveCustomerFile(moveFileRequest, uuId);
	}

	@GetMapping(value = "/file/listOfFiles")
	public List<S3ObjectSummary> listOfFiles() {
		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelDataInjectService.listOfFiles(uuId);
	}
	
	@GetMapping(value = "/file/moveunprocessedfiles/{workordernumber}")
	public UnProcessedFilesResponse moveUnprocessedFiles(@PathVariable("workordernumber") String workordernumber) {

		UniqueIdGenerator uniqueIdGenerator = new UniqueIdGenerator();
		String uuId = uniqueIdGenerator.getUUID();
		return wheelDataInjectService.moveUnprocessedFiles(uuId, workordernumber);
	}
}
