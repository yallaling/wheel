package com.ge.transportation.eservices2.wheel.awss3.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.CopyObjectResult;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.IOUtils;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;

@Component
public class AWSFileHandlerServiceImpl implements AWSFileHandlerService {

	private static final String TO = "' to '";

	private static final Logger logger = Logger.getLogger(AWSFileHandlerServiceImpl.class);

	@Autowired
	AmazonS3 s3Client;

	@Autowired
	AppConfig appConfig;

	@Override
	public boolean moveFile(String from, String to, String uuid) {
		try {
			if (copyFileFromKey(from, to, uuid)) {
				return deleteFileUsingKey(from, uuid);
			}
		} catch (Exception e) {
			logger.info(uuid + " : Error while move File from '" + from + TO + to + "'");
			throw e;
		}
		return false;
	}

	@Override
	public boolean copyFileFromKey(String from, String to, String uuId) {
		try {
			CopyObjectRequest copyObjRequest = new CopyObjectRequest(appConfig.getAwsBucketName(), from,
					appConfig.getAwsBucketName(), to);
			CopyObjectResult copyObject = s3Client.copyObject(copyObjRequest);
			if (Objects.nonNull(copyObject)) {
				logger.info(uuId + " : File Copied from '" + from + TO + to + "' successfully completed");
				return true;
			} else {
				logger.info(uuId + " : Failed to Copy from '" + from + TO + to + "'");
				return false;
			}
		} catch (Exception e) {
			throw new WheelsException(
					"Exception while doing copy from '" + from + TO + to + "' -> " + e.getLocalizedMessage(), e);
		}
	}

	@Override
	public boolean deleteFileUsingKey(String from, String uuId) {
		try {
			DeleteObjectRequest dor = new DeleteObjectRequest(appConfig.getAwsBucketName(), from);
			s3Client.deleteObject(dor);
			logger.info(uuId + " : File deleted in  ==>" + from);
		} catch (Exception e) {
			throw new WheelsException("Exception While deleting file" + e.getLocalizedMessage(), e);
		}
		return true;
	}

	@Override
	public boolean putFile(String s3ObjectKey, File fileToUpload, String uuId) {
		try {
			s3Client.putObject(appConfig.getAwsBucketName(), s3ObjectKey, fileToUpload);
			logger.info(uuId + " : File stored in  ==>" + s3ObjectKey);
		} catch (Exception e) {
			logger.error("error while upload file in AWS " + e);
			throw new WheelsException(
					"Exception while upload file in AWS using key " + s3ObjectKey + " -> " + e.getLocalizedMessage(),
					e);
		}
		return true;
	}

	@Override
	public InputStream getFileAsInputStream(String s3ObjectKey, String uuId) {
		try {
			logger.info(uuId + " : Getting a File ==>" + s3ObjectKey);

			GetObjectRequest getObjReq = new GetObjectRequest(appConfig.getAwsBucketName(), s3ObjectKey);
			S3Object s3Object = s3Client.getObject(getObjReq);
			logger.info(uuId + " : Pick File from " + s3ObjectKey + " successfully completed");
			return s3Object.getObjectContent();

		} catch (Exception e) {
			logger.info(uuId + " : Exception while Pick File from " + s3ObjectKey + "==>" + e);
			throw new WheelsException("Exception while Pick File from " + s3ObjectKey + "==>" + e.getLocalizedMessage(),
					e);
		}
	}

	@Override
	public S3Object getS3Object(String s3ObjectKey, String uuId) {
		try {
			logger.info(uuId + " : Getting a File ==>" + s3ObjectKey);

			GetObjectRequest getObjReq = new GetObjectRequest(appConfig.getAwsBucketName(), s3ObjectKey);
			S3Object s3Object = s3Client.getObject(getObjReq);

			logger.info(uuId + " : Pick File from " + s3ObjectKey + " successfully completed");
			return s3Object;

		} catch (Exception e) {
			logger.info(uuId + " : Exception while Pick File from " + s3ObjectKey + "==>" + e);
			throw new WheelsException("Exception while Pick File from " + s3ObjectKey + "==>" + e.getLocalizedMessage(),
					e);
		}
	}

	@Override
	public List<S3ObjectSummary> listOfFiles(String uuId) {

		logger.info(uuId + ": Listing objects");

		ObjectListing listing = s3Client.listObjects(appConfig.getAwsBucketName(), appConfig.getAwsS3Path());
		List<S3ObjectSummary> summaries = listing.getObjectSummaries();

		while (listing.isTruncated()) {
			listing = s3Client.listNextBatchOfObjects(listing);
			summaries.addAll(listing.getObjectSummaries());
		}
		return summaries;

	}

	@Override
	public PutObjectResult uploadFileAsInputStream(String uuId, String fileName, InputStream inputStream, String folderName) {
		
		StringBuilder key = new StringBuilder(appConfig.getAwsS3Path()).append(folderName).append(WheelConstants.FORWARD)
				.append(fileName);
		PutObjectResult putObjectResult = null;
		try {
			if(Objects.nonNull(inputStream)) {
				ObjectMetadata metaData = new ObjectMetadata();
				byte[] bytes = IOUtils.toByteArray(inputStream);
				metaData.setContentLength(bytes.length);
				ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bytes);
				PutObjectRequest putObjectRequest = new PutObjectRequest(appConfig.getAwsBucketName(), key.toString(), byteArrayInputStream, metaData);
				putObjectResult = s3Client.putObject(putObjectRequest);
				
				logger.info(uuId + " : File stored in  ==>" + key.toString());
				return putObjectResult;
			}
			else {
				logger.info(uuId + ": inputstream null");
				return putObjectResult;
			}
		} catch (Exception e) {
			logger.error("error while upload file in AWS " + e);
			throw new WheelsException(
					"Exception while upload file in AWS using key " + key.toString() + " -> " + e.getLocalizedMessage(), e);
		}
	}
}
