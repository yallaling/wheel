package com.ge.transportation.eservices2.wheel.model;

/**
 * Enum indicates service_type_code in servicesheets
 *
 * @author Shanmugaraja Kadirvel
 * @version 1.0 Oct 22, 2013
 * @since 1.0
 */
public enum ServiceTypeCode {
	
	//Gathered info using select distinct service_type_code from GETS_LMS.GETS_LMS_SERVICE_SHEET
	
	WT,
	RP,
	FP,
	MR,
	RM,
	FL,
	GR,
	RX,
	SP,
	FM,
	HR,
	CO,
	ST,
	HM,
	QM,
	OH,
	CR,
	DP,
	MF,
	SC;

}
