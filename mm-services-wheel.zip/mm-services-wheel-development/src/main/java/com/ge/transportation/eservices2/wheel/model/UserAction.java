/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2014 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *     
 ********************************************************************************/

package com.ge.transportation.eservices2.wheel.model;


/**
 * Enum class for user action
 *
 * @author Lin Han
 * @version 1.0 Aug 22, 2014
 * @since 1.0
 */
public enum UserAction {
	
	ADDME,
	REMOVEME,
	SIGNOFF,
	UNSIGNOFF,
	EDIT,
	REORDER;

}
