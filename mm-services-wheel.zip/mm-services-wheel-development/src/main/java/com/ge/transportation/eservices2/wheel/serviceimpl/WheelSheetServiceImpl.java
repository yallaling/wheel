package com.ge.transportation.eservices2.wheel.serviceimpl;

import java.io.InputStream;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.VisibilityChecker;
import com.ge.transportation.eservices2.domainobjects.AxleProperties;
import com.ge.transportation.eservices2.domainobjects.Calipriexport;
import com.ge.transportation.eservices2.domainobjects.Dimension;
import com.ge.transportation.eservices2.domainobjects.FileDetails;
import com.ge.transportation.eservices2.domainobjects.FileDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.FileDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsRequest;
import com.ge.transportation.eservices2.domainobjects.FileMeasurementsResponse;
import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.GetLmsEmployeeRequest;
import com.ge.transportation.eservices2.domainobjects.GetLmsEmployeeResponse;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.MoveFileResponse;
import com.ge.transportation.eservices2.domainobjects.Object;
import com.ge.transportation.eservices2.domainobjects.ParamDefination;
import com.ge.transportation.eservices2.domainobjects.ParamSpan;
import com.ge.transportation.eservices2.domainobjects.ParamType;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetDetails;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetFileDetail;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetRequestDetails;
import com.ge.transportation.eservices2.domainobjects.PastWheelSheetResponse;
import com.ge.transportation.eservices2.domainobjects.Point;
import com.ge.transportation.eservices2.domainobjects.Pos;
import com.ge.transportation.eservices2.domainobjects.PositionDetails;
import com.ge.transportation.eservices2.domainobjects.Properties;
import com.ge.transportation.eservices2.domainobjects.Property;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationRequest;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationResponse;
import com.ge.transportation.eservices2.domainobjects.ShimDetails;
import com.ge.transportation.eservices2.domainobjects.ShimDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.Side;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.VisibleDefectsDetails;
import com.ge.transportation.eservices2.domainobjects.VisibleDefectsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRecord;
import com.ge.transportation.eservices2.domainobjects.WheelConfigRequest;
import com.ge.transportation.eservices2.domainobjects.WheelConfigResponse;
import com.ge.transportation.eservices2.domainobjects.WheelProfile;
import com.ge.transportation.eservices2.domainobjects.WheelSheet;
import com.ge.transportation.eservices2.domainobjects.WheelSheetData;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetails;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWORequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetForWOResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetKey;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetNameDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.WheelSheetRequest;
import com.ge.transportation.eservices2.domainobjects.WheelSheetResponse;
import com.ge.transportation.eservices2.wheel.awss3.service.AWSFileHandlerService;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.config.WheelDetailConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.LocomotiveAll;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParameters;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.model.DefectDTO;
import com.ge.transportation.eservices2.wheel.model.UserDetailsDTO;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelSheetRepository;
import com.ge.transportation.eservices2.wheel.service.AdminService;
import com.ge.transportation.eservices2.wheel.service.WheelDataInjectService;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.service.WheelSheetService;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;
import com.ge.transportation.eservices2.wheel.util.WheelSortUtil;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;



@Component
public class WheelSheetServiceImpl implements WheelSheetService {


	private static final Logger logger = Logger.getLogger(WheelSheetServiceImpl.class);

	@Autowired
	WheelServiceValidator wheelServiceValidator;

	@Autowired
	WheelPersistanceService wheelPersistanceService;

	@Autowired
	AWSFileHandlerService awsFileHandlerService;

	@Autowired
	AppConfig appConfig;
	
	@Autowired
	WheelDetailConfig wheelDetConfig;

	@Autowired
	WheelFileDetailRepository wheelFileDetailRepo;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private WheelDataInjectService wheelDataInjectService;
	
	@Autowired
	WheelParamRepository wheelParamRepo;

	@Autowired
	WheelSheetRepository wheelSheetRepository;
	
	@Autowired
	RestUtility restUtility;
	
	String roadNumber = "";
	String aarRoad = "";
	String fileCreationDate = "";
	String operator = null;
	long customerId = 0;
	
	@Override
	public FileMeasurementsResponse loadFileMeasurements(FileMeasurementsRequest fileMeasurementsRequest, String uuId) {
		FileMeasurementsResponse fileMeasurementsResponse = new FileMeasurementsResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateMeasurementsParams(fileMeasurementsRequest, uuId);
			if (Objects.nonNull(statusType)) {
				fileMeasurementsResponse.setStatusType(statusType);
			} else {
				Long locomotiveID = fileMeasurementsRequest.getLocomotiveId();
				String fileName = fileMeasurementsRequest.getFileName();
				if (fileName.isEmpty()) {
					createWheelSheetWithAdminConfiguration(locomotiveID, fileMeasurementsResponse, uuId);
					fileMeasurementsResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType("Wheelsheetdata created with AdminConfiguration"));
				} else {
					loadMeasurementsFromFileAndAdminConfig(uuId, fileMeasurementsResponse, locomotiveID, fileName);
				}
			}
		} catch (Exception e) {
			logger.error(new WheelsException(e));
			logger.error(uuId + " Exception in loadFileMeasurements", e);
			fileMeasurementsResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		return fileMeasurementsResponse;
	}

	private void loadMeasurementsFromFileAndAdminConfig(String uuId, FileMeasurementsResponse fileMeasurementsResponse, Long locomotiveID,
			String fileName) {
		Calipriexport calipriexport = validateAndLoad(locomotiveID, fileName, uuId);
		if (Objects.nonNull(calipriexport)) {
			createWheelSheetDetailsFromFileAndAdminConfig(uuId, fileName, fileMeasurementsResponse, calipriexport);
		} else {
			fileMeasurementsResponse
					.setStatusType(WheelServiceUtil.setNoContentStatusType("Given File is not valid", uuId));
		}
	}

	private void createWheelSheetWithAdminConfiguration(Long locomotiveID, FileMeasurementsResponse fileMeasurementsResponse, String uuId) {
		LocomotiveAll locomotiveAll = getLocomotiveAllByLocomotiveId(locomotiveID, uuId);
		customerId = locomotiveAll.getCustomerId();
		aarRoad = locomotiveAll.getAarRoad();
		String locoType = locomotiveAll.getLocomotiveTypeCode();
		roadNumber = locomotiveAll.getRoadNumber();
		WheelConfigRequest limitRequest = new WheelConfigRequest();
		limitRequest.setCustId(customerId);
		limitRequest.setAarRoad(aarRoad);
		limitRequest.getLocoType().add(locoType);
		WheelConfigResponse wheelConfigResponse = adminService.getAdminConfiguration(limitRequest, uuId);
		List<WheelConfigRecord> wheelLimitRecords = wheelConfigResponse.getLimitRecords();
		
		List<WheelParameters> wheelParamList = wheelParamRepo.findByCustomerId(String.valueOf(limitRequest.getCustId()));
		WheelSheetDetails wheelSheetDetails = createWheelDetailsWithWheelConfigRecords(uuId, wheelParamList, wheelLimitRecords);
		fileMeasurementsResponse.setWheelSheetDetails(wheelSheetDetails);
	}

	private WheelSheetDetails createWheelDetailsWithWheelConfigRecords(String uuId, List<WheelParameters> wheelParamList, List<WheelConfigRecord> wheelLimitRecords) {
		WheelSheetDetails wheelSheetDetails = new WheelSheetDetails();
		WheelSheetKey wheelSheetKey = new WheelSheetKey();
		wheelSheetKey.setAarRoad(aarRoad);
		wheelSheetKey.setRoadNumber(roadNumber);
		wheelSheetDetails.setWheelSheetKey(wheelSheetKey);
		WheelSheet wheelsheet = new WheelSheet();
		Map<String, WheelParameters> wheelAdminIdMap = wheelParamList.stream()
				.filter(param -> Objects.nonNull(param.getDimesnionId()) && Objects.nonNull(param.getWheelAdminId())
						&& !param.getDimesnionId().isEmpty() && !param.getWheelAdminId().isEmpty())
				.collect(Collectors.toMap(WheelParameters::getWheelAdminId, param -> param));
		Optional<String> wheelDiameter = wheelParamList.stream()
				.filter(param -> Objects.nonNull(param.getDimesnionId()) && Objects.nonNull(param.getWheelAdminId())
						&& !param.getDimesnionId().isEmpty() && !param.getWheelAdminId().isEmpty())
				.filter(param -> appConfig.getXmlParamDiameter().equalsIgnoreCase(param.getDimesnionId()))
				.map(WheelParameters::getWheelAdminId)
				.findFirst();
		Optional<String> rimThickness = wheelParamList.stream()
				.filter(param -> Objects.nonNull(param.getDimesnionId()) && Objects.nonNull(param.getWheelAdminId())
						&& !param.getDimesnionId().isEmpty() && !param.getWheelAdminId().isEmpty())
				.filter(param -> appConfig.getXmlParamRimThickness().equalsIgnoreCase(param.getDimesnionId()) 
						&& WheelConstants.KTZ_CUSTOMER.equalsIgnoreCase(param.getCustomerId()))
				.map(WheelParameters::getWheelAdminId)
				.findFirst();
		List<String> wheelParamNames = new ArrayList<>();
		for (WheelParameters wheelParameter : wheelParamList) {
			wheelParamNames.add(wheelParameter.getWheelAdminId());
		}
		getAxlePropertiesForWheelSheet(uuId, wheelsheet, wheelAdminIdMap, wheelLimitRecords);
		setVisibleForAxleTruckLoco(wheelsheet, wheelDiameter, rimThickness,wheelParamNames, wheelLimitRecords);
		wheelsheet.getAxleProperties().stream().forEach(axleProps -> {
			setShimAndVisibleDefectProfiles(uuId, axleProps);
			});
		setPositionDetails(wheelsheet);
		wheelSheetDetails.getWheelSheet().add(wheelsheet);
		return wheelSheetDetails;
	}

	private void setVisibleForAxleTruckLoco(WheelSheet wheelsheet, Optional<String> wheelDiameter,Optional<String> rimThickness,
			List<String> wheelParamNames, List<WheelConfigRecord> wheelLimitRecords) {
		// US457438 : Comment this for loop if there is no need to check for limits tab
		for (WheelConfigRecord wheelConfigRecord : wheelLimitRecords) {
			if ((wheelDiameter.isPresent()
					&& wheelConfigRecord.getWheelParameter().equalsIgnoreCase(wheelDiameter.get()))
					|| (rimThickness.isPresent()
							&& wheelConfigRecord.getWheelParameter().equalsIgnoreCase(rimThickness.get()))) {
				setAxleTruckAndLocoParams(wheelsheet, rimThickness, wheelParamNames, wheelDiameter);
			}
		}
	}

	private void setAxleTruckAndLocoParams(WheelSheet wheelsheet, Optional<String> rimThickness,
			List<String> wheelParamNames, Optional<String> wheelDiameter) {
		
		wheelsheet.getAxleProperties().stream().forEach(axle -> {
			Optional<WheelProfile> diaParam = axle.getWheelProfiles().stream().filter(wheelprofile -> null!=wheelprofile.getName() &&
				wheelDiameter.isPresent() && wheelprofile.getName().equalsIgnoreCase(wheelDiameter.get())).findFirst();
			setRimAndWheelDiameters(axle.getWheelProfiles(), rimThickness, wheelDiameter);
			getDiameterProfiles(rimThickness, wheelParamNames, axle, diaParam);

		});
	}

	private void setRimAndWheelDiameters(List<WheelProfile> wheelProfiles, Optional<String> rimThickness,
			Optional<String> wheelDiameter) {
		wheelProfiles.stream().forEach(wheelProfile -> {
			if(aarRoad.contains("KTZ") && rimThickness.isPresent() && wheelProfile.getName().equalsIgnoreCase(rimThickness.get())) {
				wheelProfile.setRimThickness(Boolean.TRUE);
			}else if(wheelDiameter.isPresent() && wheelProfile.getName().equalsIgnoreCase(wheelDiameter.get())) {
				wheelProfile.setWheelDiameter(Boolean.TRUE);
			}
		});
		
	}

	private void getAxleProfile(List<String> wheelParamNames, AxleProperties axle) {
		Optional<String> axleParam = wheelParamNames.stream()
				.filter(param -> param.contains(WheelConstants.AXLE)).findFirst();
		WheelProfile wheelProfile = new WheelProfile();
		if (axleParam.isPresent()) {
			wheelProfile.setName(axleParam.get());
		} else {
			wheelProfile.setName(appConfig.getAxleName());
		}
		wheelProfile.setVisible(true);
		ParamDefination definition = new ParamDefination();
		definition.setType(ParamType.TEXTBOX);
		definition.setSpan(ParamSpan.CELL2);
		Side left = new Side();
		left.setDef(definition);
		Side right = new Side();
		right.setDef(new ParamDefination());
		wheelProfile.setLeft(left);
		wheelProfile.setRight(right);
		wheelProfile.setCalculated(true);
		axle.getWheelProfiles().add(wheelProfile);
	}

	private void getDiameterProfiles(Optional<String> rimThickness, List<String> wheelParamNames, AxleProperties axle,
			Optional<WheelProfile> diaParam) {
		if(rimThickness.isPresent() && !diaParam.isPresent()){
			WheelProfile dimterProfile = new WheelProfile();
			dimterProfile.setName(WheelConstants.CALC_WHEEL_DIAMTER);
			dimterProfile.setCalculated(true);
			dimterProfile.setVisible(true);
			ParamDefination def = new ParamDefination();
			def.setType(ParamType.TEXTBOX);
			def.setSpan(ParamSpan.CELL1);
			Side diameterLeft = new Side();
			diameterLeft.setDef(def);
			Side diamterRight = new Side();
			diamterRight.setDef(def);
			dimterProfile.setLeft(diameterLeft);
			dimterProfile.setRight(diamterRight);
			axle.getWheelProfiles().add(dimterProfile);
		}
		getAxleProfile(wheelParamNames, axle);
		if (axle.getAxleNumber() == 1) {
			WheelProfile truckProfile = new WheelProfile();
			truckProfile.setVisible(true);
			Side truckLeft = new Side();
			setTruckLevelProperties(truckProfile, truckLeft, wheelParamNames);
			setEmptyRightDef(truckProfile);
			axle.getWheelProfiles().add(truckProfile);

			WheelProfile locoProfile = new WheelProfile();
			locoProfile.setVisible(true);
			setLocoProperties(null, locoProfile, wheelParamNames);
			axle.getWheelProfiles().add(locoProfile);
		}
		if (axle.getAxleNumber() == 4) {
			WheelProfile wheelProfileTruck2 = new WheelProfile();
			wheelProfileTruck2.setVisible(true);
			Side truckLeft = new Side();
			setTruckLevelProperties(wheelProfileTruck2, truckLeft, wheelParamNames);
			setEmptyRightDef(wheelProfileTruck2);
			axle.getWheelProfiles().add(wheelProfileTruck2);
		}
	}

	private void getAxlePropertiesForWheelSheet(String uuId, WheelSheet wheelsheet, Map<String, WheelParameters> wheelAdminIdMap,
			List<WheelConfigRecord> wheelLimitRecords) {
		for (int i = 1; i <= 6; i++) {
			AxleProperties axleProperties = new AxleProperties();
			axleProperties.setAxleName("Axle" + i);
			axleProperties.setAxleNumber(i);
			logger.info("Adding Configured Wheel Parameters to the wheelsheet");
			for (WheelConfigRecord wheelConfigRecord : wheelLimitRecords) {
				setWheelProfilesForBlanksheet(wheelAdminIdMap, axleProperties, wheelConfigRecord);
			}
			//setShimAndVisibleDefectProfiles(uuId, axleProperties);
			wheelsheet.getAxleProperties().add(axleProperties);
		}
		
	}

	private void setWheelProfilesForBlanksheet(Map<String, WheelParameters> wheelAdminIdMap, AxleProperties axleProperties,
			WheelConfigRecord wheelConfigRecord) {
		logger.info("WheelParameter: "+wheelConfigRecord.getWheelParameter()+", LowerLimit: "+wheelConfigRecord.getLowerLimit()+", UpperLimit: "+wheelConfigRecord.getUpperLimit());
		WheelProfile wheelProfile = new WheelProfile();
		WheelParameters wheelParameters = wheelAdminIdMap.get(wheelConfigRecord.getWheelParameter());
		if (Objects.nonNull(wheelParameters)) {
			if(!(wheelParameters.getWheelAdminId().contains(WheelConstants.AXLE) || wheelParameters.getWheelAdminId().contains(WheelConstants.TRUCK) || wheelParameters.getWheelAdminId().contains(WheelConstants.LOCO) ||
					WheelConstants.CALC_WHEEL_DIAMTER.equalsIgnoreCase(wheelParameters.getWheelAdminId()))) {
				wheelProfile.setName(wheelParameters.getWheelAdminId());
				wheelProfile.setVisible(true);
				ParamDefination definition = new ParamDefination();
				definition.setType(ParamType.TEXTBOX);
				getParamSpan(wheelParameters, definition);
				Side left = new Side();
				left.setDef(definition);
				Side right = new Side();
				if (ParamSpan.CELL2.equals(definition.getSpan())) {
					right.setDef(new ParamDefination());
				}
				else {
					right.setDef(definition);
				}
				wheelProfile.setLeft(left);
				wheelProfile.setRight(right);
				axleProperties.getWheelProfiles().add(wheelProfile);
			}
			
		}
		else {
			logger.info("WheelParameter: "+wheelConfigRecord.getWheelParameter()+" dimensionId is null in wheelParameters collection in DocumentDb");
		}
	}


	private void getParamSpan(WheelParameters wheelParameters, ParamDefination defination) {
		if ("Y".equalsIgnoreCase(wheelParameters.getMeasuredWheelL())) {
			defination.setSpan(ParamSpan.CELL1);
		} else if ("Y".equalsIgnoreCase(wheelParameters.getMeasuredAxleL())) {
			defination.setSpan(ParamSpan.CELL2);
		} else if ("Y".equalsIgnoreCase(wheelParameters.getMeasuredBogieL())) {
			defination.setSpan(ParamSpan.CELL6);
		} else {
			defination.setSpan(ParamSpan.CELL12);
		}
	}

	private LocomotiveAll getLocomotiveAllByLocomotiveId(Long locomotiveID, String uuId) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getLocomotiveAllByLocomotiveId()).append(locomotiveID);
		return restUtility.callCoreGetService(locomotiveID , new LocomotiveAll(), stringbuilder.toString(),
				"WheelServiceImpl: " + uuId, headers);
	}

	public void createWheelSheetDetailsFromFileAndAdminConfig(String uuId, String fileName, FileMeasurementsResponse fileMeasurementsResponse,
			Calipriexport calipriexport) {
		RoadNumberValidationResponse response = getCustomerIdAarRoadAndLocotype(uuId, calipriexport);
		if (StatusCode.SUCCESS.equals(response.getStatusCode())) {
			logger.info("aarRoad: " + aarRoad + ", customerId: " + response.getCustomerId() + ", locoType: "
					+ response.getLocoType());
			updateDimensions(uuId, fileName, fileMeasurementsResponse, calipriexport, response);
		}
		else {
			fileMeasurementsResponse.setStatusType(WheelServiceUtil.setNoContentStatusType("Failed to get CustomerId, AarRoad And Locotype from Workorder Service", uuId));
		}
	}

	public RoadNumberValidationResponse getCustomerIdAarRoadAndLocotype(String uuId, Calipriexport calipriexport) {
		Properties properties = calipriexport.getProperties();
		properties.getProperty().stream().forEach(property -> {
			if (WheelConstants.LOCOID.equalsIgnoreCase(property.getId())) {
				roadNumber = property.getValue();
			}
			if (WheelConstants.AAR.equalsIgnoreCase(property.getId())) {
				aarRoad = property.getValue();
			}
		});
		RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber(roadNumber);
		request.setAarRoad(aarRoad);
		RoadNumberValidationResponse response = validateRoadnumberFromWorkOrderService(uuId, request);
		if(Objects.nonNull(response)) {
			return response;
		}
		else {
			response = new RoadNumberValidationResponse();
			return response;
		}
	}

	private Calipriexport validateAndLoad(Long locomotiveID, String fileName, String uuId) {
		Calipriexport calipriexport = null;
		fileCreationDate = wheelPersistanceService.isValidFile(locomotiveID, fileName, uuId);
		if (!fileCreationDate.isEmpty()) {
			StringBuilder processingKey = new StringBuilder(appConfig.getAwsS3Path());
			processingKey.append(appConfig.getProcessing()).append(WheelConstants.FORWARD).append(fileName);
			InputStream inputStream = awsFileHandlerService.getFileAsInputStream(processingKey.toString(), uuId);
			if (Objects.nonNull(inputStream)) {
				calipriexport = WheelServiceUtil.parseXmlFile(inputStream);
			}
			}
		return calipriexport;
	}

	@Override
	public FileDetailsResponse retrieveFileDetails(FileDetailsRequest fileDetailsRequest, String uuId) {
		FileDetailsResponse response = new FileDetailsResponse();
		StatusType statusType = null;
		try {
			logger.info(uuId + " service to fetch file details has been started ");
			statusType = wheelServiceValidator.validateRequestParams(fileDetailsRequest, uuId);
			if (Objects.nonNull(statusType)) {
				response.setStatusType(statusType);
			} else {
				response = getFileDetails(fileDetailsRequest, uuId);
			}
		} catch (Exception e) {
			statusType = WheelServiceUtil.sendErrorStatusType(e, uuId);
			response.setStatusType(statusType);
			logger.error(uuId + " Exception in retrieveFileDetails", e);
		}
		logger.info(uuId + " service to fetch file details has been executed ");
		return response;
	}

	public FileDetailsResponse getFileDetails(FileDetailsRequest fileDetailsRequest, String uuId) {
		FileDetailsResponse fileDetailsResponse = new FileDetailsResponse();
		StatusType statusType = new StatusType();
		logger.info(uuId + " Before executing database query for getting file details");
		try {
			List<WheelFileDetail> wheelFileList = wheelFileDetailRepo
					.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(fileDetailsRequest.getLocomotiveId(), WheelConstants.VALID_STATUS);
			if (!wheelFileList.isEmpty()) {
				wheelFileList.stream().forEach(
						wheelDetail -> fileDetailsResponse.getFileDetails().add(checkAndUpdateFileAge(wheelDetail,uuId)));

				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
				fileDetailsResponse.setStatusType(statusType);

			} else {
				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.NO_FILE_AVAILABLE);
				fileDetailsResponse.setStatusType(statusType);
			}
		} catch (Exception e) {
			throw new WheelsException(e);
		}
		logger.info(uuId + " Done executing getFileDetails()");
		return fileDetailsResponse;
	}

	public FileDetails checkAndUpdateFileAge(WheelFileDetail wheelFileDetail, String uuId) {
		logger.info(uuId + " Inside checkAndUpdateFileAge()");
		FileDetails fileDetails = new FileDetails();
		fileDetails.setFileName(wheelFileDetail.getFileName());
		fileDetails.setFileTimeStamp(wheelFileDetail.getFileCreationDate());
		logger.info(uuId + " File name "+wheelFileDetail.getFileName());
		boolean fileGrtThanEightHours = false;
		Date currentDate = new Date();
		Date fileRecievedDate = WheelServiceUtil.convertStringToDate(wheelFileDetail.getFileCreationDate());
		long dateDiff = currentDate.getTime() - fileRecievedDate.getTime();
		if (dateDiff > (8 * 1000 * 60 * 60))
			fileGrtThanEightHours = true;
		fileDetails.setFileAgeGrtThan8Hrs(fileGrtThanEightHours);
		return fileDetails;
	}

	public RoadNumberValidationResponse validateRoadnumberFromWorkOrderService(String uuid, RoadNumberValidationRequest request) {
		logger.info(uuid+": validate Roadnumber From Work order Service by aar: "+request.getAarRoad()+", roadNumber: "+request.getRoadNumber());
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getRoadnumberValidation());
		RoadNumberValidationResponse response = restUtility.callCorePostService(request, new RoadNumberValidationResponse(), stringbuilder.toString(),
				"WheelServiceImpl: " + uuid);
		if(Objects.nonNull(response)) {
			logger.info(uuid+": Response: "+response.getStatusCode());
			return response;
		}
		else {
			logger.info(uuid+": Failed to get Response");
			response = new RoadNumberValidationResponse();
			return response;
		}
	}
	
	private void updateDimensions(String uuId, String fileName, FileMeasurementsResponse fileMeasurementsResponse,
			Calipriexport calipriexport, RoadNumberValidationResponse response) {
		logger.info(uuId + " aarRoad: " + aarRoad + ", customerId: " + response.getCustomerId() + ", locoType: "
				+ response.getLocoType());
		WheelConfigRequest limitRequest = new WheelConfigRequest();
		limitRequest.setCustId(response.getCustomerId());
		limitRequest.setAarRoad(aarRoad);
		limitRequest.getLocoType().add(response.getLocoType());
		WheelConfigResponse wheelConfigResponse = adminService.getAdminConfiguration(limitRequest, uuId);
		List<WheelConfigRecord> wheelLimitRecords = wheelConfigResponse.getLimitRecords();
		Map<String, Boolean> wheelParams = wheelLimitRecords.stream().map(WheelConfigRecord::getWheelParameter).distinct().collect(Collectors.toMap(k -> k, k -> false));
		if (Objects.nonNull(wheelParams)) {
			logger.info(uuId + " wheelParams : " + wheelParams.size());
			List<WheelParameters> wheelParamList = wheelParamRepo.findByCustomerId(String.valueOf(limitRequest.getCustId()));
			logger.info(uuId+" Wheel Parameters from WheelParameters collection");
			wheelParamList.forEach(param -> logger.info(uuId+" DimensionId: "+param.getDimesnionId()+", WheelAdminId: "+param.getWheelAdminId()));
			WheelSheetDetails wheelSheetDetail= mapClaipriexportToWheelSheetDetail(uuId, fileName, calipriexport, wheelParamList, wheelParams,wheelLimitRecords);
			
			logger.info(uuId + " setting final response for fileMeasurementsResponse");
			fileMeasurementsResponse.setWheelSheetDetails(wheelSheetDetail);
			fileMeasurementsResponse
					.setStatusType(WheelServiceUtil.sendSuccessStatusType("Wheelsheetdata created from file and updated with AdminConfiguration"));
		}
	}

	private WheelSheetDetails mapClaipriexportToWheelSheetDetail(String uuId, String fileName, Calipriexport calipriexport, List<WheelParameters> wheelParameters, Map<String, Boolean> wheelParams, List<WheelConfigRecord> wheelLimitRecords) {
		WheelSheetDetails wheelSheetDetails = new WheelSheetDetails();
		WheelSheetKey key = new WheelSheetKey();
		key.setAarRoad(aarRoad);
		key.setRoadNumber(roadNumber);
		wheelSheetDetails.setWheelSheetKey(key);
		WheelSheet wheelsheet = new WheelSheet();
		wheelsheet.setFileName(fileName);
		wheelsheet.setFileCreationDate(fileCreationDate);
		wheelsheet.setUom(WheelConstants.UNIT_OF_MEASUREMENT);
		List<String> wheelParamNames = new ArrayList<>();
		Map<String, WheelParameters> dimensionIdMap = getWheelParamsAndDimensionMap(wheelParameters, wheelParamNames);
		WheelSheet sortedWheelSheet = new WheelSheet();
		getAxleProperties(uuId,calipriexport, wheelParams, wheelsheet, dimensionIdMap,wheelParameters,wheelLimitRecords,sortedWheelSheet);
		setPositionDetails(sortedWheelSheet);
		wheelSheetDetails.getWheelSheet().add(sortedWheelSheet);
		return wheelSheetDetails;
	}

	private Map<String, WheelParameters> getWheelParamsAndDimensionMap(List<WheelParameters> wheelParameters,
			List<String> wheelParamNames) {
		for (WheelParameters wheelParameter : wheelParameters) {
			wheelParamNames.add(wheelParameter.getWheelAdminId());
		}
		Map<String, WheelParameters> dimensionIdMap = wheelParameters.stream()
				.filter(param -> Objects.nonNull(param.getDimesnionId()) && Objects.nonNull(param.getWheelAdminId())
						&& !param.getDimesnionId().isEmpty() && !param.getWheelAdminId().isEmpty())
				.collect(Collectors.toMap(WheelParameters::getDimesnionId, param -> param));
		return dimensionIdMap;
	}

	private void getAxleProperties(String uuId, Calipriexport calipriexport, Map<String, Boolean> wheelParams, WheelSheet wheelsheet, Map<String, WheelParameters> dimensionIdMap, List<WheelParameters> wheelParameters, List<WheelConfigRecord> wheelLimitRecords, WheelSheet sortedWheelSheet) {
		List<Double> truck1 = new ArrayList<>();
		List<Double> truck2 = new ArrayList<>();
		Map<Integer,String> axleDiaDiffMap = new HashMap<>();
		List<Object> object = calipriexport.getObjects().getObject();
		object.stream().forEach(obj -> {
		AxleProperties axleProperties = new AxleProperties();
		List<WheelProfile> wheelProfilesList = new ArrayList<>();
		axleProperties.setAxleName(obj.getName());
		char number = obj.getName().charAt(obj.getName().length()-1);
		axleProperties.setAxleNumber(Integer.valueOf(Character.toString(number)));
		obj.getPoints().getPoint().forEach(point -> {
			List<Property> properties = point.getProperties().getProperty();
			if (!properties.isEmpty()) {
				getLeftRightProperties(wheelParams, dimensionIdMap, axleProperties, wheelProfilesList, point,
						properties);
			}
			else {
				getOtherWheelProfiles(wheelParams, dimensionIdMap, axleProperties, point);
			}
			getWheelDiameters(truck1, truck2, axleProperties,dimensionIdMap,axleDiaDiffMap,wheelParams);
		});
		wheelsheet.getAxleProperties().add(axleProperties);
		});
		sortAxleProperties(wheelsheet,wheelLimitRecords,sortedWheelSheet);
		calculateDiameterDiff(uuId, truck1, truck2,sortedWheelSheet,wheelParams,axleDiaDiffMap,wheelParameters);
		sortedWheelSheet.getAxleProperties().stream().forEach(axleProps -> {
		setShimAndVisibleDefectProfiles(uuId, axleProps);
		});
	}

	private void sortAxleProperties(WheelSheet wheelsheet, List<WheelConfigRecord> wheelLimitRecords,
			WheelSheet sortedWheelSheet) {
		sortedWheelSheet.setFileName(wheelsheet.getFileName());
		sortedWheelSheet.setFileCreationDate(wheelsheet.getFileCreationDate());
		sortedWheelSheet.setUom(wheelsheet.getUom());
		wheelsheet.getAxleProperties().stream().forEach(axle -> {
			AxleProperties axleProps = new AxleProperties();
			axleProps.setAxleName(axle.getAxleName());
			axleProps.setAxleNumber(axle.getAxleNumber());
			for (int i = 0; i < wheelLimitRecords.size(); i++) {
				String sortKey = wheelLimitRecords.get(i).getWheelParameter();
				axle.getWheelProfiles().stream().forEach(wheelProfile -> {
					if (wheelProfile.getName().equalsIgnoreCase(sortKey) && !WheelConstants.CALC_WHEEL_DIAMTER.equalsIgnoreCase(sortKey)) {
						axleProps.getWheelProfiles().add(wheelProfile);
					}
				});
			}
			axle.getWheelProfiles().stream().forEach(wheelProfile -> {
				if (wheelProfile.getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER)) {
					axleProps.getWheelProfiles().add(wheelProfile);
				}
				if (!wheelProfile.isVisible()) {
					axleProps.getWheelProfiles().add(wheelProfile);
				}
			});
			sortedWheelSheet.getAxleProperties().add(axleProps);
		});
	}

	private void getLeftRightProperties(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap,
			AxleProperties axleProperties, List<WheelProfile> wheelProfilesList, Point point,
			List<Property> properties) {
		Optional<String> sectionValue = properties.stream().filter(prop -> !prop.getValue().isEmpty())
				.map(Property::getValue).findAny();
		if(sectionValue.isPresent() && sectionValue.get().equalsIgnoreCase(WheelConstants.LEFT)){
			getLeftWheelProfiles(wheelParams, dimensionIdMap, wheelProfilesList, point);
		}
		else if(sectionValue.isPresent() && sectionValue.get().equalsIgnoreCase(WheelConstants.RIGHT)){
			getRightWheelProfiles(wheelParams, dimensionIdMap, axleProperties, wheelProfilesList, point);
		}
	}

	private void getWheelDiameters(List<Double> truck1, List<Double> truck2, AxleProperties axleProperties, Map<String, WheelParameters> dimensionIdMap, Map<Integer, String> axleDiaDiffMap, Map<String, Boolean> wheelParams) {	
		getDiameterFromRimThickness(axleProperties,dimensionIdMap,wheelParams);
		WheelParameters wheelDiameterParam = dimensionIdMap.get(appConfig.getXmlParamDiameter());
		WheelParameters rimThicknessParam = dimensionIdMap.get(appConfig.getXmlParamRimThickness());
		if (Objects.nonNull(wheelDiameterParam) || Objects.nonNull(rimThicknessParam)) {
			if(Objects.isNull(axleProperties.getAxleNumber())) {
				char number = axleProperties.getAxleName().charAt(axleProperties.getAxleName().length()-1);
				axleProperties.setAxleNumber(Integer.valueOf(Character.toString(number)));
			}
			DecimalFormat df = getDecimalFormat();
			List<Integer> truck1Axils = new ArrayList<>(Arrays.asList(1, 2, 3));
			if(Objects.nonNull(rimThicknessParam) && WheelConstants.KTZ_CUSTOMER.equalsIgnoreCase(rimThicknessParam.getCustomerId())){
			if (truck1Axils.contains(axleProperties.getAxleNumber())) {
				axleProperties.getWheelProfiles().parallelStream()
						.filter(wheelProfile -> (wheelProfile.getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER)))
						.forEach(wheelProfile -> 
							getTruck1(truck1, axleProperties, axleDiaDiffMap, df, wheelProfile));
			} else {
				axleProperties.getWheelProfiles().parallelStream()
						.filter(wheelProfile ->  wheelProfile.getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER))
						.forEach(wheelProfile -> 
							getTruck2(truck2, axleProperties, axleDiaDiffMap, df, wheelProfile));
			}
			}
			else if (Objects.nonNull(wheelDiameterParam)){
					if (truck1Axils.contains(axleProperties.getAxleNumber())) {
						axleProperties.getWheelProfiles().parallelStream()
								.filter(wheelProfile -> (null!=wheelDiameterParam && wheelProfile.getName().equalsIgnoreCase(wheelDiameterParam.getWheelAdminId())))
								.forEach(wheelProfile -> { 
									wheelProfile.setWheelDiameter(true);
									getTruck1(truck1, axleProperties, axleDiaDiffMap, df, wheelProfile);
									});
					} else {
						axleProperties.getWheelProfiles().parallelStream()
								.filter(wheelProfile -> (null!=wheelDiameterParam && wheelProfile.getName().equalsIgnoreCase(wheelDiameterParam.getWheelAdminId())))
								.forEach(wheelProfile -> { 
									wheelProfile.setWheelDiameter(true);
									getTruck2(truck2, axleProperties, axleDiaDiffMap, df, wheelProfile);
									});
					}
					}
			
		}
	}

	private void getTruck1(List<Double> truck1, AxleProperties axleProperties, Map<Integer, String> axleDiaDiffMap,
			DecimalFormat df, WheelProfile wheelProfile) {
		Side left = wheelProfile.getLeft();
		Side right = wheelProfile.getRight();
		Double lvalue = null;
		Double rvalue = null;
		if (Objects.nonNull(left) && null!=left.getValue() && !left.getValue().isEmpty()) {
			lvalue = Double.parseDouble(left.getValue());
			truck1.add(lvalue);
		}
		if (Objects.nonNull(right) && null!=right.getValue() && !right.getValue().isEmpty()) {
			rvalue = Double.parseDouble(right.getValue());
			truck1.add(rvalue);
		}
		if(null!=lvalue && null!=rvalue){
		Double axleDiff = Math.max(lvalue,rvalue) - Math.min(lvalue,rvalue);
		axleDiaDiffMap.put(axleProperties.getAxleNumber(), df.format(axleDiff));
		}
	}

	
	private void getTruck2(List<Double> truck2, AxleProperties axleProperties, Map<Integer, String> axleDiaDiffMap,
			DecimalFormat df, WheelProfile wheelProfile) {
		Side left = wheelProfile.getLeft();
		Side right = wheelProfile.getRight();
		Double lvalue = null;
		Double rvalue = null;
		if (Objects.nonNull(left) && null!=left.getValue() && !left.getValue().isEmpty()) {
			lvalue = Double.parseDouble(left.getValue());
			truck2.add(lvalue);
		}
		if (Objects.nonNull(right) && null!=right.getValue() && !right.getValue().isEmpty()) {
			rvalue = Double.parseDouble(right.getValue());
			truck2.add(rvalue);
		}
		if(null!=lvalue && null!=rvalue){
		Double axleDiff = Math.max(lvalue,rvalue) - Math.min(lvalue,rvalue);
		axleDiaDiffMap.put(axleProperties.getAxleNumber(), df.format(axleDiff));
		}
	}

	private void getDiameterFromRimThickness(AxleProperties axleProperties,
			Map<String, WheelParameters> dimensionIdMap, Map<String, Boolean> wheelParams) {
		WheelParameters rimThicknessParam = dimensionIdMap.get(appConfig.getXmlParamRimThickness());
		if(Objects.nonNull(rimThicknessParam) && WheelConstants.KTZ_CUSTOMER.equalsIgnoreCase(rimThicknessParam.getCustomerId())){
			axleProperties.getWheelProfiles().parallelStream().filter(
					wheelProfile -> wheelProfile.getName().equalsIgnoreCase(rimThicknessParam.getWheelAdminId()))
					.forEach(wheelProfile -> wheelProfile.setRimThickness(true));
			List<WheelProfile> rimProperies = axleProperties.getWheelProfiles().parallelStream().filter(
					wheelProfile -> wheelProfile.getName().contains(rimThicknessParam.getWheelAdminId()))
					.collect(Collectors.toList());
			List<WheelProfile> calcDiameter = axleProperties.getWheelProfiles().parallelStream().filter(
					wheelProfile -> wheelProfile.getName().equalsIgnoreCase(WheelConstants.CALC_WHEEL_DIAMTER))
					.collect(Collectors.toList());
			if (!rimProperies.isEmpty()) {
				if(!calcDiameter.isEmpty()) {
					WheelProfile diameterProfile = calcDiameter.get(0);
					rimProperies.forEach(wheelProfile -> {
						setCalcDiameterLeftAndRight(wheelProfile, diameterProfile);
					});
					}
				else {
				rimProperies.forEach(wheelProfile -> {
					WheelProfile diameterProfile = new WheelProfile();
					diameterProfile.setName(WheelConstants.CALC_WHEEL_DIAMTER);
					// US457438 - comment is limit check is not required
					if(wheelParams.containsKey(rimThicknessParam.getWheelAdminId())){
					diameterProfile.setVisible(true);
					}
					else {
						diameterProfile.setVisible(false);
					}
					diameterProfile.setCalculated(true);
					setCalcDiameterLeftAndRight(wheelProfile, diameterProfile);
					axleProperties.getWheelProfiles().add(diameterProfile);
				});
			}
			}
		}
	}

	private void setCalcDiameterLeftAndRight(WheelProfile wheelProfile, WheelProfile diameterProfile) {
		Side left = new Side();
		ParamDefination def = wheelProfile.getLeft().getDef();
		left.setDef(def);
		String leftRimThickness = wheelProfile.getLeft().getValue();
		String wheelDiameter = calcDiamter(leftRimThickness);
		left.setValue(wheelDiameter);
		diameterProfile.setLeft(left);
		Side right = new Side();
		right.setDef(def);
		String rightRimThickness = wheelProfile.getRight().getValue();
		String rightDiameter = calcDiamter(rightRimThickness);
		right.setValue(rightDiameter);
		diameterProfile.setRight(right);
	}

	private String calcDiamter(String rimThickness) {
		String wheelDiameter = null;
		DecimalFormat df = getDecimalFormat();
		if(null!=rimThickness && !rimThickness.isEmpty() && WheelConstants.AAR_KTZ.equalsIgnoreCase(aarRoad)||WheelConstants.AAR_KTZC.equalsIgnoreCase(aarRoad)){
			 wheelDiameter =  df.format(905+(2*Double.parseDouble(rimThickness)));
		} else if (null!=rimThickness && !rimThickness.isEmpty() && WheelConstants.AAR_KTZP.equalsIgnoreCase(aarRoad)){
			 wheelDiameter =   df.format(896+(2*Double.parseDouble(rimThickness)));
		}
		return wheelDiameter;
	}

	private void calculateDiameterDiff(String uuId, List<Double> truck1, List<Double> truck2, WheelSheet wheelsheet,
			Map<String, Boolean> wheelParams, Map<Integer, String> axleDiaDiffMap, List<WheelParameters> wheelParameters) {
		logger.info(uuId + " Calculating diameter differnece");
		DecimalFormat df = getDecimalFormat();
		String truck1DiameterDiff = "0.00";
		String truck2DiameterDiff = "0.00";
		String locoDiameterDiff = "0.00";
		if (!truck1.isEmpty()) {
			Double maxTruck1Dia = Collections.max(truck1);
			Double minTruck1Dia = Collections.min(truck1);
			Double truck1DiaDiff = maxTruck1Dia - minTruck1Dia;
			truck1DiameterDiff = df.format(truck1DiaDiff);
		}
		if (!truck2.isEmpty()) {
			Double maxTruck2Dia = Collections.max(truck2);
			Double minTruck2Dia = Collections.min(truck2);
			Double truck2DiaDiff = maxTruck2Dia - minTruck2Dia;
			truck2DiameterDiff = df.format(truck2DiaDiff);
		}
		List<Double> loco = new ArrayList<>();
		loco.addAll(truck1);
		loco.addAll(truck2);
		if (!loco.isEmpty()) {
			Double maxLocoDia = Collections.max(loco);
			Double minLocoDia = Collections.min(loco);
			Double locoDiaDiff = maxLocoDia - minLocoDia;
			locoDiameterDiff = df.format(locoDiaDiff);
		}
		final String t1DiameterDiff = truck1DiameterDiff;
		final String t2DiameterDiff = truck2DiameterDiff;
		final String lcDiameterDiff = locoDiameterDiff;
		logger.info(uuId + ": Diameter Difference : Axle - " + axleDiaDiffMap + ", Truck1 - " + truck1DiameterDiff
				+ ",  Truck2 - " + truck2DiameterDiff + " Loco - " + locoDiameterDiff);
		wheelsheet.getAxleProperties().stream().forEach(axle -> {
			if (Objects.isNull(axle.getAxleNumber())) {
				char number = axle.getAxleName().charAt(axle.getAxleName().length() - 1);
				axle.setAxleNumber(Integer.valueOf(Character.toString(number)));
			}
			List<String> wheelParamNames = new ArrayList<>();
			Map<String, WheelParameters> dimensionIdMap = getWheelParamsAndDimensionMap(wheelParameters, wheelParamNames);
			WheelParameters wheelDiameterParam = dimensionIdMap.get(appConfig.getXmlParamDiameter());
			WheelParameters rimThicknessParam = dimensionIdMap.get(appConfig.getXmlParamRimThickness());
			// US457438 : Comment  wheelParams.containsKey(wheelDiameterParam.getWheelAdminId()) , wheelParams.containsKey(rimThicknessParam.getWheelAdminId()) if limits check is not required
			if ((Objects.nonNull(wheelDiameterParam) && wheelParams.containsKey(wheelDiameterParam.getWheelAdminId())) 
					|| (Objects.nonNull(rimThicknessParam) && wheelParams.containsKey(rimThicknessParam.getWheelAdminId()) 
							&& WheelConstants.KTZ_CUSTOMER.equalsIgnoreCase(rimThicknessParam.getCustomerId()))) {
				setVisibleDiameterDiff(wheelParamNames, axleDiaDiffMap, t1DiameterDiff, t2DiameterDiff, lcDiameterDiff,
						axle);
			} else {
				setInvisibleProperties(truck1, truck2, wheelParamNames, t1DiameterDiff, t2DiameterDiff, lcDiameterDiff,
						axle);
			}
		});
		logger.info(uuId + " Calculated diameter difference");
	}

	private void setInvisibleProperties(List<Double> truck1, List<Double> truck2, List<String> wheelParamNames,
			final String t1DiameterDiff, final String t2DiameterDiff, final String lcDiameterDiff,
			AxleProperties axle) {
		if (!truck1.isEmpty() || (!truck2.isEmpty())) {
			WheelProfile truck1Profile = new WheelProfile();
			truck1Profile.setVisible(false);
			Side left = new Side();
			left.setValue(t1DiameterDiff);
			setTruckLevelProperties(truck1Profile, left, wheelParamNames);
			setEmptyRightDef(truck1Profile);
			axle.getWheelProfiles().add(truck1Profile);

			WheelProfile locoProfile = new WheelProfile();
			locoProfile.setVisible(false);
			setLocoProperties(lcDiameterDiff, locoProfile, wheelParamNames);
			axle.getWheelProfiles().add(locoProfile);

			WheelProfile truck2Profile = new WheelProfile();
			truck2Profile.setVisible(false);
			Side left2 = new Side();
			left.setValue(t2DiameterDiff);
			setTruckLevelProperties(truck2Profile, left2, wheelParamNames);
			setEmptyRightDef(truck2Profile);
			axle.getWheelProfiles().add(truck2Profile);

		}
	}

	private void setVisibleDiameterDiff(List<String> wheelParamNames, Map<Integer, String> axleDiaDiffMap,
			final String t1DiameterDiff, final String t2DiameterDiff, final String lcDiameterDiff,
			AxleProperties axle) {
		if (axle.getAxleNumber() == 1) {
			setAxleDiameterDiff(wheelParamNames, axleDiaDiffMap, axle);
			
			WheelProfile truckProfile = new WheelProfile();
			truckProfile.setVisible(true);
			Side left = new Side();
			left.setValue(t1DiameterDiff);
			setTruckLevelProperties(truckProfile, left, wheelParamNames);
			setEmptyRightDef(truckProfile);
			axle.getWheelProfiles().add(truckProfile);

			WheelProfile locoProfile = new WheelProfile();
			locoProfile.setVisible(true);
			setLocoProperties(lcDiameterDiff, locoProfile, wheelParamNames);
			axle.getWheelProfiles().add(locoProfile);
		}
		if (axle.getAxleNumber() == 4) {
			setAxleDiameterDiff(wheelParamNames, axleDiaDiffMap, axle);
			
			WheelProfile wheelProfile = new WheelProfile();
			wheelProfile.setVisible(true);
			Side left = new Side();
			left.setValue(t2DiameterDiff);
			setTruckLevelProperties(wheelProfile, left, wheelParamNames);
			setEmptyRightDef(wheelProfile);
			axle.getWheelProfiles().add(wheelProfile);
		} else {
			setAxleDiameterDiff(wheelParamNames, axleDiaDiffMap, axle);
		}
	}

	private DecimalFormat getDecimalFormat() {
		int precision = appConfig.getWheelDecimalPrecision();
		String decimalFormat = "0.";
		for (int i = 0; i < precision; i++) {
			decimalFormat = decimalFormat + "0";
		}
		DecimalFormat df = new DecimalFormat(decimalFormat);
		return df;
	}

	public void setAxleDiameterDiff(List<String> wheelParamNames, Map<Integer, String> axleDiaDiffMap,
			AxleProperties axle) {
		List<WheelProfile> wheelProfile = axle.getWheelProfiles().stream().filter(wheelprofile -> null!=wheelprofile.getName() &&
			wheelprofile.getName().contains(WheelConstants.AXLE)).collect(Collectors.toList());
			if(wheelProfile.isEmpty()) {
				WheelProfile axleProfile = new WheelProfile();
				axleProfile.setVisible(true);
				Side axleleft = new Side();
				axleleft.setValue(axleDiaDiffMap.get(axle.getAxleNumber()));
				setAxleLevelProperties(axleProfile, axleleft, wheelParamNames);
				setEmptyRightDef(axleProfile);
				axle.getWheelProfiles().add(axleProfile);
			}
			else {
				wheelProfile.get(0).setCalculated(true);
				wheelProfile.get(0).setVisible(true);
			}
	}

	private void setAxleLevelProperties(WheelProfile wheelProfile, Side left, List<String> wheelParams) {
		Optional<String> axleParam = wheelParams.stream().filter(param -> param.contains(WheelConstants.AXLE)).findFirst();
		if(axleParam.isPresent()) {
			wheelProfile.setName(axleParam.get());
		}
		else {
			wheelProfile.setName(appConfig.getAxleName());
		}
		ParamDefination defination = new ParamDefination();
		defination.setType(ParamType.TEXTBOX);
		defination.setSpan(ParamSpan.CELL2);
		left.setDef(defination);	
		wheelProfile.setCalculated(true);
		wheelProfile.setLeft(left);
		
	}

	private void setLocoProperties(String locoDiameterDiff, WheelProfile wheelProfile, List<String> wheelParams) {
		Optional<String> locoParam = wheelParams.stream().filter(param -> param.contains(WheelConstants.LOCO)).findFirst();
		if(locoParam.isPresent()) {
			wheelProfile.setName(locoParam.get());
		}
		else {
			wheelProfile.setName(appConfig.getLocoName());
		}
		ParamDefination defination = new ParamDefination();
		defination.setType(ParamType.TEXTBOX);
		Side left = new Side();
		left.setValue(locoDiameterDiff);
		defination.setSpan(ParamSpan.CELL12);
		left.setDef(defination);
		wheelProfile.setLeft(left);
		wheelProfile.setCalculated(true);
		setEmptyRightDef(wheelProfile);
	}

	private void setTruckLevelProperties(WheelProfile wheelProfile, Side left, List<String> wheelParams) {
		Optional<String> truckParam = wheelParams.stream().filter(param -> param.contains(WheelConstants.TRUCK)).findFirst();
		if(truckParam.isPresent()) {
			wheelProfile.setName(truckParam.get());
		}
		else {
			wheelProfile.setName(appConfig.getTruckName());
		}
		ParamDefination defination = new ParamDefination();
		defination.setType(ParamType.TEXTBOX);
		defination.setSpan(ParamSpan.CELL6);
		left.setDef(defination);
		
		wheelProfile.setLeft(left);
		wheelProfile.setCalculated(true);
	}

	private void setEmptyRightDef(WheelProfile wheelProfile) {
		Side right = new Side();
		ParamDefination rightDef = new ParamDefination();
		right.setDef(rightDef);
		wheelProfile.setRight(right);
	}
	
	private void getOtherWheelProfiles(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap,
			AxleProperties axleProperties, Point point) {
		point.getDimensions().getDimension().forEach(dimension ->{
			WheelParameters wheelParameters2 = dimensionIdMap.get(dimension.getId());
			if(Objects.nonNull(wheelParameters2) && !(wheelParameters2.getWheelAdminId().contains(WheelConstants.AXLE))) {
			WheelProfile wheelProfile = new WheelProfile();
			Side left = getParamSectionSpanAndVisible(wheelParams, dimensionIdMap, dimension, wheelProfile);
			wheelProfile.setLeft(left);
			
			setEmptyRightDef(wheelProfile);
			axleProperties.getWheelProfiles().add(wheelProfile);
			}
		});
	}

	private Side getParamSectionSpanAndVisible(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap, Dimension dimension,
			WheelProfile wheelProfile) {
		ParamDefination defination = new ParamDefination();
		defination.setType(ParamType.TEXTBOX);
		getParamSpanAndVisible(wheelParams, dimensionIdMap, dimension, wheelProfile, defination);
		Side left = new Side();
		
		left.setValue(String.valueOf(dimension.getValue()));
		left.setDef(defination);
		return left;
	}

	private void getRightWheelProfiles(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap,
			AxleProperties axleProperties, List<WheelProfile> wheelProfilesList, Point point) {
		point.getDimensions().getDimension().forEach(dimension ->{
			WheelProfile wheelProfile = new WheelProfile();
			Side right = getParamSectionSpanAndVisible(wheelParams, dimensionIdMap, dimension, wheelProfile);
			wheelProfile.setRight(right);
			wheelProfilesList.stream().forEach(profile -> {
				if(profile.getName().trim().equalsIgnoreCase(wheelProfile.getName().trim())) {
					wheelProfile.setLeft(profile.getLeft());
				}
			});
			axleProperties.getWheelProfiles().add(wheelProfile);
		});
	}

	private void getLeftWheelProfiles(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap,
			List<WheelProfile> wheelProfilesList, Point point) {
		List<WheelProfile> wheelProfiles = new ArrayList<>();
		point.getDimensions().getDimension().forEach(dimension ->{
			WheelProfile wheelProfile = new WheelProfile();
			Side left = getParamSectionSpanAndVisible(wheelParams, dimensionIdMap, dimension, wheelProfile);
			wheelProfile.setLeft(left);
			wheelProfiles.add(wheelProfile);
		});
		wheelProfilesList.addAll(wheelProfiles);
	}

	private void setPositionDetails(WheelSheet wheelsheet) {

		Pos pos = new Pos();
		PositionDetails pilotHeightLeft = new PositionDetails();
		// Front position
		Side front = new Side();
		ParamDefination pilotleftDef = new ParamDefination();
		pilotleftDef.setSpan(ParamSpan.CELL1);
		pilotleftDef.setType(ParamType.TEXTBOX);
		front.setDef(pilotleftDef);
		// Back position
		Side back = new Side();
		back.setDef(pilotleftDef);
		pilotHeightLeft.setFront(front);
		pilotHeightLeft.setBack(back);
		// pilotHeightRight
		PositionDetails pilotHeightRight = new PositionDetails();
		// Front position
		Side front1 = new Side();
		ParamDefination pilotRightDef1 = new ParamDefination();
		pilotRightDef1.setSpan(ParamSpan.CELL1);
		pilotRightDef1.setType(ParamType.TEXTBOX);
		front1.setDef(pilotRightDef1);
		// Back position
		Side back1 = new Side();
		back1.setDef(pilotRightDef1);
		pilotHeightRight.setFront(front1);
		pilotHeightRight.setBack(back1);

		PositionDetails couplerHeight = new PositionDetails();
		// Front position
		Side couplerFront = new Side();
		ParamDefination couplerHeightDef = new ParamDefination();
		couplerHeightDef.setSpan(ParamSpan.CELL1);
		couplerHeightDef.setType(ParamType.TEXTBOX);
		couplerFront.setDef(couplerHeightDef);
		// Back position
		Side couplerBack = new Side();
		couplerBack.setDef(couplerHeightDef);
		couplerHeight.setFront(couplerFront);
		couplerHeight.setBack(couplerBack);
		pos.setPilotHeightLeft(pilotHeightLeft);
		pos.setPilotHeightRight(pilotHeightRight);
		pos.setCouplerHeight(couplerHeight);
		wheelsheet.getPos().add(pos);
	}

	private void getParamSpanAndVisible(Map<String, Boolean> wheelParams, Map<String, WheelParameters> dimensionIdMap, Dimension dimension,
			WheelProfile wheelProfile, ParamDefination defination) {
		WheelParameters wheelParameters2 = dimensionIdMap.get(dimension.getId());
		if(Objects.nonNull(wheelParameters2)) {
			wheelProfile.setName(wheelParameters2.getWheelAdminId());
			wheelProfile.setVisible(false);
			if (wheelParams.containsKey(wheelParameters2.getWheelAdminId())) { 
				wheelProfile.setVisible(true);
				wheelParams.computeIfPresent(wheelParameters2.getWheelAdminId(), (k, v) -> Boolean.TRUE);
			}
			if("Y".equalsIgnoreCase(wheelParameters2.getMeasuredWheelL())) {
				defination.setSpan(ParamSpan.CELL1);
			}
			else if("Y".equalsIgnoreCase(wheelParameters2.getMeasuredAxleL())) {
				defination.setSpan(ParamSpan.CELL2);
			}
			else if("Y".equalsIgnoreCase(wheelParameters2.getMeasuredBogieL())) {
				defination.setSpan(ParamSpan.CELL6);
			}
			else {
				defination.setSpan(ParamSpan.CELL12);
			}
			// US457438 : Comment  if there is no need to check limits table
			/*if(wheelParameters2.getWheelAdminId().contains(WheelConstants.AXLE)) {
				wheelParameters2 = dimensionIdMap.get(appConfig.getXmlParamDiameter());
				if (!wheelParams.containsKey(wheelParameters2.getWheelAdminId())) { 
					wheelProfile.setVisible(false);
				}
			}*/
			logger.info("wheelParameters2.getWheelAdminId(): "+wheelParameters2.getWheelAdminId() +"--"+ wheelProfile.isVisible() );
		}
		else {
			wheelProfile.setName(dimension.getId());
			wheelProfile.setVisible(false);
			defination.setSpan(ParamSpan.CELL1);
		}
	}

	public void setShimAndVisibleDefectProfiles(String uuId, AxleProperties axleProperties) {
		ShimDetailsResponse shimDetailsResponse = retrieveShimDetails(uuId);
		List<ShimDetails> shimDetails = shimDetailsResponse.getShimDetails();
		
		// Shim Details adding to WheeSheet			
		WheelProfile shimProfile = new WheelProfile();
		shimProfile.setVisible(true);
		Side left = new Side();
		left.setValue(shimDetails.get(0).getShimValue());
		ParamDefination paramDefination = new ParamDefination();
		paramDefination.setType(ParamType.LIST);
		paramDefination.setSpan(ParamSpan.CELL1);
		paramDefination.getValues().addAll(shimDetails);
		left.setDef(paramDefination);
		shimProfile.setName("Shim Y/N");
		Side right = new Side();
		right.setValue(shimDetails.get(0).getShimValue());
		right.setDef(paramDefination);
		shimProfile.setLeft(left);
		shimProfile.setRight(right);
		axleProperties.getWheelProfiles().add(shimProfile);
		// visibleDefect Details adding to WheeSheet
		VisibleDefectsResponse visiblelDefectsResponse = retrieveVisDefectsDetails(uuId);
		List<VisibleDefectsDetails> visibleDefectsDetails = visiblelDefectsResponse.getVisibleDefectsDetails();
		WheelProfile visibleProfile = new WheelProfile();
		visibleProfile.setVisible(true);
		Side visibleLeft = new Side();
		visibleLeft.setValue(visibleDefectsDetails.get(0).getVisibleDefectsValue());
		ParamDefination visibleParamDef = new ParamDefination();
		visibleParamDef.setType(ParamType.LIST);
		visibleParamDef.setSpan(ParamSpan.CELL1);
		visibleParamDef.getValues().addAll(visibleDefectsDetails);
		visibleLeft.setDef(visibleParamDef);
		visibleProfile.setName(WheelConstants.VISIBLE_DEFECT);
		Side visibleRight = new Side();
		visibleRight.setValue(visibleDefectsDetails.get(0).getVisibleDefectsValue());
		visibleRight.setDef(visibleParamDef);
		visibleProfile.setLeft(visibleLeft);
		visibleProfile.setRight(visibleRight);
		axleProperties.getWheelProfiles().add(visibleProfile);
	}
	
	@Override
	public ShimDetailsResponse retrieveShimDetails(String uuId) {
		ShimDetailsResponse shimDetailsResponse = new ShimDetailsResponse();
		StatusType statusType = new StatusType();
		try {
			logger.info(uuId+" Inside retrieveShimDetails()");
			Map<String, String> shimMap = wheelDetConfig.getShimMap();
			if (!shimMap.isEmpty()) {
				logger.info(uuId+" Shim Map is not empty");
				shimDetailsResponse.getShimDetails().addAll((fetchShimDetails(shimMap,uuId)));
				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
				shimDetailsResponse.setStatus(statusType);
			} else {
				logger.info(uuId+" Shim Map is empty");
				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.NO_DATA_AVAILABLE);
				shimDetailsResponse.setStatus(statusType);
			}
		} catch (Exception e) {
			logger.error(uuId + " Exception in retrieveShimDetails", e);
			throw new WheelsException(e);
		}
		logger.info(uuId+" Compeleted executing retrieveShimDetails()");
		return shimDetailsResponse;

	}

	public List<ShimDetails> fetchShimDetails(Map<String, String> shimMap,String uuId) {
		List<ShimDetails> shimList = new ArrayList<>();
		logger.info(uuId+" Inside fetchShimDetails");
		for (Map.Entry<String, String> shimDetail : shimMap.entrySet()) {
			ShimDetails shimDetailsObj = new ShimDetails();
			shimDetailsObj.setShimCode(shimDetail.getKey());
			shimDetailsObj.setShimValue(shimDetail.getValue());
			shimList.add(shimDetailsObj);
		}
		return shimList;
	}

	@Override
	public VisibleDefectsResponse retrieveVisDefectsDetails(String uuId) {
		VisibleDefectsResponse visibleDefectsResponse = new VisibleDefectsResponse();
		StatusType statusType = new StatusType();
		try {
			logger.info(uuId+" Inside retrieveVisDefectsDetails()");

			Map<String, String> vDMap = wheelDetConfig.getVisualDefectMap();
			if (!vDMap.isEmpty()) {
				logger.info(uuId+" Visual Defect Map is not empty");
				
				visibleDefectsResponse.getVisibleDefectsDetails().addAll((fetchVisibleDefectDetails(vDMap,uuId)));

				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
				visibleDefectsResponse.setStatus(statusType);

			} else {
				logger.info(uuId+" Visual Defect Map is empty");

				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage(WheelConstants.NO_DATA_AVAILABLE);
				visibleDefectsResponse.setStatus(statusType);
			}
		} catch (Exception e) {
			logger.error(uuId + " Exception in retrieveVisDefectsDetails", e);
			throw new WheelsException(e);
		}
		logger.info(uuId+" Compeleted executing retrieveVisDefectsDetails()");
		
		return visibleDefectsResponse;

	}

	public List<VisibleDefectsDetails> fetchVisibleDefectDetails(Map<String, String> visualDefectMap,String uuId) {
		List<VisibleDefectsDetails> vDList = new ArrayList<>();
		logger.info(uuId+" Inside fetchVisualDefectDetails");
		
		for (Map.Entry<String, String> visualDefect : visualDefectMap.entrySet()) {
			VisibleDefectsDetails vDefectsDetailsObj = new VisibleDefectsDetails();
			vDefectsDetailsObj.setVisibleDefectsCode(visualDefect.getKey());
			vDefectsDetailsObj.setVisibleDefectsValue(visualDefect.getValue());
			vDList.add(vDefectsDetailsObj);
		}
		return vDList;
	}

	@Override
	@org.springframework.transaction.annotation.Transactional(rollbackFor = Exception.class)	
	public WheelSheetDetailsResponse saveWheelSheetDetails(String uuId,
			WheelSheetDetailsRequest wheelSheetDetailsRequest) {
		long startTime = System.currentTimeMillis();
		logger.info(uuId+":********* Save WheelSheetDetails Started @"+LocalDateTime.now());
		WheelSheetDetailsResponse wheelSheetDetailsResponse = new WheelSheetDetailsResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelSheetDetailsRequest, uuId);
			if (Objects.nonNull(statusType)) {
				wheelSheetDetailsResponse.setStatusType(statusType);
			} else {
				WheelSheetDetails wheelSheetDetails = saveOrUpdateWheelSheetDetails(uuId, wheelSheetDetailsRequest.getWheelSheetDetails(), wheelSheetDetailsResponse);
				wheelSheetDetailsResponse.setWheelSheetDetails(wheelSheetDetails);
				wheelSheetDetailsResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType(uuId+": Wheelsheetdata stored in database successfully"));
			}
		} catch (Exception e) {
			logger.error(new WheelsException(e));
			logger.error(uuId + " Exception in saveWheelSheetDetails", e);
			wheelSheetDetailsResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		long endTime = System.currentTimeMillis() - startTime;
		logger.info(uuId+": Total Time Taken for save wheelsheetdata,  "+TimeUnit.MILLISECONDS.toSeconds(endTime)+" SECONDS");
		logger.info(uuId+":********* Save WheelSheetDetails Stopped @"+LocalDateTime.now()+"********");
		return wheelSheetDetailsResponse;
	}


	private void changeFilestatusAndMovingFileToArchive(String uuId, WheelSheetDetailsResponse wheelSheetDetailsResponse,
			 String fileName, String fileReceivedDate2) {
		logger.info(uuId+": FileStatus try to change from "+FileStatus.VALID+" to "+FileStatus.PROCESSED+" in wheelfiledetail collection...");
		logger.info(uuId+": fileName: "+fileName+", fileReceivedDate2: "+fileReceivedDate2);
		WheelFileDetail wheelFileDetail = wheelFileDetailRepo.findByFileNameAndFileCreationDateAndStatus(fileName, fileReceivedDate2, FileStatus.VALID);
		if (Objects.isNull(wheelFileDetail)) {
			wheelSheetDetailsResponse.setWheelSheetDetails(null);
			throw new WheelsException(uuId+": File not available with given date in WheelFileDetail Collection");
		} else {
			wheelFileDetail.setStatus(FileStatus.PROCESSED);
			wheelFileDetail.setLastUpdatedDate(WheelServiceUtil.convertDateToString(new Date()));
			wheelFileDetailRepo.save(wheelFileDetail);
			logger.info(uuId+": FileStatus changed from "+FileStatus.VALID+" to "+FileStatus.PROCESSED+" in wheelfiledetail collection...");
		}
		StatusType saveStatusType = moveFileFromProcessingToArchive(uuId, fileName);
		if(StatusCode.SUCCESS.equals(saveStatusType.getStatusCode())) {
			wheelSheetDetailsResponse.setStatusType(saveStatusType);
		} else {
			wheelSheetDetailsResponse.setWheelSheetDetails(null);
			wheelSheetDetailsResponse.setStatusType(saveStatusType);
		}
	}

	private StatusType moveFileFromProcessingToArchive(String uuId, String fileName) {
		MoveFileRequest moveFileRequest = new MoveFileRequest();
		moveFileRequest.setFileName(fileName);
		moveFileRequest.setFrom(appConfig.getProcessing());
		moveFileRequest.setTo(appConfig.getProcessed());
		MoveFileResponse moveFileResponse = wheelDataInjectService.moveCustomerFile(moveFileRequest, uuId);
		return moveFileResponse.getStatusType();
	}

	private WheelSheetDetails saveOrUpdateWheelSheetDetails(String uuId, WheelSheetDetails wheelSheetDetails, WheelSheetDetailsResponse wheelSheetDetailsResponse){
		String roadnum = wheelSheetDetails.getWheelSheetKey().getRoadNumber();
		aarRoad = wheelSheetDetails.getWheelSheetKey().getAarRoad();
		roadNumber = String.valueOf(roadnum);
		List<WheelConfigRecord> wheelLimitRecords = getWheelParamsFromAdminConfiguration(uuId);
		verifyAndCalcDiaDiffForAxleTruckLoco(uuId, wheelSheetDetails, wheelLimitRecords);
		WheelSheetDataCollection wheelSheetDataCollection = WheelServiceUtil.mapDomainObjectToDocumentObject(wheelSheetDetails);
		List<WheelSheetCollection> docWheelSheet = wheelSheetDataCollection.getWheelSheet();
		WheelSheetCollection wheelSheetCollection = docWheelSheet.get(0);
		checkAndCreateWheelSheetDefects(uuId, wheelSheetDataCollection, wheelSheetCollection.getWheelsheetId(), wheelLimitRecords);
		WheelSheetDataCollection persistedWheelSheetData = wheelPersistanceService.getWheelSheetDetiails(wheelSheetDataCollection.getWheelSheetKey());
		if(Objects.nonNull(persistedWheelSheetData)) {
			logger.info(uuId+": wheelsheetdata updating in document DB...");
			List<WheelSheetCollection> wheelSheetList = persistedWheelSheetData.getWheelSheet();
			wheelSheetList.add(wheelSheetCollection);
			persistedWheelSheetData.setWheelSheet(wheelSheetList);
			wheelPersistanceService.saveWheelSheetDetails(persistedWheelSheetData);
			logger.info(uuId+": wheelsheetdata updated in document DB.");
		}
		else {
			logger.info(uuId+": wheelsheetdata inserting in document DB...");
			wheelPersistanceService.saveWheelSheetDetails(wheelSheetDataCollection);
			logger.info(uuId+": wheelsheetdata inserted in document DB.");
		}
		logger.info(uuId+": Converting Document WheelSheet to response WheelSheet...");
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
		WheelSheet wheelSheetDomain = mapper.convertValue(wheelSheetCollection, WheelSheet.class);
		logger.info(uuId+": Mapping Converted for Document WheelSheet to response WheelSheet");
		wheelSheetDomain.setFileCreationDate(wheelSheetCollection.getFileCreationDate());
		String fileName = wheelSheetDomain.getFileName();
		String fileReceivedDate2 = wheelSheetCollection.getFileCreationDate();
		WheelSheetDetails wheelSheetDataDomain = new WheelSheetDetails();
		wheelSheetDataDomain.setWheelSheetKey(wheelSheetDetails.getWheelSheetKey());
		wheelSheetDomain.setOperator(getNameforUser(wheelSheetDomain.getCreatedBy(), uuId));
		wheelSheetDataDomain.getWheelSheet().add(wheelSheetDomain);
		if(fileName != null && !fileName.isEmpty()) {
			changeFilestatusAndMovingFileToArchive(uuId, wheelSheetDetailsResponse, fileName, fileReceivedDate2);
		} else {
			wheelSheetDetailsResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType(uuId+": Wheelsheetdata without BlankSheet stored in database successfully"));
		}
		
		return wheelSheetDataDomain;
	}
	
	public String getNameforUser(String createdBy, String uuId) {
		List<Long> userNames = Arrays.asList(Long.valueOf(createdBy));
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getUserProfileUrl());
		GetLmsEmployeeRequest request = new GetLmsEmployeeRequest();
		request.getUserId().addAll(userNames);
		GetLmsEmployeeResponse resp =  restUtility.callCorePostService(request, new GetLmsEmployeeResponse(), stringbuilder.toString(),
				"AdminServiceImpl: "+uuId);
		if(Objects.nonNull(resp)) {
			resp.getGetsLMSUsers().forEach(user -> {
				if (user.getUserId().equalsIgnoreCase(createdBy)) {
					operator = user.getFirstName() + " " + user.getLastName();
				}
			});
		}
		else {
			throw new WheelsException(uuId+": FAILED to get Response for getting Operator name");
		}
		logger.info(uuId + " After getting the response from common service");
		return operator;
	}
	
	private void verifyAndCalcDiaDiffForAxleTruckLoco(String uuId, WheelSheetDetails wheelSheetDetails, List<WheelConfigRecord> wheelLimitRecords) {
		
		WheelSheet wheelSheet = wheelSheetDetails.getWheelSheet().get(0);
		aarRoad = wheelSheetDetails.getWheelSheetKey().getAarRoad();
		roadNumber = String.valueOf(wheelSheetDetails.getWheelSheetKey().getRoadNumber());
		List<WheelParameters> wheelParameters = wheelParamRepo.findByCustomerId(customerId+"");
		List<String> wheelParamNames = new ArrayList<>();
		for (WheelParameters wheelParameter : wheelParameters) {
			wheelParamNames.add(wheelParameter.getWheelAdminId());
		}
		Map<String, WheelParameters> dimensionIdMap = wheelParameters.stream()
				.filter(param -> Objects.nonNull(param.getDimesnionId()) && Objects.nonNull(param.getWheelAdminId())
						&& !param.getDimesnionId().isEmpty() && !param.getWheelAdminId().isEmpty())
				.collect(Collectors.toMap(WheelParameters::getDimesnionId, param -> param));
		Map<Integer,String> axleDiaDiffMap = new HashMap<>();
		List<Double> truck1 = new ArrayList<>();
		List<Double> truck2 = new ArrayList<>();
		Map<String, Boolean> wheelParams = wheelLimitRecords.stream().map(WheelConfigRecord::getWheelParameter).distinct().collect(Collectors.toMap(k -> k, k -> false));
		wheelSheet.getAxleProperties().stream().forEach(axle -> getWheelDiameters(truck1, truck2, axle, dimensionIdMap,axleDiaDiffMap,wheelParams));
		logger.info(uuId+": WheelParameters: "+wheelParams);
		calculateDiameterDiffForAll(uuId, wheelSheet, truck1, truck2, axleDiaDiffMap);
	}
	
	private void calculateDiameterDiffForAll(String uuId, WheelSheet wheelSheet, List<Double> truck1, List<Double> truck2, Map<Integer, String> axleDiaDiffMap) {
		logger.info(uuId + " Calculating diameter differnece for Axle, Truck and Loco");
		DecimalFormat df = getDecimalFormat();
		String truck1DiameterDiff = null;
		String truck2DiameterDiff = null;
		String locoDiameterDiff = null;
		if (!truck1.isEmpty() && truck1.size() == 6) {
			Double maxTruck1Dia = Collections.max(truck1);
			Double minTruck1Dia = Collections.min(truck1);
			Double truck1DiaDiff = maxTruck1Dia - minTruck1Dia;
			truck1DiameterDiff = df.format(truck1DiaDiff);
		}
		if (!truck2.isEmpty() && truck2.size() == 6) {
			Double maxTruck2Dia = Collections.max(truck2);
			Double minTruck2Dia = Collections.min(truck2);
			Double truck2DiaDiff = maxTruck2Dia - minTruck2Dia;
			truck2DiameterDiff = df.format(truck2DiaDiff);
		}
		List<Double> loco = new ArrayList<>();
		loco.addAll(truck1);
		loco.addAll(truck2);
		if (!loco.isEmpty() && loco.size() == 12) {
			Double maxLocoDia = Collections.max(loco);
			Double minLocoDia = Collections.min(loco);
			Double locoDiaDiff = maxLocoDia - minLocoDia;
			locoDiameterDiff = df.format(locoDiaDiff);
		}
		logger.info(uuId + ": Diameter Difference : Axle - "+axleDiaDiffMap+", Truck1 - " + truck1DiameterDiff + ",  Truck2 - " + truck2DiameterDiff
				+ " Loco - " + locoDiameterDiff);
		setAxleTruckAndLocoAfterSave(wheelSheet, axleDiaDiffMap, truck1DiameterDiff, truck2DiameterDiff, locoDiameterDiff);
	}

	private void setAxleTruckAndLocoAfterSave(WheelSheet wheelSheet, Map<Integer, String> axleDiaDiffMap, String truck1DiameterDiff,
			String truck2DiameterDiff, String locoDiameterDiff) {
		
		wheelSheet.getAxleProperties().parallelStream().forEach(axle -> {
		
		if(Objects.isNull(axle.getAxleNumber())) {
			char number = axle.getAxleName().charAt(axle.getAxleName().length()-1);
			axle.setAxleNumber(Integer.valueOf(Character.toString(number)));
		}
			axle.getWheelProfiles().stream().forEach(wheelProfile -> {
				if(wheelProfile.getName().contains(WheelConstants.AXLE)) {
					wheelProfile.setCalculated(true);
					wheelProfile.getLeft().setValue(axleDiaDiffMap.get(axle.getAxleNumber()));
				}
				if(axle.getAxleNumber() == 1 && wheelProfile.getName().contains(WheelConstants.TRUCK)) {
					wheelProfile.setCalculated(true);
					wheelProfile.getLeft().setValue(truck1DiameterDiff);
				}
				if(axle.getAxleNumber() == 1 && wheelProfile.getName().contains(WheelConstants.LOCO)) {
					wheelProfile.setCalculated(true);
					wheelProfile.getLeft().setValue(locoDiameterDiff);
				}
				if(axle.getAxleNumber() == 4 && wheelProfile.getName().contains(WheelConstants.TRUCK)) {
					wheelProfile.setCalculated(true);
					wheelProfile.getLeft().setValue(truck2DiameterDiff);
				}
			});
		}
		);
	}

	private DefectDTO checkAndCreateWheelSheetDefects(String uuId, WheelSheetDataCollection persistedWheelSheetData, String wheelSheetId, List<WheelConfigRecord> wheelLimitRecords) {
		logger.info(uuId+": Inside checkAndCreateWheelSheetDefects() method...");
		List<WheelSheetCollection> wheelSheetsList = persistedWheelSheetData.getWheelSheet().stream()
				.filter(wheelsheet -> wheelsheet.getWheelsheetId().equalsIgnoreCase(wheelSheetId))
				.collect(Collectors.toList());
		
		List<String> wheelParams = wheelLimitRecords.stream().map(WheelConfigRecord::getWheelParameter).distinct()
				.collect(Collectors.toList());
		logger.info(uuId+": WheelParameters: "+wheelParams);
		Map<String, String> wheelParamMap = new LinkedHashMap<>();
		for (String key : wheelParams) {
			wheelParamMap.put(key, "");
		}
		wheelParamMap.put(WheelConstants.VISIBLE_DEFECT, "");
		DefectDTO defect = null;
		for (WheelSheetCollection wheelsheet : wheelSheetsList) {
			wheelsheet.getAxleProperties().stream()
					.forEach(axle -> axle.getWheelProfiles().stream().forEach(wheelprofile -> createDefects(uuId,
							wheelLimitRecords, wheelParams, wheelParamMap, axle, wheelprofile)));
			StringBuilder wheelPos = new StringBuilder();
			int num = 1;
			for (String position : wheelParamMap.values()) {
				if (!position.isEmpty()) {
					wheelPos.append("\n" + num++ + ". " + position);
				}
			}
			String defectPosition = wheelPos.toString();
			if (Objects.nonNull(defectPosition) && !defectPosition.isEmpty()) {
				logger.info(defectPosition);
				defect = createWheelSheetAutoDefect(uuId, wheelsheet, defectPosition);
				addDefectIdForEachDefectPositionInDataModel(uuId, wheelsheet, defect);
			} else {
				logger.info(uuId + ": All Parameters have no defect");
			}
		}
		return defect;
	}

	private List<WheelConfigRecord> getWheelParamsFromAdminConfiguration(String uuId) {
		logger.info(uuId+": Getting CustomerId, LocoType from LocomotiveAll by using WorkOrder service "+appConfig.getRoadnumberValidation());
		RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber(roadNumber);
		request.setAarRoad(aarRoad);
		RoadNumberValidationResponse roadNumberValidationResponse = validateRoadnumberFromWorkOrderService(uuId,
				request);

		WheelConfigRequest limitRequest = new WheelConfigRequest();
		if(StatusCode.SUCCESS.equals(roadNumberValidationResponse.getStatusCode())) {
			customerId = roadNumberValidationResponse.getCustomerId();
			limitRequest.setCustId(roadNumberValidationResponse.getCustomerId());
			limitRequest.setAarRoad(aarRoad);
			limitRequest.getLocoType().add(roadNumberValidationResponse.getLocoType());
		}
		WheelConfigResponse wheelConfigResponse = adminService.getAdminConfiguration(limitRequest, uuId);
		return wheelConfigResponse.getLimitRecords();
	}

	private void createDefects(String uuId, List<WheelConfigRecord> wheelLimitRecords, List<String> wheelParams,
			Map<String, String> wheelParamMap, com.ge.transportation.eservices2.wheel.docdb.model.AxleProperties axle,
			com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile wheelprofile) {
		logger.info(uuId+": wheel parameter: "+wheelprofile.getName()+" visible: "+wheelprofile.isVisible());
		if (wheelprofile.isVisible()) {
			if (wheelParams.contains(wheelprofile.getName())) {
				logger.info(uuId+": Creating defect for wheel parameter: "+wheelprofile.getName());
				wheelLimitRecords.parallelStream().filter(limitparam -> limitparam.getWheelParameter().equalsIgnoreCase(wheelprofile.getName())).forEach(limitparam -> {
					com.ge.transportation.eservices2.wheel.docdb.model.Side left = wheelprofile.getLeft();
					com.ge.transportation.eservices2.wheel.docdb.model.Side right = wheelprofile.getRight();
					logger.info("From File : " + wheelprofile.getName() + ", left: " + left.getValue() + ", right: " + right.getValue());
					String defectPosStr = wheelParamMap.get(wheelprofile.getName());
					StringBuilder paramPosBuilder = new StringBuilder();
					createDefectForWheelParameter(axle, wheelprofile, limitparam, left, defectPosStr, paramPosBuilder,  "L"+axle.getAxleNumber());
					createDefectForWheelParameter(axle, wheelprofile, limitparam, right, defectPosStr, paramPosBuilder, "R"+axle.getAxleNumber());
					wheelParamMap.replace(wheelprofile.getName(), wheelParamMap.get(wheelprofile.getName())	+ paramPosBuilder.toString());
				});
			}
			else if (wheelprofile.getName().equalsIgnoreCase(WheelConstants.VISIBLE_DEFECT)) {
				logger.info(uuId+": Creating defect for wheel parameter: "+wheelprofile.getName());
				com.ge.transportation.eservices2.wheel.docdb.model.Side left = wheelprofile.getLeft();
				com.ge.transportation.eservices2.wheel.docdb.model.Side right = wheelprofile.getRight();
				String paramValue = wheelParamMap.get(wheelprofile.getName());
				StringBuilder paramPos = new StringBuilder();
				if (!"None".equalsIgnoreCase(left.getValue())) {
					setDefectPosition(wheelprofile.getName(), paramValue, paramPos, "L"+axle.getAxleNumber()+"-"+left.getValue(), null, left.getDef().getSpan());
					left.setIsDefect(true);
				}
				if (!"None".equalsIgnoreCase(right.getValue())) {
					setDefectPosition(wheelprofile.getName(), paramValue, paramPos, "R"+axle.getAxleNumber()+"-"+right.getValue(), null, right.getDef().getSpan());
					right.setIsDefect(true);
				}
				wheelParamMap.replace(wheelprofile.getName(), wheelParamMap.get(wheelprofile.getName()) + paramPos.toString());
			}
		}
	}

	private String createDefectForWheelParameter(com.ge.transportation.eservices2.wheel.docdb.model.AxleProperties axle,
			com.ge.transportation.eservices2.wheel.docdb.model.WheelProfile wheelprofile, WheelConfigRecord limitParam,
			com.ge.transportation.eservices2.wheel.docdb.model.Side side, String defectPosStr, StringBuilder paramPosBuilder,
			String pos) {
		String defectPositionStr = defectPosStr;
		double value;
		double lowerLimit = limitParam.getLowerLimit();
		double upperLimit = limitParam.getUpperLimit();
		if(Objects.nonNull(side.getDef().getSpan())) {
			if((Objects.isNull(side.getValue()) || side.getValue().isEmpty())) {
				defectPositionStr = setDefectPosition(wheelprofile.getName(), defectPositionStr, paramPosBuilder, pos, axle.getAxleNumber(), side.getDef().getSpan());
				side.setIsDefect(true);
			} else {
				value = Double.parseDouble(side.getValue());
				if (value < lowerLimit || value > upperLimit) {
					defectPositionStr = setDefectPosition(wheelprofile.getName(), defectPositionStr, paramPosBuilder, pos, axle.getAxleNumber(), side.getDef().getSpan());
					side.setIsDefect(true);
				}
			}
		}
		return defectPositionStr;
	}

	private String setDefectPosition(String paramName, String defectPosStr, StringBuilder paramPosBuilder, String pos, Integer axleNumber, ParamSpan paramSpan) {
		boolean isSetParam = false;
		if (!defectPosStr.contains(paramName)) {
			if(!paramPosBuilder.toString().contains(paramName)) {
				paramPosBuilder.append(paramName + "");
				isSetParam = true;
			}
			defectPosStr = paramName;
		}
		String paramPos = "";
		if(isSetParam) {
			if(ParamSpan.CELL2.compareTo(paramSpan) == 0) {
				paramPos = String.join(": ","",WheelConstants.AXLE + axleNumber);
			}
			else if(ParamSpan.CELL6.compareTo(paramSpan) == 0) {
				paramPos = String.join(": ","",WheelConstants.TRUCK_1);
			}
			else if(ParamSpan.CELL12.compareTo(paramSpan) != 0) {
				paramPos = String.join(": ","",pos);
			}
		}
		else if(ParamSpan.CELL2.compareTo(paramSpan) == 0) {
			paramPos = String.join(", ","",WheelConstants.AXLE + axleNumber);
		}
		else if(ParamSpan.CELL6.compareTo(paramSpan) == 0) {
			paramPos = String.join(", ","",WheelConstants.TRUCK_2);
		}
		else if(ParamSpan.CELL12.compareTo(paramSpan) != 0) {
			paramPos = String.join(",","",pos);
		}
		paramPosBuilder.append(paramPos);
		logger.info("Created Defect on cell: "+paramPos+"for wheelparam: "+paramName+"");
		return defectPosStr;
	}
	private DefectDTO createWheelSheetAutoDefect(String uuId, WheelSheetCollection wheelsheet, String defectPosition) {
		
		HttpHeaders headers = setHttpHeaders(uuId, wheelsheet);
		
		MultiValueMap<String, String> mpParams = new LinkedMultiValueMap<>();
		mpParams.add("workOrderId",String.valueOf(wheelsheet.getWorkorderId()));
		mpParams.add("serviceSheetId", String.valueOf(wheelsheet.getWheelsheetId()));
		mpParams.add("custName", aarRoad);
		mpParams.add("wheelPos", defectPosition);
		logger.info(uuId+": Method param values for createdefect of TDService");
		logger.info(uuId+": mParams: "+mpParams);
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getCreateWheelSheetDefectUrl());
		logger.info(uuId+": Calling TaskDefect Service to create defect in Oracle table 'GETS_LMS.GETS_LMS_DEFECT_SHEETS'");
		DefectDTO defectDTO = restUtility.callTDServiceToCreateWheelSheetDefect(new DefectDTO(), stringbuilder.toString(), headers, mpParams, uuId);
		if(Objects.nonNull(defectDTO) && Objects.nonNull(defectDTO.getTimeCard())) {
			logger.info(uuId+": Defect Created successfully with defectId: "+defectDTO.getTimeCard().getDefectId());
			logger.info(uuId+": Defect Description : "+defectDTO.getDescription());
			return defectDTO;
		} else {
			logger.info(uuId+": Failed to Create Defect for "+defectPosition);
			throw new WheelsException(uuId+": Failed to Create Defect "+defectPosition);
		}
	}

	private HttpHeaders setHttpHeaders(String uuId, WheelSheetCollection wheelsheet) {
		HttpHeaders headers = new HttpHeaders();
		headers.set("User-TimeZone", "EST");
		headers.set("serviceorgid", wheelsheet.getServiceOrgId());
		headers.set("roadnumber", roadNumber);
		headers.set("User-LoginId", wheelsheet.getUserId());
		headers.set("User-LangCode", "ENG");
		headers.set("User-Id", wheelsheet.getCreatedBy());
		headers.set("customerId", wheelsheet.getCustomerId());
		headers.set("workorderid", String.valueOf(wheelsheet.getWorkorderId()));
		headers.setContentType(MediaType.APPLICATION_JSON);
		logger.info(uuId+": HttpHeaders for getting Workshift: "+headers.entrySet());
		
		StringBuilder getUserDetailsURL = new StringBuilder();
		getUserDetailsURL.append(appConfig.getBaseUrl()).append(appConfig.getTdUserDetails());
		
		logger.info(uuId+": Calling TaskDefect Service to get workshift from Oracle View 'ESV_COEXIST.ESV_USER_TD_V'");
		
		UserDetailsDTO userDetailsDTO = restUtility.callCoreGetServiceForUserDetails(new UserDetailsDTO(), getUserDetailsURL.toString(), uuId+": WheelServiceImpl: ", headers);
		logger.info(uuId+": UserDetails returned successfully from TaskDefect Service to get workshift from Oracle View 'ESV_COEXIST.ESV_USER_TD_V'");
		
		if(Objects.nonNull(userDetailsDTO) && Objects.nonNull(userDetailsDTO.getWorkShift()) && !userDetailsDTO.getWorkShift().isEmpty()) {
			logger.info(uuId+": Value Of Workshift: "+userDetailsDTO.getWorkShift());
			wheelsheet.setWorkshift(userDetailsDTO.getWorkShift());
			headers.set("workshift", userDetailsDTO.getWorkShift());
		}
		else {
			logger.info(uuId+": Workshift value is empty or null");
			throw new WheelsException("Workshift value is empty or null");
		}
		return headers;
	}
	
	private void addDefectIdForEachDefectPositionInDataModel(String uuId, WheelSheetCollection wheelsheet,
			DefectDTO defect) {
		logger.info(uuId + ": Updating defect cell in wheelsheetdata collection");
		Integer defectId = defect.getTimeCard().getDefectId();
		wheelsheet.getAxleProperties().parallelStream()
				.forEach(axle -> axle.getWheelProfiles().stream().forEach(wheelprofile -> {
					com.ge.transportation.eservices2.wheel.docdb.model.Side left = wheelprofile.getLeft();
					com.ge.transportation.eservices2.wheel.docdb.model.Side right = wheelprofile.getRight();
					if (left.isIsDefect()) {
						left.setDefectId(defectId);
					}
					if (right.isIsDefect()) {
						right.setDefectId(defectId);
					}
				}));
	}
	
	@Override
	public WheelSheetForWOResponse getWheelSheetDetails(String uuId,
			WheelSheetForWORequest wheelSheetForWORequest) {
		WheelSheetForWOResponse wheelSheetForWOResponse = new WheelSheetForWOResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelSheetForWORequest, uuId);
			if (Objects.nonNull(statusType)) {
				wheelSheetForWOResponse.setStatusType(statusType);
			} else {
				com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelSheetKey = new com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey();
				wheelSheetKey.setAarRoad(wheelSheetForWORequest.getAarRoad());
				wheelSheetKey.setRoadNumber(wheelSheetForWORequest.getRoadNumber());
				Long workOrderId = wheelSheetForWORequest.getWorkOrderId();
				logger.info(" getWheelSheetDetails for aar " + wheelSheetForWORequest.getAarRoad() + " Road "
						+ wheelSheetForWORequest.getRoadNumber() + " workOrderId " + workOrderId);
				WheelSheetDataCollection wheelSheetDataCollection = wheelSheetRepository
						.findByWheelSheetKey(wheelSheetKey);
				if (!Objects.isNull(wheelSheetDataCollection)) {
					populateWheelSheetDataResp(uuId, wheelSheetForWOResponse, workOrderId, wheelSheetDataCollection);
				} else {
					StatusType sts = setNoDataResponse();
					wheelSheetForWOResponse.setStatusType(sts);
				}
			}
		} catch (Exception e) {
			logger.error(uuId + " Exception in getWheelSheetDetails", e);
			logger.error(new WheelsException(e));
			wheelSheetForWOResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		return wheelSheetForWOResponse;

	}

	private void populateWheelSheetDataResp(String uuId, WheelSheetForWOResponse wheelSheetForWOResponse,
			Long workOrderId, WheelSheetDataCollection wheelSheetDataCollection) {
		List<WheelSheetCollection> wheelSheets = wheelSheetDataCollection.getWheelSheet();
		List<WheelSheetCollection> wheelSheetsWithWO = wheelSheets.stream()
				.filter(wheelSheet -> Objects.nonNull(wheelSheet.getWorkorderId())
						&& wheelSheet.getWorkorderId().equals(workOrderId))
				.collect(Collectors.toList());
		if (!wheelSheetsWithWO.isEmpty()) {
			logger.info(" getWheelSheetDetails - Sorting based on createdDate");
			WheelSortUtil.sortByCreatedDate(wheelSheetsWithWO);
			wheelSheetsWithWO.stream().forEach(wheelSheet -> {
					wheelSheet.setOperator(getNameforUser(wheelSheet.getCreatedBy(), uuId));
					wheelSheetForWOResponse.getWheelSheetData().add(mapWheelSheetData(wheelSheet));});
			wheelSheetForWOResponse.getWheelSheetData().get(0).setIsDefault(true);
			wheelSheetForWOResponse.setStatusType(
					WheelServiceUtil.sendSuccessStatusType(WheelConstants.STATUS_MESSAGE_OK));
		} else {
			logger.info(uuId + " wheelSheetDataCollection is empty");
			StatusType sts = setNoDataResponse();
			wheelSheetForWOResponse.setStatusType(sts);
		}
	}

	private StatusType setNoDataResponse() {
		StatusType statusType = new StatusType();
		statusType.setStatusCode(StatusCode.SUCCESS);
		statusType.setMessage(WheelConstants.NO_DATA_AVAILABLE);
		return statusType;
	}

	public WheelSheetData mapWheelSheetData(WheelSheetCollection wheelSheet) {
		WheelSheetData wheelSheetData = new WheelSheetData();
		wheelSheetData.setWheelSheetID(wheelSheet.getWheelsheetId());
		wheelSheetData.setWheelSheetname(wheelSheet.getWheelSheetName());
		wheelSheetData.setIsDefault(false);
		wheelSheetData.setCreatedDate(wheelSheet.getCreatedDate());
		return wheelSheetData;
	}

	@Override
	public WheelSheetResponse getWheelSheet(String uuId, WheelSheetRequest wheelSheetRequest) {
		WheelSheetResponse wheelSheetResponse = new WheelSheetResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelSheetRequest, uuId);
			if (Objects.nonNull(statusType)) {
				wheelSheetResponse.setStatusType(statusType);
			} else {
				com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelSheetKey = new com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey();
				wheelSheetKey.setAarRoad(wheelSheetRequest.getAarRoad());
				wheelSheetKey.setRoadNumber(wheelSheetRequest.getRoadNumber());
				String wheelSheetId = wheelSheetRequest.getWheelSheetID();
				logger.info(" getWheelSheet for aar " + wheelSheetRequest.getAarRoad() + " Road "
						+ wheelSheetRequest.getRoadNumber() + " wheelSheetId " + wheelSheetId);
				WheelSheetDataCollection wheelSheetDataCollection = wheelSheetRepository
						.findByWheelSheetKey(wheelSheetKey);
				if (!Objects.isNull(wheelSheetDataCollection)) {
					populateWheelSheet(wheelSheetResponse, wheelSheetId, wheelSheetDataCollection, uuId);
					
				} else {
					logger.info(uuId + " wheelSheetDataCollection is empty");
					StatusType sts = setNoDataResponse();
					wheelSheetResponse.setStatusType(sts);
				}
			}
		} catch (Exception e) {
			logger.error(uuId + " Exception in getWheelSheet", e);
			logger.error(new WheelsException(e));
			wheelSheetResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		return wheelSheetResponse;

	}

	private void populateWheelSheet(WheelSheetResponse wheelSheetResponse, String wheelSheetId,
			WheelSheetDataCollection wheelSheetDataCollection, String uuId) {
		List<WheelSheetCollection> wheelSheets = wheelSheetDataCollection.getWheelSheet();
		List<WheelSheetCollection> wheelSheetsWithId = wheelSheets.stream()
				.filter(wheelSheet -> Objects.nonNull(wheelSheet.getWheelsheetId())
						&& wheelSheet.getWheelsheetId().equals(wheelSheetId))
				.collect(Collectors.toList());
		wheelSheets.stream().forEach(wheelsheet -> wheelsheet.setOperator(getNameforUser(wheelsheet.getCreatedBy(), uuId)));
		if (!wheelSheetsWithId.isEmpty()) {
			logger.info(uuId+": wheelSheetDataCollection with wheelSheetId not empty");
			wheelSheetDataCollection.setWheelSheet(wheelSheetsWithId);
			wheelSheetResponse.setWheelSheetDetails(wheelSheetDataCollection);
			wheelSheetResponse
					.setStatusType(WheelServiceUtil.sendSuccessStatusType(WheelConstants.STATUS_MESSAGE_OK));
		} else {
			StatusType sts = setNoDataResponse();
			wheelSheetResponse.setStatusType(sts);
		}
	}
	
	
	@Override 
	public PastWheelSheetResponse getPastWheelSheetDetails(String uuId,PastWheelSheetRequestDetails pastwheelSheetRequestDetails) {
		PastWheelSheetResponse pastWheelSheetResponse=new PastWheelSheetResponse();
		logger.info(uuId+" Inside getPastWheelSheetDetails() service ");
		try {
		StatusType statusType = wheelServiceValidator.validateRequestParams(pastwheelSheetRequestDetails, uuId);
		if (Objects.nonNull(statusType)) {
			pastWheelSheetResponse.setStatusType(statusType);
			logger.info(uuId+" Incorrect request for getPastWheelSheetDetails() service");
			
		} else {
			logger.info(uuId + " Past Wheel sheet search for aarRoad: "+pastwheelSheetRequestDetails.getAarRoad() +" and roadNumber :"+pastwheelSheetRequestDetails.getRoadNumber() +" started");
			
			logger.info(uuId+" before calling fetchPastWheelDetails()");
			pastWheelSheetResponse=fetchPastWheelDetails(uuId,pastwheelSheetRequestDetails);
		}
		}catch (Exception e) {
			logger.error(uuId + " Exception in getPastWheelSheetDetails", e);
			logger.error(new WheelsException(e));
			pastWheelSheetResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
			return pastWheelSheetResponse;
		}
		
		logger.info(uuId + " Past Wheel sheet search for aarRoad: "+pastwheelSheetRequestDetails.getAarRoad() +" and roadNumber :"+pastwheelSheetRequestDetails.getRoadNumber() +" finished");
		
		return pastWheelSheetResponse;
	}
	
	
	public PastWheelSheetResponse fetchPastWheelDetails(String uuId,PastWheelSheetRequestDetails pastwheelSheetRequestDetails)
	{
		PastWheelSheetResponse pastWheelSheetResponse = new PastWheelSheetResponse();
		WheelSheetDataCollection wheelSheetDataCollection;
		PastWheelSheetDetails pastWheelSheetDetail = new PastWheelSheetDetails();
		com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelSheetKey = new com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey();
		StatusType statusType = new StatusType();
		List<PastWheelSheetFileDetail> filteredList;
		String createdDateOfCurrentWorkOrder = null;

		wheelSheetKey.setAarRoad(pastwheelSheetRequestDetails.getAarRoad());
		wheelSheetKey.setRoadNumber(pastwheelSheetRequestDetails.getRoadNumber());
		wheelSheetDataCollection = wheelSheetRepository.findByWheelSheetKey(wheelSheetKey);
		if (null != wheelSheetDataCollection) {
			List<WheelSheetCollection> wheelSheetsWithCurrentWOId = wheelSheetDataCollection.getWheelSheet().stream()
					.filter(wheelSheet -> Objects.nonNull(wheelSheet.getWorkorderId())
							&& wheelSheet.getWorkorderId().equals(pastwheelSheetRequestDetails.getWorkorderId()))
					.collect(Collectors.toList());

			if (!wheelSheetsWithCurrentWOId.isEmpty() && !wheelSheetDataCollection.getWheelSheet().isEmpty()) {
				WheelSortUtil.reverseSortByCreatedDate(wheelSheetsWithCurrentWOId);
				createdDateOfCurrentWorkOrder = wheelSheetsWithCurrentWOId.get(0).getCreatedDate();
				filteredList = getSortedWheelFileList(uuId, wheelSheetDataCollection,pastwheelSheetRequestDetails.getWorkorderId(), createdDateOfCurrentWorkOrder);
				pastWheelSheetDetail.getPastWheelSheetFileDetail().addAll(filteredList);
				pastWheelSheetResponse.setPastWheelSheetDetails(pastWheelSheetDetail);
				statusType.setStatusCode(StatusCode.SUCCESS);
				if (filteredList.isEmpty()) {
					statusType.setMessage("No wheel sheets available ");
				} else {
					statusType.setMessage(WheelConstants.STATUS_MESSAGE_OK);
				}
			
			}else {
				logger.info(uuId + " No Wheel sheets available ");
				statusType.setStatusCode(StatusCode.SUCCESS);
				statusType.setMessage("No wheel sheets available ");

			}

		} else {
			logger.info(uuId + " Not an existing AAR road or Road Number");
			statusType.setStatusCode(StatusCode.SUCCESS);
			statusType.setMessage("Not an existing AAR road or Road Number");
		}
		pastWheelSheetResponse.setStatusType(statusType);
		return pastWheelSheetResponse;

	}
	
	public List<PastWheelSheetFileDetail> getSortedWheelFileList(String uuId,
			WheelSheetDataCollection wheelSheetDataCollection, Long workOrderId, String createdDate) {

		logger.info(uuId + " Inside getSortedWheelFileList()");
		List<PastWheelSheetFileDetail> filteredList = new ArrayList<>();
		List<PastWheelSheetFileDetail> sortedList = new ArrayList<>();
		PastWheelSheetDetails pastWheelSheetDetail = new PastWheelSheetDetails();

		if (!wheelSheetDataCollection.getWheelSheet().isEmpty()) {
			WheelSortUtil.reverseSortByCreatedDate(wheelSheetDataCollection.getWheelSheet());
			wheelSheetDataCollection.getWheelSheet().stream().forEach(wheelSheet -> {
				try {
					wheelSheet.setOperator(getNameforUser(wheelSheet.getCreatedBy(), uuId));
					sortedList.add(assignFileDetails(uuId, wheelSheet, workOrderId, createdDate,
							pastWheelSheetDetail.getPastWheelSheetFileDetail()));
				} catch (Exception e) {
					logger.error(uuId +"Exception in getSortedWheelFileList", e);
				}
			});

			sortedList.removeIf(Objects::isNull);
			if (sortedList.size() > 10) {
				filteredList = sortedList.stream().limit(10).collect(Collectors.toList());
			} else {
				filteredList = sortedList;
			}
		}
		return filteredList;
	}
	
	public PastWheelSheetFileDetail assignFileDetails(String uuId, WheelSheetCollection wheelSheet, Long workOrderId, String createdDate,List<PastWheelSheetFileDetail> pastWheelSheetFileDetailList){
		PastWheelSheetFileDetail pastWheelSheetFileDetail = null;
		if (wheelSheet.getWorkorderId() != null && pastWheelSheetFileDetailList.size() <= 10 && null!=createdDate) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				try {
					Date date1 = sdf.parse(createdDate);
					Date date2 = sdf.parse(wheelSheet.getCreatedDate());
					if (!workOrderId.equals(wheelSheet.getWorkorderId()) && date2.before(date1)) {
						pastWheelSheetFileDetail = new PastWheelSheetFileDetail();
		
						pastWheelSheetFileDetail.setWheelSheetName(wheelSheet.getWheelSheetName());
						pastWheelSheetFileDetail.setWheelSheetID(wheelSheet.getWheelsheetId());
						pastWheelSheetFileDetail.setCreatedDate(wheelSheet.getCreatedDate());
					
					}
				}
				catch (ParseException e) {
					logger.error(uuId+": Exception while assignFileDetails() for parsing to get PastWheelSheetFileDetail "+e);
					throw new WheelsException(uuId+": Exception while assignFileDetails() for parsing to get PastWheelSheetFileDetail "+e, e);
				}
			
		}
		return pastWheelSheetFileDetail;

	}

	@Override
	public WheelSheetDetailsResponse getDiameterCalculation(String uuId,
			WheelSheetDetailsRequest wheelSheetDetailsRequest) {
		logger.info(uuId+":********* getDiameterCalculation started @"+LocalDateTime.now());
		WheelSheetDetailsResponse wheelSheetDetailsResponse = new WheelSheetDetailsResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelSheetDetailsRequest, uuId);
			if (Objects.nonNull(statusType)) {
				wheelSheetDetailsResponse.setStatusType(statusType);
			} else {
				WheelSheetDetails wheelSheetDetails = getWheelSheetWithDiameterCalc(uuId, wheelSheetDetailsRequest.getWheelSheetDetails());
				wheelSheetDetailsResponse.setWheelSheetDetails(wheelSheetDetails);
				wheelSheetDetailsResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType(uuId+": Wheelsheetdata stored in database successfully"));
			}
		} catch (Exception e) {
			logger.error(new WheelsException(e));
			logger.error(uuId + " Exception in getDiameterCalculation", e);
			wheelSheetDetailsResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		logger.info(uuId+":********* getDiameterCalculation Stopped @"+LocalDateTime.now()+"********");
		return wheelSheetDetailsResponse;
	}
	
	private WheelSheetDetails getWheelSheetWithDiameterCalc(String uuId, WheelSheetDetails wheelSheetDetails){
		String roadnum = wheelSheetDetails.getWheelSheetKey().getRoadNumber();
		aarRoad = wheelSheetDetails.getWheelSheetKey().getAarRoad();
		roadNumber = String.valueOf(roadnum);
		List<WheelConfigRecord> wheelLimitRecords = getWheelParamsFromAdminConfiguration(uuId);
		verifyAndCalcDiaDiffForAxleTruckLoco(uuId, wheelSheetDetails, wheelLimitRecords);
		WheelSheetDataCollection wheelSheetDataCollection = WheelServiceUtil.mapDomainObjectToDocumentObject(wheelSheetDetails);
		List<WheelSheetCollection> docWheelSheet = wheelSheetDataCollection.getWheelSheet();
		WheelSheetCollection wheelSheetCollection = docWheelSheet.get(0);
		logger.info(uuId+": Converting Document WheelSheet to response WheelSheet...");
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
		mapper.setVisibility(VisibilityChecker.Std.defaultInstance().withFieldVisibility(JsonAutoDetect.Visibility.ANY));
		WheelSheet wheelSheetDomain = mapper.convertValue(wheelSheetCollection, WheelSheet.class);
		logger.info(uuId+": Mapping Converted for Document WheelSheet to response WheelSheet");
		WheelSheetDetails wheelSheetDataDomain = new WheelSheetDetails();
		wheelSheetDataDomain.setWheelSheetKey(wheelSheetDetails.getWheelSheetKey());
		wheelSheetDataDomain.getWheelSheet().add(wheelSheetDomain);		
		return wheelSheetDataDomain;
	}

	
	@Override
	public WheelSheetNameDetailsResponse validateAndSaveWheelSheetDetails(String uuId,
			WheelSheetNameDetailsRequest wheelSheetNameDetailsRequest) {
		WheelSheetNameDetailsResponse wheelSheetNameDetailsResponse = new WheelSheetNameDetailsResponse();

		try {
			logger.info(uuId + " Inside validateWheelSheetDetails ");
			StatusType statusType = wheelServiceValidator.validateRequestParams(wheelSheetNameDetailsRequest, uuId);
			if (Objects.nonNull(statusType)) {
				wheelSheetNameDetailsResponse.setStatusType(statusType);
				logger.info(uuId + " Incorrect request for validateWheelSheetDetails() service");

			}

			else {
				long workorderId = wheelSheetNameDetailsRequest.getWorkorderId();
				String wheelSheetName = wheelSheetNameDetailsRequest.getWheelSheetName();
				String wheelSheetId = wheelSheetNameDetailsRequest.getWheelSheetID();
				com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelSheetKey = new com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey();
				wheelSheetKey.setAarRoad(wheelSheetNameDetailsRequest.getAarRoad());
				wheelSheetKey.setRoadNumber(wheelSheetNameDetailsRequest.getRoadNumber());
				wheelSheetNameDetailsResponse = fetchWheelSheetFileName(uuId, wheelSheetKey, workorderId, wheelSheetId,
						wheelSheetName);
				logger.info(uuId + " Completed Excecution of validateWheelSheetDetails");

			}
		} catch (Exception e) {
			logger.error(uuId + " Exception in validateWheelSheetDetails", e);
			logger.error(new WheelsException(e));
			wheelSheetNameDetailsResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));

		}
		return wheelSheetNameDetailsResponse;
	}

	public WheelSheetNameDetailsResponse fetchWheelSheetFileName(String uuId,
			com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey wheelSheetKey, Long workorderId,
			String wheelSheetId, String wheelSheetName) {
		WheelSheetNameDetailsResponse wheelSheetNameDetailsResponse = new WheelSheetNameDetailsResponse();
		StatusType statusType;
		logger.info(uuId + " Inside fetchWheelSheetFileName");
		List<WheelSheetCollection> wheelSheetsWithmatchingWorkOrder = null;
		WheelSheetDataCollection wheelSheetDataCollection = wheelSheetRepository.findByWheelSheetKey(wheelSheetKey);
		if (null != wheelSheetDataCollection) {
			wheelSheetsWithmatchingWorkOrder = wheelSheetDataCollection.getWheelSheet().stream()
					.filter(wheelSheet -> Objects.nonNull(wheelSheet.getWorkorderId())
							&& workorderId.equals(wheelSheet.getWorkorderId()))
					.collect(Collectors.toList());
		}

		if (null != wheelSheetDataCollection && !wheelSheetsWithmatchingWorkOrder.isEmpty()) {

			// checking if the filename exists
			List<WheelSheetCollection> wheelSheetsWithmatchingName = wheelSheetsWithmatchingWorkOrder.stream()
					.filter(wheelSheet -> Objects.nonNull(wheelSheet.getWheelSheetName())
							&& wheelSheetName.equals(wheelSheet.getWheelSheetName()))
					.collect(Collectors.toList());

			// checking if name already exists
			if (!wheelSheetsWithmatchingName.isEmpty()) {
				statusType = WheelServiceUtil.sendSuccessStatusType(WheelConstants.WHEEL_NAME_ALREADY_EXIST);
				wheelSheetNameDetailsResponse.setStatusType(statusType);
				wheelSheetNameDetailsResponse.setValidFileName(false);
				logger.info(uuId + " Wheel Sheet Name already exists");

			} else {
				wheelSheetNameDetailsResponse=updateWheelSheetName(wheelSheetDataCollection, wheelSheetId, wheelSheetName);
			}

		} else {
			logger.info(uuId + " No records exists for the provided request");

			wheelSheetNameDetailsResponse
					.setStatusType(WheelServiceUtil.sendSuccessStatusType(WheelConstants.NO_RECORD_AVAILABLE));

		}

		return wheelSheetNameDetailsResponse;

	}

	public WheelSheetNameDetailsResponse updateWheelSheetName(WheelSheetDataCollection wheelSheetDataCollection,
			String wheelSheetId, String wheelSheetName) {
		StatusType statusType;
		WheelSheetNameDetailsResponse wheelSheetNameDetailsResponse = new WheelSheetNameDetailsResponse();

		List<WheelSheetCollection> wheelSheetToBeUpdated = new ArrayList<>();

		wheelSheetDataCollection.getWheelSheet().stream().forEach(wheelSheet -> {
			if (wheelSheetId.equals(wheelSheet.getWheelsheetId())) {
				wheelSheet.setWheelSheetName(wheelSheetName);
				wheelSheetToBeUpdated.add(wheelSheet);

			}
		});

		if (!wheelSheetToBeUpdated.isEmpty()
				&& null != wheelPersistanceService.saveWheelSheetDetails(wheelSheetDataCollection))

			statusType = WheelServiceUtil.sendSuccessStatusType(WheelConstants.WHEEL_NAME_SAVED);

		else
			statusType = WheelServiceUtil.sendSuccessStatusType(WheelConstants.WHEEL_NAME_SAVED_FAILED);

		wheelSheetNameDetailsResponse.setStatusType(statusType);
		wheelSheetNameDetailsResponse.setValidFileName(true);

		return wheelSheetNameDetailsResponse;
	}
	
	


}
