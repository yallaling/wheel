package com.ge.transportation.eservices2.wheel.config;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:wheelDetail.properties")
public class WheelDetailConfig {

	@Value("#{${Shim}}")
	public Map<String, String> shimMap;

	@Value("#{${VisibleDefects}}")
	public Map<String, String> visualDefectMap;

	public Map<String, String> getShimMap() {
		return shimMap;
	}

	public void setShimMap(Map<String, String> shimMap) {
		this.shimMap = shimMap;
	}

	public Map<String, String> getVisualDefectMap() {
		return visualDefectMap;
	}

	public void setVisualDefectMap(Map<String, String> visualDefectMap) {
		this.visualDefectMap = visualDefectMap;
	}

}
