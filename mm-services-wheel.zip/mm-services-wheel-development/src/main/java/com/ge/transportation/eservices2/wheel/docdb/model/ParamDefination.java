package com.ge.transportation.eservices2.wheel.docdb.model;

import java.util.List;

import com.ge.transportation.eservices2.domainobjects.ParamSpan;
import com.ge.transportation.eservices2.domainobjects.ParamType;

public class ParamDefination {

	private ParamType type;
    private ParamSpan span;
    private List<Object> values;
	
	public ParamDefination() {
		// Default Constructor
	}

	public ParamType getType() {
		return type;
	}

	public void setType(ParamType type) {
		this.type = type;
	}

	public ParamSpan getSpan() {
		return span;
	}

	public void setSpan(ParamSpan span) {
		this.span = span;
	}

	public List<java.lang.Object> getValues() {
		return values;
	}

	public void setValues(List<java.lang.Object> values) {
		this.values = values;
	}

}
