package com.ge.transportation.eservices2.wheel.docdb.model;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class WheelParamLimits {

	@Id
	private String id;
	private WheelParamKey wheelParamKey;
	private List<ParamLimits> paramLimits;

	public WheelParamLimits() {
		// Default Method
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public WheelParamKey getWheelParamKey() {
		return wheelParamKey;
	}

	public void setWheelParamKey(WheelParamKey wheelParamKey) {
		this.wheelParamKey = wheelParamKey;
	}

	public List<ParamLimits> getParamLimits() {
		if (paramLimits == null) {
			paramLimits = new ArrayList<>();
		}
		return paramLimits;
	}

	public void setParamLimits(List<ParamLimits> paramLimits) {
		this.paramLimits = paramLimits;
	}

}
