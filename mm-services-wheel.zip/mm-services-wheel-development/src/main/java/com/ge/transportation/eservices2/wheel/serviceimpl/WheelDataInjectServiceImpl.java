package com.ge.transportation.eservices2.wheel.serviceimpl;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.ge.transportation.eservices2.domainobjects.Calipriexport;
import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.MoveFileRequest;
import com.ge.transportation.eservices2.domainobjects.MoveFileResponse;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationRequest;
import com.ge.transportation.eservices2.domainobjects.RoadNumberValidationResponse;
import com.ge.transportation.eservices2.domainobjects.StatusCode;
import com.ge.transportation.eservices2.domainobjects.StatusType;
import com.ge.transportation.eservices2.domainobjects.UnProcessedFilesResponse;
import com.ge.transportation.eservices2.domainobjects.UploadFileResponse;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailRequest;
import com.ge.transportation.eservices2.domainobjects.WorkorderDetailResponse;
import com.ge.transportation.eservices2.wheel.awss3.service.AWSFileHandlerService;
import com.ge.transportation.eservices2.wheel.config.AppConfig;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.service.WheelDataInjectService;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.util.RestUtility;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;
import com.ge.transportation.eservices2.wheel.validator.WheelServiceValidator;

@Component
public class WheelDataInjectServiceImpl implements WheelDataInjectService {

	private static final String MOVED_TO_PROCESSING = " and is moved to 'processing' Folder";

	private static final String VALID_ROADNUMBER = "Given input file is valid with roadnumber : ";

	private static final String EXCEPTION_WHILE_VALIDATE_AND_FILE_WILL_BE_MOVE_TO_ERROR_FOLDER = " : Exception occured during validation, so File is moved to 'error' Folder";

	private static final String INVALID_ROADNUMBER = "Given input file is not-valid with roadnumber : ";

	private static final String ROAD_NUMBER_DOES_NOT_EXIST = "Road Number does not exist in the given input file";

	private static final String MOVED_TO_ERROR = " and is moved to 'error' Folder";

	private static final Logger logger = Logger.getLogger(WheelDataInjectServiceImpl.class);

	@Autowired
	AppConfig appConfig;

	@Autowired
	WheelPersistanceService wheelPersistanceService;

	@Autowired
	private WheelServiceValidator wheelServiceValidator;

	@Autowired
	private RestUtility restUtility;

	@Autowired
	AWSFileHandlerService awsFileHandlerService;
	
	@Autowired
	WheelFileDetailRepository wheelFileDetailRepository;

	String lastModifiedDate = "";
	int count = 0;
	String roadNumber = "";
	String aarRoad = "";

	@Override
	public MoveFileResponse moveCustomerFile(MoveFileRequest moveFileRequest, String uuId) {
		MoveFileResponse moveFileResponse = new MoveFileResponse();
		try {

			StatusType statusType = wheelServiceValidator.validateRequestParams(moveFileRequest, uuId);
			if (Objects.nonNull(statusType)) {
				moveFileResponse.setStatusType(statusType);
			} else {
				String successMsg = moveFile(moveFileRequest.getFileName(),
						moveFileRequest.getFrom(), moveFileRequest.getTo(), uuId);
				moveFileResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType(successMsg));
			}
		} catch (Exception e) {
			StringBuilder builder = new StringBuilder();
			builder.append("File not available in the AWS "+moveFileRequest.getFrom()+" folder of S3 Bucket, ");
			builder.append("Please check files in the S3 Bucket "+"/wheel/v1/file/listOfFiles ");
			logger.error(uuId+": Exception :"+e);
			moveFileResponse.setStatusType(WheelServiceUtil.sendFailedStatusType(builder.toString(), uuId));
		}
		return moveFileResponse;
	}

	public String validateFileAndSaveMetadata(String uuId, MultipartFile multipartFile) throws IOException {

		try(
				InputStream streamForParseXmlFile = multipartFile.getInputStream();
				InputStream streamForUploadAWSS3 = multipartFile.getInputStream();
			){
			String fileName = multipartFile.getOriginalFilename();
			
			RoadNumberValidationResponse response = new RoadNumberValidationResponse();
			Calipriexport calipriexport = parseXmlFile(streamForParseXmlFile, streamForUploadAWSS3, fileName, uuId, response);
	
			BigInteger lastmodified = calipriexport.getLastmodified();
			Date fileModifiedDate = WheelServiceUtil.convertIntegerToDate(lastmodified);
			lastModifiedDate = WheelServiceUtil.convertDateToString(fileModifiedDate);
			
			calipriexport.getProperties().getProperty().stream().forEach(property -> {
				if (WheelConstants.LOCOID.equalsIgnoreCase(property.getId())) {
					roadNumber = property.getValue();
				}
				if (WheelConstants.AAR.equalsIgnoreCase(property.getId())) {
					aarRoad = property.getValue();
				}
			});
			if (!aarRoad.isEmpty() && !roadNumber.isEmpty()) {
	
				response = validateRoadnumberFromWorkOrderService(uuId, roadNumber, aarRoad);
				if (StatusCode.SUCCESS.equals(response.getStatusCode())) {
					logger.info(uuId + " : " + VALID_ROADNUMBER + roadNumber + MOVED_TO_PROCESSING);
					awsFileHandlerService.uploadFileAsInputStream(uuId, fileName, streamForUploadAWSS3, appConfig.getProcessing());
					wheelPersistanceService.saveMetadata(uuId, fileName, FileStatus.VALID, response.getLocomotiveId(),
							lastModifiedDate);
					
					return VALID_ROADNUMBER + roadNumber + MOVED_TO_PROCESSING;
				} else {
					logger.info(uuId + " : " + INVALID_ROADNUMBER + " " + roadNumber + MOVED_TO_ERROR);
					awsFileHandlerService.uploadFileAsInputStream(uuId, fileName, streamForUploadAWSS3, appConfig.getError());
					wheelPersistanceService.saveMetadata(uuId, fileName, FileStatus.ERROR, response.getLocomotiveId(),
							lastModifiedDate);
					return INVALID_ROADNUMBER + roadNumber + MOVED_TO_ERROR;
				}
			} else {
				logger.info(uuId + " : " + ROAD_NUMBER_DOES_NOT_EXIST + MOVED_TO_ERROR);
				awsFileHandlerService.uploadFileAsInputStream(uuId, fileName, streamForUploadAWSS3, appConfig.getError());
				wheelPersistanceService.saveMetadata(uuId, fileName, FileStatus.ERROR, response.getLocomotiveId(),
						lastModifiedDate);
				return ROAD_NUMBER_DOES_NOT_EXIST + MOVED_TO_ERROR;
			}
		}

	}

	public Calipriexport parseXmlFile(InputStream inputStream, InputStream streamForUploadAWSS3, String fileName,
			String uuId, RoadNumberValidationResponse response) {
		if (fileName.endsWith(WheelConstants.XML)) {
			try {
				return WheelServiceUtil.parseXmlFile(inputStream);
			} catch (Exception e) {
				logger.info(uuId + EXCEPTION_WHILE_VALIDATE_AND_FILE_WILL_BE_MOVE_TO_ERROR_FOLDER + e);
				awsFileHandlerService.uploadFileAsInputStream(uuId, fileName, streamForUploadAWSS3,
						appConfig.getError());
				wheelPersistanceService.saveMetadata(uuId, fileName, FileStatus.ERROR, response.getLocomotiveId(),
						null);
				throw new WheelsException(uuId + EXCEPTION_WHILE_VALIDATE_AND_FILE_WILL_BE_MOVE_TO_ERROR_FOLDER + ", "
						+ e.getLocalizedMessage(), e);
			}
		} else {
			logger.info(uuId +": Invalid File Type, So File will be move to 'error' Folder");
			awsFileHandlerService.uploadFileAsInputStream(uuId, fileName, streamForUploadAWSS3,
					appConfig.getError());
			wheelPersistanceService.saveMetadata(uuId, fileName, FileStatus.ERROR, response.getLocomotiveId(),
					null);
			throw new WheelsException("Invalid File Type, So File is moved to 'error' Folder");
		}
	}

	private RoadNumberValidationResponse validateRoadnumberFromWorkOrderService(String uuid, String roadnumber,
			String aarRoad) {
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getRoadnumberValidation());
		RoadNumberValidationRequest request = new RoadNumberValidationRequest();
		request.setRoadNumber(roadnumber);
		request.setAarRoad(aarRoad);
		return restUtility.callCorePostService(request, new RoadNumberValidationResponse(), stringbuilder.toString(),
				"WheelServiceImpl: " + uuid);
	}

	public String moveFile(String file, String from, String to, String uuId) {
		if (checkNull(from, to) && !from.equalsIgnoreCase(to)) {
			// from
			StringBuilder fromBuilder = fromBuilder(file, from);
			// to
			StringBuilder toBuilder = toBuilder(file, to);
			awsFileHandlerService.moveFile(fromBuilder.toString(), toBuilder.toString(), uuId);
			return "File Successfully moved from: "+from+ ", to: "+to;
		}
		return "Failed - folder name should not empty or same ";
	}

	public StringBuilder toBuilder(String file, String to) {
		StringBuilder toBuilder = new StringBuilder(appConfig.getAwsS3Path());
		if (appConfig.getProcessing().equalsIgnoreCase(to)) {
			toBuilder.append(appConfig.getProcessing()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getError().equalsIgnoreCase(to)) {
			toBuilder.append(appConfig.getError()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getProcessed().equalsIgnoreCase(to)) {
			toBuilder.append(appConfig.getProcessed()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getUnProcessed().equalsIgnoreCase(to)) {
			toBuilder.append(appConfig.getUnProcessed()).append(WheelConstants.FORWARD).append(file);
		}
		
		return toBuilder;
	}

	public StringBuilder fromBuilder(String file, String from) {
		StringBuilder fromBuilder = new StringBuilder(appConfig.getAwsS3Path());
		if (appConfig.getProcessing().equalsIgnoreCase(from)) {
			fromBuilder.append(appConfig.getProcessing()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getError().equalsIgnoreCase(from)) {
			fromBuilder.append(appConfig.getError()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getProcessed().equalsIgnoreCase(from)) {
			fromBuilder.append(appConfig.getProcessed()).append(WheelConstants.FORWARD).append(file);
		} else if (appConfig.getUnProcessed().equalsIgnoreCase(from)) {
			fromBuilder.append(appConfig.getUnProcessed()).append(WheelConstants.FORWARD).append(file);
		}
		return fromBuilder;
	}

	public boolean checkNull(String from, String to) {
		return (null != from && !from.isEmpty()) && (null != to && !to.isEmpty());
	}

	@Override
	public List<S3ObjectSummary> listOfFiles(String uuId) {
		return awsFileHandlerService.listOfFiles(uuId);
	}

	@Override
	public UploadFileResponse uploadFile(String uuId, MultipartFile multipartFile) {
		UploadFileResponse uploadFileResponse = new UploadFileResponse();
		if(Objects.nonNull(multipartFile)) {
			try {
				InputStream multiPartStream = multipartFile.getInputStream();
				if(Objects.nonNull(multiPartStream)) {
					uploadFileResponse.setFileName(multipartFile.getOriginalFilename());
					String uploadFile = validateFileAndSaveMetadata(uuId, multipartFile);
					uploadFileResponse.setStatusType(WheelServiceUtil.sendSuccessStatusType(uploadFile));
				}
			} catch (Exception e) {
				uploadFileResponse.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
			}
		}
		return uploadFileResponse;
	}

	@Override
	public UnProcessedFilesResponse moveUnprocessedFiles(String uuId, String workOrderNum) {
		UnProcessedFilesResponse response = new UnProcessedFilesResponse();
		try {
			StatusType statusType = wheelServiceValidator.validateRequestParams(workOrderNum, uuId);
			if (Objects.nonNull(statusType)) {
				response.setStatusType(statusType);
			} else {
				List<WheelFileDetail> wheelFileDetails = getWorkorderAndMoveFiles(uuId, workOrderNum);
				response.setWheelFileDetails(wheelFileDetails);
				response.setStatusType(WheelServiceUtil.sendSuccessStatusType("Files Moved to UnProcessed"));
			}
		} catch (Exception e) {
			logger.error(uuId+": Exception :"+e);
			response.setStatusType(WheelServiceUtil.sendErrorStatusType(e, uuId));
		}
		return response;
	}
	
	public List<WheelFileDetail> getWorkorderAndMoveFiles(String uuId, String workOrderNum) {
		List<WheelFileDetail> wheelFileDetails = null;
		WorkorderDetailResponse workOrderDetails = getWorkorderStatus(uuId, workOrderNum);
		if(Objects.nonNull(workOrderDetails) && StatusCode.SUCCESS.equals(workOrderDetails.getStatus()) && Objects.nonNull(workOrderDetails.getWorkorder())) {
			logger.info(uuId + ": Workorder status : " + workOrderDetails.getWorkorder().getStatusMeaning());
			if ("Closed".equalsIgnoreCase(workOrderDetails.getWorkorder().getStatusMeaning())) {
				wheelFileDetails = checkAndMoveUnprocessedFiles(uuId, workOrderDetails);
			}
		}
		else {
			logger.warn(uuId+": Failed to get Workorder details from WorkOrder Service");
			throw new WheelsException(uuId+": Failed to get Workorder details from WorkOrder Service");
		}
		return wheelFileDetails;
	}

	public List<WheelFileDetail> checkAndMoveUnprocessedFiles(String uuId, WorkorderDetailResponse workOrderDetails) {
		List<WheelFileDetail> wheelFileDetails = wheelFileDetailRepository.findByLocomotiveIdAndStatusOrderByFileCreationDateDesc(
				workOrderDetails.getWorkorder().getLocomotiveId(), "VALID");
		wheelFileDetails.stream().filter(file -> FileStatus.VALID.equals(file.getStatus())).forEach(file -> {
			try {
				moveFile(file.getFileName(), appConfig.getProcessing(), appConfig.getUnProcessed(), uuId);
			} catch (Exception e) {
				if (e.getMessage().contains("The specified key does not exist")) {
					logger.warn(uuId + ": " + file.getFileName() + " file not found, "+e);
				} else {
					logger.error(uuId + ": Exception while Move UnProcessed files, "+e);
				}
			}
			file.setStatus(FileStatus.UNPROCESSED);
			wheelFileDetailRepository.save(file);
			logger.info(uuId + ": FileStatus changed from " + FileStatus.VALID + " to " + FileStatus.PROCESSED
					+ " in wheelfiledetail collection...");
		});
		return wheelFileDetails;
	}

	private WorkorderDetailResponse getWorkorderStatus(String uuId, String workOrderNum) {
		StringBuilder stringbuilder = new StringBuilder();
		stringbuilder.append(appConfig.getBaseUrl()).append(appConfig.getWorkorderDetails()).append(workOrderNum);
		WorkorderDetailRequest workorderDetailRequest = new WorkorderDetailRequest();
		workorderDetailRequest.setServiceWorkorderId(workOrderNum);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		return restUtility.callCoreGetService(workorderDetailRequest, new WorkorderDetailResponse(), stringbuilder.toString(),
				"WheelDataInjectServiceImpl: " + uuId, httpHeaders);
	}
	
}
