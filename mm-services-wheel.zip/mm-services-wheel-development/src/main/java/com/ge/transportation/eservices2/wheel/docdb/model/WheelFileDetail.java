package com.ge.transportation.eservices2.wheel.docdb.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.ge.transportation.eservices2.domainobjects.FileStatus;

@Document
public class WheelFileDetail {

	@Id
	private String id;
	private Long locomotiveId;
	private String fileName;
	private String fileCreationDate;
	private FileStatus status;
	private String creationDate;
	private String lastUpdatedDate;

	public WheelFileDetail() {
		// Default Constructor
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getLocomotiveId() {
		return locomotiveId;
	}

	public void setLocomotiveId(Long locomotiveId) {
		this.locomotiveId = locomotiveId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileCreationDate() {
		return fileCreationDate;
	}

	public void setFileCreationDate(String fileCreationDate) {
		this.fileCreationDate = fileCreationDate;
	}

	public FileStatus getStatus() {
		return status;
	}

	public void setStatus(FileStatus status) {
		this.status = status;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

}
