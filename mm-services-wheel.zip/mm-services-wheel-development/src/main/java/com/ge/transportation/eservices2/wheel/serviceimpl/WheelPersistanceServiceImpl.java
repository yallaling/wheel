package com.ge.transportation.eservices2.wheel.serviceimpl;


import java.util.ArrayList;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import org.apache.log4j.LogManager;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.ge.transportation.eservices2.domainobjects.FileStatus;
import com.ge.transportation.eservices2.domainobjects.WheelparamLimits;
import com.ge.transportation.eservices2.wheel.constants.WheelConstants;
import com.ge.transportation.eservices2.wheel.docdb.model.ParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelFileDetail;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamKey;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelParamLimits;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetDataCollection;
import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetKey;
import com.ge.transportation.eservices2.wheel.exception.WheelsException;
import com.ge.transportation.eservices2.wheel.repository.WheelFileDetailRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelParamLimitsRepository;
import com.ge.transportation.eservices2.wheel.repository.WheelSheetRepository;
import com.ge.transportation.eservices2.wheel.service.WheelPersistanceService;
import com.ge.transportation.eservices2.wheel.util.WheelServiceUtil;

@Component
@Transactional
public class WheelPersistanceServiceImpl implements WheelPersistanceService {

	private static final Logger logger = LogManager.getLogger(WheelPersistanceServiceImpl.class);

	@Autowired
	WheelFileDetailRepository wheelFileDetailRepository;

	@Autowired
	WheelParamLimitsRepository wheelParamLimitsRepository;
	
	@Autowired
	WheelSheetRepository wheelSheetRepository;

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public void saveMetadata(String uuId, String fileName, FileStatus status, String locomotiveId,
			String lastModifiedDate) {
		try {
			WheelFileDetail wheelFileDetail = new WheelFileDetail();
			wheelFileDetail.setStatus(status);
			wheelFileDetail.setLocomotiveId(locomotiveId != null ? Long.valueOf(locomotiveId) : 0);
			wheelFileDetail.setFileName(fileName);
			wheelFileDetail.setFileCreationDate(lastModifiedDate);
			wheelFileDetail.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
			wheelFileDetail.setLastUpdatedDate(WheelServiceUtil.convertDateToString(new Date()));
			WheelFileDetail docWheelFileDetail = wheelFileDetailRepository.findByFileNameAndStatus(wheelFileDetail.getFileName(), wheelFileDetail.getStatus());
			if(Objects.nonNull(docWheelFileDetail)) {
				docWheelFileDetail.setFileCreationDate(wheelFileDetail.getFileCreationDate());
				docWheelFileDetail.setLocomotiveId(wheelFileDetail.getLocomotiveId());
				docWheelFileDetail.setCreationDate(WheelServiceUtil.convertDateToString(new Date()));
				docWheelFileDetail.setLastUpdatedDate(WheelServiceUtil.convertDateToString(new Date()));
				wheelFileDetailRepository.save(docWheelFileDetail);
			} else {
				wheelFileDetailRepository.save(wheelFileDetail);
			}
		} catch (Exception e) {
			throw new WheelsException(uuId + WheelConstants.EXCEPTION_DB + e);
		}
	}

	@Override
	public String isValidFile(Long locomotiveID, String fileName, String uuId) {
		List<WheelFileDetail> wheelFileDetails = wheelFileDetailRepository.findByLocomotiveIdAndFileName(locomotiveID,
				fileName);
		boolean isValid = false;
		if (Objects.nonNull(wheelFileDetails)) {
			for (WheelFileDetail wheelFileDetail : wheelFileDetails) {
				FileStatus fileStatus = wheelFileDetail.getStatus();
				logger.info(uuId + " : File - " + fileName + " " + wheelFileDetail.getStatus());
				if (FileStatus.VALID.name().equalsIgnoreCase(fileStatus.name())) {
					isValid = true;
				}
				if (isValid) {
					return wheelFileDetail.getFileCreationDate();
				}
			}
		}
		return "";
	}

	@Override
	public WheelParamLimits findByWheelParamKey(WheelParamKey wheelParamKey) {
		return wheelParamLimitsRepository.findByWheelParamKeyCustomerIdAndWheelParamKeyAarRoadAndWheelParamKeyWheelParameterAndWheelParamKeyLocoType(wheelParamKey.getCustomerId(), wheelParamKey.getAarRoad(), wheelParamKey.getWheelParameter(), wheelParamKey.getLocoType());	
	}

	@Override
	public WheelparamLimits saveParamLimits(WheelParamLimits limitsCollection) {
		WheelParamLimits docObj = wheelParamLimitsRepository.save(limitsCollection);
		if(Objects.nonNull(docObj)) {
			return mapCollectionToResponse(docObj);
		}
		return null;
	}
	
	private WheelparamLimits mapCollectionToResponse(WheelParamLimits docObj) {
		WheelparamLimits responseObj = new WheelparamLimits();
		ParamLimits paramLimits = docObj.getParamLimits().get(0);
		responseObj.setId(docObj.getId());
		responseObj.setCustomerId(docObj.getWheelParamKey().getCustomerId());
		responseObj.setAarRoad(docObj.getWheelParamKey().getAarRoad());
		responseObj.setLocoType(docObj.getWheelParamKey().getLocoType());
		responseObj.setWheelParameter(docObj.getWheelParamKey().getWheelParameter());
		responseObj.setLowerLimit(paramLimits.getLowerLimit());
		responseObj.setUpperLimit(paramLimits.getUpperLimit());
		responseObj.setCreatedBy(paramLimits.getCreatedBy());
		responseObj.setCreationDate(paramLimits.getCreationDate());
		responseObj.setLastUpdatedBy(paramLimits.getLastUpdatedBy());
		responseObj.setLastUpdatedDate(paramLimits.getLastUpdateDate());
		return responseObj;
	}
	
	@Override
	public List<WheelparamLimits> saveParamLimitsList(List<WheelParamLimits> limitsCollection) {
		List<WheelparamLimits> resultList=new ArrayList<>();
		WheelparamLimits wheelData=null;
		
		List<WheelParamLimits> docObj = wheelParamLimitsRepository.save(limitsCollection);
		
		for(WheelParamLimits wheelParamLimits:docObj)
		{
		if(Objects.nonNull(wheelParamLimits)) {
			wheelData=mapCollectionToResponse(wheelParamLimits);
			resultList.add(wheelData);
		}
		}
		return resultList;
	}

	@Override
	public WheelSheetDataCollection getWheelSheetDetiails(WheelSheetKey wheelSheetKey) {
		return wheelSheetRepository.findByWheelSheetKey(wheelSheetKey);
	}

	@Override
	public WheelSheetDataCollection saveWheelSheetDetails(WheelSheetDataCollection docWheelSheetDetails) {
		return wheelSheetRepository.save(docWheelSheetDetails);
	}
	
}
