package com.ge.transportation.eservices2.wheel.model;


import java.util.Date;


public class ActionDTO{

	private String description;
	private Date timestamp;
	private UserDTO userDTO;
	
	public ActionDTO() { 
		// Dafault constructor
	}

	
	public UserDTO getUserDTO() {
		return userDTO;
	}


	public void setUserDTO(UserDTO userDTO) {
		this.userDTO = userDTO;
	}


	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	
}
