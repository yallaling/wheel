package com.ge.transportation.eservices2.wheel.docdb.model;

import java.util.List;

import org.springframework.data.annotation.Transient;

public class WheelSheetCollection {

		private String fileName;
		@Transient
	    private String serviceOrgId;
		@Transient
	    private String customerId;
	    private Long workorderId;
	    private String wheelsheetId;
	    private String wheelSheetName;
	    private String fileCreationDate;
	    @Transient
	    private String workshift;
	    @Transient
	    private String userId;
	    private String createdDate;
	    private String createdBy;
	    private String gaugeType;
	    private String uom;
	    @Transient
	    private String operator;
	    private List<AxleProperties> axleProperties;
	    private List<Pos> pos;

	
	public WheelSheetCollection() {
		// Default Constructor
	}

	public String getFileName() {
		return fileName;
	}
	
	public String getServiceOrgId() {
		return serviceOrgId;
	}

	public void setServiceOrgId(String serviceOrgId) {
		this.serviceOrgId = serviceOrgId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getWorkshift() {
		return workshift;
	}

	public void setWorkshift(String workshift) {
		this.workshift = workshift;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getWorkorderId() {
		return workorderId;
	}

	public void setWorkorderId(Long workorderId) {
		this.workorderId = workorderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getWheelsheetId() {
		return wheelsheetId;
	}

	public void setWheelsheetId(String wheelsheetId) {
		this.wheelsheetId = wheelsheetId;
	}

	public String getWheelSheetName() {
		return wheelSheetName;
	}

	public void setWheelSheetName(String wheelSheetName) {
		this.wheelSheetName = wheelSheetName;
	}

	public String getFileCreationDate() {
		return fileCreationDate;
	}

	public void setFileCreationDate(String fileCreationDate) {
		this.fileCreationDate = fileCreationDate;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getGaugeType() {
		return gaugeType;
	}

	public void setGaugeType(String gaugeType) {
		this.gaugeType = gaugeType;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public List<AxleProperties> getAxleProperties() {
		return axleProperties;
	}

	public void setAxleProperties(List<AxleProperties> axleProperties) {
		this.axleProperties = axleProperties;
	}

	public List<Pos> getPos() {
		return pos;
	}

	public void setPos(List<Pos> pos) {
		this.pos = pos;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	
	
}
