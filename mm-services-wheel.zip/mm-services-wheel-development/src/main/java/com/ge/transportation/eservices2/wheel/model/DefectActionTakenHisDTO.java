/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2014 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *     
 ********************************************************************************/

package com.ge.transportation.eservices2.wheel.model;

import java.util.Date;


/**
 * DTO class to entity DefectActionTakenHis
 *
 * @author Lin Han
 * @version 1.0 Aug 20, 2014
 * @since 1.0
 */

public class DefectActionTakenHisDTO{
	
	private String actionComments;
	private UserProfileDTO updatedBy;
	private Date creationDate;
	
	/**
	 * @return the actionComments
	 */
	public String getActionComments() {
		return actionComments;
	}
	
	/**
	 * @param actionComments the actionComments to set
	 */
	public void setActionComments(String actionComments) {
		this.actionComments = actionComments;
	}
	
	/**
	 * @return the updatedBy
	 */
	public UserProfileDTO getUpdatedBy() {
		return updatedBy;
	}
	
	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(UserProfileDTO updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}
	
	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

}
