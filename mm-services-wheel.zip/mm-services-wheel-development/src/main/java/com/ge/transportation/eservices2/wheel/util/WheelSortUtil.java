package com.ge.transportation.eservices2.wheel.util;

import java.util.Comparator;
import java.util.List;

import com.ge.transportation.eservices2.wheel.docdb.model.WheelSheetCollection;

public class WheelSortUtil {

	private WheelSortUtil() {
		// Default Constructor
	}
	
	public static void reverseSortByCreatedDate(List<WheelSheetCollection> wheelSheetsWithCurrentWOId) {
		wheelSheetsWithCurrentWOId.sort(Comparator.comparing(WheelSheetCollection::getCreatedDate).reversed());
	}
	
	public static void sortByCreatedDate(List<WheelSheetCollection> wheelSheetsWithWO) {
		wheelSheetsWithWO.sort(Comparator.comparing(WheelSheetCollection::getCreatedDate));
	}
	
}
