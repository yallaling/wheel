package com.ge.transportation.eservices2.wheel.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.ge.transportation.eservices2.wheel.docdb.model.WheelParameters;

@Repository
public interface WheelParamRepository extends MongoRepository<WheelParameters, String> {

	List<WheelParameters> findByCustomerId(String customerId);
	List<WheelParameters> findByCustomerIdAndWheelAdminIdIn(String string,List<String> wheelParams);
}
