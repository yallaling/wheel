package com.ge.transportation.eservices2.wheel.model;

public class DefectSignOffDTO {
	
	private String  loginId;
	private Integer workOrderId;
	private Integer sourceId;
	private String  sourceType;
	private Integer signOffLineId;
	private String  userName;
	private String  fullNameUN;
	private String  fullName;	
	
	/**
	 * @return the loginId
	 */
	public String getLoginId() {
		return loginId;
	}
	/**
	 * @param loginId the loginId to set
	 */
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	/**
	 * @return the workOrderId
	 */
	public Integer getWorkOrderId() {
		return workOrderId;
	}
	/**
	 * @param workOrderId the workOrderId to set
	 */
	public void setWorkOrderId(Integer workOrderId) {
		this.workOrderId = workOrderId;
	}
	/**
	 * @return the sourceId
	 */
	public Integer getSourceId() {
		return sourceId;
	}
	/**
	 * @param sourceId the sourceId to set
	 */
	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}
	/**
	 * @return the sourceType
	 */
	public String getSourceType() {
		return sourceType;
	}
	/**
	 * @param sourceType the sourceType to set
	 */
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	/**
	 * @return the signOffLineId
	 */
	public Integer getSignOffLineId() {
		return signOffLineId;
	}
	/**
	 * @param signOffLineId the signOffLineId to set
	 */
	public void setSignOffLineId(Integer signOffLineId) {
		this.signOffLineId = signOffLineId;
	}
	/**
	 * @return the fullNameUN
	 */
	public String getFullNameUN() {
		return fullNameUN;
	}
	/**
	 * @param fullNameUN the fullNameUN to set
	 */
	public void setFullNameUN(String fullNameUN) {
		this.fullNameUN = fullNameUN;
	}
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}	
	
}
