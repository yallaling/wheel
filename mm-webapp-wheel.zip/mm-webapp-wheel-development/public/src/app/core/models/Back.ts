import { Def } from './Def';

export class Back {
        private value: string;
        private def: Def;


    /**
     * Getter $value
     * @return {string}
     */
	public get getvalue(): string {
		return this.value;
	}

    /**
     * Getter $def
     * @return {Def}
     */
	public get getdef(): Def {
		return this.def;
	}

    /**
     * Setter $value
     * @param {string} value
     */
	public set setvalue(value: string) {
		this.value = value;
	}

    /**
     * Setter $def
     * @param {Def} value
     */
	public set setdef(value: Def) {
		this.def = value;
	}

}
