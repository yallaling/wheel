export class SessionDetails {

    public userid = '';
    public ssoId = '';
    public firstName = '';
    public lastName = '';
    public organizationid = '';
    public locale = '';
    public inflag = '';

    public sesid = '';
    public roadNumber = '';
    public customerName = '';
    public customerId = '';
    public defectid = '';
    public workorderid = '';
    public clientUrl = '';
    public locoId = '';

    constructor() {
    }
}
