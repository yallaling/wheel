import { Def } from './Def';

export class Left {
        private value: string;
        private def: Def;
        private defectId: number;
        private isDefect: boolean;


    /**
     * Getter $value
     * @return {string}
     */
	public get getvalue(): string {
		return this.value;
	}

    /**
     * Getter $def
     * @return {Def}
     */
	public get getdef(): Def {
		return this.def;
	}

    /**
     * Setter $value
     * @param {string} value
     */
	public set setvalue(value: string) {
		this.value = value;
	}

    /**
     * Setter $def
     * @param {Def} value
     */
	public set setdef(value: Def) {
		this.def = value;
    }
    
    /**
     * Getter $def
     * @return {Def}
     */
	public get getdefectId(): number {
		return this.defectId;
	}

    /**
     * Setter $value
     * @param {string} value
     */
	public set setdefectId(value: number) {
		this.defectId = value;
    }
    
    /**
     * Getter $def
     * @return {Def}
     */
	public get getisDefect(): boolean {
		return this.isDefect;
	}

    /**
     * Setter $value
     * @param {string} value
     */
	public set setisDefect(value: boolean) {
		this.isDefect = value;
	}

}
