export class WheelSheetKey {
   private aarRoad: string;
   private roadNumber: number;


    /**
     * Getter $aarRoad
     * @return {string}
     */
	public get getaarRoad(): string {
		return this.aarRoad;
	}

    /**
     * Getter $roadNumber
     * @return {number}
     */
	public get getroadNumber(): number {
		return this.roadNumber;
	}

    /**
     * Setter $aarRoad
     * @param {string} value
     */
	public set setaarRoad(value: string) {
		this.aarRoad = value;
	}

    /**
     * Setter $roadNumber
     * @param {number} value
     */
	public set setroadNumber(value: number) {
		this.roadNumber = value;
	}

}
