import { WheelProfiles } from './WheelProfiles';

export class AxleProperties {
    private axleName: string;
    private wheelProfiles: Array<WheelProfiles>;


    /**
     * Getter $axlename
     * @return {string}
     */
	public get getaxlename(): string {
		return this.axleName;
	}

    /**
     * Getter $wheelprofile
     * @return {Array<any>}
     */
	public get getwheelprofiles(): Array<any> {
		return this.wheelProfiles;
	}

    /**
     * Setter $axlename
     * @param {string} value
     */
	public set setaxlename(value: string) {
		this.axleName = value;
	}

    /**
     * Setter $wheelprofile
     * @param {Array<any>} value
     */
	public set setwheelprofiles(value: Array<any>) {
		this.wheelProfiles = value;
	}

}
