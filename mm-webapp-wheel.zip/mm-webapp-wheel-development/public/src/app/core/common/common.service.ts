import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppConfig, APP_CONFIG } from '../../app.config';
import { SessionDetails } from '../models/session-details.model';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  sessionDetails: SessionDetails = new SessionDetails();

  constructor(private http: HttpClient, @Inject(APP_CONFIG) private config: AppConfig) { }

  getUserDetails() {
    return this.http.get(this.config.userDetailsApiUrl)
      .pipe(
        catchError(this.handleError)
      );
  }

  getAarRoad(custId): Observable<any> {
    return this.http.get(this.config.getAarRoadUrl, {
      params: {
        custid: custId
      }
    }).pipe(
      catchError(this.handleError)
    );
  }
  getLocoType(custId, aarRoadLists): Observable<any> {
    const payload = {'custId': custId, 'aarRoad': aarRoadLists.aarRoad};

    return this.http.post(this.config.getLocoTypeUrl, payload)
      .pipe(
        catchError(this.handleError)
      );
  }
  getWheelParameterByCustomer(custId): Observable<any> {
    const payload = {'custId': custId};

    return this.http.post(this.config.getWheelParameterByCustomerUrl, payload)
      .pipe(
        catchError(this.handleError)
      );
  }
  getWheelParameterLimit(custId, aarRoadList, selectedItems): Observable<any> {
      const payload = {'aarRoad': aarRoadList, 'custId': custId, 'locoType': selectedItems};

    return this.http.post(this.config.getWheelParameterLimitUrl, payload)
      .pipe(
        catchError(this.handleError)
      );
  }
deleteWheelParameterLimit(wheelParamPayload): Observable<any> {
  console.log(wheelParamPayload);
  return this.http.post(this.config.deleteWheelParameterLimitUrl, wheelParamPayload)
    .pipe(
      catchError(this.handleError)
    );
}

  getWheelParameterLimits(wheelParamPayload): Observable<any> {

    return this.http.post(this.config.getWheelParameterLimitsUrl, wheelParamPayload)
      .pipe(
        catchError(this.handleError)
      );
  }

  getHistoryWheelParameterLimit(historyParamPayload): Observable<any> {

    return this.http.post(this.config.historyWheelParameterLimitUrl, historyParamPayload)
      .pipe(
        catchError(this.handleError)
      );
  }

  getWheelsheetFileDetails(locoId): Observable<any> {

    return this.http.post(this.config.getWheelsheetFileDetails,locoId)
      .pipe(
        catchError(this.handleError)
      );
  }
  saveWheelsheetData(wheelSheetDetails): Observable<any> {

    return this.http.post(this.config.saveWheelsheetData, wheelSheetDetails)
      .pipe(
        catchError(this.handleError)
      );
  }

  getLocomotiveId(woId): Observable<any> {

    return this.http.get(this.config.getLocomotiveId,{
      params: {
        woId: woId
      }
    }).pipe(
      catchError(this.handleError)
    );
  }

  getMeasurements(fileDetail): Observable<any> {

    return this.http.post(this.config.getMeasurements,fileDetail)
      .pipe(
        catchError(this.handleError)
      );
  }

  getPastWheelsheetData(wheelSheetDetails): Observable<any> {

    return this.http.post(this.config.pastWheelSheetData, wheelSheetDetails)
      .pipe(
        catchError(this.handleError)
      );
  }

  getPast10WheelsheetData(wheelSheetDetails): Observable<any> {

    return this.http.post(this.config.past10Wheelsheet, wheelSheetDetails)
      .pipe(
        catchError(this.handleError)
      );
  }

  getwheelsheetdataforwo(wheelSheetDetails): Observable<any> {

    return this.http.post(this.config.getwheelsheetdataforwo, wheelSheetDetails)
      .pipe(
        catchError(this.handleError)
      );
  }

  uploadfile(formData): Observable<any> {

    return this.http.post(this.config.uploadfile, formData)
      .pipe(
        catchError(this.handleError)
      );
  }

  getDefectDetails(defectDetailsHeaders): Observable<any> {

    return this.http.get(this.config.getDefectDetails,{
      params: {
        woId: defectDetailsHeaders.workorderid,
        defectId: defectDetailsHeaders.defectId
      },
      headers: defectDetailsHeaders
    }).pipe(
      catchError(this.handleError)
    );
  }

  getTdUserDetails(workshiftHeaders): Observable<any> {

    return this.http.get(this.config.getTdUserDetails,{
      params: {
        userid: workshiftHeaders.UserId
      },
      headers: workshiftHeaders
    }).pipe(
      catchError(this.handleError)
    );
  }

  updateDefect(defectDetailsHeaders,defectPayload): Observable<any> {

    return this.http.post(this.config.updateDefect,defectPayload,{
      params: {
        defectId: defectDetailsHeaders.defectId
      },
      headers: defectDetailsHeaders
    }).pipe(
      catchError(this.handleError)
    );
  }

  renameWheelsheet(renamePayload): Observable<any> {

    return this.http.post(this.config.renameWheelsheet,renamePayload)
    .pipe(
      catchError(this.handleError)
    );
  }

  diametercalculation(wheelSheetDetails): Observable<any> {

    return this.http.post(this.config.diametercalculation, wheelSheetDetails)
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  }

  post(path, params, target, method) {
    method = method || 'post'; // Set method to post by default if not specified.

    const form = <HTMLFormElement>document.createElement('form');
    form.setAttribute('method', method);
    form.setAttribute('action', path);
    if (target) {
      form.setAttribute('target', target);
    }

    for (const key in params) {
      if (params.hasOwnProperty(key)) {
        const hiddenField = <HTMLInputElement>document.createElement('input');
        hiddenField.setAttribute('type', 'hidden');
        hiddenField.setAttribute('name', key);
        hiddenField.setAttribute('value', params[key]);
        form.appendChild(hiddenField);
      }
    }
    window.top.document.body.appendChild(form);
    form.submit();
  }

  redirectToTask() {
    this.sessionDetails.clientUrl = window.location.origin + '/eservices/';
    console.log('clientUrl : '+this.sessionDetails.clientUrl);
    this.post('' + this.sessionDetails.clientUrl + this.config.RAIL_CONNECT,
      {
        menuid: this.config.TASK_MENU_ID, sesid: this.sessionDetails.sesid, roadnoindex: 9999, flag: this.config.OS_FLAG,
        inflag: this.config.OS_FLAG, woid: this.sessionDetails.workorderid,
        workorderid: this.sessionDetails.workorderid
      }, null, this.config.POST);
  }
}
