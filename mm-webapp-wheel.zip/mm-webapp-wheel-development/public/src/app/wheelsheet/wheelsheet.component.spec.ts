import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WheelsheetComponent } from './wheelsheet.component';

describe('WheelsheetComponent', () => {
  let component: WheelsheetComponent;
  let fixture: ComponentFixture<WheelsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WheelsheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WheelsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
