import { Component, ViewEncapsulation, OnInit, ElementRef } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FaIconService } from '@fortawesome/angular-fontawesome';
import { HistoryModalComponent } from '../history-modal/history-modal.component';
import { ConfirmationModalComponent } from '../confirmation-modal/confirmation-modal.component';
import{ DeleteConfirmationComponent } from '../delete-confirmation-modal/delete-confirmation-modal.component';
import { faPlusCircle, faSearch, faFileAlt, faSave, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import {MatSnackBar} from '@angular/material/snack-bar';
import{UtilService} from '../core/utils/util.service';

@Component({
  selector: 'app-wheeladmin',
  templateUrl: './wheeladmin.component.html',
  styleUrls: ['./wheeladmin.component.scss']
})
export class WheeladminComponent implements OnInit {
  closeResult: string;
  aarRoadLists = [];
  wheelParamList = [];
  saveResponse: any;
  deleteResponse: any;
  locoTypeLists = [];
  faPlusCircle = faPlusCircle;
  faSearch = faSearch;
  faFileAlt = faFileAlt;
  faSave = faSave;
  faTrashAlt = faTrashAlt;

  rows = [];

  selected = [];
  selectedItems = [];
  dropdownSettings = {};
  selectedAarRoad = {'aarRoad': 'Select'};
  selectAarRoad = {'aarRoad': 'Select'};
  selectedWheelParam: String = 'Select';
  staticAlertClosed = false;
  successMessage: string;
  nonconfiguredParameter = [];
  searchdone = 0;
  newParamFlag:boolean=false;
  newParam:any;

  columns: any[] = [
    { prop: 'Wheel Parameter'} ,
    { name: 'Lower Limit' },
    { name: 'Upper Limit' }
  ];

  constructor(
    private commonService: CommonService,
    private activeRoute: ActivatedRoute,
    private modalService: NgbModal,
    private faIconService: FaIconService,
    private snackBar: MatSnackBar,
    private utilService:UtilService) {
      this.faIconService.defaultPrefix = 'far';
      this.commonService.sessionDetails.sesid = this.activeRoute.snapshot.queryParams['sessid'];
 }

  ngOnInit() {
    this.commonService.getAarRoad(this.commonService.sessionDetails.customerId).subscribe(res => {
      this.aarRoadLists = res.aarRoadList;
     });
     this.commonService.getWheelParameterByCustomer(this.commonService.sessionDetails.customerId).subscribe(res => {
      this.wheelParamList = res.wheelParamList;
      this.selectedAarRoad = this.selectAarRoad;
     });

     this.dropdownSettings = {
      singleSelection: false,
      idField: 'locoType',
      textField: 'locoType',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3
    };
  }
  onItemSelect(item:any){
    this.cleanData();
  }
OnItemDeSelect(item:any){
  this.cleanData();
}
onSelectAll(items: any){
  this.cleanData();
}
onDeSelectAll(items: any){
  this.cleanData();
}
  getSelectedAarRoad(aarRoadList) {
    this.commonService.getLocoType(this.commonService.sessionDetails.customerId, aarRoadList).subscribe(res => {
      this.rows = [];
      this.selectedItems = [];
      this.locoTypeLists = res.locoTypeList;
     });

  }
  loadParameter() {
    // tslint:disable-next-line:max-line-length
    this.newParamFlag=false;
    this.commonService.getWheelParameterLimit(this.commonService.sessionDetails.customerId, this.selectedAarRoad.aarRoad, this.selectedItems).subscribe(res => {
      for (let value1 of res.limitRecords) {
        for (let value2 of this.wheelParamList) {
          if(value1.wheelParameter == value2.wheelAdminId) {
            value1.selectedWheelParam = value1.wheelParameter;
          }
         }

      }
      this.searchdone = 1;
      this.rows  = res.limitRecords;
      this.filterParameter();
   });
}

deleteParameter(row) {
  console.log('row', row);
  const modalRef = this.modalService.open(DeleteConfirmationComponent, { size: 'sm', centered: true });
  modalRef.componentInstance.confirmationBoxTitle = 'Delete Parameter';
  modalRef.componentInstance.confirmationMessage = 'Data will not be saved and hence defects will not be created for deleted wheel parameters in future wheel sheets. Are you sure you want to delete?';
  modalRef.componentInstance.confirmationOption='Yes';
  modalRef.result.then((userResponse) => {
    if (userResponse === true) {
      const deleteParamPayload = {
        'aarRoad': this.selectedAarRoad.aarRoad,
        'customerId': this.commonService.sessionDetails.customerId,
        'locoType': this.selectedItems,
        'wheelParameter': row.wheelParameter
      };

  this.commonService.deleteWheelParameterLimit(deleteParamPayload).subscribe(res => {
    this.deleteResponse = res;
    if (this.deleteResponse.statusType.statusCode === 'SUCCESS') {

      const index: number = this.rows.indexOf(row);
      if (index !== -1) {
        this.rows.splice(index, 1);
    }
    this.utilService.success_snackbar('Parameter deleted successfully.');
    if (this.newParam === row.wheelParameter)
          {
            this.filterParameter();
            this.newParamFlag = false;
          }
    } else {
      this.successMessage = null;
    }
 });
   }
 });

}

  addRecord() {
    this.newParamFlag=true;
  //  this.filterParameter();
    console.log('nonconfiguredParameter', this.nonconfiguredParameter);

     const newData = {
                      'wheelAdmin': this.nonconfiguredParameter,
                      'lowerLimit': '',
                      'upperLimit': '',
                      'rowDisabled': true


                  };
                  this.rows.push(newData);

  }

  open(row) {
    const modalRef = this.modalService.open(HistoryModalComponent, { size: 'lg', centered: true});
    modalRef.componentInstance.wheelModalParameter = row.wheelParameter;
    modalRef.componentInstance.aarRoad = this.selectedAarRoad.aarRoad;
    modalRef.componentInstance.locoType = this.selectedItems;
    modalRef.componentInstance.customerId = this.commonService.sessionDetails.customerId;

  }

  saveWheelParam(row) {
    if (this.selectedWheelParam === 'Select') {
      this.selectedWheelParam = row.wheelParameter;
    }
    const wheelParamPayload = {
      'wheelParameterLimits': [
        {
          'aarRoad': this.selectedAarRoad.aarRoad,
          'customerId': this.commonService.sessionDetails.customerId,
          'id': row.id || '',
          'lastUpdatedBy': this.commonService.sessionDetails.userid,
          'locoType': this.selectedItems,
          'lowerLimit': +row.lowerLimit,
          'upperLimit': +row.upperLimit,
          'wheelParameter': row.wheelParameter
        }
      ]
    };
    this.commonService.getWheelParameterLimits(wheelParamPayload).subscribe(res => {
      this.saveResponse = res;
      if (this.saveResponse.statusType.statusCode === 'SUCCESS') {
        this.utilService.success_snackbar('Parameter saved successfully.');
        row.rowDisabled = false;
      } else {
        this.successMessage = null;
      }
     });

     if(this.newParam === row.wheelParameter)
     {
       this.newParamFlag = false;
       this.filterParameter();
     }
  }

  filterParameter() {
    console.log('called');
    this.nonconfiguredParameter = [];
    this.wheelParamList.forEach((wheelParam)=>{
      var existNotification = this.rows.find(({wheelParameter}) => wheelParam.wheelAdminId === wheelParameter);
      if(!existNotification){
        this.nonconfiguredParameter.push(wheelParam);
      }
    });

  }

  selectOption(selectedWheelParam,row) {

    this.selectedWheelParam = row.selectedWheelParam;
    row.wheelParameter = row.selectedWheelParam;
    this.newParam=row.wheelParameter;
  }

  onKeyPress(event) {
    if(event.charCode == 45 || event.charCode == 43){
      return event.preventDefault();
    }
  }

  cleanData()
  {
    this.rows = [];
    this.filterParameter();
    this.searchdone = 0;
  }

}
