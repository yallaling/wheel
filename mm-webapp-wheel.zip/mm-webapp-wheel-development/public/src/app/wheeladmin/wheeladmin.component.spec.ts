import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { WheeladminComponent } from './wheeladmin.component';

describe('WheeladminComponent', () => {
  let component: WheeladminComponent;
  let fixture: ComponentFixture<WheeladminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
       FormsModule
      ],
      declarations: [ WheeladminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WheeladminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
