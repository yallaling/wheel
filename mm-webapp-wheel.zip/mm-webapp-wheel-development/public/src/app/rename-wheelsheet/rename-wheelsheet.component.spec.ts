import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RenameWheelsheetComponent } from './rename-wheelsheet.component';

describe('RenameWheelsheetComponent', () => {
  let component: RenameWheelsheetComponent;
  let fixture: ComponentFixture<RenameWheelsheetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RenameWheelsheetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RenameWheelsheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
