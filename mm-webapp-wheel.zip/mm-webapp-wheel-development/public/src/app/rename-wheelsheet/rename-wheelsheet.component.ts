import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-rename-wheelsheet',
  templateUrl: './rename-wheelsheet.component.html',
  styleUrls: ['./rename-wheelsheet.component.scss']
})
export class RenameWheelsheetComponent implements OnInit {

  @Input() oldwheelSheet: any;
  @Input() workorderResponse: any;
  wheelSheetName = '';

  constructor(public activeModal: NgbActiveModal,
    private commonService: CommonService,
    private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.wheelSheetName = this.oldwheelSheet.wheelSheetname;
  }

  renameWheelsheet() {
    let wheelSheetNameRequest = {
      "aarRoad": this.workorderResponse.workorder.aarRoad,
      "roadNumber": this.workorderResponse.workorder.roadNumber,
      "wheelSheetID": this.oldwheelSheet.wheelSheetID,
      "wheelSheetName": this.wheelSheetName,
      "workorderId": this.workorderResponse.workorder.workorderId
    }
    this.commonService.renameWheelsheet(wheelSheetNameRequest).subscribe(res => {
      if(res && res.statusType.statusCode == "SUCCESS" && res.validFileName == true) {
        console.log(res);
        this.snackBar.open('Wheelsheet name updated sucessfully.', 'X', {
          duration: 5000,
          horizontalPosition: 'center',
          verticalPosition : 'top',
          panelClass : ['success-snackbar']
        });
        const wheelSheetObj = {
          "wheelSheetName": this.wheelSheetName
        }
        this.activeModal.close(wheelSheetObj);
      } else {
        this.activeModal.dismiss();
        this.snackBar.open(res.statusType.message, 'X', {
          duration: 5000,
          horizontalPosition: 'center',
          verticalPosition : 'top',
          panelClass : ['failure-snackbar']
        });
      }
    });
  }

  closeModal() {
    this.activeModal.close();
  }

}
