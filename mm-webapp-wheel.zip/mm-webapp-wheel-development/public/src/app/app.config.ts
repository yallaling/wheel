import { InjectionToken } from '@angular/core';

export let APP_CONFIG = new InjectionToken<AppConfig>('app.config');

export class AppConfig {
    userDetailsApiUrl: string;
    getAarRoadUrl: string;
    getLocoTypeUrl: string;
    getWheelParameterByCustomerUrl: string;
    getWheelParameterLimitsUrl: string;
    getWheelParameterLimitUrl: string;
    deleteWheelParameterLimitUrl: string;
    historyWheelParameterLimitUrl: string;
    getWheelsheetFileDetails: string;
    saveWheelsheetData: string;
    getLocomotiveId: string;
    getMeasurements: string;
    pastWheelSheetData: string;
    past10Wheelsheet: string;
    getwheelsheetdataforwo: string;
    uploadfile: string;
    getDefectDetails: string;
    TASK_MENU_ID: number;
    OS_FLAG: string;
    RAIL_CONNECT: string;
    POST: string;
    getTdUserDetails: string;
    updateDefect: string;
    renameWheelsheet: string;
    diametercalculation: string;
  }

export const APP_DI_CONFIG: AppConfig = {
    userDetailsApiUrl: '/eservices2/wheel/app/api/userdetails',
    getAarRoadUrl: '/eservices2/wheel/app/api/getaarraod',
    getLocoTypeUrl: '/eservices2/wheel/app/api/getlocotype',
    getWheelParameterByCustomerUrl: '/eservices2/wheel/app/api/getwheelparameterbycustomer',
    getWheelParameterLimitsUrl: '/eservices2/wheel/app/api/getWheelparameterlimits',
    getWheelParameterLimitUrl: '/eservices2/wheel/app/api/getwheelparameterlimit',
    deleteWheelParameterLimitUrl: '/eservices2/wheel/app/api/deletewheelparameterlimit',
    historyWheelParameterLimitUrl: '/eservices2/wheel/app/api/historywheelparameterlimit',
    getWheelsheetFileDetails: '/eservices2/wheel/app/api/getWheelsheetFileDetails',
    getLocomotiveId: '/eservices2/wheel/app/api/getLocomotiveId',
    getMeasurements: '/eservices2/wheel/app/api/getMeasurements',
    saveWheelsheetData: '/eservices2/wheel/app/api/saveWheelsheet',
    pastWheelSheetData: '/eservices2/wheel/app/api/pastWheelsheet',
    past10Wheelsheet: '/eservices2/wheel/app/api/past10Wheelsheet',
    getwheelsheetdataforwo: '/eservices2/wheel/app/api/getwheelsheetdataforwo',
    uploadfile: '/eservices2/wheel/app/api/uploadfile',
    getDefectDetails: '/eservices2/wheel/app/api/getDefectDetails',
    renameWheelsheet: '/eservices2/wheel/app/api/renameWheelsheet',
    TASK_MENU_ID: 1044,
    OS_FLAG: 'OS',
    RAIL_CONNECT: 'RailConnect.do',
    POST: 'post',
    getTdUserDetails: '/eservices2/wheel/app/api/getTdUserDetails',
    updateDefect: '/eservices2/wheel/app/api/updateDefect',
    diametercalculation: '/eservices2/wheel/app/api/diametercalculation'
  };
