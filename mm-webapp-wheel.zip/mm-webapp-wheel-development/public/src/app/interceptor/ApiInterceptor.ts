import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import {Spinner} from 'spin.js';

@Injectable()
export class ApiInterceptor implements HttpInterceptor {

    options = {
        lines: 12,
        length: 20,
        width: 8,
        radius: 20,
        corners: 0.5,
        rotate: 0,
        direction: 1,
        color: '#3b73b9',
        speed: 1,
        trail: 64,
        shadow: true,
        hwaccel: false,
        className: 'spinner',
        zIndex: 2000000000,
        top: '50%',
        left: '50%'
    };

    spinner: any;
    constructor() { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        this.startSpinner();
        return next.handle(req).pipe(finalize(() => this.stopSpinner()));
    }

    startSpinner() {
        const target = document.getElementById('spin-area');
        const parentBody = parent.document.body;
        const parentDocument = parent.document;
        const newdiv = parentDocument.createElement('DIV');
        newdiv.style.backgroundColor = '#000000';
        newdiv.style.opacity = '0.6';
        newdiv.style.width = '100%';
        newdiv.style.height = '100%';
        newdiv.style.position = 'fixed';
        newdiv.style.top = '0px';
        newdiv.style.left = '0px';
        newdiv.style.zIndex = '200000000';
        newdiv.classList.add('loadingShadow');

        parentBody.appendChild(newdiv);
        parentBody.style.overflow = 'hidden';

        this.spinner = new Spinner(this.options);
        this.spinner.spin(target);
    }

    stopSpinner() {
        const parentBody = parent.document.body;
        const parentDocument = parent.document;
        if (parentBody.getElementsByClassName('loadingShadow').length > 0) {
            for (let i = 0 ; i < parentBody.getElementsByClassName('loadingShadow').length; i++) {
                parentBody.removeChild(parentBody.getElementsByClassName('loadingShadow')[i]);
            }
        }
        document.getElementById('spin-area').removeChild(document.getElementsByClassName('spinner')[0]);
        parentBody.style.overflow = 'visible';
    }
}
