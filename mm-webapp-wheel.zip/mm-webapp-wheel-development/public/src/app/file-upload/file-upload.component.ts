import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { TranslateService } from '@ngx-translate/core';
import { ActivatedRoute, Router } from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';
import{UtilService} from '../core/utils/util.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

   constructor(
    private commonService: CommonService,
    private activeRoute: ActivatedRoute,
    private snackBar: MatSnackBar,
    private router: Router, private translate: TranslateService,
    private utilService:UtilService) {
      

 }
 //files: any = [];
 filetoupload: any = [];

ngOnInit() {

}

  uploadFile(event) {
    let notaxml = false;
    if (event.length <= 10) {
    for (let index = 0; index < event.length; index++) {
      const element = event[index];
      if (element.name.includes('.xml')) {
          this.filetoupload.push(element);
      } else if (event.length === 1) {
        notaxml = true;
      }
  }
    if (notaxml === true) {
      this.utilService.failure_snackbar('Invalid file type.');
    
    }
    this.uploadOneFile();
  } else {
    this.utilService.failure_snackbar('Maximum 10 file allowed to upload.');
   
    this.filetoupload = [];
  }
  }
   uploadOneFile() {
     let sucessfiles = 0;
     let filecount = 0;
     for (let index = 0; index < this.filetoupload.length; index++) {
      const formData = new FormData();
       formData.append('file', this.filetoupload[index], this.filetoupload[index].name);
       this.commonService.uploadfile(formData).subscribe(res => {
      console.log(res);
      filecount = filecount + 1;
       if (res.statusType.message.includes('processing')) {
          sucessfiles = sucessfiles + 1;
        }
          if (filecount === this.filetoupload.length) {
            this.printMessage(sucessfiles, filecount);
          }
    });
     }

     // this.files = [];
  }
  printMessage(sucessfiles, filecount) {
    if ( filecount === this.filetoupload.length) {
      let message=sucessfiles + ' out of ' + this.filetoupload.length + ' file(s) uploaded sucessfully.';
      this.utilService.success_snackbar(message);
    
     }
     this.filetoupload = [];
  }
}

