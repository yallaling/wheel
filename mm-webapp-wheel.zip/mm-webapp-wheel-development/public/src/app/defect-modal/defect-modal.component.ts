import { Component, OnInit, Input, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from '../core/common/common.service';

@Component({
  selector: 'app-defect-modal',
  templateUrl: './defect-modal.component.html',
  styleUrls: ['./defect-modal.component.scss']
})
export class DefectModalComponent implements OnInit {

  actionsTaken: string = '';
  isComplete: boolean;
  @Input() defectDetails: any;
  @Input() workorderResponse: any;
  @Input() enableAddWheelsheet: any;

  constructor(public activeModal: NgbActiveModal,
    private commonService: CommonService) { }

  ngOnInit() {
    console.log(this.defectDetails);
    if(this.defectDetails.completeDefect == 'Y') {
      this.isComplete = true;
    } else {
      this.isComplete = false;
    }
    this.actionsTaken = this.defectDetails.actionComments
  }

  toggleComplete(event) {
    if ( event.target.checked ) {
      this.isComplete = true;
    } else {
      this.isComplete = false;
    }
  }

  saveDefect() {
    let defectPayload = {};
    if(this.isComplete) {
      defectPayload = {
        "id": this.defectDetails.defectId,
        "status": "COMPLETED",
        "description": this.defectDetails.defectComments,
        "actions": [
          {
            "description": this.actionsTaken
          }
        ],
        "causeCode": null,
        "remedyCode": null,
        "timeCard": null,
        "signOffList": [
          {
            "loginId": this.commonService.sessionDetails.ssoId,
            "workOrderId": this.commonService.sessionDetails.workorderid,
            "sourceType": "DEFECT"
          }
        ],
        "userAction": "EDIT"
      }
    } else {
      defectPayload = {
        "id": this.defectDetails.defectId,
        "status": "OPEN",
        "description": this.defectDetails.defectComments,
        "actions": [
          {
            "description": this.actionsTaken
          }
        ],
        "causeCode": null,
        "remedyCode": null,
        "timeCard": null,
        "signOffList": [],
        "userAction": "EDIT"
      }
    }

    let defectDetailsHeaders =  {
      "customerId": this.workorderResponse.workorder.customerId,
      "roadnumber": this.workorderResponse.workorder.roadNumber,
      "UserId": this.commonService.sessionDetails.userid.toString(),
      "UserLoginId": this.commonService.sessionDetails.ssoId,
      "serviceorgId": this.commonService.sessionDetails.organizationid.toString(),
      "UserLangCode": this.commonService.sessionDetails.locale,
      "UserTimeZone": 'EST',
      "workorderid": this.workorderResponse.workorder.workorderId.toString(),
      "workshift": '2',
      "Content-Type": "application/json",
      "defectId": this.defectDetails.defectId
    }
    this.commonService.updateDefect(defectDetailsHeaders,defectPayload).subscribe(res => {
      if(res) {
        console.log(res);
        this.activeModal.close();
      }
    });  
  }

}
