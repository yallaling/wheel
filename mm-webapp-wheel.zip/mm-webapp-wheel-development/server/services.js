const config = require('nconf');
const request = require('request');
var fs  = require('fs');
const service = {};

module.exports = service;
service.getaarroad = function(custid,callback){
  const getaarroadURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getaarroad+'/'+custid;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": getaarroadURL,
      "method": "GET",
      "headers": {
          "Content-Type": "application/json",
      },
      "auth": auth
  };
  console.log("Get check get locations URL:", getaarroadURL);
  request(requestOption, function(err, response, body){

      if(!err && response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while getting locations", getlocationsURL, err, response.statusCode, body);
      callback(err);
  });
}
service.getlocotype = function(reportAttr,callback){
  const getlocotypeURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getlocotype;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": getlocotypeURL,
      "method": "POST",
      "headers": {
          "Content-Type": "application/json"
      },
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check add to cart URL:", getlocotypeURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
      callback(err);
  });
}
service.getwheelparameterbycustomer = function(reportAttr,callback){
  const getwheelparameterURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getwheelparameterbycustomer;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": getwheelparameterURL,
      "method": "POST",
      "headers": {
          "Content-Type": "application/json"
      },
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check add to cart URL:", getwheelparameterURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
      callback(err);
  });
}

  service.getwheelparameterlimits = function(reportAttr,callback){
    const getwheelparameterURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getWheelparameterlimits;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

    const requestOption = {
        "url": getwheelparameterURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get wheel param URL:", getwheelparameterURL);
    request(requestOption, function(err, response, body){
        console.log("Wheel Param request:", body);
        if(!err &&  response.statusCode == 200){
            console.log("Wheel Param Response:", body);
            return callback(null, body);
        }
        //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
        callback(err);
    });
}

service.getwheelparameterlimit = function(reportAttr,callback){
  const getwheelparameterlimitURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getwheelparameterlimit;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": getwheelparameterlimitURL,
      "method": "POST",
      "headers": {
          "Content-Type": "application/json"
      },
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check add to cart URL:", getwheelparameterlimitURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
      callback(err);
  });
}
service.deletewheelparameterlimit = function(reportAttr,callback){
  const deletewheelparameterlimitURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').deleteWheelparameterlimit;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": deletewheelparameterlimitURL,
      "method": "POST",
      "headers": {
          "Content-Type": "application/json"
      },
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check add to cart URL:", deletewheelparameterlimitURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
      callback(err);
  });
}
service.historywheelparameterlimit = function(reportAttr,callback){
  const historywheelparameterlimitURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').historywheelparameterlimit;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};

  const requestOption = {
      "url": historywheelparameterlimitURL,
      "method": "POST",
      "headers": {
          "Content-Type": "application/json"
      },
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check get history URL:", historywheelparameterlimitURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      //console.log("Error getting while adding to cart", addtocartURL, err, response.statusCode, body);
      callback(err);
  });
}
service.getWheelsheetFileDetails = function(reportAttr,callback){
    const getWheelsheetFileDetailsURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getWheelsheetFileDetails;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": getWheelsheetFileDetailsURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check get history URL:", getWheelsheetFileDetailsURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }
  service.getLocomotiveId = function(serviceWorkorderId,callback){
    const getLocomotiveIdURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getLocomotiveId+"?serviceWorkorderId="+serviceWorkorderId;
    //const getLocomotiveIdURL = "https://eservices-dev-api.cloud.trans.ge.com/workorder/services/v1/wo/workOrderDetailsByServiceWoId?"+"serviceWorkorderId="+serviceWorkorderId;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log("getLocomotiveIdURL", getLocomotiveIdURL);
    const requestOption = {
        "url": getLocomotiveIdURL,
        "method": "GET",
        "headers": {
            "Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("Get check get history URL:", getLocomotiveIdURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }
  service.getMeasurements = function(reportAttr,callback){
    const getMeasurementsURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getMeasurements;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": getMeasurementsURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check getMeasurementsURL:", getMeasurementsURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.saveWheelsheet = function(reportAttr,callback){
    const saveWheelsheetURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').saveWheelsheet;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": saveWheelsheetURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check saveWheelsheetURL:", saveWheelsheetURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.pastWheelsheet = function(reportAttr,callback){
    const pastWheelsheetURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').pastWheelSheetDropdown;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": pastWheelsheetURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check pastWheelsheetURL:", pastWheelsheetURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.past10Wheelsheet = function(reportAttr,callback){
    const past10WheelsheetURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').past10WheelSheetDropdown;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": past10WheelsheetURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check past10WheelsheetURL:", past10WheelsheetURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.getwheelsheetdataforwo = function(reportAttr,callback){
    const getwheelsheetdataforwoURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getwheelsheetdataforwo;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": getwheelsheetdataforwoURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check getwheelsheetdataforwoURL:", getwheelsheetdataforwoURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.fileupload = function(originalname,folderpath,callback){
    const fileuploadURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').fileupload;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
  var path=folderpath+originalname;
   console.log("path"+path);
    const options = {
    method: "POST",
    url: fileuploadURL,
    auth:auth,
    headers: {
        "Content-Type": "multipart/form-data"
    },
    formData : {
        "file" : fs.createReadStream(path)
    }
};

request(options, function (err, response, body) {
    if(!err &&  response.statusCode == 200){
      fs.unlink(path, (err) => {
       if (err) throw err;
         console.log('successfully deleted');
        });
            return callback(null, body);
        }
        callback(err);
});
  }
  service.getDefectDetails = function(serviceWorkorderId,defectId,callback){
    const getDefectDetailsURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getDefectDetails+"?defectId="+defectId+"&defectType="+"&woNumber="+serviceWorkorderId;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log("getDefectDetailsURL", getDefectDetailsURL);
    const requestOption = {
        "url": getDefectDetailsURL,
        "method": "GET",
        "headers": {
            "Content-Type": "application/json"
        },
        "auth": auth
    };
    console.log("Get check get getDefectDetailsURL:", getDefectDetailsURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }

  service.getTdUserDetails = function(userid,headers,callback){
    console.log("defect headers",headers);
    let headersData = JSON.parse(headers);

    let tdDetailsHeaders =  {
      "customerId": headersData.customerid,
      "roadnumber": headersData.roadnumber,
      "User-Id": headersData.userid,
      "User-LoginId": headersData.userloginid,
      "serviceorgid": headersData.serviceorgid,
      "User-LangCode": headersData.userlangcode,
      "User-TimeZone": headersData.usertimezone,
      "workorderid": headersData.workorderid,
      "Content-Type": "application/json"
    }
    console.log("defect headers",tdDetailsHeaders);
  const getTdUserDetailsURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').getTdUserDetails+"?User-Id="+userid;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
  console.log("getDefectDetailsURL", getTdUserDetailsURL);
  const requestOption = {
      "url": getTdUserDetailsURL,
      "method": "GET",
      "headers": tdDetailsHeaders,
      "auth": auth
  };
  console.log("Get check get getTdUserDetailsURL:", getTdUserDetailsURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      callback(err);
  });
}

service.updateDefect = function(reportAttr,defectid,headers,callback){
    console.log("defect headers",headers);
    let headersData = JSON.parse(headers);

    let defectHeaders =  {
      "customerId": headersData.customerid,
      "roadnumber": headersData.roadnumber,
      "User-Id": headersData.userid,
      "User-LoginId": headersData.userloginid,
      "serviceorgid": headersData.serviceorgid,
      "User-LangCode": headersData.userlangcode,
      "User-TimeZone": headersData.usertimezone,
      "workorderid": headersData.workorderid,
      "Content-Type": "application/json"
    }
    console.log("defect headers",defectHeaders);
  const updateDefectURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').updateDefect+defectid;
  const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
  console.log("getDefectDetailsURL", updateDefectURL);
  const requestOption = {
      "url": updateDefectURL,
      "method": "POST",
      "headers": defectHeaders,
      "body": JSON.stringify(reportAttr),
      "auth": auth
  };
  console.log("Get check get updateDefectURL:", updateDefectURL);
  request(requestOption, function(err, response, body){
      if(!err &&  response.statusCode == 200){
          return callback(null, body);
      }
      callback(err);
  });
}
service.renameWheelsheet = function(reportAttr,callback){
    const renameWheelsheetURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').renameWheelsheet;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": renameWheelsheetURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check renameWheelsheetURL:", renameWheelsheetURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }
  service.diametercalculation = function(reportAttr,callback){
    const diametercalculationURL = config.get('MM_API_BASE_URL') + config.get('API_ENDPOINTS').diametercalculation;
    const auth = {'user': config.get('MM_API_BASIC_AUTH_USER'), 'pass': config.get('MM_API_BASIC_AUTH_CRED')};
    console.log(JSON.stringify(reportAttr));
    const requestOption = {
        "url": diametercalculationURL,
        "method": "POST",
        "headers": {
            "Content-Type": "application/json"
        },
        "body": JSON.stringify(reportAttr),
        "auth": auth
    };
    console.log("Get check diametercalculationURL:", diametercalculationURL);
    request(requestOption, function(err, response, body){
        if(!err &&  response.statusCode == 200){
            return callback(null, body);
        }
        callback(err);
    });
  }