var npm = require('npm-install-global');
const express = require('express');
const router = express.Router();
const services = require('./services');
const defaultConfig = require('./config');
const bodyParser = require("body-parser");
var multer = require("multer");
var folderpath='server/uploads/';
var multipartUpload = multer({storage: multer.diskStorage({
    destination: function (req, file, callback) { callback(null, folderpath);},
    filename: function (req, file, callback) { callback(null, file.originalname);}})
}).single('file');
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: true }));
router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
router.post("/uploadfile", multipartUpload, function(req, res) {
  services.fileupload(req.file.originalname,folderpath,function(err, getResponse){
     if (err) {
         console.log('getResponse', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
 
});

router.get('/userdetails', function(req, res){
    if (req.user === null) return;
    req.user.user.clientUrl = defaultConfig.ESONE_BASE_URL;
    res.send(req.user);
});


router.get('/getaarraod', function(req, res){
    var custid = req.query.custid;
    console.log(custid);
  services.getaarroad(custid,function(err, getResponse){
      if (err) {
          console.log('getResponse', err);
          return res.status(500).json({"error": err});
      } else {
          res.send(getResponse);
      }
  });
});
router.post('/getlocotype', function(req, res){
   const reportAttr = req.body;
  console.log(reportAttr);
  services.getlocotype(reportAttr,function(err, getResponse){
      if (err) {
          console.log('getResponse', err);
          return res.status(500).json({"error": err});
      } else {
          res.send(getResponse);
      }
  });
});
router.post('/getwheelparameterbycustomer', function(req, res){
  const reportAttr = req.body;
 console.log(reportAttr);
 services.getwheelparameterbycustomer(reportAttr,function(err, getResponse){
     if (err) {
         console.log('getResponse', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
});
 router.post('/getwheelparameterlimits', function(req, res){
    const reportAttr = req.body;
   console.log(reportAttr);
   services.getwheelparameterlimits(reportAttr,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});
router.post('/getwheelparameterlimit', function(req, res){
  const reportAttr = req.body;
 console.log(reportAttr);
 services.getwheelparameterlimit(reportAttr,function(err, getResponse){
     if (err) {
         console.log('getResponse', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
});
router.post('/deletewheelparameterlimit', function(req, res){
  const reportAttr = req.body;
 console.log(reportAttr);
 services.deletewheelparameterlimit(reportAttr,function(err, getResponse){
     if (err) {
         console.log('getResponse', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
});
router.post('/historywheelparameterlimit', function(req, res){
  const reportAttr = req.body;
 console.log(reportAttr);
 services.historywheelparameterlimit(reportAttr,function(err, getResponse){
     if (err) {
         console.log('getResponse', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
});
router.post('/getWheelsheetFileDetails', function(req, res){
    const locomotiveId = req.body;
   console.log("getWheelsheetFileDetails",locomotiveId);
   services.getWheelsheetFileDetails(locomotiveId,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});
router.get('/getLocomotiveId', function(req, res){
    const serviceWorkorderId = req.query.woId;
   console.log("getWheelsheetFileDetails",serviceWorkorderId);
   services.getLocomotiveId(serviceWorkorderId,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});
router.post('/getMeasurements', function(req, res){
    const fileDetail = req.body;
   console.log("getMeasurements",fileDetail);
   services.getMeasurements(fileDetail,function(err, getResponse){
       if (err) {
           console.log('getMeasurements', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});

router.post('/saveWheelsheet', function(req, res){
  const wheelsheet = req.body;
 console.log("wheelsheet",wheelsheet);
 services.saveWheelsheet(wheelsheet,function(err, getResponse){
     if (err) {
         console.log('wheelsheet', err);
         return res.status(500).json({"error": err});
     } else {
         res.send(getResponse);
     }
 });
});

router.post('/pastWheelsheet', function(req, res){
    const wheelsheet = req.body;
   console.log("pastwheelsheet",wheelsheet);
   services.pastWheelsheet(wheelsheet,function(err, getResponse){
       if (err) {
           console.log('wheelsheet', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
  });

  router.post('/past10Wheelsheet', function(req, res){
    const wheelsheet = req.body;
   console.log("past10wheelsheet",wheelsheet);
   services.past10Wheelsheet(wheelsheet,function(err, getResponse){
       if (err) {
           console.log('wheelsheet', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
  });

  router.post('/getwheelsheetdataforwo', function(req, res){
    const wheelsheet = req.body;
   console.log("getwheelsheetdataforwo",wheelsheet);
   services.getwheelsheetdataforwo(wheelsheet,function(err, getResponse){
       if (err) {
           console.log('wheelsheet', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
  });

  router.get('/getDefectDetails', function(req, res){
    const serviceWorkorderId = req.query.woId;
    const defectId = req.query.defectId;
   console.log("getWheelsheetFileDetails",serviceWorkorderId,defectId);
   services.getDefectDetails(serviceWorkorderId,defectId,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});

router.get('/getTdUserDetails', function(req, res){
    const userid = req.query.userid;
    let headers = JSON.stringify(req.headers);
    console.log("defect headers",headers);
   console.log("getWheelsheetFileDetails",userid);
   services.getTdUserDetails(userid,headers,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});

router.post('/updateDefect', function(req, res){
    const defectId = req.query.defectId;
    const reportAttr = req.body;
    let headers = JSON.stringify(req.headers);
    console.log("defect headers",headers);
   console.log("updateDefect",defectId);
   services.updateDefect(reportAttr,defectId,headers,function(err, getResponse){
       if (err) {
           console.log('getResponse', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
});
router.post('/renameWheelsheet', function(req, res){
    const renamePayload = req.body;
   console.log("renameWheelsheet",renamePayload);
   services.renameWheelsheet(renamePayload,function(err, getResponse){
       if (err) {
           console.log('renameWheelsheet', err);
           return res.status(500).json({"error": err});
       } else {
           console.log('renameWheelsheet', getResponse);
           res.send(getResponse);
       }
   });
  });
  router.post('/diametercalculation', function(req, res){
    const wheelsheet = req.body;
   console.log("wheelsheet",wheelsheet);
   services.diametercalculation(wheelsheet,function(err, getResponse){
       if (err) {
           console.log('wheelsheet', err);
           return res.status(500).json({"error": err});
       } else {
           res.send(getResponse);
       }
   });
  });
module.exports = router;
