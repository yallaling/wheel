0.3.0 / 2013-07-05
==================
* Migrate off require-jquery


