package models;

import java.util.List;

public class ServiceSheetDTO {

	private Long Id;
	private Long workOrderId;
	private String title; 
	private List<String> qualityPlans;
	private List<String> Task;
	private Long totalTasks;
	private Long remainingTasks;
	private String status;
	private String qualityPlanType;
	private String serviceTypeCode;
	private Long wheelSheetCount;
	private String b2benabledFlag;
	private String customerName;
	private String roadNumber;
	private Long serviceItemId;
	private String serviceItem;
	private String boundType;
	private boolean requestMaterial;
	
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Long getWorkOrderId() {
		return workOrderId;
	}
	public void setWorkOrderId(Long workOrderId) {
		this.workOrderId = workOrderId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<String> getQualityPlans() {
		return qualityPlans;
	}
	public void setQualityPlans(List<String> qualityPlans) {
		this.qualityPlans = qualityPlans;
	}
	public List<String> getTask() {
		return Task;
	}
	public void setTask(List<String> task) {
		Task = task;
	}
	
		
	public Long getTotalTasks() {
		return totalTasks;
	}
	public void setTotalTasks(Long totalTasks) {
		this.totalTasks = totalTasks;
	}
	public Long getRemainingTasks() {
		return remainingTasks;
	}
	public void setRemainingTasks(Long remainingTasks) {
		this.remainingTasks = remainingTasks;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getQualityPlanType() {
		return qualityPlanType;
	}
	public void setQualityPlanType(String qualityPlanType) {
		this.qualityPlanType = qualityPlanType;
	}
	public String getServiceTypeCode() {
		return serviceTypeCode;
	}
	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
	public Long getWheelSheetCount() {
		return wheelSheetCount;
	}
	public void setWheelSheetCount(Long wheelSheetCount) {
		this.wheelSheetCount = wheelSheetCount;
	}
	public String getB2benabledFlag() {
		return b2benabledFlag;
	}
	public void setB2benabledFlag(String b2benabledFlag) {
		this.b2benabledFlag = b2benabledFlag;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	public Long getServiceItemId() {
		return serviceItemId;
	}
	public void setServiceItemId(Long serviceItemId) {
		this.serviceItemId = serviceItemId;
	}
	public String getServiceItem() {
		return serviceItem;
	}
	public void setServiceItem(String serviceItem) {
		this.serviceItem = serviceItem;
	}
	public String getBoundType() {
		return boundType;
	}
	public void setBoundType(String boundType) {
		this.boundType = boundType;
	}
	public boolean isRequestMaterial() {
		return requestMaterial;
	}
	public void setRequestMaterial(boolean requestMaterial) {
		this.requestMaterial = requestMaterial;
	}
	
	
}
