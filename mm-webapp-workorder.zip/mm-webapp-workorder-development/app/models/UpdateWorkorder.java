package models;

public class UpdateWorkorder {

	public String workorderId;
	public String workorderStatus;
	public String reasonCode;
	public String inshopReason;
	public Long UpdatedBy;
	
	public String getWorkorderId() {
		return workorderId;
	}
	public void setWorkorderId(String workorderId) {
		this.workorderId = workorderId;
	}
	public String getWorkorderStatus() {
		return workorderStatus;
	}
	public void setWorkorderStatus(String workorderStatus) {
		this.workorderStatus = workorderStatus;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getInshopReason() {
		return inshopReason;
	}
	public void setInshopReason(String inshopReason) {
		this.inshopReason = inshopReason;
	}
	public Long getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(Long updatedBy) {
		UpdatedBy = updatedBy;
	}
	
}
