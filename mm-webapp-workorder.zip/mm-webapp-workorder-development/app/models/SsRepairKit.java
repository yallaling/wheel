/**
 * 
 */
package models;

/**
 * @author 212462885
 *
 */
public class SsRepairKit {

	private Long serviceSheetId;
	private long bomId;
	private String bomName;
	private PcFmiItems pcFmiItems;
    
	public Long getServiceSheetId() {
		return serviceSheetId;
	}
	public void setServiceSheetId(Long serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
	public long getBomId() {
		return bomId;
	}
	public void setBomId(long bomId) {
		this.bomId = bomId;
	}
	public String getBomName() {
		return bomName;
	}
	public void setBomName(String bomName) {
		this.bomName = bomName;
	}
    public PcFmiItems getPcFmiItems() {
        return pcFmiItems;
    }
    public void setPcFmiItems(PcFmiItems pcFmiItems) {
        this.pcFmiItems = pcFmiItems;
    }
  
    
}
