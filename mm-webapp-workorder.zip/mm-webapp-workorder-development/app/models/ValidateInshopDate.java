package models;

/**
 * @author 212462885
 *
 */
public class ValidateInshopDate {
 private String locomotiveId;
 private String customerId;
 private String inshopDate;
 
public String getLocomotiveId() {
	return locomotiveId;
}
public void setLocomotiveId(String locomotiveId) {
	this.locomotiveId = locomotiveId;
}
public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getInshopDate() {
	return inshopDate;
}
public void setInshopDate(String inshopDate) {
	this.inshopDate = inshopDate;
}
}
