package models;

public class ServiceSheetForm {
	
	private String serviceTypeCode;
	private String workorderStatus;
	private String serviceSheetStatusCode;
	private String statusDesc;
	private String programName;
	private String serviceSheetComments;
	private Long serviceSheetId;
	private Long serviceProgramId;
	private Long serviceWorkorderId;
	private Long serviceItemId;
	private String scheduledDate;
	private String scheduledOverrideFlag;
	private String lastPerformedDate;
	private Long fmiId;
	private String fmiFlag;
	private String scheduledMaintenanceFlag;
	private String autoAttachFlag;
	private String fmiMandatoryFlag;
	private String customerName;
	private String dueFlag;
	private String materialFlag;
	private String lastUpdateDate;
	private Long lastUpdatedBy;
	private String locale;
	private String removalModalFlag;
	private String removalReasonCode;
	private String removalReasonComments;
	private String spOrgApplicableFlag;
	
	
	
	public String getServiceTypeCode() {
		return serviceTypeCode;
	}
	public void setServiceTypeCode(String serviceTypeCode) {
		this.serviceTypeCode = serviceTypeCode;
	}
	public String getWorkorderStatus() {
		return workorderStatus;
	}
	public void setWorkorderStatus(String workorderStatus) {
		this.workorderStatus = workorderStatus;
	}
	public String getServiceSheetStatusCode() {
		return serviceSheetStatusCode;
	}
	public void setServiceSheetStatusCode(String serviceSheetStatusCode) {
		this.serviceSheetStatusCode = serviceSheetStatusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getServiceSheetComments() {
		return serviceSheetComments;
	}
	public void setServiceSheetComments(String serviceSheetComments) {
		this.serviceSheetComments = serviceSheetComments;
	}
	public Long getServiceSheetId() {
		return serviceSheetId;
	}
	public void setServiceSheetId(Long serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
	public Long getServiceProgramId() {
		return serviceProgramId;
	}
	public void setServiceProgramId(Long serviceProgramId) {
		this.serviceProgramId = serviceProgramId;
	}
	public Long getServiceWorkorderId() {
		return serviceWorkorderId;
	}
	public void setServiceWorkorderId(Long serviceWorkorderId) {
		this.serviceWorkorderId = serviceWorkorderId;
	}
	public Long getServiceItemId() {
		return serviceItemId;
	}
	public void setServiceItemId(Long serviceItemId) {
		this.serviceItemId = serviceItemId;
	}
	public String getScheduledDate() {
		return scheduledDate;
	}
	public void setScheduledDate(String scheduledDate) {
		this.scheduledDate = scheduledDate;
	}
	public String getScheduledOverrideFlag() {
		return scheduledOverrideFlag;
	}
	public void setScheduledOverrideFlag(String scheduledOverrideFlag) {
		this.scheduledOverrideFlag = scheduledOverrideFlag;
	}
	public String getLastPerformedDate() {
		return lastPerformedDate;
	}
	public void setLastPerformedDate(String lastPerformedDate) {
		this.lastPerformedDate = lastPerformedDate;
	}
	public Long getFmiId() {
		return fmiId;
	}
	public void setFmiId(Long fmiId) {
		this.fmiId = fmiId;
	}
	public String getFmiFlag() {
		return fmiFlag;
	}
	public void setFmiFlag(String fmiFlag) {
		this.fmiFlag = fmiFlag;
	}
	public String getScheduledMaintenanceFlag() {
		return scheduledMaintenanceFlag;
	}
	public void setScheduledMaintenanceFlag(String scheduledMaintenanceFlag) {
		this.scheduledMaintenanceFlag = scheduledMaintenanceFlag;
	}
	public String getAutoAttachFlag() {
		return autoAttachFlag;
	}
	public void setAutoAttachFlag(String autoAttachFlag) {
		this.autoAttachFlag = autoAttachFlag;
	}
	public String getFmiMandatoryFlag() {
		return fmiMandatoryFlag;
	}
	public void setFmiMandatoryFlag(String fmiMandatoryFlag) {
		this.fmiMandatoryFlag = fmiMandatoryFlag;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getDueFlag() {
		return dueFlag;
	}
	public void setDueFlag(String dueFlag) {
		this.dueFlag = dueFlag;
	}
	public String getMaterialFlag() {
		return materialFlag;
	}
	public void setMaterialFlag(String materialFlag) {
		this.materialFlag = materialFlag;
	}
	public String getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	public Long getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(Long lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getRemovalModalFlag() {
		return removalModalFlag;
	}
	public void setRemovalModalFlag(String removalModalFlag) {
		this.removalModalFlag = removalModalFlag;
	}
	public String getRemovalReasonCode() {
		return removalReasonCode;
	}
	public void setRemovalReasonCode(String removalReasonCode) {
		this.removalReasonCode = removalReasonCode;
	}
	public String getRemovalReasonComments() {
		return removalReasonComments;
	}
	public void setRemovalReasonComments(String removalReasonComments) {
		this.removalReasonComments = removalReasonComments;
	}
	public String getSpOrgApplicableFlag() {
		return spOrgApplicableFlag;
	}
	public void setSpOrgApplicableFlag(String spOrgApplicableFlag) {
		this.spOrgApplicableFlag = spOrgApplicableFlag;
	}	

}
