/**
 * 
 */
package models;

import java.util.List;

/**
 * @author 212462885
 *
 */
public class AddRepairKitRequest {

	private String locomotiveId;
	private String customerId;
	private String orgId;
	private String workorderId;
	private String locale;
	private String userId;
	private String ssoId;
	private List<SsRepairKit> ssRepairKit;
	private String requestedStatus;
	private String serviceSheetId;
	
	public String getLocomotiveId() {
		return locomotiveId;
	}
	public void setLocomotiveId(String locomotiveId) {
		this.locomotiveId = locomotiveId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getWorkorderId() {
		return workorderId;
	}
	public void setWorkorderId(String workorderId) {
		this.workorderId = workorderId;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRequestedStatus() {
		return requestedStatus;
	}
	public void setRequestedStatus(String requestedStatus) {
		this.requestedStatus = requestedStatus;
	}
	public List<SsRepairKit> getSsRepairKit() {
		return ssRepairKit;
	}
	public void setSsRepairKit(List<SsRepairKit> ssRepairKit) {
		this.ssRepairKit = ssRepairKit;
	}
	public String getSsoId() {
		return ssoId;
	}
	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}
	public String getServiceSheetId() {
		return serviceSheetId;
	}
	public void setServiceSheetId(String serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
}
