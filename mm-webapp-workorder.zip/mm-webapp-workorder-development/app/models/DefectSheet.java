package models;

import java.util.List;

public class DefectSheet {
	
	private String  serviceWorkorderId;
	private String  defectId;
	private String 	defectComments;
	private String 	workorderNumber;
	private String 	createdBy;
	private String 	updatedBy;
	private String	actionComments;
	private String	completeDefect;
	private String causeCode;
	private String remedyCode;
	private String defectOriginType;
	private String customerId;
	private String showOnShopSummary;
	private String updateForShopSumm;
	private List<DefectAttachment> defectAttachments;
	
   	
	public String getServiceWorkorderId() {
		return serviceWorkorderId;
	}
	public void setServiceWorkorderId(String serviceWorkorderId) {
		this.serviceWorkorderId = serviceWorkorderId;
	}
	public String getDefectComments() {
		return defectComments;
	}
	public void setDefectComments(String defectComments) {
		this.defectComments = defectComments;
	}
	public String getWorkorderNumber() {
		return workorderNumber;
	}
	public void setWorkorderNumber(String workorderNumber) {
		this.workorderNumber = workorderNumber;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getDefectId() {
		return defectId;
	}
	public void setDefectId(String defectId) {
		this.defectId = defectId;
	}
	public String getActionComments() {
		return actionComments;
	}
	public void setActionComments(String actionComments) {
		this.actionComments = actionComments;
	}
	public String getCompleteDefect() {
		return completeDefect;
	}
	public void setCompleteDefect(String completeDefect) {
		this.completeDefect = completeDefect;
	}
	public String getCauseCode() {
		return causeCode;
	}
	public void setCauseCode(String causeCode) {
		this.causeCode = causeCode;
	}
	public String getRemedyCode() {
		return remedyCode;
	}
	public void setRemedyCode(String remedyCode) {
		this.remedyCode = remedyCode;
	}
	public String getDefectOriginType() {
		return defectOriginType;
	}
	public void setDefectOriginType(String defectOriginType) {
		this.defectOriginType = defectOriginType;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getShowOnShopSummary() {
		return showOnShopSummary;
	}
	public void setShowOnShopSummary(String showOnShopSummary) {
		this.showOnShopSummary = showOnShopSummary;
	}
	public String getUpdateForShopSumm() {
		return updateForShopSumm;
	}
	public void setUpdateForShopSumm(String updateForShopSumm) {
		this.updateForShopSumm = updateForShopSumm;
	}
	public List<DefectAttachment> getDefectAttachments() {
		return defectAttachments;
	}
	public void setDefectAttachments(List<DefectAttachment> defectAttachments) {
		this.defectAttachments = defectAttachments;
	}

	
	
	

}
