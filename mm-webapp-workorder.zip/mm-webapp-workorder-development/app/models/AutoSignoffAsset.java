package models;


public class AutoSignoffAsset {

    public Long locomotiveId;
    public String locomotiveTypeCode;
	public Long getLocomotiveId() {
		return locomotiveId;
	}
	public void setLocomotiveId(Long locomotiveId) {
		this.locomotiveId = locomotiveId;
	}
	public String getLocomotiveTypeCode() {
		return locomotiveTypeCode;
	}
	public void setLocomotiveTypeCode(String locomotiveTypeCode) {
		this.locomotiveTypeCode = locomotiveTypeCode;
	}	
}
