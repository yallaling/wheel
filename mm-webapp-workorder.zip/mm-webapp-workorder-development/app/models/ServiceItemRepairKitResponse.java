package models;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "serviceItemRepairKitResponse")
public class ServiceItemRepairKitResponse {

    protected PcNonFmiItems pcNonFmiItems;
    protected List<PcFmiItems> pcFmiItems;
    protected StatusTypeForMaterial status;

    /**
     * Gets the value of the pcNonFmiItems property.
     * 
     * @return
     *     possible object is
     *     {@link PcNonFmiItems }
     *     
     */
    public PcNonFmiItems getPcNonFmiItems() {
        return pcNonFmiItems;
    }

    /**
     * Sets the value of the pcNonFmiItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link PcNonFmiItems }
     *     
     */
    public void setPcNonFmiItems(PcNonFmiItems value) {
        this.pcNonFmiItems = value;
    }

    /**
     * Gets the value of the pcFmiItems property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pcFmiItems property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPcFmiItems().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PcFmiItems }
     * 
     * 
     */
    public List<PcFmiItems> getPcFmiItems() {
        if (pcFmiItems == null) {
            pcFmiItems = new ArrayList<PcFmiItems>();
        }
        return this.pcFmiItems;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link StatusType }
     *     
     */
    public StatusTypeForMaterial getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusType }
     *     
     */
    public void setStatus(StatusTypeForMaterial value) {
        this.status = value;
    }

}
