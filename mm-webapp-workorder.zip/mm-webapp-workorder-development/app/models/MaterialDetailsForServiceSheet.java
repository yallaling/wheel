package models;

import java.util.ArrayList;
import java.util.List;

public class MaterialDetailsForServiceSheet {
	
	
	private ServiceSheetDTO serviceSheet;
	private List<RepairKit> repairKits;
	private List<PcFmiItems> pcFmiItems;


	public ServiceSheetDTO getServiceSheet() {
		return serviceSheet;
	}
	public void setServiceSheet(ServiceSheetDTO serviceSheet) {
		this.serviceSheet = serviceSheet;
	}
	public List<RepairKit> getRepairKits() {
		return repairKits;
	}
	public void setRepairKits(List<RepairKit> repairKits) {
		this.repairKits = repairKits;
	}

	public List<PcFmiItems> getPcFmiItems() {
        if (pcFmiItems == null) {
            pcFmiItems = new ArrayList<PcFmiItems>();
        }
        return this.pcFmiItems;
    }
}
