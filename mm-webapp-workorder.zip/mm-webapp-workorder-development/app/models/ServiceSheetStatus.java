package models;

public class ServiceSheetStatus {

	private Long serviceSheetId;

	public Long getServiceSheetId() {
		return serviceSheetId;
	}

	public void setServiceSheetId(Long serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
	
}
