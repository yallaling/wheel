package models;


public class AutoSignoffRequest {

	public Long messageId;
    public Long serviceOrgId;
    public String eventName;
    public Long customerId;	
	public Long locomotiveId;
    public String locomotiveTypeCode;
    public Long getMessageId() {
		return messageId;
	}
	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}
	public Long getServiceOrgId() {
		return serviceOrgId;
	}
	public void setServiceOrgId(Long serviceOrgId) {
		this.serviceOrgId = serviceOrgId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public Long getLocomotiveId() {
		return locomotiveId;
	}
	public void setLocomotiveId(Long locomotiveId) {
		this.locomotiveId = locomotiveId;
	}
	public String getLocomotiveTypeCode() {
		return locomotiveTypeCode;
	}
	public void setLocomotiveTypeCode(String locomotiveTypeCode) {
		this.locomotiveTypeCode = locomotiveTypeCode;
	}	
}
