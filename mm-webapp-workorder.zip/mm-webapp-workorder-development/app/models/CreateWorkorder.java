package models;

public class CreateWorkorder {

	public String customerId;
	public String customerName;
	public String roadNumber;
	public String workorderStatus;
	public String reasonCode;
	public String inshopReason;
	public Long createdBy;
	public Long UpdatedBy;
	private String aarRoad;
	private String inShopDate;
	private String track;
	private String position;
	private String direction;
	private String authorizedBy;
	private String outOfShopRepairLocation;
	private String outOfShopRepairFlag;
	private Long orgId;
	private String isSmartShop;

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public String getWorkorderStatus() {
		return workorderStatus;
	}

	public void setWorkorderStatus(String workorderStatus) {
		this.workorderStatus = workorderStatus;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getInshopReason() {
		return inshopReason;
	}

	public void setInshopReason(String inshopReason) {
		this.inshopReason = inshopReason;
	}

	public Long getCreatedBy() {
		// TODO Auto-generated method stub
		return createdBy;
	}

	public Long getUpdatedBy() {
		return UpdatedBy;
	}

	public void setUpdatedBy(Long UpdatedBy) {
		this.UpdatedBy = UpdatedBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public String getAarRoad() {
		// TODO Auto-generated method stub
		return aarRoad;
	}

	public void setAarRoad(String aarRoad) {
		this.aarRoad = aarRoad;
	}

	public String getInShopDate() {
		return inShopDate;
	}

	public void setInShopDate(String inShopDate) {
		this.inShopDate = inShopDate;
	}

	public String getTrack() {
		return track;
	}

	public void setTrack(String track) {
		this.track = track;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getAuthorizedBy() {
		return authorizedBy;
	}

	public void setAuthorizedBy(String authorizedBy) {
		this.authorizedBy = authorizedBy;
	}

	public String getOutOfShopRepairLocation() {
		return outOfShopRepairLocation;
	}

	public void setOutOfShopRepairLocation(String outOfShopRepairLocation) {
		this.outOfShopRepairLocation = outOfShopRepairLocation;
	}

	public String getOutOfShopRepairFlag() {
		return outOfShopRepairFlag;
	}

	public void setOutOfShopRepairFlag(String outOfShopRepairFlag) {
		this.outOfShopRepairFlag = outOfShopRepairFlag;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getIsSmartShop() {
        return isSmartShop;
	}
	
    public void setIsSmartShop(String value) {
        this.isSmartShop = value;
    } 	

}
