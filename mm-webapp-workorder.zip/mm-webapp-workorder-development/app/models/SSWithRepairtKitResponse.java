package models;

import java.util.ArrayList;
import java.util.List;

public class SSWithRepairtKitResponse {

	private List<MaterialDetailsForServiceSheet> servicesheetWithMaterial = new ArrayList<>();
	private StatusCode status;
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageParams() {
		return messageParams;
	}

	public void setMessageParams(String messageParams) {
		this.messageParams = messageParams;
	}

	protected String message;
    protected String messageParams;

	public List<MaterialDetailsForServiceSheet> getServicesheetWithMaterial() {
		return servicesheetWithMaterial;
	}

	public void setServicesheetWithMaterial(List<MaterialDetailsForServiceSheet> servicesheetWithMaterial) {
		this.servicesheetWithMaterial = servicesheetWithMaterial;
	}

	public StatusCode getStatus() {
		return status;
	}

	public void setStatus(StatusCode status) {
		this.status = status;
	}
	
	
	
	
}
