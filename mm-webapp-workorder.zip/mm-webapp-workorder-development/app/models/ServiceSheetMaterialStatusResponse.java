package models;
import java.util.ArrayList;
import java.util.List;

 
public class ServiceSheetMaterialStatusResponse {

    private List<Long> serviceSheets;
    private StatusType status;
    
	public List<Long> getServiceSheets() {
		if (serviceSheets == null) {
			serviceSheets = new ArrayList<Long>();
        }
		return serviceSheets;
	}
	public void setServiceSheets(List<Long> serviceSheets) {
		this.serviceSheets = serviceSheets;
	}
	public StatusType getStatus() {
		return status;
	}
	public void setStatus(StatusType status) {
		this.status = status;
	}  

    
}
