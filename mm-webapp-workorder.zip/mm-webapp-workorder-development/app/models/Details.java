package models;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for details complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="details">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="shoppingCartDetailsId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="shoppingCartDetailsStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shoppingCartId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="partsCatelogItemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="itemIdPicked" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="requestedQuantity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="pickedQuantity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="deletedQuantity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="returnedQuantity" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="uxItemFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag"/>
 *         &lt;element name="uxQuantityDue" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="dmrItemFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag"/>
 *         &lt;element name="dmrQuantityDue" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="repeatorFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag"/>
 *         &lt;element name="materialRequetedBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="shortageFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag"/>
 *         &lt;element name="shortageComments" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="creationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="lastUpdatedDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="lastUpdateBy" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="partsCatalogItemNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="itemNumberPicked" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="subinventory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="locatorId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="stockLocator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="defectId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="shoppingCartStatusId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="fmiId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="requestSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serviceItemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="materialRequestDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="materialRequestLocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="floorPick" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="dftDefectPickFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="dftShortageComments" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="shortageItemId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="requestedDuringOutage" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="lastUsageDate" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="itemDescription" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="traceable" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="positionTracked" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="componentId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="assetComponentSnapshot" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}assetComponentSnapshot" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="isValidTraceableQuantity" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "details", propOrder = {
    "shoppingCartDetailsId",
    "shoppingCartDetailsStatus",
    "shoppingCartId",
    "partsCatelogItemId",
    "itemIdPicked",
    "requestedQuantity",
    "pickedQuantity",
    "deletedQuantity",
    "returnedQuantity",
    "uxItemFlag",
    "uxQuantityDue",
    "dmrItemFlag",
    "dmrQuantityDue",
    "repeatorFlag",
    "materialRequetedBy",
    "shortageFlag",
    "shortageComments",
    "creationDate",
    "createdBy",
    "lastUpdatedDate",
    "lastUpdateBy",
    "partsCatalogItemNumber",
    "itemNumberPicked",
    "subinventory",
    "locatorId",
    "stockLocator",
    "defectId",
    "shoppingCartStatusId",
    "fmiId",
    "requestSource",
    "serviceItemId",
    "materialRequestDate",
    "materialRequestLocation",
    "floorPick",
    "dftDefectPickFlag",
    "dftShortageComments",
    "shortageItemId",
    "requestedDuringOutage",
    "lastUsageDate",
    "itemDescription",
    "traceable",
    "positionTracked",
    "componentId",
    "assetComponentSnapshot",
    "isValidTraceableQuantity"
})
public class Details {

    protected long shoppingCartDetailsId;
    protected String shoppingCartDetailsStatus;
    protected long shoppingCartId;
    protected Long partsCatelogItemId;
    protected Long itemIdPicked;
    protected Long requestedQuantity;
    protected Long pickedQuantity;
    protected Long deletedQuantity;
    protected Long returnedQuantity;
    @XmlElement(required = true)
    protected Flag uxItemFlag;
    protected Long uxQuantityDue;
    @XmlElement(required = true)
    protected Flag dmrItemFlag;
    protected Long dmrQuantityDue;
    @XmlElement(required = true)
    protected Flag repeatorFlag;
    @XmlElement(required = true)
    protected String materialRequetedBy;
    @XmlElement(required = true)
    protected Flag shortageFlag;
    @XmlElement(required = true)
    protected String shortageComments;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar creationDate;
    protected long createdBy;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastUpdatedDate;
    protected long lastUpdateBy;
    protected String partsCatalogItemNumber;
    protected String itemNumberPicked;
    protected String subinventory;
    protected Long locatorId;
    protected String stockLocator;
    protected Long defectId;
    protected Long shoppingCartStatusId;
    protected Long fmiId;
    protected String requestSource;
    protected Long serviceItemId;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar materialRequestDate;
    protected String materialRequestLocation;
    protected Flag floorPick;
    protected Flag dftDefectPickFlag;
    protected String dftShortageComments;
    protected Long shortageItemId;
    protected Flag requestedDuringOutage;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastUsageDate;
    @XmlElement(required = true)
    protected String itemDescription;
    @XmlElement(required = true)
    protected String traceable;
    @XmlElement(required = true)
    protected String positionTracked;
    protected long componentId;
    protected List<AssetComponentSnapshot> assetComponentSnapshot;
    protected boolean isValidTraceableQuantity;

    /**
     * Gets the value of the shoppingCartDetailsId property.
     * 
     */
    public long getShoppingCartDetailsId() {
        return shoppingCartDetailsId;
    }

    /**
     * Sets the value of the shoppingCartDetailsId property.
     * 
     */
    public void setShoppingCartDetailsId(long value) {
        this.shoppingCartDetailsId = value;
    }

    /**
     * Gets the value of the shoppingCartDetailsStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShoppingCartDetailsStatus() {
        return shoppingCartDetailsStatus;
    }

    /**
     * Sets the value of the shoppingCartDetailsStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShoppingCartDetailsStatus(String value) {
        this.shoppingCartDetailsStatus = value;
    }

    /**
     * Gets the value of the shoppingCartId property.
     * 
     */
    public long getShoppingCartId() {
        return shoppingCartId;
    }

    /**
     * Sets the value of the shoppingCartId property.
     * 
     */
    public void setShoppingCartId(long value) {
        this.shoppingCartId = value;
    }

    /**
     * Gets the value of the partsCatelogItemId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPartsCatelogItemId() {
        return partsCatelogItemId;
    }

    /**
     * Sets the value of the partsCatelogItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPartsCatelogItemId(Long value) {
        this.partsCatelogItemId = value;
    }

    /**
     * Gets the value of the itemIdPicked property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getItemIdPicked() {
        return itemIdPicked;
    }

    /**
     * Sets the value of the itemIdPicked property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setItemIdPicked(Long value) {
        this.itemIdPicked = value;
    }

    /**
     * Gets the value of the requestedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRequestedQuantity() {
        return requestedQuantity;
    }

    /**
     * Sets the value of the requestedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRequestedQuantity(Long value) {
        this.requestedQuantity = value;
    }

    /**
     * Gets the value of the pickedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getPickedQuantity() {
        return pickedQuantity;
    }

    /**
     * Sets the value of the pickedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setPickedQuantity(Long value) {
        this.pickedQuantity = value;
    }

    /**
     * Gets the value of the deletedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDeletedQuantity() {
        return deletedQuantity;
    }

    /**
     * Sets the value of the deletedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDeletedQuantity(Long value) {
        this.deletedQuantity = value;
    }

    /**
     * Gets the value of the returnedQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getReturnedQuantity() {
        return returnedQuantity;
    }

    /**
     * Sets the value of the returnedQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setReturnedQuantity(Long value) {
        this.returnedQuantity = value;
    }

    /**
     * Gets the value of the uxItemFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getUxItemFlag() {
        return uxItemFlag;
    }

    /**
     * Sets the value of the uxItemFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setUxItemFlag(Flag value) {
        this.uxItemFlag = value;
    }

    /**
     * Gets the value of the uxQuantityDue property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getUxQuantityDue() {
        return uxQuantityDue;
    }

    /**
     * Sets the value of the uxQuantityDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setUxQuantityDue(Long value) {
        this.uxQuantityDue = value;
    }

    /**
     * Gets the value of the dmrItemFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getDmrItemFlag() {
        return dmrItemFlag;
    }

    /**
     * Sets the value of the dmrItemFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setDmrItemFlag(Flag value) {
        this.dmrItemFlag = value;
    }

    /**
     * Gets the value of the dmrQuantityDue property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDmrQuantityDue() {
        return dmrQuantityDue;
    }

    /**
     * Sets the value of the dmrQuantityDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDmrQuantityDue(Long value) {
        this.dmrQuantityDue = value;
    }

    /**
     * Gets the value of the repeatorFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getRepeatorFlag() {
        return repeatorFlag;
    }

    /**
     * Sets the value of the repeatorFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setRepeatorFlag(Flag value) {
        this.repeatorFlag = value;
    }

    /**
     * Gets the value of the materialRequetedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaterialRequetedBy() {
        return materialRequetedBy;
    }

    /**
     * Sets the value of the materialRequetedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaterialRequetedBy(String value) {
        this.materialRequetedBy = value;
    }

    /**
     * Gets the value of the shortageFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getShortageFlag() {
        return shortageFlag;
    }

    /**
     * Sets the value of the shortageFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setShortageFlag(Flag value) {
        this.shortageFlag = value;
    }

    /**
     * Gets the value of the shortageComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShortageComments() {
        return shortageComments;
    }

    /**
     * Sets the value of the shortageComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShortageComments(String value) {
        this.shortageComments = value;
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreationDate(XMLGregorianCalendar value) {
        this.creationDate = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     */
    public long getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     */
    public void setCreatedBy(long value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the lastUpdatedDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    /**
     * Sets the value of the lastUpdatedDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdatedDate(XMLGregorianCalendar value) {
        this.lastUpdatedDate = value;
    }

    /**
     * Gets the value of the lastUpdateBy property.
     * 
     */
    public long getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * Sets the value of the lastUpdateBy property.
     * 
     */
    public void setLastUpdateBy(long value) {
        this.lastUpdateBy = value;
    }

    /**
     * Gets the value of the partsCatalogItemNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPartsCatalogItemNumber() {
        return partsCatalogItemNumber;
    }

    /**
     * Sets the value of the partsCatalogItemNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPartsCatalogItemNumber(String value) {
        this.partsCatalogItemNumber = value;
    }

    /**
     * Gets the value of the itemNumberPicked property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemNumberPicked() {
        return itemNumberPicked;
    }

    /**
     * Sets the value of the itemNumberPicked property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemNumberPicked(String value) {
        this.itemNumberPicked = value;
    }

    /**
     * Gets the value of the subinventory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubinventory() {
        return subinventory;
    }

    /**
     * Sets the value of the subinventory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubinventory(String value) {
        this.subinventory = value;
    }

    /**
     * Gets the value of the locatorId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocatorId() {
        return locatorId;
    }

    /**
     * Sets the value of the locatorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocatorId(Long value) {
        this.locatorId = value;
    }

    /**
     * Gets the value of the stockLocator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStockLocator() {
        return stockLocator;
    }

    /**
     * Sets the value of the stockLocator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStockLocator(String value) {
        this.stockLocator = value;
    }

    /**
     * Gets the value of the defectId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getDefectId() {
        return defectId;
    }

    /**
     * Sets the value of the defectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setDefectId(Long value) {
        this.defectId = value;
    }

    /**
     * Gets the value of the shoppingCartStatusId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getShoppingCartStatusId() {
        return shoppingCartStatusId;
    }

    /**
     * Sets the value of the shoppingCartStatusId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setShoppingCartStatusId(Long value) {
        this.shoppingCartStatusId = value;
    }

    /**
     * Gets the value of the fmiId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getFmiId() {
        return fmiId;
    }

    /**
     * Sets the value of the fmiId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setFmiId(Long value) {
        this.fmiId = value;
    }

    /**
     * Gets the value of the requestSource property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestSource() {
        return requestSource;
    }

    /**
     * Sets the value of the requestSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestSource(String value) {
        this.requestSource = value;
    }

    /**
     * Gets the value of the serviceItemId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServiceItemId() {
        return serviceItemId;
    }

    /**
     * Sets the value of the serviceItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServiceItemId(Long value) {
        this.serviceItemId = value;
    }

    /**
     * Gets the value of the materialRequestDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getMaterialRequestDate() {
        return materialRequestDate;
    }

    /**
     * Sets the value of the materialRequestDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setMaterialRequestDate(XMLGregorianCalendar value) {
        this.materialRequestDate = value;
    }

    /**
     * Gets the value of the materialRequestLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMaterialRequestLocation() {
        return materialRequestLocation;
    }

    /**
     * Sets the value of the materialRequestLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMaterialRequestLocation(String value) {
        this.materialRequestLocation = value;
    }

    /**
     * Gets the value of the floorPick property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getFloorPick() {
        return floorPick;
    }

    /**
     * Sets the value of the floorPick property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setFloorPick(Flag value) {
        this.floorPick = value;
    }

    /**
     * Gets the value of the dftDefectPickFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getDftDefectPickFlag() {
        return dftDefectPickFlag;
    }

    /**
     * Sets the value of the dftDefectPickFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setDftDefectPickFlag(Flag value) {
        this.dftDefectPickFlag = value;
    }

    /**
     * Gets the value of the dftShortageComments property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDftShortageComments() {
        return dftShortageComments;
    }

    /**
     * Sets the value of the dftShortageComments property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDftShortageComments(String value) {
        this.dftShortageComments = value;
    }

    /**
     * Gets the value of the shortageItemId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getShortageItemId() {
        return shortageItemId;
    }

    /**
     * Sets the value of the shortageItemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setShortageItemId(Long value) {
        this.shortageItemId = value;
    }

    /**
     * Gets the value of the requestedDuringOutage property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getRequestedDuringOutage() {
        return requestedDuringOutage;
    }

    /**
     * Sets the value of the requestedDuringOutage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setRequestedDuringOutage(Flag value) {
        this.requestedDuringOutage = value;
    }

    /**
     * Gets the value of the lastUsageDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUsageDate() {
        return lastUsageDate;
    }

    /**
     * Sets the value of the lastUsageDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUsageDate(XMLGregorianCalendar value) {
        this.lastUsageDate = value;
    }

    /**
     * Gets the value of the itemDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the value of the itemDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemDescription(String value) {
        this.itemDescription = value;
    }

    /**
     * Gets the value of the traceable property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTraceable() {
        return traceable;
    }

    /**
     * Sets the value of the traceable property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTraceable(String value) {
        this.traceable = value;
    }

    /**
     * Gets the value of the positionTracked property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPositionTracked() {
        return positionTracked;
    }

    /**
     * Sets the value of the positionTracked property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPositionTracked(String value) {
        this.positionTracked = value;
    }

    /**
     * Gets the value of the componentId property.
     * 
     */
    public long getComponentId() {
        return componentId;
    }

    /**
     * Sets the value of the componentId property.
     * 
     */
    public void setComponentId(long value) {
        this.componentId = value;
    }

    /**
     * Gets the value of the assetComponentSnapshot property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assetComponentSnapshot property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssetComponentSnapshot().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssetComponentSnapshot }
     * 
     * 
     */
    public List<AssetComponentSnapshot> getAssetComponentSnapshot() {
        if (assetComponentSnapshot == null) {
            assetComponentSnapshot = new ArrayList<AssetComponentSnapshot>();
        }
        return this.assetComponentSnapshot;
    }

    /**
     * Gets the value of the isValidTraceableQuantity property.
     * 
     */
    public boolean isIsValidTraceableQuantity() {
        return isValidTraceableQuantity;
    }

    /**
     * Sets the value of the isValidTraceableQuantity property.
     * 
     */
    public void setIsValidTraceableQuantity(boolean value) {
        this.isValidTraceableQuantity = value;
    }

}
