package models;

public class TransferWorkorderDTO {

	private String workorderId;
	private String originOrg;
	private String originInshopDate;
	private String originOutshopDate;
	private String destinationOrg;
	private String destinationStatus;
	private String destinationInshopDate;
	private String destinationIncomingDate;
	private String track;
	private String position;
	private String direction;
	private String transitStartTime;
	private String transitEndTime;
	private String updatedBy;
	
	public String getWorkorderId() {
		return workorderId;
	}
	public void setWorkorderId(String workorderId) {
		this.workorderId = workorderId;
	}
	public String getOriginOrg() {
		return originOrg;
	}
	public void setOriginOrg(String originOrg) {
		this.originOrg = originOrg;
	}
	public String getOriginInshopDate() {
		return originInshopDate;
	}
	public void setOriginInshopDate(String originInshopDate) {
		this.originInshopDate = originInshopDate;
	}
	public String getOriginOutshopDate() {
		return originOutshopDate;
	}
	public void setOriginOutshopDate(String originOutshopDate) {
		this.originOutshopDate = originOutshopDate;
	}
	public String getDestinationOrg() {
		return destinationOrg;
	}
	public void setDestinationOrg(String destinationOrg) {
		this.destinationOrg = destinationOrg;
	}
	public String getDestinationStatus() {
		return destinationStatus;
	}
	public void setDestinationStatus(String destinationStatus) {
		this.destinationStatus = destinationStatus;
	}
	public String getDestinationInshopDate() {
		return destinationInshopDate;
	}
	public void setDestinationInshopDate(String destinationInshopDate) {
		this.destinationInshopDate = destinationInshopDate;
	}	
	public String getDestinationIncomingDate() {
		return destinationIncomingDate;
	}
	public void setDestinationIncomingDate(String destinationIncomingDate) {
		this.destinationIncomingDate = destinationIncomingDate;
	}
	public String getTrack() {
		return track;
	}
	public void setTrack(String track) {
		this.track = track;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getTransitStartTime() {
		return transitStartTime;
	}
	public void setTransitStartTime(String transitStartTime) {
		this.transitStartTime = transitStartTime;
	}
	public String getTransitEndTime() {
		return transitEndTime;
	}
	public void setTransitEndTime(String transitEndTime) {
		this.transitEndTime = transitEndTime;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
}
