package models; 

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="serviceOrgId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="pcNonFmi" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}pcNonFmi" minOccurs="0"/>
 *         &lt;element name="pcFmi" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}pcFmi" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "serviceOrgId",
    "pcNonFmi",
    "pcFmi"
})
@XmlRootElement(name = "serviceItemRepairKitRequest")
public class ServiceItemRepairKitRequest {

    protected Long serviceOrgId;
    protected PcNonFmi pcNonFmi;
    protected PcFmi pcFmi;

    /**
     * Gets the value of the serviceOrgId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServiceOrgId() {
        return serviceOrgId;
    }

    /**
     * Sets the value of the serviceOrgId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServiceOrgId(Long value) {
        this.serviceOrgId = value;
    }

    /**
     * Gets the value of the pcNonFmi property.
     * 
     * @return
     *     possible object is
     *     {@link PcNonFmi }
     *     
     */
    public PcNonFmi getPcNonFmi() {
        return pcNonFmi;
    }

    /**
     * Sets the value of the pcNonFmi property.
     * 
     * @param value
     *     allowed object is
     *     {@link PcNonFmi }
     *     
     */
    public void setPcNonFmi(PcNonFmi value) {
        this.pcNonFmi = value;
    }

    /**
     * Gets the value of the pcFmi property.
     * 
     * @return
     *     possible object is
     *     {@link PcFmi }
     *     
     */
    public PcFmi getPcFmi() {
        return pcFmi;
    }

    /**
     * Sets the value of the pcFmi property.
     * 
     * @param value
     *     allowed object is
     *     {@link PcFmi }
     *     
     */
    public void setPcFmi(PcFmi value) {
        this.pcFmi = value;
    }

}
