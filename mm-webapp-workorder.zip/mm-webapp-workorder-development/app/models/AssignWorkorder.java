package models;

public class AssignWorkorder {

	 private String workorderId;
	 private String workorderNumber;
	 private String roadNumber;
	 private String customerId;
	 private String reasonCode;
	 private String workorderComment;
	 private String workorderStatus;
	 private String locomotiveId;
	 private String organisationId;
	 private String date;
	 private String track;
	 private String position;
	 private String direction;
	 private String lastupdatedby;
	 private String locale;
	 private String isSmartShop;
	 
	public String getWorkorderId() {
		return workorderId;
	}
	public void setWorkorderId(String workorderId) {
		this.workorderId = workorderId;
	}
	public String getWorkorderNumber() {
		return workorderNumber;
	}
	public void setWorkorderNumber(String workorderNumber) {
		this.workorderNumber = workorderNumber;
	}
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getWorkorderComment() {
		return workorderComment;
	}
	public void setWorkorderComment(String workorderComment) {
		this.workorderComment = workorderComment;
	}
	public String getWorkorderStatus() {
		return workorderStatus;
	}
	public void setWorkorderStatus(String workorderStatus) {
		this.workorderStatus = workorderStatus;
	}
	public String getLocomotiveId() {
		return locomotiveId;
	}
	public void setLocomotiveId(String locomotiveId) {
		this.locomotiveId = locomotiveId;
	}
	public String getOrganisationId() {
		return organisationId;
	}
	public void setOrganisationId(String organisationId) {
		this.organisationId = organisationId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTrack() {
		return track;
	}
	public void setTrack(String track) {
		this.track = track;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}
	public String getLastupdatedby() {
		return lastupdatedby;
	}
	public void setLastupdatedby(String lastupdatedby) {
		this.lastupdatedby = lastupdatedby;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	 
	public String getIsSmartShop() {
        return isSmartShop;
	}
	
    public void setIsSmartShop(String value) {
        this.isSmartShop = value;
    } 


	
	
}
