package models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for assetComponentSnapshot complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="assetComponentSnapshot">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="snapshotId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="assetComponentId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="position" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serialNumberIn" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="serialNumberOut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="oldSerialNumberOut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="newSerialNumberOut" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="isPositionSelected" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="warrantyReason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="removalReasonCode" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="locomotiveId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="serviceMaterialId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="shoppingCartDetailsId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="lastUpdatedBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="creationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="lastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assetComponentSnapshot", propOrder = {
    "snapshotId",
    "assetComponentId",
    "position",
    "serialNumberIn",
    "serialNumberOut",
    "oldSerialNumberOut",
    "newSerialNumberOut",
    "isPositionSelected",
    "warrantyReason",
    "removalReasonCode",
    "locomotiveId",
    "serviceMaterialId",
    "shoppingCartDetailsId",
    "createdBy",
    "lastUpdatedBy",
    "creationDate",
    "lastUpdateDate"
})
public class AssetComponentSnapshot {

    protected long snapshotId;
    protected long assetComponentId;
    @XmlElement(required = true)
    protected String position;
    @XmlElement(required = true)
    protected String serialNumberIn;
    @XmlElement(required = true)
    protected String serialNumberOut;
    @XmlElement(required = true)
    protected String oldSerialNumberOut;
    @XmlElement(required = true)
    protected String newSerialNumberOut;
    protected Flag isPositionSelected;
    @XmlElement(required = true)
    protected String warrantyReason;
    protected long removalReasonCode;
    protected long locomotiveId;
    protected long serviceMaterialId;
    protected long shoppingCartDetailsId;
    @XmlElement(required = true)
    protected String createdBy;
    @XmlElement(required = true)
    protected String lastUpdatedBy;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar creationDate;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastUpdateDate;

    /**
     * Gets the value of the snapshotId property.
     * 
     */
    public long getSnapshotId() {
        return snapshotId;
    }

    /**
     * Sets the value of the snapshotId property.
     * 
     */
    public void setSnapshotId(long value) {
        this.snapshotId = value;
    }

    /**
     * Gets the value of the assetComponentId property.
     * 
     */
    public long getAssetComponentId() {
        return assetComponentId;
    }

    /**
     * Sets the value of the assetComponentId property.
     * 
     */
    public void setAssetComponentId(long value) {
        this.assetComponentId = value;
    }

    /**
     * Gets the value of the position property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPosition() {
        return position;
    }

    /**
     * Sets the value of the position property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPosition(String value) {
        this.position = value;
    }

    /**
     * Gets the value of the serialNumberIn property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumberIn() {
        return serialNumberIn;
    }

    /**
     * Sets the value of the serialNumberIn property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumberIn(String value) {
        this.serialNumberIn = value;
    }

    /**
     * Gets the value of the serialNumberOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSerialNumberOut() {
        return serialNumberOut;
    }

    /**
     * Sets the value of the serialNumberOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSerialNumberOut(String value) {
        this.serialNumberOut = value;
    }

    /**
     * Gets the value of the oldSerialNumberOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOldSerialNumberOut() {
        return oldSerialNumberOut;
    }

    /**
     * Sets the value of the oldSerialNumberOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOldSerialNumberOut(String value) {
        this.oldSerialNumberOut = value;
    }

    /**
     * Gets the value of the newSerialNumberOut property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNewSerialNumberOut() {
        return newSerialNumberOut;
    }

    /**
     * Sets the value of the newSerialNumberOut property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNewSerialNumberOut(String value) {
        this.newSerialNumberOut = value;
    }

    /**
     * Gets the value of the isPositionSelected property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getIsPositionSelected() {
        return isPositionSelected;
    }

    /**
     * Sets the value of the isPositionSelected property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setIsPositionSelected(Flag value) {
        this.isPositionSelected = value;
    }

    /**
     * Gets the value of the warrantyReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWarrantyReason() {
        return warrantyReason;
    }

    /**
     * Sets the value of the warrantyReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWarrantyReason(String value) {
        this.warrantyReason = value;
    }

    /**
     * Gets the value of the removalReasonCode property.
     * 
     */
    public long getRemovalReasonCode() {
        return removalReasonCode;
    }

    /**
     * Sets the value of the removalReasonCode property.
     * 
     */
    public void setRemovalReasonCode(long value) {
        this.removalReasonCode = value;
    }

    /**
     * Gets the value of the locomotiveId property.
     * 
     */
    public long getLocomotiveId() {
        return locomotiveId;
    }

    /**
     * Sets the value of the locomotiveId property.
     * 
     */
    public void setLocomotiveId(long value) {
        this.locomotiveId = value;
    }

    /**
     * Gets the value of the serviceMaterialId property.
     * 
     */
    public long getServiceMaterialId() {
        return serviceMaterialId;
    }

    /**
     * Sets the value of the serviceMaterialId property.
     * 
     */
    public void setServiceMaterialId(long value) {
        this.serviceMaterialId = value;
    }

    /**
     * Gets the value of the shoppingCartDetailsId property.
     * 
     */
    public long getShoppingCartDetailsId() {
        return shoppingCartDetailsId;
    }

    /**
     * Sets the value of the shoppingCartDetailsId property.
     * 
     */
    public void setShoppingCartDetailsId(long value) {
        this.shoppingCartDetailsId = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedBy(String value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the lastUpdatedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * Sets the value of the lastUpdatedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastUpdatedBy(String value) {
        this.lastUpdatedBy = value;
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreationDate(XMLGregorianCalendar value) {
        this.creationDate = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }

}
