package models;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for header complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="header">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="shoppingCartHeaderId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="serviceWorkOrderId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="workOrderNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="roadNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="locomotiveId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="organizationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="shoppingCartStatus" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}shoppingCartStatus"/>
 *         &lt;element name="creationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="createdBy" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="lastUpdateDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="lastUpdateBy" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="customerId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="coreDue" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="floorPick" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="b2bFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="outOfShopRepairFlag" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}flag" minOccurs="0"/>
 *         &lt;element name="details" type="{http://www.ge.com/transportation/eservices2/domainobjects/services}details" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="uuid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="rmFmiSheet" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="workOrderStatusFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="bomId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="bomName" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="defectId" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "header", propOrder = {
    "shoppingCartHeaderId",
    "serviceWorkOrderId",
    "workOrderNumber",
    "roadNumber",
    "locomotiveId",
    "organizationId",
    "shoppingCartStatus",
    "creationDate",
    "createdBy",
    "lastUpdateDate",
    "lastUpdateBy",
    "customerId",
    "coreDue",
    "floorPick",
    "b2BFlag",
    "outOfShopRepairFlag",
    "details",
    "uuid",
    "rmFmiSheet",
    "workOrderStatusFlag",
    "bomId",
    "bomName",
    "defectId"
})
public class Header {

    protected long shoppingCartHeaderId;
    protected Long serviceWorkOrderId;
    @XmlElement(required = true)
    protected String workOrderNumber;
    protected String roadNumber;
    protected Long locomotiveId;
    protected Long organizationId;
    @XmlElement(required = true)
    protected ShoppingCartStatus shoppingCartStatus;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar creationDate;
    protected long createdBy;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar lastUpdateDate;
    protected long lastUpdateBy;
    protected Long customerId;
    protected Flag coreDue;
    protected Flag floorPick;
    @XmlElement(name = "b2bFlag")
    protected Flag b2BFlag;
    protected Flag outOfShopRepairFlag;
    protected List<Details> details;
    @XmlElement(required = true)
    protected String uuid;
    @XmlElement(required = true)
    protected String rmFmiSheet;
    protected boolean workOrderStatusFlag;
    protected long bomId;
    @XmlElement(required = true)
    protected String bomName;
    protected long defectId;

    /**
     * Gets the value of the shoppingCartHeaderId property.
     * 
     */
    public long getShoppingCartHeaderId() {
        return shoppingCartHeaderId;
    }

    /**
     * Sets the value of the shoppingCartHeaderId property.
     * 
     */
    public void setShoppingCartHeaderId(long value) {
        this.shoppingCartHeaderId = value;
    }

    /**
     * Gets the value of the serviceWorkOrderId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getServiceWorkOrderId() {
        return serviceWorkOrderId;
    }

    /**
     * Sets the value of the serviceWorkOrderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setServiceWorkOrderId(Long value) {
        this.serviceWorkOrderId = value;
    }

    /**
     * Gets the value of the workOrderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWorkOrderNumber() {
        return workOrderNumber;
    }

    /**
     * Sets the value of the workOrderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWorkOrderNumber(String value) {
        this.workOrderNumber = value;
    }

    /**
     * Gets the value of the roadNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoadNumber() {
        return roadNumber;
    }

    /**
     * Sets the value of the roadNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoadNumber(String value) {
        this.roadNumber = value;
    }

    /**
     * Gets the value of the locomotiveId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLocomotiveId() {
        return locomotiveId;
    }

    /**
     * Sets the value of the locomotiveId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLocomotiveId(Long value) {
        this.locomotiveId = value;
    }

    /**
     * Gets the value of the organizationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getOrganizationId() {
        return organizationId;
    }

    /**
     * Sets the value of the organizationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setOrganizationId(Long value) {
        this.organizationId = value;
    }

    /**
     * Gets the value of the shoppingCartStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ShoppingCartStatus }
     *     
     */
    public ShoppingCartStatus getShoppingCartStatus() {
        return shoppingCartStatus;
    }

    /**
     * Sets the value of the shoppingCartStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShoppingCartStatus }
     *     
     */
    public void setShoppingCartStatus(ShoppingCartStatus value) {
        this.shoppingCartStatus = value;
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreationDate(XMLGregorianCalendar value) {
        this.creationDate = value;
    }

    /**
     * Gets the value of the createdBy property.
     * 
     */
    public long getCreatedBy() {
        return createdBy;
    }

    /**
     * Sets the value of the createdBy property.
     * 
     */
    public void setCreatedBy(long value) {
        this.createdBy = value;
    }

    /**
     * Gets the value of the lastUpdateDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastUpdateDate() {
        return lastUpdateDate;
    }

    /**
     * Sets the value of the lastUpdateDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastUpdateDate(XMLGregorianCalendar value) {
        this.lastUpdateDate = value;
    }

    /**
     * Gets the value of the lastUpdateBy property.
     * 
     */
    public long getLastUpdateBy() {
        return lastUpdateBy;
    }

    /**
     * Sets the value of the lastUpdateBy property.
     * 
     */
    public void setLastUpdateBy(long value) {
        this.lastUpdateBy = value;
    }

    /**
     * Gets the value of the customerId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCustomerId() {
        return customerId;
    }

    /**
     * Sets the value of the customerId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCustomerId(Long value) {
        this.customerId = value;
    }

    /**
     * Gets the value of the coreDue property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getCoreDue() {
        return coreDue;
    }

    /**
     * Sets the value of the coreDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setCoreDue(Flag value) {
        this.coreDue = value;
    }

    /**
     * Gets the value of the floorPick property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getFloorPick() {
        return floorPick;
    }

    /**
     * Sets the value of the floorPick property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setFloorPick(Flag value) {
        this.floorPick = value;
    }

    /**
     * Gets the value of the b2BFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getB2BFlag() {
        return b2BFlag;
    }

    /**
     * Sets the value of the b2BFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setB2BFlag(Flag value) {
        this.b2BFlag = value;
    }

    /**
     * Gets the value of the outOfShopRepairFlag property.
     * 
     * @return
     *     possible object is
     *     {@link Flag }
     *     
     */
    public Flag getOutOfShopRepairFlag() {
        return outOfShopRepairFlag;
    }

    /**
     * Sets the value of the outOfShopRepairFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link Flag }
     *     
     */
    public void setOutOfShopRepairFlag(Flag value) {
        this.outOfShopRepairFlag = value;
    }

    /**
     * Gets the value of the details property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the details property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Details }
     * 
     * 
     */
    public List<Details> getDetails() {
        if (details == null) {
            details = new ArrayList<Details>();
        }
        return this.details;
    }

    /**
     * Gets the value of the uuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * Sets the value of the uuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUuid(String value) {
        this.uuid = value;
    }

    /**
     * Gets the value of the rmFmiSheet property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRmFmiSheet() {
        return rmFmiSheet;
    }

    /**
     * Sets the value of the rmFmiSheet property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRmFmiSheet(String value) {
        this.rmFmiSheet = value;
    }

    /**
     * Gets the value of the workOrderStatusFlag property.
     * 
     */
    public boolean isWorkOrderStatusFlag() {
        return workOrderStatusFlag;
    }

    /**
     * Sets the value of the workOrderStatusFlag property.
     * 
     */
    public void setWorkOrderStatusFlag(boolean value) {
        this.workOrderStatusFlag = value;
    }

    /**
     * Gets the value of the bomId property.
     * 
     */
    public long getBomId() {
        return bomId;
    }

    /**
     * Sets the value of the bomId property.
     * 
     */
    public void setBomId(long value) {
        this.bomId = value;
    }

    /**
     * Gets the value of the bomName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBomName() {
        return bomName;
    }

    /**
     * Sets the value of the bomName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBomName(String value) {
        this.bomName = value;
    }

    /**
     * Gets the value of the defectId property.
     * 
     */
    public long getDefectId() {
        return defectId;
    }

    /**
     * Sets the value of the defectId property.
     * 
     */
    public void setDefectId(long value) {
        this.defectId = value;
    }

}
