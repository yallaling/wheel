package models;

public enum StatusCode {

    SUCCESS,
    FAILED;

    public String value() {
        return name();
    }

    public static StatusCode fromValue(String v) {
        return valueOf(v);
    }

}
