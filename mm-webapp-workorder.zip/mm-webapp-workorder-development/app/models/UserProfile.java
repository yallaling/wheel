package models;

import java.util.ArrayList;
import java.util.List;

public class UserProfile {

	private UserDetails userDetails;
	private List<String> userAttributes;

	public UserProfile() {

	}

	public UserProfile(String userId, String userName, String userSSOId, String userOrgId, String userRole,
			String userLang) {

	}

	public List<String> getUserAttributes() {
		if (userAttributes == null) {
			userAttributes = new ArrayList<String>();
		}
		return userAttributes;
	}

	public UserDetails getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}

}
