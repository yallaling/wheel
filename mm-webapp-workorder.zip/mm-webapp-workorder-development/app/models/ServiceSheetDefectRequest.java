package models;


public class ServiceSheetDefectRequest {
 
	public Long serviceWorkorderId;
    public Long serviceSheetId;
    public Long customerId;
    
	public Long getServiceWorkorderId() {
		return serviceWorkorderId;
	}
	public void setServiceWorkorderId(Long serviceWorkorderId) {
		this.serviceWorkorderId = serviceWorkorderId;
	}
	public Long getServiceSheetId() {
		return serviceSheetId;
	}
	public void setServiceSheetId(Long serviceSheetId) {
		this.serviceSheetId = serviceSheetId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
    
}
