import java.io.PrintWriter;
import java.io.StringWriter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controllers.WorkorderController;
import play.http.HttpErrorHandler;
import play.mvc.*;
import play.mvc.Http.*;
import play.libs.F.*;

public class ErrorHandler implements HttpErrorHandler {
	
	private static final   Logger logger = LoggerFactory.getLogger(ErrorHandler.class);
	
    public Promise<Result> onClientError(RequestHeader request, int statusCode, String message) {
    	
    	logger.error("Invalid url is called : "+message);
    	
        return Promise.<Result>pure(
            Results.status(statusCode, "A client error occurred: " + message)
        );
    }

    public Promise<Result> onServerError(RequestHeader request, Throwable exception) {
    	StringWriter writer = new StringWriter();
		PrintWriter s = new PrintWriter(writer);
		exception.printStackTrace(s);
    	logger.error("Exception occured n calling the service : "+writer.toString());
        return Promise.<Result>pure(
            Results.internalServerError("_internal_server_error")
        );
    }
}