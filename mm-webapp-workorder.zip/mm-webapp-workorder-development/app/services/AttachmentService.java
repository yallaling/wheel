package services;

import org.apache.http.HttpHeaders;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import models.FileUploadRequest;
import play.libs.ws.WS;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;
import util.WorkorderConstants;



public class AttachmentService{

	private static final String BASIC_AUTH_TYPE = "Basic";
	private static final String UPLOAD_ATTACHMENT = "upload";
	private static final String GET_ATTACHMENT = "download";
	private static final String DELETE_ATTACHMENT = "delete";
	
	private static final   Logger logger = LoggerFactory.getLogger(AttachmentService.class);
	public WSResponse uploadAttachment(FileUploadRequest fileUploadRequest) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
        String request = mapper.writeValueAsString(fileUploadRequest);
       WSRequest wsRequest = WS.url(WorkorderConstants.BASE_URL+WorkorderConstants.STORAGE_SERVICE+"/"+UPLOAD_ATTACHMENT);
       wsRequest.setHeader("content-type", WorkorderConstants.APPLICATION_JSON);
       wsRequest.setHeader("Accept", WorkorderConstants.APPLICATION_JSON);
        if(BASIC_AUTH_TYPE.equalsIgnoreCase(WorkorderConstants.AUTH_TYPE)){
        	wsRequest.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD);
        }
        return wsRequest.post(request).get(WorkorderConstants.TIMEOUT_POST);
    }
	
	public WSResponse downloadAttachment(String fileName,String filePath) throws Exception {
		WSResponse response = null;
		try{
			logger.debug("URL called to download Attachment "+WorkorderConstants.BASE_URL+WorkorderConstants.STORAGE_SERVICE+"/"+GET_ATTACHMENT);
			WSRequest wsReq = WS.url(WorkorderConstants.BASE_URL+WorkorderConstants.STORAGE_SERVICE+"/"+GET_ATTACHMENT);
			wsReq.setQueryParameter("filePath", filePath);
			wsReq.setQueryParameter("fileName", fileName);
			if(BASIC_AUTH_TYPE.equalsIgnoreCase(WorkorderConstants.AUTH_TYPE)){
	        	wsReq.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD);
	        }			
			response = wsReq.get().get(WorkorderConstants.TIMEOUT_GET);
			logger.debug("download Attachment status "+response.getStatusText());
		}catch(Exception exception){
			logger.error(exception.getMessage(),exception);
		}
		return response;
    }

	public WSResponse deleteAttachment(String fileName, String filePath)
			throws Exception {
		logger.debug("URL called to delete Attachment "+WorkorderConstants.BASE_URL+WorkorderConstants.STORAGE_SERVICE+"/"+DELETE_ATTACHMENT);
		WSRequest wsReq = WS.url(WorkorderConstants.BASE_URL+WorkorderConstants.STORAGE_SERVICE+"/"+DELETE_ATTACHMENT);
		wsReq.setQueryParameter("filePath", filePath);
		wsReq.setQueryParameter("fileName", fileName);
		if(BASIC_AUTH_TYPE.equalsIgnoreCase(WorkorderConstants.AUTH_TYPE)){
			wsReq.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD);
        }
		WSResponse response = wsReq.delete().get(WorkorderConstants.TIMEOUT_POST);
		logger.debug("deleteAttachment response status "+response.getStatus());
		logger.debug("deleteAttachment response status "+response.getStatusText());
		return response;
	}
	
}
