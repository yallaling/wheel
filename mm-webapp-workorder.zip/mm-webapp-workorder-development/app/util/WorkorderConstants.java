package util;

import play.Play;

public interface WorkorderConstants {
	
	public static final String CONTENT_TYPE = "content-type";
	public static final String ACCEPT = "Accept";
	public static final String CONTENT_DISPOSITION = "content-disposition";
	public static final String APPLICATION_XML = "application/xml";
	public static final String APPLICATION_JSON = "application/json";
	
	
	public static final String WORKORDER_STATUS="workorderStatus";
	public static final String WORKORDER_ID="workorderId";
	public static final String CUSTOMER_ID="customerId"; 
	public static final String ROAD_NUMBER="roadNumber";
	public static final String LOCOMOTIVE_ID = "locomotiveId";
	public static final String SERVICE_WORKORDER_ID = "serviceWorkorderId";
	public static final String SERVICESHEET_ID= "serviceSheetId";
	public static final String SERVICESHEET_COMMENT="serviceSheetComments";
	public static final String SERVICE_ORG_ID = "organizationId";
	public static final String AAR_ROAD = "aarRoad";
	public static final String LOCOMOTIVEIDS = "locomotiveIds";
	public static final String ORG_ID = "orgId";
	public static final String SERVICEITEM_ID = "serviceItemId";

	public static final String US_LOCALE ="en_US";
	public static final String LOCALE = "locale";
	public static final String REQUEST_HEADER_SSO 			= "SM_SSOID";
	public static final String REQUEST_QUERY_SESSIONID 		= "sesid";
	public static final String REQUEST_TRANS_NAME  		    = "transName";
	public static final String SESSION_SSO 					= "User-SSO";
	
	public static final String REQUEST_QUERY_WORKORDERID 	= "workorderid";
	public static final String REQUEST_QUERY_ROADNUMBER		= "roadnoindex";
	public static final String REQUEST_QUERY_CLIENTURL	 	= "ClientURL";
	public static final String REQUEST_QUERY_WORKORDERNUMBER= "woid";
	public static final String REQUEST_QUERY_FLAG		 	= "flag";
	public static final String REQUEST_QUERY_INFLAG	 		= "inflag";
	
	
	public static final String SESSION_USERID 				= "User-Id";
	public static final String SESSION_LOGINID 				= "User-LoginId";
	public static final String SESSION_LANGID				= "User-LangId";
	public static final String SESSION_USERPROFILE 			= "User-Profile";
	public static final String SESSION_LOCALE				="locale";
	public static final String SESSION_CUSTOMERID			= "customerid";
	public static final String SESSION_USERFIRSTNAME 		= "User-FirstName";
	public static final String SESSION_USERLASTNAME 		= "User-LastName";
	public static final String SESSION_USEREMAIL 			= "User-Email";
	public static final String INSHOP_REASON_CODE 			= "inshopReasonCode";
	public static final String SERVICE_TYPE_CODE 			= "serviceTypeCode";
	
	public static final String MENU_NAME = "menuName";
	
	public static final String[] REQUIRED_1_0_PARAMS = { 
			REQUEST_HEADER_SSO,
			REQUEST_QUERY_WORKORDERID, 
			REQUEST_QUERY_SESSIONID,
			REQUEST_QUERY_ROADNUMBER, 
			REQUEST_QUERY_CLIENTURL,
			REQUEST_QUERY_WORKORDERNUMBER,
			REQUEST_QUERY_FLAG,
			REQUEST_QUERY_INFLAG}; 
	
	
	public static String BASE_URL =  Play.application().configuration().getString("mm.api.baseurl");
	public static String BASE_COMMON_URL =  Play.application().configuration().getString("mm.api.common.baseurl");
	public static String GET_WORK_ORDER_URL =  Play.application().configuration().getString("get_workorders_url");
	public static String GET_REASON_CODE_URL =  Play.application().configuration().getString("get_reason_code_url");
	public static String GET_CUSTOMERLIST_URL =  Play.application().configuration().getString("get_customer_list_url");
	public static String GET_AAR_ASSET_URL =  Play.application().configuration().getString("get_aar_list_url");
	public static String CREATE_WORKORDER_URL =  Play.application().configuration().getString("create_workorder_url");
	public static final String GET_SS_BY_LOCOID_URL = Play.application().configuration().getString("get_serv_sheet_list_by_locoId_url");
	public static final String GET_WORKORDER_DETAIL_URL = Play.application().configuration().getString("get_workorder_detail_by_id");
	public static final String GET_SS_BY_WOID_URL = Play.application().configuration().getString("get_serv_sheet_list_by_woId_url");
	public static final String GET_DEFECTS_BY_WOID_URL = Play.application().configuration().getString("get_defects_by_woId_url");
	public static final String GET_DEFECTS_BY_SSID_URL = Play.application().configuration().getString("get_defects_by_ssId_url");
	public static final String ADD_SS_URL = Play.application().configuration().getString("add_service_sheet_url");
	public static final String REMOVE_SS_URL = Play.application().configuration().getString("remove_service_sheet_url");
	public static final String ADD_COMMENT_URL = Play.application().configuration().getString("add_service_sheet_comment_url");
	public static final String ADD_WORKORDER_DEFECT_URL = Play.application().configuration().getString("add_workorder_defect_url");
	public static final String DELETE_WORKORDER_URL = Play.application().configuration().getString("delete_workorder_by_id_url");
	public static final String UPDATE_WORKORDER_URL =  Play.application().configuration().getString("update_workorder_url");
	public static final String UPDATE_DEFECT_URL =  Play.application().configuration().getString("update_defect_url");
	public static final String MANDATORY_SS_URL =  Play.application().configuration().getString("mandatory_service_sheets_url");

	public static final String AUTH_TYPE = Play.application().configuration().getString("mm.api.authtype");
	public static final String USER_NAME = Play.application().configuration().getString("mm.api.user");
	public static final String PASSWORD = Play.application().configuration().getString("mm.api.passwd");

	public static final String GET_USER_ATTR_URL = Play.application().configuration().getString("GET_USER_ATTR_URL");
	public static final String GET_USER_PROFILE_URL = Play.application().configuration().getString("GET_USER_PROFILE_URL");
	public static final String GET_USER_DETAILS_URL = Play.application().configuration().getString("GET_USER_DETAILS_URL");
	public static final String GET_MATERIAL_DETAILS_URL = Play.application().configuration().getString("GET_MATERIAL_DETAILS_URL");
	public static final String VALIDATE_MATERIAL_FOR_TWO_URL = Play.application().configuration().getString("VALIDATE_MATERIAL_FOR_TWO_URL");

	public static final String GET_SERVICE_ORG_LIST_URL = Play.application().configuration().getString("get_service_org_list_url");
	public static final String GET_TRACK_DETAIL_URL = Play.application().configuration().getString("get_track_detail_url");

	public static final String GET_USER_PROFILE_DETAIL_URL = Play.application().configuration().getString("GET_USER_PROFILE_DETAIL_URL");
	public static final String ASSIGN_WORKORDER_URL = Play.application().configuration().getString("assign_work_order_url");
	public static final String VALIDATE_WORKORDER_DATE_URL = Play.application().configuration().getString("validate_workorder_date_url");
	public static final String SCHEDULE_INSHOP_DATE = "scheduledInshopDate";
	public static final String REPAIR_KIT_URL = Play.application().configuration().getString("repair_kit_for_serviceItem_URL");
	public static final String SERVICE_ITEM_ID_LIST = "serviceItemIds[]";
	public static final String GET_DEFAULT_WORKORDER_COMMENT_URL = Play.application().configuration().getString("default_workorder_comment_URL");
	public static final String ADD_REPAIRKIT_TO_SERVICEITEM_URL = Play.application().configuration().getString("add_RepairKits_To_ServiceItem");
	public static final String LAST_INSHOP_SUMMARY_URL = Play.application().configuration().getString("last_insop_summary_URL");
	public static final String TRANSFER_WO_URL = Play.application().configuration().getString("transfer_workorder_URL");
	public static final String TRANSFER_WO_MATERIAL_NEW_ORG = Play.application().configuration().getString("transfer_pending_material_to_new_organization_url");
	public static final String SS_WHY_DETAILS_URL = Play.application().configuration().getString("ss_why_details");
	public static final String GET_WO_COMMENTS_CONFIG_URL = Play.application().configuration().getString("get_wo_comments_config");
	public static final String ADD_WO_COMMENTS_FIELD_CONFIG_URL = Play.application().configuration().getString("add_wo_comment_field_config");
	public static final String EDIT_WO_COMMENTS_FIELD_CONFIG_URL = Play.application().configuration().getString("edit_wo_comment_field_config");
	public static final String SAVE_WO_COMMENTS_FIELD_CONFIG_URL = Play.application().configuration().getString("save_wo_comment_fields_config");
	public static final String RX_SHEETS_FOR_LOCOS_URL = Play.application().configuration().getString("get_rx_sheets_for_locos_URL");
	public static final String LAST_WORKORDER_INFO_URL = Play.application().configuration().getString("get_last_wo_info_URL");
	public static final String WO_COMMENT_HISTORY_URL = Play.application().configuration().getString("get_wo_comment_history");
	public static final String FMISHEETS_FOR_LOCOS_URL = Play.application().configuration().getString("get_fmi_sheets_locos");
	public static final String AVG_DIS_FRAME_GROOVE_URL = Play.application().configuration().getString("get_avgdist_frame_groove");
	public static final String NEXT_RM_DATE_URL = Play.application().configuration().getString("get_next_rm_date");
	public static final String LAST_COMMUNICATION_DATE_URL = Play.application().configuration().getString("get_last_communication_date");
	public static final String EDIT_SERVICESHEET_URL = Play.application().configuration().getString("edit_servicesheets");
	public static final String TASK_SIGNOFF_STATUS_URL = Play.application().configuration().getString("task_signoff_status");
	public static final String DUPLICATE_SERVICESHEET_URL = Play.application().configuration().getString("duplicate_service_sheet");
	public static final String VALIDATE_FMI_SOFTWARE_SS_URL = Play.application().configuration().getString("validate_fmi_software_ss_url");
	public static final String WORKORDER_STATUS_URL = Play.application().configuration().getString("workorder_status_url");

	public static final String CHECK_TRANSFER_WO_URL = Play.application().configuration().getString("check_workorder_transfers_URL");
	public static final String VALIDATE_FMI_SOFTWARE_URL = Play.application().configuration().getString("validate_fmi_software_url");
	
	public static final String GETS_SERVICESHEETS_TASKCOUNTS = Play.application().configuration().getString("servicesheets_and_taskCount_for_WO_url");
	
	public static final String AUTOSIGNOFF_URL = Play.application().configuration().getString("autosignoff_URL");
	
	public static long TIMEOUT_GET = Play.application().configuration().getLong("TIMEOUT_GET").longValue();
	public static long TIMEOUT_POST = Play.application().configuration().getLong("TIMEOUT_POST").longValue();
	
	public static final String STORAGE_SERVICE = Play.application().configuration().getString("service.storage.baseurl");
	public static final String GETLOCOMOTIVE_ALL_DETAILS_URL = Play.application().configuration().getString("locomotive_details");
	
	public static final String SS_REMOVAL_REASON_CODES_URL = Play.application().configuration().getString("ss_removal_reason_codes");
	public static final String GET_SERVICE_SHEET_MATERIAL_STATUS_URL = Play.application().configuration().getString("service_sheet_material_status_URL");
	
	public static final String GET_ALL_SERVICE_TYPES_FOR_EDIT_SS_URL = Play.application().configuration().getString("get_all_service_types_for_edit_ss_URL");
	public static final String GET_ALL_SERVICE_ITEMS_URL = Play.application().configuration().getString("get_all_service_items_URL");
	public static final String GET_MENU_TITLE_BY_NAME = Play.application().configuration().getString("get_menu_title_by_name_url");
	public static final String GET_WORKORDER_STATUS_DATES_URL = Play.application().configuration().getString("get_workorder_status_dates_url");
	
	public static final String GET_ALL_SERVICE_ITEMS_VALID_FOR_LOCO_AND_ORG_URL = Play.application().configuration().getString("get_all_service_items_valid_for_loco_and_org_URL");
	public static final String GET_SERVICE_SHEET_HISTORY_URL = Play.application().configuration().getString("get_service_sheet_history_url");

	public static final String UPDATE_ODOMETER_READING_URL = Play.application().configuration().getString("update_odometer_reading_url");
	public static final String UPDATE_OOSLOCATION_URL = Play.application().configuration().getString("update_oos_location_url");
	public static final String UPDATE_WO_STATUS_DATETIME_URL = Play.application().configuration().getString("update_wo_status_datetime_url");
	public static final String UPDATE_CURRENT_WO_STATUS_DATETIME_URL = Play.application().configuration().getString("update_current_wo_status_datetime_url");
	public static final String CLOSE_WORKORDER_URL =  Play.application().configuration().getString("close_workorder_url");
	public static final String CHECK_DOWNLOAD_PROCESS_URL =  Play.application().configuration().getString("check_downloadprocess_url");
	public static final String VALIDATE_MATERIAL_PICKED_URL = Play.application().configuration().getString("validate_material_picked_url");
	public static final String GET_SERVICESHEET_POSITIONS_URL = Play.application().configuration().getString("get_servicesheet_positions_url");
}