package util;
import java.util.HashMap;

public enum Permissions {
	
	ASSIGN("PAGE.FLEET_VIEW.BTN.ASSIGN"),
	UPDATE("PAGE.FLEET_VIEW.BTN.UPDATE"),
	DELETE("PAGE.FLEET_VIEW.BTN.DELETE"),
	CREATE("PAGE.FLEET_VIEW.BTN.CREATE"),
	TRANSFER("PAGE.FLEET_VIEW.BTN.TRANSFER"),
	FLEET_VIEW("PAGE.FLEET_VIEW"),
	MAND_SS_DELETE("PAGE.WORKSCOPE.BTN.SERVICESHEET.DELETE"),
	UPDATE_WO("PAGE.FLEET_VIEW.BTN.UPDATEWO");
	
	private String value;
	
	private static final HashMap<String,Permissions> permissionMap = new HashMap<>();
	
	static{
		for(Permissions permission:values()){
			permissionMap.put(permission.getValue(), permission);
		}
	}
	
	Permissions(String value){
		
		this.value = value;
	}
	
	public String getValue(){
		return value;
	}
 
	public static Permissions getByValue(String val){
		return permissionMap.get(val);
	}
	
	
}