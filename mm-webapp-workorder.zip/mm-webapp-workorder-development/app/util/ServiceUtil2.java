/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2013 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *
 ********************************************************************************/

/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.function.Supplier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.ge.transportation.eservices2.domainobjects.services.WorkorderResponse;

import play.Play;
import play.libs.F.Promise;
import play.libs.Json;
import play.libs.ws.WS;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;
import play.mvc.Result;

/**
 * 
 * @author 212359409
 *
 */

public class ServiceUtil2 {

  	private static final Logger logger = LoggerFactory.getLogger(ServiceUtil2.class);
	
	
	  public static String callSynchronousGetService(String url, String contentType, Map<String, String> queryParams,Map<String, String> headers)
	            throws IOException {
	        logger.debug(String.format("#SYNCHRONOUS# ServiceUtil.callGetService url[%s] invoked", url));

	        long startTime = System.currentTimeMillis();

	        WSRequest wsreqHolder = WS.url(url);
	        setQueryParams(wsreqHolder, queryParams);
	     
	        for (String key : headers.keySet()) {
	        	wsreqHolder.setHeader(key,headers.get(key));
			}

	        Promise<WSResponse> response = wsreqHolder.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)      		 
	                 								   .setHeader(WorkorderConstants.ACCEPT, contentType)
	                 								   .setAuth(WorkorderConstants.USER_NAME,WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
	                 								   .get();
	        		/*wsreqHolder.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
	                .setHeader(WorkorderConstants.ACCEPT, contentType).get();*/
	       

	        String responseString = logAndProcessResponse(url, response, WorkorderConstants.TIMEOUT_GET);

	        logger.trace("URL >> " + url + " :: Time Taken >> " + (System.currentTimeMillis() - startTime));
	        return responseString;
	    }
	  
	  
	  public static String callSynchronousPostService(String url, String contentType, String request, Map<String, String> queryParams,Map<String, String> headers)
	            throws IOException {
	       
		  logger.debug(String.format("#SYNCHRONOUS# ServiceUtil.callPostService url[%s] invoked", url));
	        long startTime = System.currentTimeMillis();
	        logger.trace("made a call  " + url + " " + request);
	        WSRequest wsreqHolder = WS.url(url);
	        setQueryParams(wsreqHolder, queryParams);
	        wsreqHolder.setHeader(WorkorderConstants.CONTENT_TYPE, contentType);
	        wsreqHolder.setHeader(WorkorderConstants.ACCEPT, contentType);
	        wsreqHolder.setAuth(WorkorderConstants.USER_NAME,
					WorkorderConstants.PASSWORD, WSAuthScheme.BASIC);
	        for (String key : headers.keySet()) {
	        	wsreqHolder.setHeader(key,headers.get(key));
			}
	        Promise<WSResponse> newResponse = wsreqHolder.post(request);

	        String responseString = logAndProcessResponse(url, newResponse, WorkorderConstants.TIMEOUT_POST);

	        logger.trace("URL >> " + url + " :: Time Taken >> " + (System.currentTimeMillis() - startTime));
	        return responseString;
	    }
	  
	  

    public static Promise<WSResponse> callGetService(String url, String contentType, Map<String, String> queryParams) {
        WSRequest wsreqHolder = play.libs.ws.WS.url(url);
        setQueryParams(wsreqHolder, queryParams);

        return wsreqHolder.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
                .setHeader(WorkorderConstants.ACCEPT, contentType).get();
    }

    public static Promise<WSResponse> callGetService(String url, String contentType) {
        return callGetService(url, contentType, Collections.<String, String> emptyMap());
    }

   
    
    /**
     * 
     *
     * @param response
     * @param waitTime
     * @return
     * @throws IOException
     */
    private static String getDecompressedResponse(Promise<WSResponse> response, long waitTime) throws IOException {
        StringBuilder responseString = new StringBuilder();
        InputStream is = null;

     /*   if (waitTime == 0) {
            is = response.get().getBodyAsStream();
        } else {*/
            is = response.get(waitTime).getBodyAsStream();
       // }

        // Decompressing the Response
     
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String test = "";
        while ((test = br.readLine()) != null) {
            responseString.append(test);
        }
        return responseString.toString();
    }
    
    /*public static String getResponseBody(String url, WSResponse resp) throws IOException {
        return getDecompressedResponse(resp);
    }*/

    /**
     * Method to handle Post Service calls
     *
     * @param url
     * @param contentType
     * @param request
     * @return response String
     */
    public static Promise<WSResponse> callPostService(String url, String contentType, String request) {
        return callPostService(url, contentType, request, Collections.<String, String> emptyMap());
    }

    public static Promise<WSResponse> callPostService(String url, String contentType, String request,
            Map<String, String> queryParams) {
        WSRequest wsreqHolder = play.libs.ws.WS.url(url);
        setQueryParams(wsreqHolder, queryParams);
        wsreqHolder.setHeader(WorkorderConstants.CONTENT_TYPE, contentType);
        wsreqHolder.setHeader(WorkorderConstants.ACCEPT, contentType);
        return wsreqHolder.post(request);
    }

    private static void setQueryParams(WSRequest request, Map<String, String> params) {
        for (Map.Entry<String, String> e : params.entrySet()) {
            if (e.getKey() != null && e.getValue() != null) {
                request.setQueryParameter(e.getKey(), e.getValue());
            }
        }
    }
    
    
    private  static String logAndProcessResponse(String url, Promise<WSResponse> response, long timeOut)
            throws IOException {
     
    	if (response != null) {
              //  logBytesTransferred(response, url, timeOut);
                return getDecompressedResponse(response, timeOut);
            }
        
        return null;
    }
    
    
    
    private static  void logBytesTransferred(Promise<WSResponse> response, String url, long waitTime) {
        if (waitTime == 0) {
            logger.debug("URL >> " + url + " :: Bytes transferred >> " + response.get(waitTime).getBody().getBytes().length);
        } else {
            logger.debug("URL >> " + url + " :: Bytes transferred >> "
                    + response.get(waitTime).getBody().getBytes().length);
        }
    }

    
    
    @SuppressWarnings("unchecked")
	public static String convertStreamToString(InputStream stream ,Class<?> clazz){
    	String resp = null;
    		try {
    			Object readValue = Json.mapper().readValue(stream, clazz);
    			
				resp =  Json.mapper().writeValueAsString(readValue);
			} catch (IOException e) {
			logger.error("Exception occured in ");
			}
    	return resp;
    }
    
    
    
    


    /**
     * Method to handle put service calls
     *
     * @param url
     * @param contentType
     * @param request
     * @return response String
     */
    public static Promise<WSResponse> callPutService(String url, String contentType, String request) {
        return play.libs.ws.WS.url(url).setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
                .setHeader(WorkorderConstants.ACCEPT, contentType).put(request);
    }

    /**
     * Method to handle Delete Service calls
     *
     * @param url
     * @param contentType
     * @return response String
     */
   /* public static Promise<WS.Response> callDeleteService(String url, String contentType) {
        return WS.url(url).setHeader(EservicesConstants.CONTENT_TYPE, contentType)
                .setHeader(EservicesConstants.ACCEPT, contentType).delete();
    }*/

    /*public static Function<Response, String> newSimpleStringFunction(final String url) {
        return new Function<Response, String>() {
            @Override
            public String apply(Response resp) throws Throwable {
                return getResponseBody(url, resp);
            }
        };
    }*/
    
   /* public static <T> Function<Response, T> newSimpleFunction(final String url, final Class<T> clazz) {
        return new Function<Response, T>() {
            @Override
            public T apply(Response resp) throws Throwable {
                String rsBody = getResponseBody(url, resp);
                return MAPPER.readValue(rsBody, clazz);
            }
        };
    }
    public static <T> Function<Response, List<T>> newListOfFunction(final String url, final Class<T> clazz) {
        return new Function<Response, List<T>>() {
            @Override
            public List<T> apply(Response resp) throws Throwable {
                String rsBody = getResponseBody(url, resp);
                return MAPPER.readValue(rsBody, TypeFactory.defaultInstance().constructCollectionType(List.class, clazz));
            }
        };
    }*/
    
   /* public static String createJsonRequest(Object inputObject) throws IOException {
        return MAPPER.writeValueAsString(inputObject);
    }

    public static <T> T castResponse(String respString, Class<T> clazz) throws IOException {
        return MAPPER.readValue(respString, clazz);
    }

    public static <T> List<T> deserializeAsList(String respString, Class<T> elementClass) throws IOException {
        TypeFactory t = TypeFactory.defaultInstance();
        List<T> rslt = MAPPER.readValue(respString, t.constructCollectionType(List.class, elementClass));
        return rslt;
    }

    public static <T> T deserialize(String respString) throws IOException {
        T rslt = MAPPER.readValue(respString, new TypeReference<T>() {
        });
        return rslt;
    }
*/
}
