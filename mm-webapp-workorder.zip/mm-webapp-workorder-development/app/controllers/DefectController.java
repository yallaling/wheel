package controllers;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ge.transportation.eservices2.domainobjects.services.CreateDefectRequest;
import com.ge.transportation.eservices2.domainobjects.services.DefectSheet;
import com.ge.transportation.eservices2.domainobjects.services.DefectSheetResponse;
import com.ge.transportation.eservices2.domainobjects.services.SsResponse;

import play.data.Form;
import play.libs.F.Promise;
import play.libs.Json;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSResponse;
import play.mvc.Result;
import util.WorkorderConstants;

public class DefectController extends BaseController {

	
	public Promise<Result> getDefectsByWorkorderId(String workorderId, String customerId){

		 Promise<WSResponse> ssResponse = null;
		 
		 String url = WorkorderConstants.BASE_URL+WorkorderConstants.GET_DEFECTS_BY_WOID_URL;
		 
		Map<String, String> queryParams = new HashMap<String,String>();
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);
	 
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, DefectSheetResponse.class);
		
	}
	
	public Promise<Result> addWorkorderDefect() {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_WORKORDER_DEFECT_URL;
		
		 Form<models.DefectSheet> addDefectForm = Form.form(models.DefectSheet.class).bindFromRequest();
		 models.DefectSheet defectForm = addDefectForm.get();
	
		 CreateDefectRequest req = new CreateDefectRequest();
		 DefectSheet defect = new DefectSheet();
		 defect.setServiceWorkorderId(Long.parseLong(defectForm.getServiceWorkorderId()));
		 defect.setDefectComments(defectForm.getDefectComments());
		 defect.setWorkorderNumber(defectForm.getWorkorderNumber());
		 req.setUpdatedBy(Long.parseLong(defectForm.getUpdatedBy()));
		 req.setCreatedBy(Long.parseLong(defectForm.getCreatedBy()));	 
		 req.setDefectSheet(defect);
		 			
		 String createDefect = null;
			 
			  try {
				  createDefect = Json.mapper().writeValueAsString(req);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			

/*		ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
				.post(createDefect);
				
		return ssResponse.map(resp -> {

			DefectSheetResponse servicesheetResp = Json.mapper().readValue(resp.getBodyAsStream(),
					DefectSheetResponse.class);
			return ok(Json.mapper().writeValueAsString(servicesheetResp));
		});*/
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, createDefect, DefectSheetResponse.class);

	}

	public Promise<Result> updateWorkorderDefect() {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_DEFECT_URL;
		
		 Form<models.DefectSheet> updateDefectForm = Form.form(models.DefectSheet.class).bindFromRequest();
		 models.DefectSheet defectForm = updateDefectForm.get();
		 CreateDefectRequest req = null;
		 if(null!=defectForm.getUpdateForShopSumm() && "Y".equalsIgnoreCase(defectForm.getUpdateForShopSumm())){
			 req = new CreateDefectRequest();
			 DefectSheet defect = new DefectSheet();
			 defect.setDefectId(Long.parseLong(defectForm.getDefectId()));
			 defect.setShowOnShopSummary(defectForm.getShowOnShopSummary());
			 req.setUpdatedBy(Long.parseLong(defectForm.getUpdatedBy()));
			 req.setUpdateShowOnShopSummary(defectForm.getUpdateForShopSumm());
			 req.setDefectSheet(defect);
		 }else{
			req = new CreateDefectRequest();
			 
			 DefectSheet defect = new DefectSheet();
			 defect.setDefectId(Long.parseLong(defectForm.getDefectId()));
			 defect.setActionComments(defectForm.getActionComments());
			 defect.setCompleteDefect(defectForm.getCompleteDefect());
			 defect.setCauseCode(defectForm.getCauseCode());
			 defect.setRemedyCode(defectForm.getRemedyCode());
			 defect.setDefectOriginType(defectForm.getDefectOriginType());
			 defect.setCustomerId(Long.parseLong(defectForm.getCustomerId()));
			 req.setUpdatedBy(Long.parseLong(defectForm.getUpdatedBy()));
			 req.setCreatedBy(Long.parseLong(defectForm.getCreatedBy()));
			 req.setDefectSheet(defect);
		 }
		 			
		 String updateDefect = null;
			 
			  try {
				  updateDefect = Json.mapper().writeValueAsString(req);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, updateDefect, DefectSheetResponse.class);

	}

}
