package controllers;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import com.ge.transportation.eservices2.domainobjects.services.ShopResponse;
import com.ge.transportation.eservices2.domainobjects.services.TrackPositionDirectionResponse;

import play.cache.CacheApi;
import play.libs.F.Promise;
import play.mvc.Http.Context;
import play.mvc.Result;
import play.mvc.With;
import util.WorkorderConstants;

@With(AuthController.class)
public class CustomerController extends BaseController{
	
	@Inject CacheApi cache;
	
	public Promise<Result> serviceOrgListForCustomer(String id) {
	
			String url = WorkorderConstants.BASE_URL
				+ WorkorderConstants.GET_SERVICE_ORG_LIST_URL;

		String customerId  = (id == null || "".equals(id)) ?Context.current().session().get(WorkorderConstants.SESSION_CUSTOMERID):id;
			
		Map<String, String> queryParams = new HashMap<String,String>();
	
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);
		
		String key = "orgList"+customerId;
		return cache.getOrElse(key, () ->
		callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ShopResponse.class),60*24*60);
		//return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ShopResponse.class);
	}
	
	public Promise<Result> getTrackDetailByServiceOrgId(String id) {
		
		String url = WorkorderConstants.BASE_URL
			+ WorkorderConstants.GET_TRACK_DETAIL_URL;
		
	Map<String, String> queryParams = new HashMap<String,String>();
	queryParams.put(WorkorderConstants.SERVICE_ORG_ID, id);
	
	
	return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, TrackPositionDirectionResponse.class);
}


}
