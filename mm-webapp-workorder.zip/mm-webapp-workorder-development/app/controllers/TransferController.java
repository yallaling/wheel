package controllers;

import java.util.HashMap;
import java.util.Map;

import models.TransferWorkorderDTO;
import play.data.Form;
import play.libs.F.Promise;
import play.libs.Json;
import play.libs.ws.WSResponse;
import play.mvc.Result;
import util.WorkorderConstants;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.ge.transportation.eservices2.domainobjects.services.TransferRequest;
import com.ge.transportation.eservices2.domainobjects.services.TransferResponse;
import com.ge.transportation.eservices2.domainobjects.services.TransferWorkorder;
import com.ge.transportation.eservices2.domainobjects.services.ValidateSoftwareFmiResponse;
import com.ge.transportation.eservices2.domainobjects.services.ValidateTransferWoSequenceResponse;

public class TransferController extends BaseController {

	public Promise<Result> transferWorkorder() {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.TRANSFER_WO_URL;
		
		 Form<TransferWorkorderDTO> transferWoForm = Form.form(TransferWorkorderDTO.class).bindFromRequest();
		 TransferWorkorderDTO transferWorkorder = transferWoForm.get();
	
		 TransferWorkorder transferWo = new TransferWorkorder();
		 transferWo.setDestinationInshopDate(transferWorkorder.getDestinationInshopDate());
		 transferWo.setDestinationIncomingDate(transferWorkorder.getDestinationIncomingDate());
		 transferWo.setDestinationOrg(null!=transferWorkorder.getDestinationOrg()?Long.parseLong(transferWorkorder.getDestinationOrg()):null);
		 transferWo.setDestinationStatus(transferWorkorder.getDestinationStatus());
		 transferWo.setDirection(transferWorkorder.getDirection());
		 transferWo.setOriginInshopDate(transferWorkorder.getOriginInshopDate());
		 transferWo.setOriginOutshopDate(transferWorkorder.getOriginOutshopDate());
		 transferWo.setPosition(transferWorkorder.getPosition());
		 transferWo.setTrack(transferWorkorder.getTrack());
		 transferWo.setTransitEndTime(transferWorkorder.getTransitEndTime());
		 transferWo.setTransitStartTime(transferWorkorder.getTransitStartTime());
		 transferWo.setOriginOrg(null!=transferWorkorder.getOriginOrg()?Long.parseLong(transferWorkorder.getOriginOrg()):null);
		 transferWo.setWorkorderId(null!=transferWorkorder.getWorkorderId()?Long.parseLong(transferWorkorder.getWorkorderId()):null);
		
		 com.ge.transportation.eservices2.domainobjects.services.ServiceSheet ss = new com.ge.transportation.eservices2.domainobjects.services.ServiceSheet();
		TransferRequest request = new TransferRequest();
		request.setTransferWorkorder(transferWo);
		request.setUpdatedBy(null!=transferWorkorder.getUpdatedBy()?Long.parseLong(transferWorkorder.getUpdatedBy()):null);
		String transferWoRequest = null;
		 
		try {
		  transferWoRequest = Json.mapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, transferWoRequest, TransferResponse.class);

	}
	
	public Promise<Result> checkWorkorderTransfers(String workorderId) {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.CHECK_TRANSFER_WO_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);

		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ValidateTransferWoSequenceResponse.class);

	}
	
	public Promise<Result> validateFmiSoftwareOnTransfer(String workorderId) {

        String url = WorkorderConstants.BASE_URL + WorkorderConstants.VALIDATE_FMI_SOFTWARE_URL;

        Map<String, String> queryParams = new HashMap<String, String>();
        queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);

        return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ValidateSoftwareFmiResponse.class);

    }
	
	public Promise<Result> transferPendingMaterialToNewOrganization() {
		String transferMaterialJson = request().body().asJson().toString();
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.TRANSFER_WO_MATERIAL_NEW_ORG;
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, transferMaterialJson, Object.class);
	}
}
