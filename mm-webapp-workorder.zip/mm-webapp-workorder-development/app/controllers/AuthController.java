package controllers;

import static util.WorkorderConstants.REQUEST_HEADER_SSO;
import static util.WorkorderConstants.REQUEST_QUERY_SESSIONID;
import static util.WorkorderConstants.REQUEST_TRANS_NAME;
import static util.WorkorderConstants.SESSION_SSO;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ge.transportation.eservices2.domainobjects.services.UserAttributeType;
import com.ge.transportation.eservices2.domainobjects.services.UserDetailsRequest;
import com.ge.transportation.eservices2.domainobjects.services.UserDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.services.UserProfileType;

import models.UserDetails;
import models.UserProfile;
import play.libs.F;
import play.libs.F.Promise;
import play.libs.Json;
import play.mvc.Action;
import play.mvc.Http;
import play.mvc.Http.Context;
import play.mvc.Result;
import play.mvc.With;
import util.Permissions;
import util.ServiceUtil2;
import util.WorkorderConstants;


public class AuthController extends Action.Simple {

private static final   Logger logger = LoggerFactory.getLogger(AuthController.class);

       @Override
       public Promise<Result> call(Context ctx) throws Throwable {
	       String requestJSessionId = ctx.request().getQueryString(REQUEST_QUERY_SESSIONID);
	       String transName = ctx.request().getQueryString(REQUEST_TRANS_NAME);
	       String sessionJSessionId = ctx.session().get(REQUEST_QUERY_SESSIONID);
       if(requestJSessionId!=null &&
                       sessionJSessionId!=null && !requestJSessionId.equals(sessionJSessionId)) {
               logger.debug("Request with different JSESSIONID. Clearing Play session.");
               ctx.session().clear();
       }

       if(requestJSessionId!=null)
       {
    	   ctx.session().clear();
       }
       String customerId = ctx.session().get(WorkorderConstants.SESSION_CUSTOMERID);
    
       String sessionSSO = ctx.session().get(SESSION_SSO);
      
    
       logger.debug("SSO from session: " + sessionSSO);
       logger.debug("JSession ID "+requestJSessionId);

       String requestSSO = ctx.request().getHeader(REQUEST_HEADER_SSO);
               if (requestSSO == null || requestSSO.isEmpty()) {
                       logger.debug("SSO missing in request header : '" + REQUEST_HEADER_SSO + "'");
                       return F.Promise.promise(new F.Function0<Result>() {
                @Override
                public Result apply() throws Throwable {
                    return unauthorized("SSO missing in request header");
                }
            });
               }

               logger.debug("request SSO from session: " + requestSSO);

               if(sessionSSO!=null && !sessionSSO.equalsIgnoreCase(requestSSO)) {
                       logger.debug("Unauthorized request from different sso. Please clear your cache.");
                       return F.Promise.promise(new F.Function0<Result>() {
                @Override
                public Result apply() throws Throwable {
                    return unauthorized("SSO is different from the original sso");
                }
            });
               }

             
               
               if (sessionSSO == null) {

                   ctx.session().clear();
                   logger.debug("Resetting session information");

                   loadAllReqHeaders(ctx);
              
                   String USR_PROFILE_DETAIL_URL = WorkorderConstants.BASE_URL + WorkorderConstants.GET_USER_PROFILE_DETAIL_URL;
                   logger.debug("profileUrl :::: "+WorkorderConstants.GET_USER_PROFILE_DETAIL_URL);

                   UserDetailsRequest userRequest = populateUserRequest();
                   String userRequestString = null;
                   try {
                           userRequestString = Json.mapper().writeValueAsString(userRequest);
                   } catch (JsonProcessingException e) {
                           e.printStackTrace();
                   }
                   
                   String response = ServiceUtil2.callSynchronousPostService(USR_PROFILE_DETAIL_URL,
                		   WorkorderConstants.APPLICATION_JSON, userRequestString, Collections.<String,String>emptyMap(),Collections.<String,String>emptyMap());

                   UserDetailsResponse resp = Json.mapper().readValue(response, UserDetailsResponse.class);

                   List<UserAttributeType> userAttributeTypeList = resp.getUserAttributeType();//getUserAttributeType();
                   List<String> userAttribute  = getUserAttributeList(userAttributeTypeList);


                   UserProfile userProfile = new UserProfile();

                   if(resp !=null) {
                           UserProfileType user = resp.getUser();

                           UserDetails userDetails = new UserDetails();
                           if (null != user) {
                                   userDetails.setId(user.getId());
                                   userDetails.setLang(user.getLanguageCode());
                                   userDetails.setSSOId(user.getLoginId());
                                   userDetails.setLocale(UserDetails.langToLocale(user.getLanguageCode()));
                                   userDetails.setFirstName(user.getFirstName());
                                   userDetails.setLastName(user.getLastName());
                                   userDetails.setCustomerId(user.getCustomerId());
                                   userDetails.setOrgId(user.getServiceOrgId());
                                   userDetails.setEmailAddress(user.getEmailAddress());
                                   userProfile.setUserDetails(userDetails);
                                   userProfile.getUserAttributes().addAll(userAttribute);
                           }

                           if (user != null ) {
                                   ctx.session().put(WorkorderConstants.SESSION_USERPROFILE, Json.mapper().writeValueAsString(userProfile));
                                   ctx.session().put(SESSION_SSO, requestSSO);
                                   // Set UserId
                                   try{
                                           ctx.session().put(WorkorderConstants.SESSION_USERID, String.valueOf(userDetails.getId()));
                                           ctx.session().put(WorkorderConstants.SESSION_LOGINID, String.valueOf(userDetails.getSSOId()));
                                           ctx.session().put(WorkorderConstants.SESSION_LANGID, String.valueOf(userDetails.getLang()));
                                           ctx.session().put(WorkorderConstants.SESSION_LOCALE, String.valueOf(userDetails.getLocale()));
                                           ctx.session().put(WorkorderConstants.SESSION_CUSTOMERID, String.valueOf(userDetails.getCustomerId()));
                                           ctx.session().put(WorkorderConstants.SESSION_USERFIRSTNAME, String.valueOf(userDetails.getFirstName()));
                                           ctx.session().put(WorkorderConstants.SESSION_USERLASTNAME, String.valueOf(userDetails.getLastName()));
                                           ctx.session().put(WorkorderConstants.SESSION_USEREMAIL, String.valueOf(userDetails.getEmailAddress()));
                                       

                                   } catch (Exception exception) {
                                           logger.debug("Not able to set UserProfile to Session", exception);
                                           return F.Promise.promise(new F.Function0<Result>() {
                                   @Override
                                   public Result apply() throws Throwable {
                                       return internalServerError("Not able to set UserProfile to Session");
                                   }
                               });


                                   }
                           } else {
                                   logger.debug("Error retrieving user profile info for sso : "+ requestSSO);
                                   return F.Promise.promise(new F.Function0<Result>() {
                           @Override
                           public Result apply() throws Throwable {
                               return internalServerError("Not able to retrieve userprofile");
                           }
                       });
                           }
                   } else {
                           logger.debug("Error retrieving user profile info for sso : "+ requestSSO);
                           return F.Promise.promise(new F.Function0<Result>() {
                   @Override
                   public Result apply() throws Throwable {
                       return internalServerError("Error retrieving user profile info for sso : ");
                   }
               });
                   }

           }

           return delegate.call(ctx);
       }
       
       private UserDetailsRequest populateUserRequest() {
           Http.Request request = Http.Context.current().request();
           Map<String, String[]> headerMap = request.headers();
           String loginId = headerMap.get("SM_SSOID")[0];
           UserDetailsRequest userRequest = new UserDetailsRequest();
        
           userRequest.setLoginId(loginId);
       
           return userRequest;
   }
       
       
       private List<String> getUserAttributeList(List<UserAttributeType> userAttributeTypes) {
           List<String> userAttributeList = new ArrayList<String>();
           if (null != userAttributeTypes && !userAttributeTypes.isEmpty()) {
                   for (UserAttributeType userAttributeType : userAttributeTypes) {
                           if(userAttributeType.getPermit().equalsIgnoreCase("Y")){
                                   Permissions attribute = util.Permissions.getByValue(userAttributeType.getUiCode());
                                   if(attribute != null){
                                   userAttributeList.add(attribute.toString());
                                   }
                           }

                   }
           }
           return userAttributeList;
   }
     


       /**
        * Loads all the Request Headers to session
        * @param ctx
        * @since 1.0
        *
        */
       private void loadAllReqHeaders(Context ctx) {
               Map<String, String[]> reqHeaders = ctx.request().headers();
               for (String headerKey : reqHeaders.keySet()) {
                       if(Arrays.asList(WorkorderConstants.REQUIRED_1_0_PARAMS).contains(headerKey)) {
                               ctx.session().put(headerKey,  ctx.request().getHeader(headerKey));
                       }
               }
       }



       /**
        * Logsout user by clearing session information
        * @return
        * @since 1.0
        *
        */
         @With(AuthController.class)
       public static Result logout() {
           logger.debug("---- Play Inteceptor: logout called ----");
           Http.Context.current().session().clear();
           return ok("logged out");
       }

}     
       
       

               
