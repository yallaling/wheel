package controllers;

import java.util.concurrent.CompletionStage;

import javax.inject.Inject;
import javax.inject.Named;

import akka.actor.ActorRef;
import play.libs.ws.WSClient;
import play.mvc.Controller;
import play.mvc.Result;
import play.mvc.With;
import views.html.*;

@With(AuthController.class)
public class Application extends Controller {

	public Result index() {
	
	return ok(index.render("Your application is ready ........"));
		
	}

	}
