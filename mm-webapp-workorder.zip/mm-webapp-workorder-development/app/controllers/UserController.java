package controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import play.mvc.Http;
import play.mvc.Result;
import play.mvc.With;
import util.WorkorderConstants;

@With(AuthController.class)
public class UserController extends BaseController {

       private static final    Logger logger = LoggerFactory.getLogger(AuthController.class);

           public Result getUserProfile() {
                        logger.debug("get user profile called");
                       String requestSSO = Http.Context.current().request().getHeader(WorkorderConstants.REQUEST_HEADER_SSO);
                       //Http.Context.current().session().clear();
                       //reloadSession(requestSSO);
               logger.debug("########################################################################################################");
               String userProfile = Http.Context.current().session().get(WorkorderConstants.SESSION_USERPROFILE);
               if(userProfile == null || userProfile.isEmpty()) {
                       return unauthorized("unauthorized");
               }
               logger.debug("########################################################################################################");
               return ok(userProfile);
           }

}