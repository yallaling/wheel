package controllers;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpHeaders;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import models.DefectAttachment;
import models.Document;
import models.FileUploadRequest;
import play.libs.ws.WS;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;
import play.mvc.Http;
import play.mvc.Http.MultipartFormData;
import play.mvc.Http.MultipartFormData.FilePart;
import play.mvc.Result;
import services.AttachmentService;
import util.WorkorderConstants;

public class AttachmentsController extends BaseController {
	
	private static final String DELETE_DEFECT_ATTACHMENT  = "workorder/services/v1/defect/deleteattachment";
	private static final   Logger logger = LoggerFactory.getLogger(AttachmentsController.class);
	private static final String CREATED_BY = "createdBy";
	private static final String DEFECT_ATTACHMENT_ADD_DETAILS_URL = "workorder/services/v1/defect/saveDefectAttachment";
	private static final String ATTACHMENT = "attachment";
	private static final String DEFECT_ID = "defectId";
	private static final String FILE_UPLOAD_PATH = "fileUploadPath";
	private static final String FILE_NAME = "fileName";
	public static final Map<String, String> NO_EXTRA_HEADERS = Collections.<String,String>emptyMap(); 
	public Result uploadDefectAttachment() {
		try {
			MultipartFormData body = request().body().asMultipartFormData();
			Map<String, String[]> formData = body.asFormUrlEncoded();
			String fileName = formData.get(FILE_NAME)[0];
			String filePath = formData.get(FILE_UPLOAD_PATH)[0];
			String defectId = formData.get(DEFECT_ID)[0];
			String user=formData.get(CREATED_BY)[0];
			FilePart filePart = body.getFile(ATTACHMENT);
			if (null == filePart) {
				return badRequest("Expecting File data");
			}if(fileName==null || filePath==null || defectId==null || user==null){
				return badRequest("Expecting File data");
			}
			FileUploadRequest fileUploadRequest = createFileUploadRequest(fileName, filePath, filePart);
			AttachmentService service = new AttachmentService();
			WSResponse response = service.uploadAttachment(fileUploadRequest);
			if (isOK(response.getStatus())) {
				String rsBody = response.getBody();
				if (rsBody != null && !rsBody.isEmpty()) {
					logger.debug(WorkorderConstants.BASE_URL + "/" + DEFECT_ATTACHMENT_ADD_DETAILS_URL);
					WSRequest wsRequest = WS.url(WorkorderConstants.BASE_URL + "/" + DEFECT_ATTACHMENT_ADD_DETAILS_URL);
					setHeaders(wsRequest, NO_EXTRA_HEADERS, request().queryString());
					setQueryParams(wsRequest, request().queryString());
			        wsRequest.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD);
			        DefectAttachment defectAttachment = createDefectAttachment(fileName,filePath, defectId, user);
					String attachmentStr = updateTdAttachmentsRequest(defectAttachment);
					response = wsRequest.post(attachmentStr).get(WorkorderConstants.TIMEOUT_POST);
					if(isOK(response.getStatus())){
						return status(response.getStatus(),attachmentStr);
					}else{
						return noContent();
					}
				} else {
					return noContent();
				}
			} else {
				return status(response.getStatus(), response.getBody());
			}
		} catch (Exception exception) {
			return internalServerError();
		}
	}

	private static String updateTdAttachmentsRequest(DefectAttachment defectAttachment) throws IOException,
			JsonGenerationException, JsonMappingException {
		ObjectMapper mapper = new ObjectMapper();
		String jsonString = mapper.writeValueAsString(defectAttachment);
		return jsonString;
	}

	private static DefectAttachment createDefectAttachment(String fileName,
			String filePath, String defectId, String user) {
		DefectAttachment defectAttachment = new DefectAttachment();
		defectAttachment.setFileName(fileName);
		defectAttachment.setFilePath(filePath);
		defectAttachment.setDefectId(defectId);
		defectAttachment.setCreatedBy(user);
		return defectAttachment;
	}

	private static FileUploadRequest createFileUploadRequest(String fileName,
			String filePath, FilePart filePart) throws IOException {
		byte[] bFile = convertToByteArray(filePart);
		Document document = new Document();
		document.setFileName(fileName);
		document.setAttachment(bFile);
		document.setFilePath(filePath);
		FileUploadRequest fileUploadRequest = new FileUploadRequest();
		fileUploadRequest.getDocument().add(document);
		return fileUploadRequest;
	}
	
	public Result downloadDefectAttachment(String fileName,
			String filePath) {
		try {
			logger.debug("Requesting download file "+filePath+"/"+fileName);
			AttachmentService service = new AttachmentService();
			WSResponse response = service.downloadAttachment(fileName, filePath);
			if(null!=response){
				logger.debug(response.getStatus()+"");
				if (isOK(response.getStatus())) {
					File f = new File("temp").getCanonicalFile();
					logger.debug("Creating Temp : "+f.exists());
					if (!f.isDirectory()) {
						logger.debug("Creating Temp folder : "+f.exists());
						f.mkdir();
					}
					logger.debug("Creating file"+f.exists());
					File file = new File(f.getAbsolutePath() + File.separator
							+ fileName);
					convertToFile(response.asByteArray(), file);
					logger.debug("File exists "+file.exists());
					logger.debug("file "+file);
					return ok(file);
				} else {
					return status(response.getStatus(), response.getBody());
				}
			}
		} catch (Exception exception) {
			logger.error(exception.getMessage(),exception);
			return internalServerError();
		}
		return null;
	}
	
	public Result deleteDefectAttachment(String fileName,String filePath, String defectId) {
		try {
			AttachmentService service = new AttachmentService();
			WSResponse response = service.deleteAttachment(fileName, filePath);
			if (isOK(response.getStatus())) {
				String rsBody = response.getBody();
				if (rsBody != null && !rsBody.isEmpty()) {
					
					WSRequest wsRequest = WS
							.url(WorkorderConstants.BASE_URL + "/" + DELETE_DEFECT_ATTACHMENT);
					logger.debug(WorkorderConstants.BASE_URL + "/" + DELETE_DEFECT_ATTACHMENT);
					setHeaders(wsRequest, NO_EXTRA_HEADERS, request()
							.queryString());
					setQueryParams(wsRequest, request().queryString());
					wsRequest.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD);
					DefectAttachment defectAttachment = createDefectAttachment(fileName, filePath, defectId, null);
					String s = updateTdAttachmentsRequest(defectAttachment);
					response = wsRequest.post(s).get(WorkorderConstants.TIMEOUT_GET);
					logger.debug(response.getBody());
					return ok(response.getBody());
				} else {
					return noContent();
				}
			} else {
				return status(response.getStatus(), response.getBody());
			}
		} catch (Exception exception) {
			return internalServerError();
		}
	}
	
	
	private static void setHeaders(WSRequest request, Map<String,String> headers, Map<String,String[]> params) {
		if(null !=headers && headers.isEmpty()){
			request.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
			request.setHeader(HttpHeaders.ACCEPT, "application/json");
			request.setHeader(HttpHeaders.CONTENT_LANGUAGE, "en-US");
			request.setHeader(HttpHeaders.ACCEPT_LANGUAGE, "en-US");
		}
		
		Set<String> reqHeaders = Http.Context.current().session().keySet();
		for (String headerKey : reqHeaders) {
			request.setHeader(headerKey, Http.Context.current().session().get(headerKey));
		}
		
		for (Map.Entry<String,String> e: headers.entrySet()) {
			if (e.getKey() != null && e.getValue() != null) {
				request.setHeader(e.getKey(), e.getValue());
			}
		}
		
		for (Map.Entry<String,String[]> e: params.entrySet()) {
			if (e.getKey() != null && e.getValue() != null && e.getKey().equalsIgnoreCase("uuid")) {
				request.setHeader(e.getKey(), e.getValue()[0]);
			}
		}		
	}
	
	private static byte[] convertToByteArray(FilePart filePart) throws IOException {
		
		File file = new File(filePart.getFile().getPath());
		 FileInputStream fis = null;
		 byte[] bytes = null;
		try {
			fis = new FileInputStream(file);
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
		    byte[] buf = new byte[1024];
		    for (int readNum; (readNum = fis.read(buf)) != -1;) {
		    	bos.write(buf, 0, readNum); 
		    }
	        bytes = bos.toByteArray();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			if(null!=fis){
				fis.close();
			}
		}	
			return bytes;
			
	}

	private static void setQueryParams(WSRequest request, Map<String,String[]> params) {
		for (Map.Entry<String,String[]> e: params.entrySet()) {
			if (e.getKey() != null && e.getValue() != null) {
				request.setQueryParameter(e.getKey(), e.getValue()[0]);
			}
		}
	}


	/**
	 * Returns <code>true</code> if the Http status is 2XX success.
	 * 
	 * @param status
	 * @return
	 * @since 1.0
	 */
	private static boolean isOK(int status) {
		return status >= HttpStatus.SC_OK && status < HttpStatus.SC_MULTIPLE_CHOICES;
	}
	
	private static void convertToFile(byte[] bFile,File file ){
        try {
        logger.debug("Writing to file starts");	
	    FileOutputStream fileOuputStream = new FileOutputStream(file); 
	    fileOuputStream.write(bFile);
	    fileOuputStream.flush();
	    fileOuputStream.close();
	    logger.debug("Writing to file ends");
        }catch(Exception e){
            logger.error(e.getMessage(),e);
        }
	}
}