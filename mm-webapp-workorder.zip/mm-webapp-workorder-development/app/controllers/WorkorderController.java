package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import models.AddRepairKitRequest;
import models.AssignWorkorder;
import models.AutoSignoffAsset;
import models.AutoSignoffEvent;
import models.AutoSignoffRequest;
import models.CreateWorkorder;
import models.Details;
import models.Flag;
import models.Header;
import models.MaterialDetailsForServiceSheet;
import models.PcFmi;
import models.PcFmiItems;
import models.PcNonFmi;
import models.RepairKitsRequest;
import models.RepairKitsResponse;
import models.SSWithRepairtKitResponse;
import models.ServiceItem;
import models.ServiceItemRepairKitRequest;
import models.ServiceItemRepairKitResponse;
import models.ServiceSheetDTO;
import models.ServiceSheetDefectRequest;
import models.ServiceSheetMaterialStatusResponse;
import models.ShoppingCartStatus;
import models.SsRepairKit;
import models.StatusCode;
import models.UpdateWorkorder;
import models.ValidateInshopDate;
import play.Play;
import play.cache.Cache;
import play.cache.CacheApi;
import play.data.Form;
import play.libs.F.Promise;
import play.libs.Json;
import play.mvc.Http.Context;
import play.mvc.Result;
import play.mvc.With;
import util.ServiceUtil2;
import util.WorkorderConstants;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.transportation.eservices2.domainobjects.services.AarRoadListResponse;
import com.ge.transportation.eservices2.domainobjects.services.AssignRequest;
import com.ge.transportation.eservices2.domainobjects.services.AssignResponse;
import com.ge.transportation.eservices2.domainobjects.services.CreateWorkorderRequest;
import com.ge.transportation.eservices2.domainobjects.services.CreateWorkorderResponse;
import com.ge.transportation.eservices2.domainobjects.services.CustomerListResponse;
import com.ge.transportation.eservices2.domainobjects.services.DefaultWoCommentResponse;
import com.ge.transportation.eservices2.domainobjects.services.DefectSheet;
import com.ge.transportation.eservices2.domainobjects.services.DefectSheetResponse;
import com.ge.transportation.eservices2.domainobjects.services.DeleteWorkorderRequest;
import com.ge.transportation.eservices2.domainobjects.services.DeleteWorkorderResponse;
import com.ge.transportation.eservices2.domainobjects.services.LastInshopSummaryResponse;
import com.ge.transportation.eservices2.domainobjects.services.MaterialDetailsResponse;
import com.ge.transportation.eservices2.domainobjects.services.ReasonCodesResponse;
import com.ge.transportation.eservices2.domainobjects.services.ServiceSheet;
import com.ge.transportation.eservices2.domainobjects.services.UpdateWorkorderRequest;
import com.ge.transportation.eservices2.domainobjects.services.UpdateWorkorderResponse;
import com.ge.transportation.eservices2.domainobjects.services.ValidateInshopDateRequest;
import com.ge.transportation.eservices2.domainobjects.services.ValidateInshopDateResponse;
import com.ge.transportation.eservices2.domainobjects.services.Workorder;
import com.ge.transportation.eservices2.domainobjects.services.WorkorderDetailResponse;
import com.ge.transportation.eservices2.domainobjects.services.WorkorderResponse;



@With(AuthController.class)
public class WorkorderController extends BaseController {

	@Inject
	CacheApi cache;
	
	private static final Long ZERO=0L; 

	private static final Logger logger = LoggerFactory.getLogger(WorkorderController.class);

	public Promise<Result> getWorkorders(String id) {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_WORK_ORDER_URL;

		/*String customerId = (id == null || "".equals(id))
				? Context.current().session().get(WorkorderConstants.SESSION_CUSTOMERID) : id;*/
		String customerId = id;
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);

		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, WorkorderResponse.class);
	}

	public Promise<Result> getReasonCodes() {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_REASON_CODE_URL;

		return (Promise<Result>) cache.getOrElse("reasonCodes.key",
				() -> callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON,
						Collections.<String, String> emptyMap(), ReasonCodesResponse.class),
				60 * 24 * 60);
	}

	public Promise<Result> getCustomerList() {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_CUSTOMERLIST_URL;

		return cache.getOrElse("customerList.Key", () -> callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON,
				Collections.<String, String> emptyMap(), CustomerListResponse.class), 60 * 24 * 60);

	}

	public Promise<Result> createWorkorder() {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.CREATE_WORKORDER_URL;

		Form<CreateWorkorder> serviceItemForm = Form.form(CreateWorkorder.class).bindFromRequest();
		CreateWorkorder createWorkorder = serviceItemForm.get();

		CreateWorkorderRequest req = populateCreateWorkorderRequest(createWorkorder);
		String workorderAsString = null;

		try {
			workorderAsString = Json.mapper().writeValueAsString(req);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, workorderAsString,
				CreateWorkorderResponse.class);

	}

	private CreateWorkorderRequest populateCreateWorkorderRequest(CreateWorkorder createWorkorder) {
		CreateWorkorderRequest request = new CreateWorkorderRequest();
		request.setWorkorderStatusCode(createWorkorder.getWorkorderStatus());

		Workorder workorder = new Workorder();
		workorder.setCustomerId(createWorkorder.getCustomerId());
		workorder.setCustomerName(createWorkorder.getCustomerName());
		workorder.setReasonCode(createWorkorder.getReasonCode());
		workorder.setWorkorderComment(createWorkorder.getInshopReason());
		workorder.setRoadNumber(createWorkorder.getRoadNumber());
		workorder.setWorkorderStatus(createWorkorder.getWorkorderStatus());
		workorder.setAarRoad(createWorkorder.getAarRoad());
		workorder.setAuthorizedBy(createWorkorder.getAuthorizedBy());
		workorder.setInShopDate(createWorkorder.getInShopDate());
		workorder.setTrack(createWorkorder.getTrack());
		workorder.setPosition(createWorkorder.getPosition());
		workorder.setDirection(createWorkorder.getDirection());
		workorder.setOutOfShopRepairFlag(createWorkorder.getOutOfShopRepairFlag());
		workorder.setOutOfShopRepairLocation(createWorkorder.getOutOfShopRepairLocation());
		workorder.setOrganisationId(createWorkorder.getOrgId());
		workorder.setIsSmartShop(createWorkorder.getIsSmartShop());
		request.setCreatedBy(createWorkorder.getCreatedBy());
		request.setUpdatedBy(createWorkorder.getUpdatedBy());
		request.setWorkorder(workorder);

		return request;

	}

	public Promise<Result> getAARRoadList(String customerId, String roadNumber) {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_AAR_ASSET_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);
		queryParams.put(WorkorderConstants.ROAD_NUMBER, roadNumber);

		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, AarRoadListResponse.class);

	}

	public Promise<Result> getWorkorderDetail(String workorderId) {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_WORKORDER_DETAIL_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);

		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams,
				WorkorderDetailResponse.class);
	}

	public Promise<Result> deleteWorkorder(String workorderId, String WorkorderNumber, String lastUpdatedBy) {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.DELETE_WORKORDER_URL;

		String workorderAsString = null;

		DeleteWorkorderRequest request = new DeleteWorkorderRequest();

		try {
			if (workorderId != null) {
				request.setWorkorderId(Long.parseLong(workorderId));
				request.setWorkorderNumber(WorkorderNumber);
				request.setLastUpdatedBy(Long.parseLong(lastUpdatedBy));
			}
			workorderAsString = Json.mapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		return callAsyncDeleteService(url, WorkorderConstants.APPLICATION_JSON, workorderAsString,
				DeleteWorkorderResponse.class);

	}

	public Promise<Result> updateWorkorder() {

		String updateWorkorderJson = request().body().asJson().toString();
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_WORKORDER_URL;
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, updateWorkorderJson, Object.class);
	}	

	public Promise<Result> assignWorkorder() {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.ASSIGN_WORKORDER_URL;

		Form<AssignWorkorder> assingWorkorder = Form.form(AssignWorkorder.class).bindFromRequest();
		AssignWorkorder updateWorkorder = assingWorkorder.get();

		AssignRequest req = null;
		String workorderAsString = null;
		SSWithRepairtKitResponse res = new SSWithRepairtKitResponse();

		JsonNode json = null;

		try {
			req = populateAssingWorkorderRequest(updateWorkorder);
			workorderAsString = Json.mapper().writeValueAsString(req);
		} catch (JsonProcessingException e) {

			StringWriter writer = new StringWriter();
			PrintWriter s = new PrintWriter(writer);
			e.printStackTrace(s);
			logger.error("Exception occured in converting UI assign object to request object :" + writer.toString());

		}

		/*
		 * try { String assignResponseAsString =
		 * ServiceUtil2.callSynchronousPostService(url,
		 * WorkorderConstants.APPLICATION_JSON, workorderAsString,
		 * Collections.<String, String> emptyMap()); AssignResponse
		 * assignResponse = Json.mapper().readValue(assignResponseAsString,
		 * AssignResponse.class);
		 * 
		 * List<ServiceSheet> serviceSheetList = null;
		 * 
		 * StringBuilder serviceItemList = new StringBuilder();
		 * 
		 * List<MaterialDetailsForServiceSheet> sheetList = new ArrayList<>();
		 * 
		 * if (assignResponse != null) { serviceSheetList =
		 * assignResponse.getServiceSheet(); if (serviceSheetList != null &&
		 * !serviceSheetList.isEmpty()) { for (ServiceSheet sheet :
		 * serviceSheetList) { MaterialDetailsForServiceSheet ss = new
		 * MaterialDetailsForServiceSheet(); ss.setServiceSheet(sheet); if
		 * (sheet.getServiceItemId() != null &&
		 * !"".equals(sheet.getServiceItemId())) {
		 * serviceItemList.append(sheet.getServiceItemId() + ","); }
		 * sheetList.add(ss); } }
		 * 
		 * //getMaterialForServiceItems(updateWorkorder, serviceItemList,
		 * sheetList); res.setServicesheetWithMaterial(sheetList);
		 * res.setMessage("draft.assigned"); res.setStatus(StatusCode.SUCCESS);
		 * json = Json.toJson(res);
		 * 
		 * }
		 * 
		 * } catch (IOException e) { return noContent(); }
		 */

		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, workorderAsString, AssignResponse.class);

	}

	public Result materialKitForWorkorderId(String locomotiveId, String customerId, String orgId, String workorderId,
			String locale) {

	//	String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_SS_BY_WOID_URL;
		
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GETS_SERVICESHEETS_TASKCOUNTS+"/"+workorderId+"/servicesheets";
		Map<String, String> queryParams = new HashMap<String, String>();
	//	queryParams.put(WorkorderConstants.LOCALE, locale);
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		
		List<ServiceSheet> serviceSheetList = null;

		List<Long> serviceItemList = new ArrayList<>();

		List<MaterialDetailsForServiceSheet> sheetList = new ArrayList<>();

		SSWithRepairtKitResponse response = new SSWithRepairtKitResponse();
		
		com.ge.transportation.eservices2.domainobjects.services.ServiceSheetResponse serviceSheetResponse = null;
		JsonNode json = null;
		List<ServiceSheetDTO> serviceSheetDTOList =  null;
		try {
			
			Map<String, String> headersMap = new HashMap<>();
			String serviceSheetForWorkorder = null;
			headersMap.put("User-LangCode", Context.current().session().get(WorkorderConstants.SESSION_LANGID));
			String key= "tdServiceReq."+workorderId;
			serviceSheetForWorkorder = (String)Cache.get(key); 
			if(serviceSheetForWorkorder== null){
			    serviceSheetForWorkorder = ServiceUtil2.callSynchronousGetService(url,
			            WorkorderConstants.APPLICATION_JSON, queryParams,headersMap);
			    Cache.set(key, serviceSheetForWorkorder,10);
			}
			
			ObjectMapper mapper = new ObjectMapper();
			 mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			
			mapper.configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false);
			
			serviceSheetDTOList =  Arrays.asList(mapper.readValue(serviceSheetForWorkorder, ServiceSheetDTO[].class));
			
			if (serviceSheetDTOList != null && !serviceSheetDTOList.isEmpty()) {
					for (ServiceSheetDTO sheet : serviceSheetDTOList) {
						MaterialDetailsForServiceSheet ss = new MaterialDetailsForServiceSheet();
						ss.setServiceSheet(sheet);
						if (sheet.getServiceItemId() != null && !ZERO.equals(sheet.getServiceItemId())) {
							serviceItemList.add(sheet.getServiceItemId());
						}
						sheetList.add(ss);
					}
				}
			
		}catch (Exception e) {
			response.setMessage("System couldn't retrieve Service sheet for workorder");
			response.setStatus(StatusCode.FAILED);
			return ok(Json.toJson(response));
		}
		
		try{
			setRequestMaterialFlag(workorderId, sheetList);
			
			getMaterialForServiceItems(locomotiveId, customerId, orgId, serviceItemList, sheetList,serviceSheetDTOList,workorderId);

			response.setServicesheetWithMaterial(sheetList);
		}catch(Exception e ){
			response.setMessage("System couldn't retrieve repairt kit information for sheets");
			response.setStatus(StatusCode.FAILED);
			return ok(Json.toJson(response));
		}
		
			response.setMessage("Succesfully retrieved material detail for servicesheets");
			response.setStatus(StatusCode.SUCCESS);
			json = Json.toJson(response);
			return ok(json);
		}
	
	public Result materialKitForUpdateWorkorderId(String locomotiveId, String customerId, String orgId, String workorderId, String serviceSheetIds,
			String locale) {
		List<Long> newServiceSheetIds = convertStringToList(serviceSheetIds);
		
		List<Long> serviceItemList = new ArrayList<>();
		List<MaterialDetailsForServiceSheet> sheetList = new ArrayList<>();
		List<ServiceSheetDTO> serviceSheetDTOFinalList =  new ArrayList<>();
		SSWithRepairtKitResponse response = new SSWithRepairtKitResponse();
		JsonNode json = null;
		if(!newServiceSheetIds.isEmpty())
		{
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.GETS_SERVICESHEETS_TASKCOUNTS+"/"+workorderId+"/servicesheets";
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
			
			List<ServiceSheetDTO> serviceSheetDTOList =  null;
			try {
				
				Map<String, String> headersMap = new HashMap<>();
				String serviceSheetForWorkorder = null;
				headersMap.put("User-LangCode", Context.current().session().get(WorkorderConstants.SESSION_LANGID));
				String key= "tdServiceReq."+workorderId;
				serviceSheetForWorkorder = (String)Cache.get(key); 
				if(serviceSheetForWorkorder== null){
				    serviceSheetForWorkorder = ServiceUtil2.callSynchronousGetService(url,
				            WorkorderConstants.APPLICATION_JSON, queryParams,headersMap);
				    Cache.set(key, serviceSheetForWorkorder,10);
				}
				
				ObjectMapper mapper = new ObjectMapper();
				mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				
				mapper.configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false);
				
				serviceSheetDTOList =  Arrays.asList(mapper.readValue(serviceSheetForWorkorder, ServiceSheetDTO[].class));
				
				if (serviceSheetDTOList != null && !serviceSheetDTOList.isEmpty()) {
					for (ServiceSheetDTO sheet : serviceSheetDTOList) {
						if (newServiceSheetIds.contains(sheet.getId())) {
							serviceSheetDTOFinalList.add(sheet);
							MaterialDetailsForServiceSheet ss = new MaterialDetailsForServiceSheet();
							ss.setServiceSheet(sheet);
							if (sheet.getServiceItemId() != null && !ZERO.equals(sheet.getServiceItemId())) {
								serviceItemList.add(sheet.getServiceItemId());
							}
							sheetList.add(ss);
						}
					}
				}
				
			}catch (Exception e) {
				response.setMessage("System couldn't retrieve Service sheet for workorder");
				response.setStatus(StatusCode.FAILED);
				return ok(Json.toJson(response));
			}
		}
		
		try{
			setRequestMaterialFlag(workorderId, sheetList);
			
			getMaterialForServiceItems(locomotiveId, customerId, orgId, serviceItemList, sheetList,serviceSheetDTOFinalList,workorderId);

			response.setServicesheetWithMaterial(sheetList);
		}catch(Exception e ){
			response.setMessage("System couldn't retrieve repairt kit information for sheets");
			response.setStatus(StatusCode.FAILED);
			return ok(Json.toJson(response));
		}
		
			response.setMessage("Succesfully retrieved material detail for servicesheets");
			response.setStatus(StatusCode.SUCCESS);
			json = Json.toJson(response);
			return ok(json);
		}
	
	
	private List<Long> convertStringToList(String string)
	{
		List<Long> result = new ArrayList<>();
		if (null == string || string.trim().isEmpty()) {
			return result;
		}
		String[] numbers = string.split(",");
		for (String number : numbers) {
			try {
				if (!number.trim().isEmpty()) {
					result.add(Long.parseLong(number.trim()));
				}
			} catch (Exception e) {
				// log about conversion error
			}
		}
		return result;
	}

	public Result materialKitForServiceSheetId(String locomotiveId, String customerId, String orgId, String workorderId,
			String serviceSheetId, String serviceItemId, String serviceSheetTypeCode, String locale) {

		List<MaterialDetailsForServiceSheet> sheetList = new ArrayList<>();
		SSWithRepairtKitResponse response = new SSWithRepairtKitResponse();
		JsonNode json = null;

		try {
			Long serviceItemIdLong = 0L;
			Long serviceSheetIdLong = 0L;
			MaterialDetailsForServiceSheet sheet = new MaterialDetailsForServiceSheet();
			ServiceSheetDTO sheetDTO = new ServiceSheetDTO();
			if (serviceSheetId != null && !serviceSheetId.trim().isEmpty()) {
				serviceSheetIdLong = Long.parseLong(serviceSheetId.trim());
			}
			if (serviceItemId != null && !serviceItemId.trim().isEmpty()) {
				serviceItemIdLong = Long.parseLong(serviceItemId.trim());
			}
			sheetDTO.setId(serviceSheetIdLong);
			sheetDTO.setServiceItemId(serviceItemIdLong);
			sheetDTO.setWorkOrderId(Long.parseLong(workorderId));
			sheet.setServiceSheet(sheetDTO);

			getMaterialForServiceItemsForServiceSheetId(locomotiveId, customerId, orgId, serviceSheetIdLong,
					serviceItemIdLong, serviceSheetTypeCode, sheet, workorderId);
			sheetList.add(sheet);

			response.setServicesheetWithMaterial(sheetList);
		} catch (Exception e) {
			response.setMessage("System couldn't retrieve repairt kit information for sheet");
			response.setStatus(StatusCode.FAILED);
			return ok(Json.toJson(response));
		}

		response.setMessage("Succesfully retrieved material detail for servicesheet");
		response.setStatus(StatusCode.SUCCESS);
		json = Json.toJson(response);
		return ok(json);
	} 

	public Result addRepairKitForServiceSheet() {

		Form<AddRepairKitRequest> addRepairKitForm = Form.form(AddRepairKitRequest.class).bindFromRequest();

		AddRepairKitRequest addRepairKitRequest = addRepairKitForm.get();
		String locomotiveId = addRepairKitRequest.getLocomotiveId();
		String customerId = addRepairKitRequest.getCustomerId();
		String locale = addRepairKitRequest.getLocale();
		String orgId = addRepairKitRequest.getOrgId();
		String userId = addRepairKitRequest.getUserId();
		String ssoId = addRepairKitRequest.getSsoId();
		String workorderId = addRepairKitRequest.getWorkorderId();
		String serviceSheetId = addRepairKitRequest.getServiceSheetId();
		List<SsRepairKit> ssRepairKitList = addRepairKitRequest.getSsRepairKit();
		String requstedStatus = addRepairKitRequest.getRequestedStatus();

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_DEFECTS_BY_SSID_URL;
		ServiceSheetDefectRequest ssDefectRequest = new ServiceSheetDefectRequest();
		Long serviceWorkorderIdLong = null;
		Long serviceSheetIdLong = null;
		Long customerIdLong = null;
		if(workorderId != null)
		{
			serviceWorkorderIdLong = Long.parseLong(workorderId.trim());
		}
		if(serviceSheetId != null)
		{
			serviceSheetIdLong = Long.parseLong(serviceSheetId.trim());
		}
		if(customerId != null)
		{
			customerIdLong = Long.parseLong(customerId.trim());
		}
		ssDefectRequest.setServiceWorkorderId(serviceWorkorderIdLong);
		ssDefectRequest.setCustomerId(customerIdLong);
		ssDefectRequest.setServiceSheetId(serviceSheetIdLong);
		
		
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);

		String defectSheetResponsAsString;
		DefectSheetResponse response = null;
		try {
			String defectRequestAsString = Json.mapper().writerWithDefaultPrettyPrinter().writeValueAsString(ssDefectRequest);
			defectSheetResponsAsString = ServiceUtil2.callSynchronousPostService(url,
					WorkorderConstants.APPLICATION_JSON, defectRequestAsString, Collections.emptyMap(), Collections.emptyMap());
			
			response = Json.mapper().readValue(defectSheetResponsAsString, DefectSheetResponse.class);

			RepairKitsRequest repairKitsRequest = new RepairKitsRequest();
			List<DefectSheet> defectSheetList = response.getDefect();
			for (DefectSheet defectSheet : defectSheetList) {
				for (SsRepairKit ssRepairKit : ssRepairKitList) {
					if (null != defectSheet.getServiceSheetId()) {
						if (defectSheet.getServiceSheetId().equals(ssRepairKit.getServiceSheetId())) {
							Header header = new Header();
							header.setBomId(ssRepairKit.getBomId());
							header.setBomName(ssRepairKit.getBomName());
							header.setDefectId(defectSheet.getDefectId());
							header.setShoppingCartStatus(ShoppingCartStatus.OPEN);
							header.setCoreDue(Flag.NO);
							header.setFloorPick(Flag.NO);
							header.setB2BFlag(Flag.NO);
							header.setOutOfShopRepairFlag(Flag.NO);
							header.setRmFmiSheet("false");
							if (null != userId) {
								header.setCreatedBy(Long.parseLong(userId));
								header.setLastUpdateBy(Long.parseLong(userId));
							}
							if (null != workorderId) {
								header.setServiceWorkOrderId(Long.parseLong(workorderId));
							}
							if (null != locomotiveId) {
								header.setLocomotiveId(Long.parseLong(locomotiveId));
							}
							if (null != orgId) {
								header.setOrganizationId(Long.parseLong(orgId));
							}
							if (null != customerId) {
								header.setCustomerId(Long.parseLong(customerId));
							}
							if (null != userId) {
								header.setCreatedBy(Long.parseLong(userId));
							}
							PcFmiItems fmiItems = ssRepairKit.getPcFmiItems();
							if(fmiItems!=null){
							    header.setRmFmiSheet("true");
							    Details details = new Details();
							    details.setPartsCatelogItemId(fmiItems.getInventoryItemId());
							    details.setItemIdPicked(fmiItems.getInventoryItemId());
							    details.setRequestedQuantity(fmiItems.getQuantity());
							    details.setCreatedBy(Long.parseLong(userId));
							    details.setFmiId(fmiItems.getFmiId());
							    details.setDefectId(defectSheet.getDefectId());
							    details.setShoppingCartDetailsStatus("PENDING_REQUEST");
							    details.setRequestSource("FMIKIT");
							    details.setPartsCatalogItemNumber(fmiItems.getItemName());
							    details.setItemNumberPicked(fmiItems.getItemName());
							    details.setMaterialRequetedBy(userId);
							    header.getDetails().add(details);
							}
							repairKitsRequest.getHeader().add(header);
							
						}
					}
				}
			}

			String addRepairkitUrl = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_REPAIRKIT_TO_SERVICEITEM_URL;
			Map<String, String> headersMap = new HashMap<>();
			headersMap.put("requestedStatus", requstedStatus);
			headersMap.put("locale", locale);
			headersMap.put("ssoId", ssoId);
			String addRepairKitResponsAsString;
			RepairKitsResponse repairKitsresponse = null;
			if (!repairKitsRequest.getHeader().isEmpty()) {
				String requestAsString = Json.mapper().writerWithDefaultPrettyPrinter().writeValueAsString(repairKitsRequest);
				logger.info("add Repairkit Request:  "+requestAsString);
				addRepairKitResponsAsString = ServiceUtil2.callSynchronousPostService(addRepairkitUrl,
						WorkorderConstants.APPLICATION_JSON, requestAsString, queryParams, headersMap);
				logger.info("add Repairkit Response:  "+addRepairKitResponsAsString);
				repairKitsresponse = Json.mapper().readValue(addRepairKitResponsAsString, RepairKitsResponse.class);
				if (null != repairKitsresponse && null != repairKitsresponse.getStatus()) {
					return ok(Json.toJson(repairKitsresponse));
				}
			}
		} catch (IOException e) {
			return internalServerError("err.addrepairkit");
		}
		return internalServerError("err.addrepairkit");
	}
	
	public Result addRepairKit() {

		Form<AddRepairKitRequest> addRepairKitForm = Form.form(AddRepairKitRequest.class).bindFromRequest();

		AddRepairKitRequest addRepairKitRequest = addRepairKitForm.get();
		String locomotiveId = addRepairKitRequest.getLocomotiveId();
		String customerId = addRepairKitRequest.getCustomerId();
		String locale = addRepairKitRequest.getLocale();
		String orgId = addRepairKitRequest.getOrgId();
		String userId = addRepairKitRequest.getUserId();
		String ssoId = addRepairKitRequest.getSsoId();
		String workorderId = addRepairKitRequest.getWorkorderId();
		List<SsRepairKit> ssRepairKitList = addRepairKitRequest.getSsRepairKit();
		String requstedStatus = addRepairKitRequest.getRequestedStatus();

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_DEFECTS_BY_WOID_URL;
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);

		String defectSheetResponsAsString;
		DefectSheetResponse response = null;
		try {
			defectSheetResponsAsString = ServiceUtil2.callSynchronousGetService(url,
					WorkorderConstants.APPLICATION_JSON, queryParams,Collections.<String, String> emptyMap());
			response = Json.mapper().readValue(defectSheetResponsAsString, DefectSheetResponse.class);

			RepairKitsRequest repairKitsRequest = new RepairKitsRequest();
			List<DefectSheet> defectSheetList = response.getDefect();
			for (DefectSheet defectSheet : defectSheetList) {
				for (SsRepairKit ssRepairKit : ssRepairKitList) {
					if (null != defectSheet.getServiceSheetId()) {
						if (defectSheet.getServiceSheetId().equals(ssRepairKit.getServiceSheetId())) {
							Header header = new Header();
							header.setBomId(ssRepairKit.getBomId());
							header.setBomName(ssRepairKit.getBomName());
							header.setDefectId(defectSheet.getDefectId());
							header.setShoppingCartStatus(ShoppingCartStatus.OPEN);
							header.setCoreDue(Flag.NO);
							header.setFloorPick(Flag.NO);
							header.setB2BFlag(Flag.NO);
							header.setOutOfShopRepairFlag(Flag.NO);
							header.setRmFmiSheet("false");
							if (null != userId) {
								header.setCreatedBy(Long.parseLong(userId));
								header.setLastUpdateBy(Long.parseLong(userId));
							}
							if (null != workorderId) {
								header.setServiceWorkOrderId(Long.parseLong(workorderId));
							}
							if (null != locomotiveId) {
								header.setLocomotiveId(Long.parseLong(locomotiveId));
							}
							if (null != orgId) {
								header.setOrganizationId(Long.parseLong(orgId));
							}
							if (null != customerId) {
								header.setCustomerId(Long.parseLong(customerId));
							}
							if (null != userId) {
								header.setCreatedBy(Long.parseLong(userId));
							}
							PcFmiItems fmiItems = ssRepairKit.getPcFmiItems();
							if(fmiItems!=null){
							    header.setRmFmiSheet("true");
							    Details details = new Details();
							    details.setPartsCatelogItemId(fmiItems.getInventoryItemId());
							    details.setItemIdPicked(fmiItems.getInventoryItemId());
							    details.setRequestedQuantity(fmiItems.getQuantity());
							    details.setCreatedBy(Long.parseLong(userId));
							    details.setFmiId(fmiItems.getFmiId());
							    details.setDefectId(defectSheet.getDefectId());
							    details.setShoppingCartDetailsStatus("PENDING_REQUEST");
							    details.setRequestSource("FMIKIT");
							    details.setPartsCatalogItemNumber(fmiItems.getItemName());
							    details.setItemNumberPicked(fmiItems.getItemName());
							    details.setMaterialRequetedBy(userId);
							    header.getDetails().add(details);
							}
							repairKitsRequest.getHeader().add(header);
							
						}
					}
				}
			}

			String addRepairkitUrl = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_REPAIRKIT_TO_SERVICEITEM_URL;
			Map<String, String> headersMap = new HashMap<>();
			headersMap.put("requestedStatus", requstedStatus);
			headersMap.put("locale", locale);
			headersMap.put("ssoId", ssoId);
			String addRepairKitResponsAsString;
			RepairKitsResponse repairKitsresponse = null;
			if (!repairKitsRequest.getHeader().isEmpty()) {
				String requestAsString = Json.mapper().writerWithDefaultPrettyPrinter().writeValueAsString(repairKitsRequest);
				logger.info("add Repairkit Request:  "+requestAsString);
				addRepairKitResponsAsString = ServiceUtil2.callSynchronousPostService(addRepairkitUrl,
						WorkorderConstants.APPLICATION_JSON, requestAsString, queryParams, headersMap);
				logger.info("add Repairkit Response:  "+addRepairKitResponsAsString);
				repairKitsresponse = Json.mapper().readValue(addRepairKitResponsAsString, RepairKitsResponse.class);
				if (null != repairKitsresponse && null != repairKitsresponse.getStatus()) {
					return ok(Json.toJson(repairKitsresponse));
				}
			}
		} catch (IOException e) {
			return internalServerError("err.addrepairkit");
		}
		return internalServerError("err.addrepairkit");
	}
	
	private void getMaterialForServiceItems(String locomotiveId, String customerId, String orgId,
			List<Long> serviceItemList, List<MaterialDetailsForServiceSheet> sheetList, List<ServiceSheetDTO> serviceSheetDTOList,String workorderId) throws JsonParseException, JsonMappingException, IOException {
	    
	    ServiceItemRepairKitRequest itemRepairKitRequest = new ServiceItemRepairKitRequest();
	    if(null!=customerId && null!=locomotiveId && null!=serviceItemList && !serviceItemList.isEmpty()){
	        PcNonFmi pcNonFmi = new PcNonFmi();
	        pcNonFmi.setCustomerId(Long.parseLong(customerId));
	        pcNonFmi.setLocomotiveId(Long.parseLong(locomotiveId));
	        pcNonFmi.getServiceItemIds().addAll(serviceItemList);
	        itemRepairKitRequest.setPcNonFmi(pcNonFmi);
	    }
	    
	   
	    List<Long> fmiServiceSheetIds = serviceSheetDTOList.stream().filter(sheet -> sheet.getServiceTypeCode().equalsIgnoreCase("SP")).map(ServiceSheetDTO:: getId).collect(Collectors.toList());
	    if(!fmiServiceSheetIds.isEmpty()){
	        PcFmi pcFmi = new PcFmi();
	        pcFmi.getServiceSheetIds().addAll(fmiServiceSheetIds);
	        itemRepairKitRequest.setPcFmi(pcFmi);
	    }
	    
	    itemRepairKitRequest.setServiceOrgId(Long.parseLong(orgId));
		ServiceItemRepairKitResponse response = callMaterialForServiceItemsService(itemRepairKitRequest,workorderId);

		System.out.println(response);
			if (response != null){
                if (response.getPcNonFmiItems() != null && response.getPcNonFmiItems().getServiceItems() != null
                        && !response.getPcNonFmiItems().getServiceItems().isEmpty()) {
                    List<ServiceItem> serviceItemResponseList = response.getPcNonFmiItems().getServiceItems();
                    for (ServiceItem item : serviceItemResponseList) {
                        long serviceItemId = item.getServiceItemId();
                        if (sheetList != null && !sheetList.isEmpty()) {
                            for (MaterialDetailsForServiceSheet sheet : sheetList) {
                                if (null != sheet.getServiceSheet().getServiceItemId()
                                        && sheet.getServiceSheet().getServiceItemId().equals(serviceItemId)) {
                                    sheet.setRepairKits(item.getRepairKits());
                                    break;
                                }
                            }
                        }
    
                    }
                }
                if(null!=response.getPcFmiItems()){
                    for (PcFmiItems pcFmiItem : response.getPcFmiItems()) {
                        for (MaterialDetailsForServiceSheet sheet : sheetList) {
                            if (null != sheet.getServiceSheet().getId()
                                    && sheet.getServiceSheet().getId().equals(pcFmiItem.getServiceSheetId())) {
                                sheet.getPcFmiItems().add(pcFmiItem);
                            }
                        }
                    }
                }
			}
		}
	
	private void getMaterialForServiceItemsForServiceSheetId(String locomotiveId, String customerId, String orgId, Long serviceSheetId,
			Long serviceItemId, String serviceSheetTypeCode, MaterialDetailsForServiceSheet sheet, String workorderId)
			throws JsonParseException, JsonMappingException, IOException {
		ServiceItemRepairKitRequest itemRepairKitRequest = new ServiceItemRepairKitRequest();
		if (null != customerId && null != locomotiveId && null != serviceItemId) {
			PcNonFmi pcNonFmi = new PcNonFmi();
			pcNonFmi.setCustomerId(Long.parseLong(customerId));
			pcNonFmi.setLocomotiveId(Long.parseLong(locomotiveId));
			pcNonFmi.getServiceItemIds().add(serviceItemId);
			itemRepairKitRequest.setPcNonFmi(pcNonFmi);
		}

		if ("SP".equalsIgnoreCase(serviceSheetTypeCode)) {
			PcFmi pcFmi = new PcFmi();
			pcFmi.getServiceSheetIds().add(serviceSheetId);
			itemRepairKitRequest.setPcFmi(pcFmi);
		}

		itemRepairKitRequest.setServiceOrgId(Long.parseLong(orgId));
		ServiceItemRepairKitResponse response = callMaterialForServiceItemsService(itemRepairKitRequest, workorderId);

		if (response != null) {
			if (response.getPcNonFmiItems() != null && response.getPcNonFmiItems().getServiceItems() != null
					&& !response.getPcNonFmiItems().getServiceItems().isEmpty()) {
				List<ServiceItem> serviceItemResponseList = response.getPcNonFmiItems().getServiceItems();
				for (ServiceItem item : serviceItemResponseList) {
					if (serviceItemId.equals(item.getServiceItemId())) {
						sheet.setRepairKits(item.getRepairKits());
					}

				}
			}
			if (null != response.getPcFmiItems()) {
				for (PcFmiItems pcFmiItem : response.getPcFmiItems()) {
					if (serviceSheetId.equals(pcFmiItem.getServiceSheetId())) {
						sheet.getPcFmiItems().add(pcFmiItem);
					}
				}
			}
		}
	}
	
	private ServiceItemRepairKitResponse callMaterialForServiceItemsService(
            ServiceItemRepairKitRequest itemRepairKitRequest,String workorderId) {
	    ServiceItemRepairKitResponse response = null;
        String repairKitForServItemURL = WorkorderConstants.BASE_URL + WorkorderConstants.REPAIR_KIT_URL;
        String repairKitRequestAsString;
        String responseAsString = null;
        try {
            if(null!=itemRepairKitRequest){
                repairKitRequestAsString = Json.mapper().writerWithDefaultPrettyPrinter().writeValueAsString(itemRepairKitRequest);
                logger.info("get Material details Request:  "+repairKitRequestAsString);
                String key = "materialReq."+workorderId;
                responseAsString = (String)Cache.get(key); 
                if(responseAsString== null){
                    responseAsString = ServiceUtil2.callSynchronousPostService(repairKitForServItemURL,
                            WorkorderConstants.APPLICATION_JSON, repairKitRequestAsString, Collections.emptyMap(), Collections.emptyMap());
                 Cache.set(key,responseAsString,10);
                }
                logger.info("get Material details Response:  "+responseAsString);
                response = Json.mapper().readValue(responseAsString, ServiceItemRepairKitResponse.class);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    } 
	
	private void setRequestMaterialFlag(String workorderId, List<MaterialDetailsForServiceSheet> sheetList) {
		ServiceSheetMaterialStatusResponse response = getServiceSheetMaterialStatus(workorderId);
		if (null != response && null != response.getServiceSheets() && !response.getServiceSheets().isEmpty()) {
			for (MaterialDetailsForServiceSheet sheet : sheetList) {
				if (null != sheet.getServiceSheet()
						&& response.getServiceSheets().contains(sheet.getServiceSheet().getId())) {
					sheet.getServiceSheet().setRequestMaterial(true);
				}
			}
		}
	}
	
	private ServiceSheetMaterialStatusResponse getServiceSheetMaterialStatus(String workorderId) {
		ServiceSheetMaterialStatusResponse response = null;
		try {
			if (null != workorderId) {
				String requstURL = WorkorderConstants.BASE_URL
						+ WorkorderConstants.GET_SERVICE_SHEET_MATERIAL_STATUS_URL + "/" + workorderId;
				Map<String, String> queryParams = new HashMap<String, String>();

				String serviceSheetMaterialStatusResponse = ServiceUtil2.callSynchronousGetService(requstURL,
						WorkorderConstants.APPLICATION_JSON, queryParams, Collections.<String, String>emptyMap());
				
				logger.info("getServiceSheetMaterialStatus :::::: "+serviceSheetMaterialStatusResponse);
				response = Json.mapper().readValue(serviceSheetMaterialStatusResponse,
						ServiceSheetMaterialStatusResponse.class);
			}
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return response;
	}
	
	

	private AssignRequest populateAssingWorkorderRequest(AssignWorkorder assignWorkorderForm) {
		AssignRequest request = new AssignRequest();
		com.ge.transportation.eservices2.domainobjects.services.AssignWorkorder wo = new com.ge.transportation.eservices2.domainobjects.services.AssignWorkorder();
		wo.setWorkorderId(Long.parseLong(assignWorkorderForm.getWorkorderId()));
		wo.setCustomerId(Long.parseLong(assignWorkorderForm.getCustomerId()));
		wo.setLocomotiveId(Long.parseLong(assignWorkorderForm.getLocomotiveId()));
		wo.setOrganisationId(Long.parseLong(assignWorkorderForm.getOrganisationId()));
		wo.setWorkorderStatus(Long.parseLong(assignWorkorderForm.getWorkorderStatus()));
		wo.setDirection(assignWorkorderForm.getDirection());
		wo.setPosition(assignWorkorderForm.getPosition());
		wo.setDate(assignWorkorderForm.getDate());
		wo.setReasonCode(assignWorkorderForm.getReasonCode());
		wo.setTrack(assignWorkorderForm.getTrack());
		wo.setRoadNumber(assignWorkorderForm.getRoadNumber());
		wo.setWorkorderComment(assignWorkorderForm.getWorkorderComment());
		wo.setIsSmartShop(assignWorkorderForm.getIsSmartShop());
		request.setAssignWorkorder(wo);
		request.setUpdatedBy(Long.parseLong(assignWorkorderForm.getLastupdatedby()));
		return request;
	}

	public Promise<Result> validateWorkorderDate() {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.VALIDATE_WORKORDER_DATE_URL;

		Form<ValidateInshopDate> validateDateForm = Form.form(ValidateInshopDate.class).bindFromRequest();
		ValidateInshopDate inshopDate = validateDateForm.get();
		ValidateInshopDateRequest request = new ValidateInshopDateRequest();

		if(null != inshopDate.getCustomerId())
		{
			request.setCustomerId(Long.parseLong(inshopDate.getCustomerId()));
		}
		if(null != inshopDate.getLocomotiveId())
		{
			request.setLocomotiveId(Long.parseLong(inshopDate.getLocomotiveId()));
		}
		request.setScheduledInshopDate(inshopDate.getInshopDate());
		String requestAsString = null;
		try {
			requestAsString = Json.mapper().writeValueAsString(request);
		} catch (JsonProcessingException e) {

			StringWriter writer = new StringWriter();
			PrintWriter s = new PrintWriter(writer);
			e.printStackTrace(s);
			logger.error("Exception occured in converting UI assign object to request object :" + writer.toString());

		}

		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, requestAsString,
				ValidateInshopDateResponse.class);
	}
	
	public Promise<Result> getDefaultWorkorderComment() {

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_DEFAULT_WORKORDER_COMMENT_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams,
				DefaultWoCommentResponse.class);
	}

	   public Promise<Result> getLastInshopSummary(String locomotiveId,String customerId) {

	        String url = WorkorderConstants.BASE_URL + WorkorderConstants.LAST_INSHOP_SUMMARY_URL;

	        Map<String, String> queryParams = new HashMap<String, String>();
	        queryParams.put(WorkorderConstants.LOCOMOTIVE_ID, locomotiveId);
	        queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);

	        return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams,
	                LastInshopSummaryResponse.class);
	    }

	   public Promise<Result> autoSignoff() {

	        String url = WorkorderConstants.BASE_URL + WorkorderConstants.AUTOSIGNOFF_URL;
	        Form<AutoSignoffRequest> autoSignoffForm = Form.form(AutoSignoffRequest.class).bindFromRequest();
	        AutoSignoffRequest obj=autoSignoffForm.get();
	        String autoSignoffAsString = null;
	        AutoSignoffEvent req = null;
	        try {
	            req = populateAutoSignoffRequest(obj);
	            autoSignoffAsString = Json.mapper().writeValueAsString(req);
	        } catch (JsonProcessingException e) {
	            StringWriter writer = new StringWriter();
	            PrintWriter s = new PrintWriter(writer);
	            e.printStackTrace(s);
	            logger.error("Exception occured in autosignoff :" + writer.toString());
	        }
	        return callAsyncPostServiceWithNoResponse(url, WorkorderConstants.APPLICATION_JSON, autoSignoffAsString,
	                String.class);
	    }

	   private AutoSignoffEvent populateAutoSignoffRequest(AutoSignoffRequest autoSignoffForm) {
		    AutoSignoffEvent request = new AutoSignoffEvent();
		    AutoSignoffAsset asset = new AutoSignoffAsset();
		    asset.setLocomotiveId(autoSignoffForm.getLocomotiveId());
		    asset.setLocomotiveTypeCode(autoSignoffForm.getLocomotiveTypeCode());
			request.setAsset(asset);
			request.setCustomerId(autoSignoffForm.getCustomerId());
			request.setEventName(autoSignoffForm.getEventName());
			request.setMessageId(autoSignoffForm.getMessageId());
			request.setServiceOrgId(autoSignoffForm.getServiceOrgId());
			return request;
		}
	   
	   public Promise<Result> getMaterialDetails(String workorderId,String orgId) {

			String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_MATERIAL_DETAILS_URL;
			
			url = url + "/" + workorderId + "/" + orgId;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);
			queryParams.put(WorkorderConstants.SERVICE_ORG_ID, orgId);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams,
					MaterialDetailsResponse.class);
		}
	   
	   public Promise<Result> validateMaterialsForTransferWo(String workorderId,String orgId) {

			String url = WorkorderConstants.BASE_URL + WorkorderConstants.VALIDATE_MATERIAL_FOR_TWO_URL;
			
			url = url + "/" + workorderId + "/" + orgId;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);
			queryParams.put(WorkorderConstants.SERVICE_ORG_ID, orgId);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams,
					MaterialDetailsResponse.class);
		}
	   
	   public Result isWoModernizationEnabled() {
			String isModernizationEnabled = Play.application().configuration().getString("mm.wo.modernization.enable");
			return ok(Json.toJson(isModernizationEnabled));
	   }
	   
	   public Promise<Result> getLocomotiveDetails(String customerId, String aarRoad, String roadNumber) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.GETLOCOMOTIVE_ALL_DETAILS_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);
			queryParams.put(WorkorderConstants.AAR_ROAD, aarRoad);
			queryParams.put(WorkorderConstants.ROAD_NUMBER, roadNumber);
			
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}
	   
	   public Promise<Result> getWoCommentsConfig(String customerId) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_WO_COMMENTS_CONFIG_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.CUSTOMER_ID, customerId);
			
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	   }
	   
	   public Promise<Result> createWoCommentConfigField() {
		   String addWoCommentsFieldsJson = request().body().asJson().toString();
		   String url = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_WO_COMMENTS_FIELD_CONFIG_URL;
		   return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, addWoCommentsFieldsJson, Object.class);
	   }
	   
	   public Promise<Result> editWoCommentConfigField() {
		   String editWoCommentsFieldsJson = request().body().asJson().toString();
		   String url = WorkorderConstants.BASE_URL + WorkorderConstants.EDIT_WO_COMMENTS_FIELD_CONFIG_URL;
		   return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, editWoCommentsFieldsJson, Object.class);
	   }
	   
	   public Promise<Result> saveWoCommentConfigFields() {
		   String saveWoCommentsFieldsJson = request().body().asJson().toString();
		   String url = WorkorderConstants.BASE_URL + WorkorderConstants.SAVE_WO_COMMENTS_FIELD_CONFIG_URL;
		   return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, saveWoCommentsFieldsJson, Object.class);
	   }

		public Promise<Result> getRxSheetsForLocos() {
			String rxSheetsFieldsJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.RX_SHEETS_FOR_LOCOS_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, rxSheetsFieldsJson, Object.class);
		}

		public Promise<Result> getLastWorkorderInfo(String locomotiveIds) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.LAST_WORKORDER_INFO_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVEIDS, locomotiveIds);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getWoCommentHistory(String locomotiveIds) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.WO_COMMENT_HISTORY_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVEIDS, locomotiveIds);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getNextRmDate(String locomotiveIds) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.NEXT_RM_DATE_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVEIDS, locomotiveIds);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getAvgDistFromRefGroove(String locomotiveIds) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.AVG_DIS_FRAME_GROOVE_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVEIDS, locomotiveIds);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getFmiSheetsForLocos() {
			String fmiSheetsJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.FMISHEETS_FOR_LOCOS_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, fmiSheetsJson, Object.class);
		}

		public Promise<Result> getLastCommunicationDate(String locomotiveIds) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.LAST_COMMUNICATION_DATE_URL;

			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVEIDS, locomotiveIds);

			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getWorkorderStatusByOrg(String orgId) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.WORKORDER_STATUS_URL;
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.ORG_ID, orgId);
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> getWorkorderStatusDates(String serviceWorkorderId) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_WORKORDER_STATUS_DATES_URL;
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, serviceWorkorderId);
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> updateOdoMeterReadings() {
			String meterReadingsJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_ODOMETER_READING_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, meterReadingsJson, Object.class);
		}

		public Promise<Result> updateOOSLocationDetails() {
			String oosJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_OOSLOCATION_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, oosJson, Object.class);
		}

		public Promise<Result> updateWoStatusDatetime() {
			String statusDateTimeJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_WO_STATUS_DATETIME_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, statusDateTimeJson, Object.class);
		}

		public Promise<Result> updateCurrentStatusDate() {
			String currentStatusDateTimeJson = request().body().asJson().toString();
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.UPDATE_CURRENT_WO_STATUS_DATETIME_URL;
			return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, currentStatusDateTimeJson, Object.class);
		}
		
		public Promise<Result> closeWorkorder() {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.CLOSE_WORKORDER_URL;
			String closeWOJson = request().body().asJson().toString();
			return callAsyncPutService(url, WorkorderConstants.APPLICATION_JSON, closeWOJson, Object.class);
		}

		public Promise<Result> checkDownloadProcessByLocoid(String locomotiveId) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.CHECK_DOWNLOAD_PROCESS_URL;
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVE_ID, locomotiveId);
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}

		public Promise<Result> validateMaterialPicked(String locomotiveId,String workorderId) {
			String url = WorkorderConstants.BASE_URL + WorkorderConstants.VALIDATE_MATERIAL_PICKED_URL;
			Map<String, String> queryParams = new HashMap<String, String>();
			queryParams.put(WorkorderConstants.LOCOMOTIVE_ID, locomotiveId);
			queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);
			return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
		}
}
