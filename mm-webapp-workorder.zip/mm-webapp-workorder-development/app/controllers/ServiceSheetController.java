package controllers;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ge.transportation.eservices2.domainobjects.services.ServiceSheetResponse;
import com.ge.transportation.eservices2.domainobjects.services.SsRequest;
import com.ge.transportation.eservices2.domainobjects.services.SsResponse;
import com.ge.transportation.eservices2.domainobjects.services.MandatorySSRequest;
import com.ge.transportation.eservices2.domainobjects.services.MandatorySSResponse;

import models.ServiceSheetForm;
import play.data.Form;
import play.libs.F.Promise;
import play.libs.Json;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSResponse;
import play.mvc.Result;
import util.WorkorderConstants;

public class ServiceSheetController extends BaseController {

	public Promise<Result> getServiceSheetByLocoId(String id, String locale, String workorderId) {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_SS_BY_LOCOID_URL;
/*
		ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setQueryParameter(WorkorderConstants.LOCOMOTIVE_ID, id)
				.setQueryParameter(WorkorderConstants.LOCALE, locale)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
				.get();

		return ssResponse.map(resp -> {

			ServiceSheetResponse servicesheetResp = Json.mapper().readValue(resp.getBodyAsStream(),
					ServiceSheetResponse.class);
			return ok(Json.mapper().writeValueAsString(servicesheetResp));
		});
		*/
		Map<String, String> queryParams = new HashMap<String,String>();
		queryParams.put(WorkorderConstants.LOCOMOTIVE_ID, id);
		queryParams.put(WorkorderConstants.LOCALE, locale);
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ServiceSheetResponse.class);

	}

	public Promise<Result> getServiceSheetByWorkorderId(String workorderId, String reasonCode, String orgId, String locale) {

	//	Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_SS_BY_WOID_URL;
		
/*
		ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setQueryParameter(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId)
				.setQueryParameter(WorkorderConstants.LOCALE, locale)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC).get();

		return ssResponse.map(resp -> {

			ServiceSheetResponse servicesheetResp = Json.mapper().readValue(resp.getBodyAsStream(),
					ServiceSheetResponse.class);
			return ok(Json.mapper().writeValueAsString(servicesheetResp));
		});*/
		
	 	Map<String, String> queryParams = new HashMap<String,String>();
		queryParams.put(WorkorderConstants.LOCALE, locale);
		queryParams.put(WorkorderConstants.SERVICE_WORKORDER_ID, workorderId);
		queryParams.put(WorkorderConstants.INSHOP_REASON_CODE, reasonCode);
		queryParams.put(WorkorderConstants.SERVICE_ORG_ID, orgId);
		
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, ServiceSheetResponse.class);

	}

	public Promise<Result> addServiceSheet(String workorderId,String serviceSheetId,String lastUpdatedBy,String customerId, String comments, String positions, String serviceItemId) {
		System.out.println(serviceItemId + "serviceItemId");			
		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_SS_URL;

		SsRequest req = new SsRequest();
		com.ge.transportation.eservices2.domainobjects.services.ServiceSheet ss = new com.ge.transportation.eservices2.domainobjects.services.ServiceSheet();
		ss.setServiceSheetId(Long.parseLong(serviceSheetId));
		ss.setServiceWorkorderId(Long.parseLong(workorderId));
		ss.setLastUpdatedBy(Long.parseLong(lastUpdatedBy));
		req.setServiceSheet(ss);
		req.setLocale(WorkorderConstants.US_LOCALE);
		req.setCustomerId(Long.parseLong(customerId));
		ss.setServiceSheetComments(comments);
		if (null != serviceItemId && !serviceItemId.trim().isEmpty()) {
			ss.setServiceItemId(Long.parseLong(serviceItemId));
		}
		if (null != positions && !positions.trim().isEmpty()) {
			String[] temp = positions.split(",");
			List<String> list = new ArrayList<String>();
	
			for (int l = 0; l < temp.length; l++) {
				if(null != temp[l] && !temp[l].trim().isEmpty())
				list.add(temp[l]);
			}
			
			req.getPositions().addAll(list);
		}


		String addServiceSheetRequest = null;
		 
		try {
			  addServiceSheetRequest = Json.mapper().writeValueAsString(req);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		

/*		ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
				.post(addServiceSheetRequest);
				
		return ssResponse.map(resp -> {

			SsResponse servicesheetResp = Json.mapper().readValue(resp.getBodyAsStream(), SsResponse.class);
			return ok(Json.mapper().writeValueAsString(servicesheetResp));
		});*/
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, addServiceSheetRequest, SsResponse.class);

	}

	
	public Promise<Result> removeServiceSheets(String workorderId,String serviceSheetId,String lastUpdatedBy, String removalModalFlag,String removalReasonCode, String removalReasonComments, String mandatoryFlag, String removalDescription) {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.REMOVE_SS_URL;
		
		SsRequest req = new SsRequest();
		com.ge.transportation.eservices2.domainobjects.services.ServiceSheet ss = new com.ge.transportation.eservices2.domainobjects.services.ServiceSheet();
		ss.setServiceSheetId(Long.parseLong(serviceSheetId));
		ss.setServiceWorkorderId(Long.parseLong(workorderId));
		ss.setLastUpdatedBy(Long.parseLong(lastUpdatedBy));
		ss.setRemovalModalFlag(removalModalFlag);
		ss.setRemovalReasonCode(removalReasonCode);
		ss.setRemovalReasonComments(removalReasonComments);
		ss.setMandatoryFlag(mandatoryFlag);
		ss.setRemovalDescription(removalDescription);
		req.setServiceSheet(ss);
		req.setLocale(WorkorderConstants.US_LOCALE);
		
		String removeServiceSheetRequest = null;
		 
		  try {
			  removeServiceSheetRequest = Json.mapper().writeValueAsString(req);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
/*
		ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
				.post(removeServiceSheetRequest);
				
		return ssResponse.map(resp -> {

			SsResponse ssResp = Json.mapper().readValue(resp.getBodyAsStream(), SsResponse.class);
			return ok(Json.mapper().writeValueAsString(ssResp));
		});*/
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, removeServiceSheetRequest, SsResponse.class);

	}

	public Promise<Result> addComments() {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.ADD_COMMENT_URL;
		
		 Form<ServiceSheetForm> addCommentForm = Form.form(ServiceSheetForm.class).bindFromRequest();
		 ServiceSheetForm serviceSheet = addCommentForm.get();
	
		 SsRequest req = new SsRequest();
		
		 com.ge.transportation.eservices2.domainobjects.services.ServiceSheet ss = new com.ge.transportation.eservices2.domainobjects.services.ServiceSheet();
		
		 ss.setServiceSheetId(serviceSheet.getServiceSheetId());
		 ss.setServiceWorkorderId(serviceSheet.getServiceWorkorderId());
		 ss.setServiceSheetComments(serviceSheet.getServiceSheetComments());
		 ss.setLastUpdatedBy(serviceSheet.getLastUpdatedBy());
		 
		 req.setServiceSheet(ss);
		 req.setLocale(serviceSheet.getLocale()==null?WorkorderConstants.US_LOCALE:serviceSheet.getLocale());
			
			String addSScommentRequest = null;
			 
			  try {
				  addSScommentRequest = Json.mapper().writeValueAsString(req);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			

	/*	ssResponse = ws.url(url).setContentType(WorkorderConstants.APPLICATION_JSON)
				.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
				.post(addSScommentRequest);
				
		return ssResponse.map(resp -> {

			SsResponse servicesheetResp = Json.mapper().readValue(resp.getBodyAsStream(),
					SsResponse.class);
			return ok(Json.mapper().writeValueAsString(servicesheetResp));
		});*/
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, addSScommentRequest, SsResponse.class);

	}
	
	public Promise<Result> getMandatoryServiceSheets(String workorderId,String reasonCode,String organisationId,String locale) {

		Promise<WSResponse> ssResponse = null;

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.MANDATORY_SS_URL;
		MandatorySSRequest req = new MandatorySSRequest();
		req.setWorkorderId(Long.parseLong(workorderId));
		req.setOrganisationId(Long.parseLong(organisationId));
		req.setLocale(locale);
		req.setReasonCode(reasonCode);
			
			String mandatorySSRequestStr = null;
			  try {
				  mandatorySSRequestStr = Json.mapper().writeValueAsString(req);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			
		
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, mandatorySSRequestStr, MandatorySSResponse.class);

	}
	
	public Promise<Result> getSSWhyDetails(String locomotiveId, String serviceSheetId) {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.SS_WHY_DETAILS_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.LOCOMOTIVE_ID, locomotiveId);
		queryParams.put(WorkorderConstants.SERVICESHEET_ID, serviceSheetId);
		
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}
	
	public Promise<Result> getSSRemovalReasonCodes(String serviceSheetId, String locale) {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.SS_REMOVAL_REASON_CODES_URL;

		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICESHEET_ID, serviceSheetId);
		queryParams.put(WorkorderConstants.LOCALE, locale);
		
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}
	
	public Promise<Result> getAllServiceTypesForEditSS() {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_ALL_SERVICE_TYPES_FOR_EDIT_SS_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, Collections.<String, String> emptyMap(), Object.class);
	}
	
	public Promise<Result> getAllServiceItems() {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_ALL_SERVICE_ITEMS_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, Collections.<String, String> emptyMap(), Object.class);
	}

	public Promise<Result> editServiceSheet() {
		String editServicesheetJson = request().body().asJson().toString();
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.EDIT_SERVICESHEET_URL;
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, editServicesheetJson, Object.class);
	}

	public Promise<Result> taskSignOffStatus(String serviceSheetId, String serviceTypeCode) {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICESHEET_ID, serviceSheetId);
		queryParams.put(WorkorderConstants.SERVICE_TYPE_CODE, serviceTypeCode);

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.TASK_SIGNOFF_STATUS_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}

	public Promise<Result> duplicateServiceSheet() {
		String duplicateServicesheetJson = request().body().asJson().toString();
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.DUPLICATE_SERVICESHEET_URL;
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, duplicateServicesheetJson, Object.class);
	}

	public Promise<Result> validateFmiSoftwareForSS(String serviceSheetId, String workorderId) {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICESHEET_ID, serviceSheetId);
		queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);

		String url = WorkorderConstants.BASE_URL + WorkorderConstants.VALIDATE_FMI_SOFTWARE_SS_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}
	

	public Promise<Result> getServiceItemsApplicableForLocomotiveAndOrg(String workorderId) {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.WORKORDER_ID, workorderId);
		
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_ALL_SERVICE_ITEMS_VALID_FOR_LOCO_AND_ORG_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}

	public Promise<Result> getServicesheetHistory(String serviceSheetId) {
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.SERVICESHEET_ID, serviceSheetId);
		
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_SERVICE_SHEET_HISTORY_URL;
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}

	public Promise<Result> getServicesheetPositions() {
		String ssPositionsJson = request().body().asJson().toString();
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_SERVICESHEET_POSITIONS_URL;
		return callAsyncPostService(url, WorkorderConstants.APPLICATION_JSON, ssPositionsJson, Object.class);
	}
	
}
