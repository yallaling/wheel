package controllers;

import java.util.HashMap;
import java.util.Map;

import models.MenuTitleResponse;
import play.libs.F.Promise;
import play.mvc.Result;
import play.mvc.With;
import util.WorkorderConstants;

@With(AuthController.class)
public class CommonController extends BaseController {

	public Promise<Result> getMenuTitleByName(String menuName) {
		String url = WorkorderConstants.BASE_URL + WorkorderConstants.GET_MENU_TITLE_BY_NAME;
		String menuTitleName = (null == menuName ? "" : menuName);
		
		Map<String, String> queryParams = new HashMap<String, String>();
		queryParams.put(WorkorderConstants.MENU_NAME, menuTitleName);
		return callAsyncGetService(url, WorkorderConstants.APPLICATION_JSON, queryParams, Object.class);
	}
}
