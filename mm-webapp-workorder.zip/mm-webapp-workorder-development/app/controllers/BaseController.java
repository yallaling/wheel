package controllers;

import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import play.libs.F;
import play.libs.F.Promise;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSClient;
import play.libs.ws.WSRequest;
import play.libs.ws.WSResponse;
import play.mvc.Controller;
import play.mvc.Result;
import util.ServiceUtil2;
import util.WorkorderConstants;

public class BaseController extends Controller {
	@Inject
	WSClient ws;
	private static final Logger logger = LoggerFactory.getLogger(BaseController.class);

	public Promise<Result> callAsyncGetService(String url, String contentType, Map<String, String> queryParams,
			Class<?> responseType) {
		logger.info("The serivce url getting called :" + url);
		WSRequest wsRequest = play.libs.ws.WS.url(url);
		setQueryParams(wsRequest, queryParams);
		Promise<WSResponse> promise = null;
		try {
			
			promise = wsRequest.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
					.setHeader(WorkorderConstants.ACCEPT, contentType)
					.setRequestTimeout(WorkorderConstants.TIMEOUT_GET)
					.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC).get();

			return promise.map(resp -> {
				return ok(ServiceUtil2.convertStreamToString(resp.getBodyAsStream(), responseType)).as(contentType);
			});
		} catch (Throwable e) {
			logger.error("Exception occured in calling service :" + url);
			return F.Promise.promise(new F.Function0<Result>() {
				@Override
				public Result apply() throws Throwable {
					return internalServerError("Service is unavailable ....");
				}
			});
		}

	}

	public Promise<Result> callAsyncPostService(String url, String contentType, String requestObjectAsString,
			Class<?> responseType) {
		logger.info("The serivce url getting called :" + url);
		WSRequest wsRequest = play.libs.ws.WS.url(url);
		Promise<WSResponse> promise = null;
		try {

			promise = wsRequest.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
					.setHeader(WorkorderConstants.ACCEPT, contentType)
					.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
					.setRequestTimeout(WorkorderConstants.TIMEOUT_POST)
					.post(requestObjectAsString);

			return promise.map(resp -> {
				return ok(ServiceUtil2.convertStreamToString(resp.getBodyAsStream(), responseType));

			});

		} catch (Throwable e) {
			logger.error("Exception occured in calling service :" + url);
			return F.Promise.promise(new F.Function0<Result>() {
				@Override
				public Result apply() throws Throwable {
					return internalServerError("Service is unavailable ....");
				}
			});
		}

	}

	public Promise<Result> callAsyncDeleteService(String url, String contentType, String requestObjectAsString,
			Class<?> responseType) {
		logger.info("The serivce url getting called :" + url);
		WSRequest wsRequest = play.libs.ws.WS.url(url);
		Promise<WSResponse> promise = null;
		try {
			promise = wsRequest.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
					.setHeader(WorkorderConstants.ACCEPT, contentType)
					.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
					.setBody(requestObjectAsString).delete();

			return promise.map(resp -> {
				return ok(ServiceUtil2.convertStreamToString(resp.getBodyAsStream(), responseType));

			});

		} catch (Throwable e) {
			logger.error("Exception occured in calling service :" + url);
			return F.Promise.promise(new F.Function0<Result>() {
				@Override
				public Result apply() throws Throwable {
					return internalServerError("Service is unavailable ....");
				}
			});
		}

	}

	private void setQueryParams(WSRequest request, Map<String, String> params) {
		for (Map.Entry<String, String> e : params.entrySet()) {
			if (e.getKey() != null && e.getValue() != null) {
				request.setQueryParameter(e.getKey(), e.getValue());
			}
		}
	}

	public Promise<Result> callAsyncPostServiceWithNoResponse(String url, String contentType, String requestObjectAsString,
			Class<?> responseType) {
		logger.info("The serivce url getting called :" + url);
		WSRequest wsRequest = play.libs.ws.WS.url(url);
		Promise<WSResponse> promise = null;
		try {

			promise = wsRequest.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
					.setHeader(WorkorderConstants.ACCEPT, contentType)
					.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
					.setRequestTimeout(WorkorderConstants.TIMEOUT_POST)
					.post(requestObjectAsString);
			return promise.map(resp -> {
				return ok();

			});

		} catch (Throwable e) {
			logger.error("Exception occured in calling service :" + url);
			return F.Promise.promise(new F.Function0<Result>() {
				@Override
				public Result apply() throws Throwable {
					return internalServerError("Service is unavailable ....");
				}
			});
		}

	}

	public Promise<Result> callAsyncPutService(String url, String contentType, String requestObjectAsString,
			Class<?> responseType) {
		logger.info("The serivce url getting called :" + url);
		WSRequest wsRequest = play.libs.ws.WS.url(url);
		Promise<WSResponse> promise = null;
		try {

			promise = wsRequest.setHeader(WorkorderConstants.CONTENT_TYPE, contentType)
					.setHeader(WorkorderConstants.ACCEPT, contentType)
					.setAuth(WorkorderConstants.USER_NAME, WorkorderConstants.PASSWORD, WSAuthScheme.BASIC)
					.setRequestTimeout(WorkorderConstants.TIMEOUT_POST)
					.put(requestObjectAsString);

			return promise.map(resp -> {
				return ok(ServiceUtil2.convertStreamToString(resp.getBodyAsStream(), responseType));

			});

		} catch (Throwable e) {
			logger.error("Exception occured in calling service :" + url);
			return F.Promise.promise(new F.Function0<Result>() {
				@Override
				public Result apply() throws Throwable {
					return internalServerError("Service is unavailable ....");
				}
			});
		}

	}
}
