console.log('\'Allo \'Allo!'); // eslint-disable-line no-console
