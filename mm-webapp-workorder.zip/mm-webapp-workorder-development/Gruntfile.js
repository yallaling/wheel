module.exports = function (grunt) {

        grunt.initConfig({
            pkg: grunt.file.readJSON('package.json'),
            "requirejs": {
                "main": {
                    "options": {
                        //"optimize": "none",
                        "generateSourceMaps": false,
                        "preserveLicenseComments": false,
                        "paths": {
                            "main": "javascripts/main",
                        },
                        "baseUrl": 'public',
                        "mainConfigFile": 'public/javascripts/require.config.js',
                        "name": 'main',
                        "out": 'public/main-built.js'
                    }
                }
            },
            "karma": {
                "options": {
                    // point all tasks to karma config file
                    configFile: 'public/karma.conf.js'
                },
                "unit": {
                    // run tests once instead of continuously
                    singleRun: true
                }
            },
            "html2js": {
                "options": {
                    base: 'public',
                    module: 'templates-min',
                    singleModule: true,
                    useStrict: true,
                    rename: function (tempUrl) {
                        var tempUrlReplace = tempUrl.replace('html', 'assets/html');
                        return tempUrlReplace;
                    }
                },
                "main": {
                    src: ['public/html/**/*.html'],
                    dest: 'public/template_cache.js'
                }
            }
        });

        grunt.loadNpmTasks('grunt-contrib-requirejs');
        grunt.loadNpmTasks('grunt-karma');
        grunt.loadNpmTasks('grunt-html2js');
        grunt.registerTask('default', ['html2js', 'requirejs', 'karma' ]);
};
