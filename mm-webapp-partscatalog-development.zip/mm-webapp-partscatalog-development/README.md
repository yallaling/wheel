# mm-webapp-partscatalog
Webapp repository for partscatalog using Angular6 and nodejs
