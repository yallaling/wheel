import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { UtilService } from '../core/utils/util.service';
import { AppConfig, APP_CONFIG } from '../app.config';
import { Asset } from '../core/models/asset';
import { Workorder } from '../core/models/workorder';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  roadNumber = '';
  asset: Asset = new Asset();
  workorder: Workorder = new Workorder();
  isAARRoadSelection = false;
  isCWCUser = false;

  constructor(private commonService: CommonService, private utilService: UtilService, private translate: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig) { }

  ngOnInit() {
    if (this.commonService.sessionDetails.isAARRoadSelection) {
      this.roadNumber = this.commonService.sessionDetails.roadNumber;
      this.isAARRoadSelection = true;
    } else if (this.commonService.sessionDetails.isCWCUser) {
      this.roadNumber = this.commonService.sessionDetails.roadNumber;
      this.isCWCUser = true;
    } else {
      this.commonService.getAssetDetails(this.commonService.sessionDetails.workorderid)
        .subscribe((assetDetails: any) => {
          if (assetDetails.status === this.config.SUCCESS) {
            this.commonService.sessionDetails.customerName = assetDetails.workorder.customerName;
            this.commonService.sessionDetails.customerId = assetDetails.workorder.customerId;
            this.commonService.sessionDetails.roadNumber = assetDetails.workorder.roadNumber;
            this.commonService.sessionDetails.locoId = assetDetails.workorder.locomotiveId;
            this.commonService.sessionDetails.workOrderNumber = assetDetails.workorder.workorderNumber;
            this.commonService.sessionDetails.organizationid = assetDetails.workorder.organisationId;
            this.roadNumber = assetDetails.workorder.roadNumber;
            this.workorder = assetDetails.workorder;
            this.asset = assetDetails.asset;
            this.commonService.populateLocoEE();
          } else {
            this.utilService.showAlert(this.config.ERROR, this.translate.instant('_Asset_Info_Failure_'),
              true, this.config.ERROR_TIMEOUT);
          }
        }, err => {
          this.utilService.showAlert(this.config.ERROR, this.translate.instant('_Asset_Info_Failure_'),
            true, this.config.ERROR_TIMEOUT);
        });
    }
  }

  redirectToDefect() {
    this.utilService.redirectToDefect();
  }
}
