import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { CommonService } from '../core/common/common.service';
import { UtilService } from '../core/utils/util.service';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of, Observable } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PopoverModule } from 'ngx-popover';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        NgbModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }),
        PopoverModule
      ],
      declarations: [HeaderComponent],
      providers: [
        CommonService,
        UtilService,
        WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
