import { Component, OnInit } from '@angular/core';
import { Alert } from '../core/models/alert';
import { UtilService } from '../core/utils/util.service';

@Component({
  selector: 'app-parts-catalog',
  templateUrl: './parts-catalog.component.html',
  styleUrls: ['./parts-catalog.component.scss']
})
export class PartsCatalogComponent implements OnInit {

  alert: Alert = new Alert();

  constructor(private utilService: UtilService) { }

  ngOnInit() {
    this.utilService.alertEE.subscribe((alert: Alert) => {
      this.alert = alert;
      setTimeout(() => {
        this.alert.visible = false;
      }, alert.timeout);
    });
  }

  closeAlert() {
    this.alert.visible = false;
  }

}
