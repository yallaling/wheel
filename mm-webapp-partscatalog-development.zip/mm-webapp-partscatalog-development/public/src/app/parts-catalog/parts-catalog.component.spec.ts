import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartsCatalogComponent } from './parts-catalog.component';
import { UtilService } from '../core/utils/util.service';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ClipboardModule } from 'ngx-clipboard';
import { TooltipModule } from 'ng2-tooltip-directive';
import { PopoverModule } from 'ngx-popover';
import { NavLocationsComponent } from '../nav-locations/nav-locations.component';
import { SearchComponent } from '../search/search.component';
import { SafePipe } from '../pipes/safe-url.pipe';
import { PartsbulletinComponent } from '../partsbulletin/partsbulletin.component';
import { PartinformationComponent } from '../partinformation/partinformation.component';
import { SearchResultsComponent } from '../search-results/search-results.component';
import { HeaderComponent } from '../header/header.component';
import { CommonService } from '../core/common/common.service';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('PartsCatalogComponent', () => {
  let component: PartsCatalogComponent;
  let fixture: ComponentFixture<PartsCatalogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        NgbModule,
        InfiniteScrollModule,
        HttpClientTestingModule,
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }),
        ClipboardModule,
        TooltipModule,
        PopoverModule
      ],
      declarations: [
        PartsCatalogComponent,
        NavLocationsComponent,
        SearchComponent,
        SafePipe,
        PartsbulletinComponent,
        PartinformationComponent,
        SearchResultsComponent,
        HeaderComponent
      ],
      providers: [
        CommonService,
        UtilService,
        TranslateService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartsCatalogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
