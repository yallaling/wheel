import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchComponent } from './search.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UtilService } from '../core/utils/util.service';
import { CommonService } from '../core/common/common.service';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { APP_CONFIG, APP_DI_CONFIG, AppConfig } from '../app.config';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { ClipboardService, ClipboardModule } from 'ngx-clipboard';
import { TooltipModule } from 'ng2-tooltip-directive';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let commonService: CommonService;
  let waypointnavigationService: WaypointnavigationService;
  let utilService: UtilService;
  let clipboardService: ClipboardService;
  let config: AppConfig;
  let spy: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        FormsModule,
        NgbModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }),
        ClipboardModule,
        TooltipModule
      ],
      declarations: [SearchComponent],
      providers: [
        CommonService,
        UtilService,
        WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG },
        ClipboardService
      ]
    })
      .compileComponents();
    commonService = TestBed.get(CommonService);
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    utilService = TestBed.get(UtilService);
    config = TestBed.get(APP_CONFIG);
    clipboardService = TestBed.get(ClipboardService);
    component = new SearchComponent(commonService, waypointnavigationService, utilService, config, clipboardService);
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    spyOn(waypointnavigationService, 'navigateToSection').and.stub();
    spyOn(waypointnavigationService, 'partInfoSecEE').and.stub();
    spyOn(waypointnavigationService, 'partsBulletinSecEE').and.stub();
    spyOn(waypointnavigationService, 'searchResultSecEE').and.stub();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close', () => {
    const e = event;
    component.close(e);
    const expectedResult = false;
    expect(component.isOpen).toBe(expectedResult);
  });

  it('should redirect to shopping cart', () => {
    spy = spyOn(utilService, 'post');
    component.redirectToShoppingCart();
    expect(spy).toHaveBeenCalled();
  });

});
