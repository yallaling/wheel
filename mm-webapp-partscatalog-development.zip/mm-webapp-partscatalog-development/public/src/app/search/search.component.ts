import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { Observable } from 'rxjs/internal/Observable';
import { debounceTime } from 'rxjs/internal/operators/debounceTime';
import { distinctUntilChanged } from 'rxjs/internal/operators/distinctUntilChanged';
import { map } from 'rxjs/internal/operators/map';
import { tap, switchMap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { UtilService } from '../core/utils/util.service';
import { AppConfig, APP_CONFIG } from '../app.config';
import { ClipboardService } from 'ngx-clipboard';
import { Item } from '../core/models/item';
import { Part } from '../core/models/part';
import { SearchResponse } from '../core/models/search-response';
import { StatusType } from '../core/models/statusType';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {

  model = '';
  searching = false;
  searchList: Array<Part> = new Array<Part>();
  searchStatus: StatusType = new StatusType();
  isOpen = false;
  isAARRoadSelection = false;
  isCWCUser = false;

  constructor(private commonService: CommonService, private waypointnavService: WaypointnavigationService,
    private utilService: UtilService, @Inject(APP_CONFIG) private config: AppConfig, private _clipboardService: ClipboardService) {
  }

  ngOnInit(): void {
    this.isAARRoadSelection = this.commonService.sessionDetails.isAARRoadSelection;
    this.isCWCUser = this.commonService.sessionDetails.isCWCUser;
  }

  search = (text$: Observable<any>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      tap(() => this.searching = true),
      switchMap((term: string ) => '' === term.trim() ? this.searchList = [] : this.commonService.search(term, true).pipe(
        map((search: SearchResponse) => {
          this.searchStatus = search.status;
          if (search.status.statusCode === this.config.SUCCESS) {
            this.searchList = search.parts;
          } else {
            this.searchList = [];
          }
          this.isOpen = true;
        }),
        tap(() => this.searchStatus.statusCode = this.config.SUCCESS),
        catchError(() => {
          this.searchStatus.statusCode = this.config.FAILED;
          this.searchList = [];
          this.isOpen = true;
          return of([]);
        }))
      ),
      tap(() => this.searching = false)
    )

  formatter = (x: { partDescription: string, partNumber: string }) => x.partDescription + '(' + x.partNumber + ')';

  addtoCart(r) {
    const item = new Item(r.partNumber, r.qty, r.partDescription);
    const items: Array<Item> = new Array<Item>();
    items.push(item);
    if (this.isCWCUser) {
      this.utilService.cwcAddToCart(items);
    } else {
      this.utilService.addToCart(items);
    }
  }

  copyToClipboard(text) {
    this._clipboardService.copyFromContent(text);
  }

  fullSearch() {
    if ('' === this.model.trim()) {
      return;
    }
    this.isOpen = false;
    this.waypointnavService.searchResultSecData.searchQuery = this.model;
    this.waypointnavService.openSearchResultSec();
  }

  close(e) {
    this.isOpen = false;
  }

  redirectToShoppingCart() {
    this.utilService.redirectToShoppingCart();
  }

  redirectToCatalog1() {
    this.utilService.redirectToCatalog1();
  }
}
