import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavLocationsComponent } from './nav-locations.component';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { CommonService } from '../core/common/common.service';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { ChapterHierarchy } from '../core/models/chapter-hierarchy';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('NavLocationsComponent', () => {
  let component: NavLocationsComponent;
  let fixture: ComponentFixture<NavLocationsComponent>;
  let waypointnavigationService: WaypointnavigationService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      declarations: [NavLocationsComponent],
      providers: [
        CommonService,
        WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
      .compileComponents();
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    spyOn(waypointnavigationService, 'navigateToSection').and.stub();
    spyOn(waypointnavigationService, 'partInfoSecEE').and.stub();
    spyOn(waypointnavigationService, 'partsBulletinSecEE').and.stub();
    spyOn(waypointnavigationService, 'searchResultSecEE').and.stub();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavLocationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load menu', () => {
    const menu = {
      'pcNavTitle': 'Engine',
      'subChapterHierarchy': [{
        'fileName': 'PC-000066.ditamap',
        'pcNavTitle': '-7676693481244900291',
        'subChapterHierarchy': [],
        'bulletin': []
      }],
      'bulletin': []
    };
    const expectedpcNavTitle = '-7676693481244900291';
    component.loadMenu(menu);
    expect(component.menuList[0].pcNavTitle).toBe(expectedpcNavTitle);
  });

  it('should navigate to menu', () => {
    component.breadcrumbs = ['Locations', 'Map37161'];

    const chapterHierarchy: ChapterHierarchy = new ChapterHierarchy();
    chapterHierarchy.pcNavTitle = 'Map37161';
    chapterHierarchy.bulletin = [];

    const subChapterHierarchy: Array<ChapterHierarchy> = new Array<ChapterHierarchy>();
    const chapterHierarchy1: ChapterHierarchy = new ChapterHierarchy();
    chapterHierarchy1.pcNavTitle = '1815748886711257225';
    subChapterHierarchy.push(chapterHierarchy1);
    chapterHierarchy.subChapterHierarchy = subChapterHierarchy;

    component.locations.push(chapterHierarchy);

    const expectedpcNavTitle = '1815748886711257225';
    component.navigateToMenu('Map37161');
    expect(component.menuList[0].pcNavTitle).toBe(expectedpcNavTitle);
  });

});
