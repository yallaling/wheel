import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { AppConfig, APP_CONFIG } from '../app.config';
import { StatusType } from '../core/models/statusType';
import { LocomotiveHierarchy } from '../core/models/locomotive-hierarchy';
import { ChapterHierarchy } from '../core/models/chapter-hierarchy';
import { SessionDetails } from '../core/models/session-details';
import { GetLocationResponse } from '../core/models/get-location-response';
import { UtilService } from '../core/utils/util.service';
import { DynamicImage } from '../core/models/dynamicimage';

@Component({
  selector: 'app-nav-locations',
  templateUrl: './nav-locations.component.html',
  styleUrls: ['./nav-locations.component.scss']
})
export class NavLocationsComponent implements OnInit {
  menuList: Array<any>;
  locomotiveHierarchy: LocomotiveHierarchy = new LocomotiveHierarchy();
  locations: Array<ChapterHierarchy> = new Array<ChapterHierarchy>();
  imageName: Array<DynamicImage> = new Array<DynamicImage>();
  breadcrumbs: Array<string> = new Array<string>();
  hierarchyStatus: StatusType = new StatusType();
  imageStatus: Array<any>;
  customerId: number;
  locoModel: string;
  dynamicLocoImage: string;
  locoImageEnable = false;
  partsCatalogFile: string;

  ngOnInit() {
    this.breadcrumbs.push(this.config.DEFAULT_BREADCRUMB);
    if (!this.commonService.sessionDetails.isAARRoadSelection && !this.commonService.sessionDetails.isCWCUser) {
      this.commonService.locoEE.subscribe((sessionDetails: SessionDetails) => {
        this.getLocations(sessionDetails.locoId);
        this.getDynamicImageLoco(sessionDetails.customerId, sessionDetails.locoId);
      });
    } else {
      this.getLocations(this.commonService.sessionDetails.locoId);
      this.getDynamicImageLoco(this.commonService.sessionDetails.customerId, this.commonService.sessionDetails.locoId);
    }
  }

  constructor(private commonService: CommonService, private waypointnavService: WaypointnavigationService,
    @Inject(APP_CONFIG) private config: AppConfig, private utilService: UtilService) {
  }

  getLocations(locoId: string) {
    this.commonService.getLocations(locoId).subscribe((locations: GetLocationResponse) => {
      this.hierarchyStatus = locations.status;
      if (this.hierarchyStatus.statusCode === this.config.SUCCESS) {
        this.locomotiveHierarchy = locations.locomotiveHierarchy;
        this.menuList = this.sortPcNavTitles(locations.locomotiveHierarchy.chapterHierarchy, true);
        this.locations = locations.locomotiveHierarchy.chapterHierarchy;
        this.partsCatalogFile = locations.locomotiveHierarchy.partsCatalogFile;
        this.updateSearchHierarchy();
      }
      this.setLocalStorage();
    }, err => {
      this.hierarchyStatus.statusCode = this.config.FAILED;
      this.hierarchyStatus.message = this.config.SOMETHING_WENT_WRONG_MSG;
    });
  }

  getDynamicImageLoco(customerId: string, locomotiveId: string) {
    this.commonService.getDynamicImageLoco(customerId, locomotiveId).subscribe((imageStatus: DynamicImage) => {
      this.locoImageEnable = true;
      this.dynamicLocoImage = this.config.loadImageUrl + imageStatus.locoImageName + '.jpg';
    }, err => {
      this.locoImageEnable = true;
      this.dynamicLocoImage = 'assets/images/LinedLabeled.gif';
    });
  }

  loadMenu(menu) {
    this.breadcrumbs.push(menu.pcNavTitle);
    const menuArray = [];
    menu.subChapterHierarchy = this.sortPcNavTitles(menu.subChapterHierarchy, true);
    menu.subChapterHierarchy.forEach(element => {
      menuArray.push(element);
    });
    menu.bulletin = this.sortPcNavTitles(menu.bulletin, false);
    menu.bulletin.forEach(element => {
      menuArray.push(element);
    });
    this.menuList = menuArray;
    this.setLocalStorage();
    this.updateSearchHierarchy();
  }

  navigateToMenu(breadcrumbElement) {
    let tempMenuList = [];
    tempMenuList = this.locations;
    let index = -1;
    for (const breadcrumb of this.breadcrumbs) {
      index = index + 1;
      for (const val of tempMenuList) {
        if (val.pcNavTitle === breadcrumb) {
          tempMenuList = [];
          val.subChapterHierarchy.forEach(sch => {
            tempMenuList.push(sch);
          });
          val.bulletin.forEach(bul => {
            tempMenuList.push(bul);
          });
          break;
        }
      }
      if (breadcrumb === breadcrumbElement) {
        this.breadcrumbs.splice(index + 1);
        break;
      }
    }
    this.menuList = tempMenuList;
    this.updateSearchHierarchy();
  }

  loadPartsBulletin(pb) {
    this.waypointnavService.partsBulletinSecData.partsCatalogFile = this.locomotiveHierarchy.partsCatalogFile;
    this.waypointnavService.partsBulletinSecData.bulletinFileName = pb.name.split('.')[0];
    this.waypointnavService.partsBulletinSecData.bookmapVersion = this.locomotiveHierarchy.bookMapVersion;
    this.waypointnavService.partsBulletinSecData.bulletinName = pb.bulletinNavTitle;
    this.waypointnavService.openPartsBulletinSec();
  }

  setLocalStorage() {
    let hierarchy = '';
    this.breadcrumbs.forEach(breadcrumb => {
      hierarchy = hierarchy + ' - ' + breadcrumb;
    });
    hierarchy = hierarchy.substring(2);
    this.commonService.sessionDetails.hierarchyOpened = hierarchy;
    this.utilService.setLocalStorage();
  }

  sortPcNavTitles(menudata, valueToCheck) {
    if (valueToCheck === true) {
      menudata.sort(function (a, b) {
        if (a.pcNavTitle < b.pcNavTitle) { return -1; }
        if (a.pcNavTitle > b.pcNavTitle) { return 1; }
        return 0;
      });
      return menudata;
    } else {
      menudata.sort(function (a, b) {
        if (a.bulletinNavTitle < b.bulletinNavTitle) { return -1; }
        if (a.bulletinNavTitle > b.bulletinNavTitle) { return 1; }
        return 0;
      });
      return menudata;
    }
  }

  updateSearchHierarchy() {
    let tempHierarchy = '';
    this.breadcrumbs.forEach(breadcrumb => {
      if (breadcrumb !== this.config.DEFAULT_BREADCRUMB) {
        tempHierarchy = tempHierarchy + '::' + breadcrumb;
      }
    });
    this.commonService.sessionDetails.searchHierarchy = this.partsCatalogFile + tempHierarchy;
  }
}
