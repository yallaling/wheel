import {UtilService} from '../core/utils/util.service';
import {CommonService} from '../core/common/common.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AarselectionComponent } from './aarselection.component';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { of, Observable } from 'rxjs';
import { HttpClientTestingModule } from '@angular/common/http/testing';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('AarselectionComponent', () => {
  let component: AarselectionComponent;
  let fixture: ComponentFixture<AarselectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }),
      ],
      declarations: [ AarselectionComponent ],
      providers: [
        CommonService,
        UtilService,
        TranslateService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
    .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(AarselectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close alert', () => {
    component.closeAlert();
    expect(component.alert.visible).toEqual(false);
  });
});
