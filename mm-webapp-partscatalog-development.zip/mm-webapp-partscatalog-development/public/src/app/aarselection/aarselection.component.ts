import { Component, OnInit, Inject } from '@angular/core';
import { AARRoad } from '../core/models/aarroad';
import { CommonService } from '../core/common/common.service';
import { Alert } from '../core/models/alert';
import { UtilService } from '../core/utils/util.service';
import { AppConfig, APP_CONFIG } from '../app.config';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-aarselection',
  templateUrl: './aarselection.component.html',
  styleUrls: ['./aarselection.component.scss']
})
export class AarselectionComponent implements OnInit {

  alert: Alert = new Alert();
  aarRoadsList: Array<AARRoad> = new Array<AARRoad>();
  customerName: string;
  roadNumber: string;
  isAARVisible = false;
  constructor(private commonService: CommonService, private utilService: UtilService, private translate: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig, private router: Router) { }

  ngOnInit() {
    this.customerName = this.commonService.sessionDetails.customerName;
    this.roadNumber = this.commonService.sessionDetails.roadNumber;

    this.utilService.alertEE.subscribe((alert: Alert) => {
      this.alert = alert;
      setTimeout(() => {
        this.alert.visible = false;
      }, alert.timeout);
    });

    this.commonService.getAARRoads(this.commonService.sessionDetails.roadNumber,
      +this.commonService.sessionDetails.customerId).subscribe(response => {
        if (response.status.statusCode === this.config.SUCCESS) {
          if (response.aarRoads.length === 1) {
            this.openPartsCatalog(response.aarRoads[0], false);
          } else {
            this.isAARVisible = true;
            this.aarRoadsList = response.aarRoads;
          }
        } else {
          this.isAARVisible = true;
          this.utilService.showAlert(this.config.ERROR, this.translate.instant('_get_aar_road_failure_'),
            true, this.config.ERROR_TIMEOUT);
        }
      }, err => {
        this.isAARVisible = true;
        this.utilService.showAlert(this.config.ERROR, this.translate.instant('_get_aar_road_failure_'),
          true, this.config.ERROR_TIMEOUT);
      });
  }

  closeAlert() {
    this.alert.visible = false;
  }

  openPartsCatalog(aarRoad: AARRoad, showAlert: boolean) {
    this.commonService.getLocomotiveStatus(aarRoad.locomotiveId).subscribe(data => {
      if (data.status.statusCode === this.config.SUCCESS) {
        if (data.isActive === true) {
          this.commonService.sessionDetails.locoId = '' + aarRoad.locomotiveId;
          this.router.navigateByUrl(this.config.DEFAULT_PATH, { skipLocationChange: true });
        } else {
          this.isAARVisible = true;
          if (showAlert) {
            this.utilService.showAlert(this.config.ERROR, this.translate.instant('_no_catalog_found_1_',
              { customerName: this.customerName, aarRoad: aarRoad.aarRoad, roadNumber: this.roadNumber }), true,
              this.config.ERROR_TIMEOUT);
          }
        }
      } else {
        this.isAARVisible = true;
        this.utilService.showAlert(this.config.ERROR, this.translate.instant('_get_loco_status_failure_'),
          true, this.config.ERROR_TIMEOUT);
      }
    }, err => {
      this.isAARVisible = true;
      this.utilService.showAlert(this.config.ERROR, this.translate.instant('_get_loco_status_failure_'),
        true, this.config.ERROR_TIMEOUT);
    });
  }

}
