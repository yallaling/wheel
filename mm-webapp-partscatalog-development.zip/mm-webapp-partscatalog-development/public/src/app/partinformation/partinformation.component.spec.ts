import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartinformationComponent } from './partinformation.component';
import { CommonService } from '../core/common/common.service';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { PartInfoSecData } from '../core/models/part-info-sec-data';
import { PartInformation } from '../core/models/part-information';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('PartinformationComponent', () => {
  let component: PartinformationComponent;
  let fixture: ComponentFixture<PartinformationComponent>;
  let waypointnavigationService: WaypointnavigationService;
  let commonService: CommonService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      declarations: [PartinformationComponent],
      providers: [
        CommonService,
        WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
      .compileComponents();
    commonService = TestBed.get(CommonService);
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    spyOn(waypointnavigationService, 'navigateToSection').and.stub();
    spyOn(waypointnavigationService, 'partInfoSecEE').and.stub();
    spyOn(waypointnavigationService, 'partsBulletinSecEE').and.stub();
    spyOn(waypointnavigationService, 'searchResultSecEE').and.stub();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartinformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close part information', () => {
    component.closePartInfo();
    expect(waypointnavigationService.partInfoSecData.isOpen).toEqual(false);
    expect(component.isOpen).toEqual(false);
  });

});
