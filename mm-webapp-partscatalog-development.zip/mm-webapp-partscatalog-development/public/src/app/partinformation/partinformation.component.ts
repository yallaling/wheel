import { Component, OnInit, Inject } from '@angular/core';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { APP_CONFIG, AppConfig } from '../app.config';
import { CommonService } from '../core/common/common.service';
import { PartInfoSecData } from '../core/models/part-info-sec-data';
import { PartInformation } from '../core/models/part-information';
import { StatusType } from '../core/models/statusType';

@Component({
  selector: 'app-partinformation',
  templateUrl: './partinformation.component.html',
  styleUrls: ['./partinformation.component.scss']
})
export class PartinformationComponent implements OnInit {

  isOpen: Boolean = false;
  partInfo: PartInformation = new PartInformation();
  partNumber = '';
  partInfoStatus: StatusType = new StatusType();

  constructor(private commonService: CommonService, private waypointnavService: WaypointnavigationService,
    @Inject(APP_CONFIG) private config: AppConfig) { }

  ngOnInit() {
    this.waypointnavService.partInfoSecEE.subscribe((partInfoSecData: PartInfoSecData) => {
      this.partNumber = partInfoSecData.partNumber;
      this.openPartInfo(partInfoSecData);
    });
  }

  openPartInfo(partInfoSecData: PartInfoSecData) {
    this.commonService.getPartInfo(partInfoSecData).subscribe((partInfo: PartInformation) => {
      this.isOpen = true;
      this.partInfoStatus = partInfo.status;
      if (this.partInfoStatus.statusCode === this.config.SUCCESS) {
        this.partInfo = partInfo;
      }
      this.navigate(this.config.PART_INFORMATION);
    }, err => {
      this.isOpen = true;
      this.partInfoStatus.statusCode = this.config.FAILED;
    });
  }

  closePartInfo() {
    this.waypointnavService.resetPartInfoSecData();
    this.isOpen = false;
  }

  navigate(id) {
    this.waypointnavService.navigate(this.config.PART_INFORMATION, id);
  }
}
