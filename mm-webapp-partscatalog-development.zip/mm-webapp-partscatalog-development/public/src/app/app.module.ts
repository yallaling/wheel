import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavLocationsComponent } from './nav-locations/nav-locations.component';

import { CommonService } from './core/common/common.service';

import { SafePipe } from './pipes/safe-url.pipe';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { APP_CONFIG, APP_DI_CONFIG } from './app.config';
import { SearchComponent } from './search/search.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ClickOutsideModule } from 'ng-click-outside';
import { PartsbulletinComponent } from './partsbulletin/partsbulletin.component';
import { PartinformationComponent } from './partinformation/partinformation.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { ApiInterceptor } from './interceptor/ApiInterceptor';
import { HeaderComponent } from './header/header.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { ClipboardModule } from 'ngx-clipboard';
import { TooltipModule } from 'ng2-tooltip-directive';
import { PopoverModule } from 'ngx-popover';
import { PartsCatalogComponent } from './parts-catalog/parts-catalog.component';
import { AarselectionComponent } from './aarselection/aarselection.component';

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavLocationsComponent,
    SafePipe,
    SearchComponent,
    PartsbulletinComponent,
    PartinformationComponent,
    SearchResultsComponent,
    HeaderComponent,
    PartsCatalogComponent,
    AarselectionComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    InfiniteScrollModule,
    ClickOutsideModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    }),
    ClipboardModule,
    TooltipModule,
    PopoverModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: ApiInterceptor, multi: true },
    CommonService,
    { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
