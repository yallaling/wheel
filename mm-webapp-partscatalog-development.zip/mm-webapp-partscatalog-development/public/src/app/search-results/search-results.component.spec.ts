import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchResultsComponent } from './search-results.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CommonService } from '../core/common/common.service';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { APP_CONFIG, APP_DI_CONFIG, AppConfig } from '../app.config';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { SearchResultSecData } from '../core/models/search-result-sec-data';
import { Part } from '../core/models/part';
import { UtilService } from '../core/utils/util.service';
import { SearchResponse } from '../core/models/search-response';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('SearchResultsComponent', () => {
  let component: SearchResultsComponent;
  let commonService: CommonService;
  let waypointnavigationService: WaypointnavigationService;
  let config: AppConfig;
  let fixture: ComponentFixture<SearchResultsComponent>;
  let utilService: UtilService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        FormsModule,
        NgbModule,
        InfiniteScrollModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      declarations: [
        SearchResultsComponent
      ],
      providers: [
        CommonService,
        WaypointnavigationService,
        UtilService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
      .compileComponents();
    commonService = TestBed.get(CommonService);
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    utilService = TestBed.get(UtilService);
    config = TestBed.get(APP_CONFIG);
    component = new SearchResultsComponent(commonService, waypointnavigationService, utilService, config);
    spyOn(waypointnavigationService, 'navigateToSection').and.stub();
    spyOn(waypointnavigationService, 'partInfoSecEE').and.stub();
    spyOn(waypointnavigationService, 'partsBulletinSecEE').and.stub();
    spyOn(waypointnavigationService, 'searchResultSecEE').and.stub();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close search results', () => {
    component.closeSearchResults();
    expect(waypointnavigationService.searchResultSecData.isOpen).toEqual(false);
    expect(component.isOpen).toEqual(false);
  });

  it('should open parts bulletin', () => {
    const part: Part = new Part();
    part.partsCatalogFile = 'TEST_FILE';
    part.bulletinFileName = 'TEST_BULLETIN';
    part.bookmapVersion = 'TEST_VERSION';

    component.openPartsBulletin(part);
    const expectedPartsCatalogFileName = 'TEST_FILE';
    expect(waypointnavigationService.partsBulletinSecData.isOpen).toEqual(true);
    expect(waypointnavigationService.partsBulletinSecData.partsCatalogFile).toEqual(expectedPartsCatalogFileName);
  });

  it('should open parts info', () => {
    const part: Part = new Part();
    component.showPartsInfo(part);
    expect(waypointnavigationService.partInfoSecData.isOpen).toEqual(true);
  });

  it('should select part', () => {
    const part1: Part = new Part();
    part1.partNumber = 'TEST_PARTNUMBER1';
    part1.isSelected = true;

    const part2: Part = new Part();
    part2.partNumber = 'TEST_PARTNUMBER2';
    part2.isSelected = true;

    component.filteredPartList.push(part1);
    component.filteredPartList.push(part2);

    const expectedPartNumber = 'TEST_PARTNUMBER2';
    component.selectParts(part1);
    expect(component.selectedList[0].partNumber).toEqual(expectedPartNumber);
  });

});
