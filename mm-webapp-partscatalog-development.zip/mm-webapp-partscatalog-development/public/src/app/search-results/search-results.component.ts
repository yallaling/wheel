import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { APP_CONFIG, AppConfig } from '../app.config';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { SearchResultSecData } from '../core/models/search-result-sec-data';
import { Part } from '../core/models/part';
import { UtilService } from '../core/utils/util.service';
import { Item } from '../core/models/item';
import { SearchResponse } from '../core/models/search-response';
import { StatusType } from '../core/models/statusType';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit {
  searchString: string;
  parts: Array<Part> = new Array<Part>();
  filteredPartList: Array<Part> = new Array<Part>();
  litePartsList: Array<Part> = new Array<Part>();
  searchText: string;
  isOpen = false;
  hasVerticalScrollbar: Boolean;
  infiniteScrollDataLimit = 100;
  addCss: String;
  selectedList: Array<Part> = new Array<Part>();
  searchStatus: StatusType = new StatusType();
  isAARRoadSelection = false;
  isCWCUser = false;

  constructor(private commonService: CommonService, private waypointnavService: WaypointnavigationService,
    private utilService: UtilService, @Inject(APP_CONFIG) private config: AppConfig) {
  }

  ngOnInit() {
    this.isCWCUser = this.commonService.sessionDetails.isCWCUser;
    this.isAARRoadSelection = this.commonService.sessionDetails.isAARRoadSelection;
    this.waypointnavService.searchResultSecEE.subscribe((searchResultSecData: SearchResultSecData) => {
      this.search(searchResultSecData);
    });
  }
  filterPartsList() {
    this.searchText = this.searchText.toLocaleLowerCase();
    const tableScrollElem = document.getElementById('table-body-scroll');
    tableScrollElem.scrollTop = 0;
    this.filteredPartList = this.parts.filter((part: Part) =>
      part.partDescription.toLocaleLowerCase().indexOf(this.searchText) !== -1
      || part.partNumber.toLocaleLowerCase().indexOf(this.searchText) !== -1);
    this.loadDefaultList();
  }

  loadDefaultList() {
    const list = this.searchText ? this.filteredPartList : this.parts;
    this.filteredPartList = list.sort((a, b) => a.partDescription.localeCompare(b.partDescription));
    if (this.filteredPartList && this.filteredPartList.length && this.filteredPartList.length > this.infiniteScrollDataLimit) {
      this.litePartsList = this.filteredPartList.slice(0, this.infiniteScrollDataLimit);
    } else {
      this.litePartsList = this.filteredPartList;
    }
    this.selectedList = this.filteredPartList.filter((part: Part) => part.isSelected === true);
    setTimeout(() => {
      this.onResize();
    }, 500);
  }

  loadMoreParts() {
    this.litePartsList = this.filteredPartList.slice(0, this.litePartsList.length + 100);
  }

  search(searchResultSecData: SearchResultSecData) {
    if (this.resetBeforeSearch()) {
      this.commonService.search(searchResultSecData.searchQuery, false).subscribe((response: SearchResponse) => {
        this.searchStatus = response.status;
        if (this.searchStatus.statusCode === this.config.SUCCESS) {
          this.parts = response.parts;
          this.loadDefaultList();
        }
        this.navigate(this.config.SEARCH_RESULTS);
      }, err => {
        this.searchStatus.statusCode = this.config.FAILED;
        this.navigate(this.config.SEARCH_RESULTS);
      });
    }
  }

  closeSearchResults() {
    this.waypointnavService.resetSearchResultSecData();
    this.isOpen = false;
  }

  showPartsInfo(part: Part) {
    this.waypointnavService.partInfoSecData.partNumber = part.partNumber;
    this.waypointnavService.partInfoSecData.organizationId = this.commonService.sessionDetails.organizationid;
    this.waypointnavService.openPartInfoSec();
  }

  openPartsBulletin(part: Part) {
    this.waypointnavService.partsBulletinSecData.partsCatalogFile = part.partsCatalogFile;
    this.waypointnavService.partsBulletinSecData.bulletinFileName = part.bulletinFileName;
    this.waypointnavService.partsBulletinSecData.bookmapVersion = part.bookmapVersion;
    this.waypointnavService.partsBulletinSecData.bulletinName = part.bulletinName;
    this.waypointnavService.openPartsBulletinSec();
  }

  navigate(id: string) {
    this.waypointnavService.navigate(this.config.SEARCH_RESULTS, id);
  }

  selectParts(part: Part) {
    part.isSelected = part.isSelected ? false : true;
    this.selectedList = this.filteredPartList.filter((p: Part) => p.isSelected === true);
  }

  addtoCart() {
    const items: Array<Item> = this.selectedList.map((part: Part) => new Item(part.partNumber, part.qty, part.partDescription));
    if (this.isCWCUser) {
      this.utilService.cwcAddToCart(items);
    } else {
      this.utilService.addToCart(items);
    }
  }

  onResize() {
    const div = document.getElementById('table-body-scroll');
    this.hasVerticalScrollbar = div.scrollHeight > div.clientHeight;
    this.addCss = (this.hasVerticalScrollbar === true ? 'paddingRight17px' : 'no-padding-right');
  }

  isSynonym(part: Part): Boolean {
    const regex = new RegExp(this.searchString.toUpperCase());
    if ( regex.test(part.partDescription.toUpperCase()) || regex.test(part.partNumber.toUpperCase()) ) {
      return false;
    }
    return true;
  }

  resetBeforeSearch() {
    this.litePartsList = [];
    this.filteredPartList = [];
    this.parts = [];
    this.searchString = this.waypointnavService.searchResultSecData.searchQuery;
    this.isOpen = true;
    return true;
  }
}
