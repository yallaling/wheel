import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartsbulletinComponent } from './partsbulletin.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CommonService } from '../core/common/common.service';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { APP_CONFIG, APP_DI_CONFIG } from '../app.config';
import { SafePipe } from '../pipes/safe-url.pipe';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('PartsbulletinComponent', () => {
  let component: PartsbulletinComponent;
  let fixture: ComponentFixture<PartsbulletinComponent>;
  let waypointnavigationService: WaypointnavigationService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      declarations: [
        PartsbulletinComponent,
        SafePipe
      ],
      providers: [
        CommonService,
        WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    })
      .compileComponents();
    waypointnavigationService = TestBed.get(WaypointnavigationService);
    spyOn(waypointnavigationService, 'navigateToSection').and.stub();
    spyOn(waypointnavigationService, 'partInfoSecEE').and.stub();
    spyOn(waypointnavigationService, 'partsBulletinSecEE').and.stub();
    spyOn(waypointnavigationService, 'searchResultSecEE').and.stub();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartsbulletinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
