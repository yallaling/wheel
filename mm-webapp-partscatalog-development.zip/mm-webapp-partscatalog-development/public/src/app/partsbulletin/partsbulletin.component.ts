import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { AppConfig, APP_CONFIG } from '../app.config';
import { WaypointnavigationService } from '../core/waypointnavigation/waypointnavigation.service';
import { isArray } from 'util';
import { UtilService } from '../core/utils/util.service';
import { Item } from '../core/models/item';
import { PartsBulletinSecData } from '../core/models/parts-bulletin-sec-data';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-partsbulletin',
  templateUrl: './partsbulletin.component.html',
  styleUrls: ['./partsbulletin.component.scss']
})
export class PartsbulletinComponent implements OnInit {

  isOpen: Boolean = false;
  partsBulletinUrl = '';

  constructor(private commonService: CommonService, private waypointnavService: WaypointnavigationService,
    @Inject(APP_CONFIG) private config: AppConfig, private utilService: UtilService, private translate: TranslateService) { }

  ngOnInit() {
    this.waypointnavService.partsBulletinSecEE.subscribe((partsBulletinSecData: PartsBulletinSecData) => {
      this.openPartsBulletin(partsBulletinSecData);
    });

    const pb = this;
    window.addEventListener(this.config.MESSAGE, partsBulletinListener, false);

    function partsBulletinListener(event) {
      if (isArray(event.data)) {
        const parts: Array<Item> = event.data;
        if (pb.commonService.sessionDetails.isAARRoadSelection) {
          pb.utilService.showAlert(pb.config.ERROR, pb.translate.instant('_cart_failure_meassage_'),
            true, pb.config.ERROR_DOUBLE_TIMEOUT);
        } else if (pb.commonService.sessionDetails.isCWCUser) {
          pb.utilService.cwcAddToCart(parts);
        } else {
          pb.utilService.addToCart(parts);
        }
      } else {
        const part: Item = event.data;
        pb.openPartInfo(part);
      }
    }
  }

  openPartInfo(part: Item) {
    this.waypointnavService.partInfoSecData.partNumber = part.part_number;
    this.waypointnavService.partInfoSecData.organizationId = this.commonService.sessionDetails.organizationid;
    this.waypointnavService.openPartInfoSec();
  }

  openPartsBulletin(partsBulletinSecData: PartsBulletinSecData) {
    this.commonService.sessionDetails.partsBulletinOpened = partsBulletinSecData.bulletinName
      + '(' + partsBulletinSecData.bulletinFileName + ')';
    this.utilService.setLocalStorage();
    this.partsBulletinUrl = this.config.loadFileUrl + partsBulletinSecData.partsCatalogFile
      + this.config.SLASH + partsBulletinSecData.bookmapVersion
      + this.config.SLASH + this.config.HTML + this.config.SLASH
      + partsBulletinSecData.bulletinFileName + this.config.HTML_EXTENSION;
    this.isOpen = true;
    this.navigate(this.config.PART_BULLETIN);
  }

  closePartsBulletin() {
    this.waypointnavService.resetPartsBulletinSecData();
    this.isOpen = false;
    this.partsBulletinUrl = '';
  }

  navigate(id) {
    this.waypointnavService.navigate(this.config.PART_BULLETIN, id);
  }

}
