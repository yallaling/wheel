import { Component, OnInit, Inject } from '@angular/core';
import { CommonService } from '../core/common/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { AppConfig, APP_CONFIG } from '../app.config';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  pathToRoute: string;

  constructor(private commonService: CommonService, private activeRoute: ActivatedRoute, private translate: TranslateService,
    @Inject(APP_CONFIG) private config: AppConfig, private router: Router) {
  }

  ngOnInit() {
    this.commonService.sessionDetails.sesid = this.activeRoute.snapshot.queryParams[this.config.SESSION_ID];
    this.commonService.sessionDetails.defectid = this.activeRoute.snapshot.queryParams[this.config.DEFECT_ID];
    this.commonService.sessionDetails.workorderid = this.activeRoute.snapshot.queryParams[this.config.WORKORDER_ID];
    this.commonService.sessionDetails.customerId = this.activeRoute.snapshot.queryParams[this.config.CUSTOMER_ID];
    this.commonService.sessionDetails.roadNumber = this.activeRoute.snapshot.queryParams[this.config.ROAD_NUMBER];
    this.commonService.sessionDetails.customerName = this.activeRoute.snapshot.queryParams[this.config.CUSTOMER_NAME];

    const source: string = this.activeRoute.snapshot.queryParams[this.config.SOURCE];
    if (source) {
      if (source === this.config.MONITOR_BOARD) {
        this.commonService.sessionDetails.isAARRoadSelection = true;
        this.pathToRoute = this.config.AAR_SELECTION_PATH;
      } else if (source === this.config.HOME) {
        this.commonService.sessionDetails.isAARRoadSelection = true;
        this.pathToRoute = this.config.AAR_SELECTION_PATH;
      } else if (source === this.config.CWC) {
        this.commonService.sessionDetails.isCWCUser = true;
        this.pathToRoute = this.config.AAR_SELECTION_PATH;
      }
    } else {
      this.pathToRoute = this.config.DEFAULT_PATH;
    }

    this.commonService.getUserDetails().subscribe((userDetails: any) => {
      this.commonService.sessionDetails.userid = userDetails.user.id;
      this.commonService.sessionDetails.ssoId = userDetails.user.loginId;
      this.commonService.sessionDetails.firstName = userDetails.user.firstName;
      this.commonService.sessionDetails.lastName = userDetails.user.lastName;
      this.commonService.sessionDetails.organizationid = userDetails.user.serviceOrgId;
      this.commonService.sessionDetails.locale = this.config.DEFAULT_LANGUAGE;
      this.commonService.sessionDetails.inflag = this.config.OS_FLAG;
      this.commonService.sessionDetails.clientUrl = window.location.origin + '/eservices/';
      this.commonService.sessionDetails.cwcURL = userDetails.cwcURL;
      this.translate.use(this.config.DEFAULT_LANGUAGE);
      this.router.navigateByUrl(this.pathToRoute, { skipLocationChange: true });
      console.log('*****User Session Details for CWC****' + 'userID: ' + userDetails.user.id, 'LoginID: ' + userDetails.user.loginId,
      'FIrstName: ' + userDetails.user.firstName, 'LastName: ' + userDetails.user.lastName, 'OrgId: ' + userDetails.user.serviceOrgId);
      console.log('#####User Config Details####' , 'DefaultLanuage: ' + this.config.DEFAULT_LANGUAGE, 'OS : ' + this.config.OS_FLAG);
      console.log('***CWC URL for user*** ' + userDetails.cwcURL);
      console.log('CLient URL ' + window.location.origin + '/eservices/');
      });

  }
}

