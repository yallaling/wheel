import { Injectable, Inject, Output, EventEmitter } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpBackend } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppConfig, APP_CONFIG } from '../../app.config';
import { SessionDetails } from '../models/session-details';
import { AddtocartRequest } from '../models/addtocart-request';
import { PartInfoSecData } from '../models/part-info-sec-data';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  sessionDetails: SessionDetails = new SessionDetails();
  @Output() locoEE: EventEmitter<any> = new EventEmitter();

  constructor(private handler: HttpBackend, private http: HttpClient, @Inject(APP_CONFIG) private config: AppConfig) { }

  /**
   * Usage: for emitting session details.
   */
  populateLocoEE() {
    this.locoEE.emit(this.sessionDetails);
  }

  /**
   * Usage: For fetching user details from session
   */
  getUserDetails() {
    const url = this.config.userDetailsApiUrl;
    return this.http.get(url)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Usage: For fetching location hierarchy using locomotive id
   * @param locoId
   */
  getLocations(locoId: string): Observable<any> {
    const url = this.config.getLocationsUrl + 'locoId=' + locoId;
    return this.http.get(url).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Usage: For fetching workorder details using workorder id.
   * @param workorderid
   */
  getAssetDetails(workorderid: string): Observable<any> {
    const url = this.config.getAssetDetailsUrl + 'workorderid=' + workorderid;
    return this.http.get(url).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Usage: For adding items to the shopping cart.
   * @param data
   */
  addtocart(addtocartRequest: AddtocartRequest): Observable<any> {
    return this.http.post(this.config.addToCartUrl, addtocartRequest)
      .pipe(
        catchError(this.handleError)
      );
  }

  /**
   * Usage: For free form part search.
   * @param searchValue
   * @param isLimited
   */
  search(searchValue: string, isLimited: boolean): Observable<any> {
    searchValue = searchValue.trim();
    const url = this.config.searchUrl
      + 'locoId=' + this.sessionDetails.locoId
      + '&searchValue=' + searchValue
      + '&isLimited=' + isLimited
      + '&hierarchy=' + this.sessionDetails.searchHierarchy;
    if (isLimited) {
      const httpClient = new HttpClient(this.handler);
      return httpClient.get(url).pipe(catchError(this.handleError));
    } else {
      return this.http.get(url).pipe(catchError(this.handleError));
    }
  }

  /**
   * Usage : Gettin part information
   * @param partInfoSecData
   */
  getPartInfo(partInfoSecData: PartInfoSecData): Observable<any> {
    const url = this.config.getPartInfoUrl
      + 'partNumber=' + partInfoSecData.partNumber
      + '&organizationId=' + partInfoSecData.organizationId;
    return this.http.get(url).pipe(catchError(this.handleError));
  }

  /**
   * Usage: For getting AAR Roads list
   * @param roadNumber
   * @param customerId
   */
  getAARRoads(roadNumber: string, customerId: number): Observable<any> {
    const url = this.config.getAARRoadsUrl
      + 'roadNumber=' + roadNumber
      + '&customerId=' + customerId;
    return this.http.get(url).pipe(catchError(this.handleError));
  }

  /**
   * Usage : For fetching locomotive status in Parts Catalog 2.0
   * @param locomotiveId
   */
  getLocomotiveStatus(locomotiveId: number): Observable<any> {
    const url = this.config.getLocomotiveStatusUrl
      + 'locomotiveId=' + locomotiveId;
    return this.http.get(url).pipe(catchError(this.handleError));
  }

  /**
   * Usage: For fetching dynamic image using custid and locomodel
   * @param customerId
   * @param locomotiveId
   */
  getDynamicImageLoco(customerId: string, locomotiveId: string): Observable<any> {
    const url = this.config.getDynamicImageURL
      + 'customerId=' + customerId
      + '&locomotiveId=' + locomotiveId;
      return this.http.get(url).pipe(
      catchError(this.handleError)
    );
  }


  /**
   * Usage: Error handler
   * @param error
   */
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened; please try again later.');
  }


}
