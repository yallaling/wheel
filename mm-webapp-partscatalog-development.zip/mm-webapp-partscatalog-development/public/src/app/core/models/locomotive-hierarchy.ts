import { ChapterHierarchy } from './chapter-hierarchy';

export class LocomotiveHierarchy {
    private _bookMapVersion: string;
    private _id: number;
    private _partsCatalogFile: string;
    private _chapterHierarchy: Array<ChapterHierarchy>;

    /**
     * Getter bookMapVersion
     * @return {string}
     */
    public get bookMapVersion(): string {
        return this._bookMapVersion;
    }

    /**
     * Getter id
     * @return {number}
     */
    public get id(): number {
        return this._id;
    }

    /**
     * Getter partsCatalogFile
     * @return {string}
     */
    public get partsCatalogFile(): string {
        return this._partsCatalogFile;
    }

    /**
     * Getter chapterHierarchy
     * @return {Array<ChapterHierarchy>}
     */
    public get chapterHierarchy(): Array<ChapterHierarchy> {
        return this._chapterHierarchy;
    }

    /**
     * Setter bookMapVersion
     * @param {string} value
     */
    public set bookMapVersion(value: string) {
        this._bookMapVersion = value;
    }

    /**
     * Setter id
     * @param {number} value
     */
    public set id(value: number) {
        this._id = value;
    }

    /**
     * Setter partsCatalogFile
     * @param {string} value
     */
    public set partsCatalogFile(value: string) {
        this._partsCatalogFile = value;
    }

    /**
     * Setter chapterHierarchy
     * @param {Array<ChapterHierarchy>} value
     */
    public set chapterHierarchy(value: Array<ChapterHierarchy>) {
        this._chapterHierarchy = value;
    }

}
