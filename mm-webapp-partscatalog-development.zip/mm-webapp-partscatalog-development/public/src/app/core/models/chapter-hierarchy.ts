import { Bulletin } from './bulletin';

export class ChapterHierarchy {
    private _fileName: string;
    private _pcNavTitle: string;
    private _subChapterHierarchy: Array<ChapterHierarchy>;
    private _bulletin: Array<Bulletin>;

    /**
     * Getter fileName
     * @return {string}
     */
    public get fileName(): string {
        return this._fileName;
    }

    /**
     * Getter pcNavTitle
     * @return {string}
     */
    public get pcNavTitle(): string {
        return this._pcNavTitle;
    }

    /**
     * Getter subChapterHierarchy
     * @return {Array<ChapterHierarchy>}
     */
    public get subChapterHierarchy(): Array<ChapterHierarchy> {
        return this._subChapterHierarchy;
    }

    /**
     * Getter bulletin
     * @return {Array<Bulletin>}
     */
    public get bulletin(): Array<Bulletin> {
        return this._bulletin;
    }

    /**
     * Setter fileName
     * @param {string} value
     */
    public set fileName(value: string) {
        this._fileName = value;
    }

    /**
     * Setter pcNavTitle
     * @param {string} value
     */
    public set pcNavTitle(value: string) {
        this._pcNavTitle = value;
    }

    /**
     * Setter subChapterHierarchy
     * @param {Array<ChapterHierarchy>} value
     */
    public set subChapterHierarchy(value: Array<ChapterHierarchy>) {
        this._subChapterHierarchy = value;
    }

    /**
     * Setter bulletin
     * @param {Array<Bulletin>} value
     */
    public set bulletin(value: Array<Bulletin>) {
        this._bulletin = value;
    }

}
