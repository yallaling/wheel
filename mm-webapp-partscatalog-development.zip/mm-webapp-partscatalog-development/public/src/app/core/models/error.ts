export class Error {
    private _errorCode: string;
    private _errorMsg: string;

    /**
     * Getter errorCode
     * @return {string}
     */
    public get errorCode(): string {
        return this._errorCode;
    }

    /**
     * Getter errorMsg
     * @return {string}
     */
    public get errorMsg(): string {
        return this._errorMsg;
    }

    /**
     * Setter errorCode
     * @param {string} value
     */
    public set errorCode(value: string) {
        this._errorCode = value;
    }

    /**
     * Setter errorMsg
     * @param {string} value
     */
    public set errorMsg(value: string) {
        this._errorMsg = value;
    }

}
