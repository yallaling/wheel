export class Item {
    private _part_number: string;
    private _quantity: number;
    private _description: string;

    constructor(_part_number: string, _quantity: number, _description: string) {
        this._part_number = _part_number;
        this._quantity = _quantity;
        this._description = _description;
    }

    /**
     * Getter part_number
     * @return {string}
     */
    public get part_number(): string {
        return this._part_number;
    }

    /**
     * Getter quantity
     * @return {number}
     */
    public get quantity(): number {
        return this._quantity;
    }

    /**
     * Getter description
     * @return {string}
     */
    public get description(): string {
        return this._description;
    }

    /**
     * Setter part_number
     * @param {string} value
     */
    public set part_number(value: string) {
        this._part_number = value;
    }

    /**
     * Setter quantity
     * @param {number} value
     */
    public set quantity(value: number) {
        this._quantity = value;
    }

    /**
     * Setter description
     * @param {string} value
     */
    public set description(value: string) {
        this._description = value;
    }

}

