export class AARRoad {
    private _locomotiveId: number;
    private _roadNumber: string;
    private _aarRoad: string;
    private _locoStatus: string;
    private _locoType: string;

    /**
     * Getter locomotiveId
     * @return {number}
     */
    public get locomotiveId(): number {
        return this._locomotiveId;
    }

    /**
     * Setter locomotiveId
     * @param {number} value
     */
    public set locomotiveId(value: number) {
        this._locomotiveId = value;
    }

    /**
     * Getter roadNumber
     * @return {string}
     */
    public get roadNumber(): string {
        return this._roadNumber;
    }

    /**
     * Getter aarRoad
     * @return {string}
     */
    public get aarRoad(): string {
        return this._aarRoad;
    }

    /**
     * Getter locoStatus
     * @return {string}
     */
    public get locoStatus(): string {
        return this._locoStatus;
    }

    /**
     * Getter locoType
     * @return {string}
     */
    public get locoType(): string {
        return this._locoType;
    }

    /**
     * Setter roadNumber
     * @param {string} value
     */
    public set roadNumber(value: string) {
        this._roadNumber = value;
    }

    /**
     * Setter aarRoad
     * @param {string} value
     */
    public set aarRoad(value: string) {
        this._aarRoad = value;
    }

    /**
     * Setter locoStatus
     * @param {string} value
     */
    public set locoStatus(value: string) {
        this._locoStatus = value;
    }

    /**
     * Setter locoType
     * @param {string} value
     */
    public set locoType(value: string) {
        this._locoType = value;
    }
}
