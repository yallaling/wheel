export class Workorder {
    private _badActor: string;
    private _workorderNumber: string;

    /**
     * Getter badActor
     * @return {string}
     */
    public get badActor(): string {
        return this._badActor;
    }

    /**
     * Getter workorderNumber
     * @return {string}
     */
    public get workorderNumber(): string {
        return this._workorderNumber;
    }

    /**
     * Setter badActor
     * @param {string} value
     */
    public set badActor(value: string) {
        this._badActor = value;
    }

    /**
     * Setter workorderNumber
     * @param {string} value
     */
    public set workorderNumber(value: string) {
        this._workorderNumber = value;
    }

}
