export class StatusType {
    private _statusCode: string;
    private _message: string;

    /**
     * Getter statusCode
     * @return {string}
     */
    public get statusCode(): string {
        return this._statusCode;
    }

    /**
     * Getter message
     * @return {string}
     */
    public get message(): string {
        return this._message;
    }

    /**
     * Setter statusCode
     * @param {string} value
     */
    public set statusCode(value: string) {
        this._statusCode = value;
    }

    /**
     * Setter message
     * @param {string} value
     */
    public set message(value: string) {
        this._message = value;
    }

}
