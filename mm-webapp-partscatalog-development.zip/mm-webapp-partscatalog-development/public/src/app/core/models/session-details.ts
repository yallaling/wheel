export class SessionDetails {

    private _userid: string;
    private _ssoId: string;
    private _firstName: string;
    private _lastName: string;
    private _organizationid: string;
    private _locale: string;
    private _inflag: string;
    private _sesid: string;
    private _roadNumber: string;
    private _customerName: string;
    private _customerId: string;
    private _defectid: string;
    private _workorderid: string;
    private _clientUrl: string;
    private _locoId: string;
    private _workOrderNumber: string;
    private _isAARRoadSelection: boolean;
    private _hierarchyOpened: string;
    private _partsBulletinOpened: string;
    private _isCWCUser: boolean;
    private _cwcURL: string;
    private _searchHierarchy: string;

    constructor() {
    }

    /**
     * Getter userid
     * @return {string}
     */
    public get userid(): string {
        return this._userid;
    }

    /**
     * Getter ssoId
     * @return {string}
     */
    public get ssoId(): string {
        return this._ssoId;
    }

    /**
     * Getter firstName
     * @return {string}
     */
    public get firstName(): string {
        return this._firstName;
    }

    /**
     * Getter lastName
     * @return {string}
     */
    public get lastName(): string {
        return this._lastName;
    }

    /**
     * Getter organizationid
     * @return {string}
     */
    public get organizationid(): string {
        return this._organizationid;
    }

    /**
     * Getter locale
     * @return {string}
     */
    public get locale(): string {
        return this._locale;
    }

    /**
     * Getter inflag
     * @return {string}
     */
    public get inflag(): string {
        return this._inflag;
    }

    /**
     * Getter sesid
     * @return {string}
     */
    public get sesid(): string {
        return this._sesid;
    }

    /**
     * Getter roadNumber
     * @return {string}
     */
    public get roadNumber(): string {
        return this._roadNumber;
    }

    /**
     * Getter customerName
     * @return {string}
     */
    public get customerName(): string {
        return this._customerName;
    }

    /**
     * Getter customerId
     * @return {string}
     */
    public get customerId(): string {
        return this._customerId;
    }

    /**
     * Getter defectid
     * @return {string}
     */
    public get defectid(): string {
        return this._defectid;
    }

    /**
     * Getter workorderid
     * @return {string}
     */
    public get workorderid(): string {
        return this._workorderid;
    }

    /**
     * Getter clientUrl
     * @return {string}
     */
    public get clientUrl(): string {
        return this._clientUrl;
    }

    /**
     * Getter locoId
     * @return {string}
     */
    public get locoId(): string {
        return this._locoId;
    }

    /**
     * Setter userid
     * @param {string} value
     */
    public set userid(value: string) {
        this._userid = value;
    }

    /**
     * Setter ssoId
     * @param {string} value
     */
    public set ssoId(value: string) {
        this._ssoId = value;
    }

    /**
     * Setter firstName
     * @param {string} value
     */
    public set firstName(value: string) {
        this._firstName = value;
    }

    /**
     * Setter lastName
     * @param {string} value
     */
    public set lastName(value: string) {
        this._lastName = value;
    }

    /**
     * Setter organizationid
     * @param {string} value
     */
    public set organizationid(value: string) {
        this._organizationid = value;
    }

    /**
     * Setter locale
     * @param {string} value
     */
    public set locale(value: string) {
        this._locale = value;
    }

    /**
     * Setter inflag
     * @param {string} value
     */
    public set inflag(value: string) {
        this._inflag = value;
    }

    /**
     * Setter sesid
     * @param {string} value
     */
    public set sesid(value: string) {
        this._sesid = value;
    }

    /**
     * Setter roadNumber
     * @param {string} value
     */
    public set roadNumber(value: string) {
        this._roadNumber = value;
    }

    /**
     * Setter customerName
     * @param {string} value
     */
    public set customerName(value: string) {
        this._customerName = value;
    }

    /**
     * Setter customerId
     * @param {string} value
     */
    public set customerId(value: string) {
        this._customerId = value;
    }

    /**
     * Setter defectid
     * @param {string} value
     */
    public set defectid(value: string) {
        this._defectid = value;
    }

    /**
     * Setter workorderid
     * @param {string} value
     */
    public set workorderid(value: string) {
        this._workorderid = value;
    }

    /**
     * Setter clientUrl
     * @param {string} value
     */
    public set clientUrl(value: string) {
        this._clientUrl = value;
    }

    /**
     * Setter locoId
     * @param {string} value
     */
    public set locoId(value: string) {
        this._locoId = value;
    }

    /**
     * Getter workOrderNumber
     * @return {string}
     */
    public get workOrderNumber(): string {
        return this._workOrderNumber;
    }

    /**
     * Setter workOrderNumber
     * @param {string} value
     */
    public set workOrderNumber(value: string) {
        this._workOrderNumber = value;
    }

    /**
     * Getter isAARRoadSelection
     * @return {boolean}
     */
    public get isAARRoadSelection(): boolean {
        return this._isAARRoadSelection;
    }

    /**
     * Setter isAARRoadSelection
     * @param {boolean} value
     */
    public set isAARRoadSelection(value: boolean) {
        this._isAARRoadSelection = value;
    }


    /**
     * Getter hierarchyOpened
     * @return {string}
     */
    public get hierarchyOpened(): string {
        return this._hierarchyOpened;
    }

    /**
     * Setter hierarchyOpened
     * @param {string} value
     */
    public set hierarchyOpened(value: string) {
        this._hierarchyOpened = value;
    }

    /**
     * Getter partsBulletinOpened
     * @return {string}
     */
    public get partsBulletinOpened(): string {
        return this._partsBulletinOpened;
    }

    /**
     * Setter partsBulletinOpened
     * @param {string} value
     */
    public set partsBulletinOpened(value: string) {
        this._partsBulletinOpened = value;
    }

    /**
     * Getter cwcURL
     * @return {string}
     */
    public get cwcURL(): string {
        return this._cwcURL;
    }

    /**
     * Setter cwcURL
     * @param {string} value
     */
    public set cwcURL(value: string) {
        this._cwcURL = value;
    }
    /**
     * Getter isCWCUser
     * @return {boolean}
     */
    public get isCWCUser(): boolean {
        return this._isCWCUser;
    }

    /**
     * Setter isCWCUser
     * @param {boolean} value
     */
    public set isCWCUser(value: boolean) {
        this._isCWCUser = value;
    }

    /**
     * Getter searchHierarchy
     * @return {string}
     */
    public get searchHierarchy(): string {
        return this._searchHierarchy;
    }

    /**
     * Setter searchHierarchy
     * @param {string} value
     */
    public set searchHierarchy(value: string) {
        this._searchHierarchy = value;
    }

}
