export class Alert {
    private _type: string;
    private _msg: string;
    private _visible: boolean;
    private _timeout: number;

    constructor(_type?: string, _msg?: string, _visible?: boolean, _timeout?: number) {
        this._type = _type;
        this._msg = _msg;
        this._visible = _visible;
        this._timeout = _timeout;
    }

    /**
     * Getter type
     * @return {string}
     */
    public get type(): string {
        return this._type;
    }

    /**
     * Getter msg
     * @return {string}
     */
    public get msg(): string {
        return this._msg;
    }

    /**
     * Getter visible
     * @return {boolean}
     */
    public get visible(): boolean {
        return this._visible;
    }

    /**
     * Getter timeout
     * @return {number}
     */
    public get timeout(): number {
        return this._timeout;
    }

    /**
     * Setter type
     * @param {string} value
     */
    public set type(value: string) {
        this._type = value;
    }

    /**
     * Setter msg
     * @param {string} value
     */
    public set msg(value: string) {
        this._msg = value;
    }

    /**
     * Setter visible
     * @param {boolean} value
     */
    public set visible(value: boolean) {
        this._visible = value;
    }

    /**
     * Setter timeout
     * @param {number} value
     */
    public set timeout(value: number) {
        this._timeout = value;
    }

}
