export class PartInfoSecData {
    private _isOpen: boolean;
    private _partNumber: string;
    private _organizationId: string;

    /**
     * Getter isOpen
     * @return {boolean}
     */
    public get isOpen(): boolean {
        return this._isOpen;
    }

    /**
     * Getter partNumber
     * @return {string}
     */
    public get partNumber(): string {
        return this._partNumber;
    }

    /**
     * Getter organizationId
     * @return {string}
     */
    public get organizationId(): string {
        return this._organizationId;
    }

    /**
     * Setter isOpen
     * @param {boolean} value
     */
    public set isOpen(value: boolean) {
        this._isOpen = value;
    }

    /**
     * Setter partNumber
     * @param {string} value
     */
    public set partNumber(value: string) {
        this._partNumber = value;
    }

    /**
     * Setter organizationId
     * @param {string} value
     */
    public set organizationId(value: string) {
        this._organizationId = value;
    }

}
