import { EmissionTier } from './emission-tier';
import { StatusType } from './statusType';

export class PartInformation {
    private _partNumber: string;
    private _partDescription: string;
    private _partStatus: string;
    private _emmissionTier: Array<EmissionTier>;
    private _status: StatusType;

    /**
     * Getter partNumber
     * @return {string}
     */
    public get partNumber(): string {
        return this._partNumber;
    }

    /**
     * Getter partDescription
     * @return {string}
     */
    public get partDescription(): string {
        return this._partDescription;
    }

    /**
     * Getter partStatus
     * @return {string}
     */
    public get partStatus(): string {
        return this._partStatus;
    }

    /**
     * Getter emmissionTier
     * @return {Array<EmissionTier>}
     */
    public get emmissionTier(): Array<EmissionTier> {
        return this._emmissionTier;
    }

    /**
     * Setter partNumber
     * @param {string} value
     */
    public set partNumber(value: string) {
        this._partNumber = value;
    }

    /**
     * Setter partDescription
     * @param {string} value
     */
    public set partDescription(value: string) {
        this._partDescription = value;
    }

    /**
     * Setter partStatus
     * @param {string} value
     */
    public set partStatus(value: string) {
        this._partStatus = value;
    }

    /**
     * Setter emmissionTier
     * @param {Array<EmissionTier>} value
     */
    public set emmissionTier(value: Array<EmissionTier>) {
        this._emmissionTier = value;
    }


    /**
     * Getter status
     * @return {StatusType}
     */
    public get status(): StatusType {
        return this._status;
    }

    /**
     * Setter status
     * @param {StatusType} value
     */
    public set status(value: StatusType) {
        this._status = value;
    }


}
