export class Details {
    private requestedQuantity: number;
    private createdBy: number;
    private lastUpdateBy: number;
    private partsCatalogItemNumber: string;
    private itemNumberPicked: string;
    private defectId: number;
    private traceable: string;
    private positionTracked: string;
    private shoppingCartDetailsStatus: string;
    private requestSource: string;
    private materialRequetedBy: string;

    /**
     * Getter requestedQuantity
     * @return {number}
     */
    public get getRequestedQuantity(): number {
        return this.requestedQuantity;
    }

    /**
     * Getter createdBy
     * @return {number}
     */
    public get getCreatedBy(): number {
        return this.createdBy;
    }

    /**
     * Getter lastUpdateBy
     * @return {number}
     */
    public get getLastUpdateBy(): number {
        return this.lastUpdateBy;
    }

    /**
     * Getter partsCatalogItemNumber
     * @return {string}
     */
    public get getPartsCatalogItemNumber(): string {
        return this.partsCatalogItemNumber;
    }

    /**
     * Getter itemNumberPicked
     * @return {string}
     */
    public get getItemNumberPicked(): string {
        return this.itemNumberPicked;
    }

    /**
     * Getter defectId
     * @return {number}
     */
    public get getDefectId(): number {
        return this.defectId;
    }

    /**
     * Getter traceable
     * @return {string}
     */
    public get getTraceable(): string {
        return this.traceable;
    }

    /**
     * Getter positionTracked
     * @return {string}
     */
    public get getPositionTracked(): string {
        return this.positionTracked;
    }

    /**
     * Getter shoppingCartDetailsStatus
     * @return {string}
     */
    public get getShoppingCartDetailsStatus(): string {
        return this.shoppingCartDetailsStatus;
    }

    /**
     * Getter requestSource
     * @return {string}
     */
    public get getRequestSource(): string {
        return this.requestSource;
    }

    /**
     * Getter materialRequetedBy
     * @return {string}
     */
    public get getMaterialRequetedBy(): string {
        return this.materialRequetedBy;
    }

    /**
     * Setter requestedQuantity
     * @param {number} value
     */
    public set setRequestedQuantity(value: number) {
        this.requestedQuantity = value;
    }

    /**
     * Setter createdBy
     * @param {number} value
     */
    public set setCreatedBy(value: number) {
        this.createdBy = value;
    }

    /**
     * Setter lastUpdateBy
     * @param {number} value
     */
    public set setLastUpdateBy(value: number) {
        this.lastUpdateBy = value;
    }

    /**
     * Setter partsCatalogItemNumber
     * @param {string} value
     */
    public set setPartsCatalogItemNumber(value: string) {
        this.partsCatalogItemNumber = value;
    }

    /**
     * Setter itemNumberPicked
     * @param {string} value
     */
    public set setItemNumberPicked(value: string) {
        this.itemNumberPicked = value;
    }

    /**
     * Setter defectId
     * @param {number} value
     */
    public set setDefectId(value: number) {
        this.defectId = value;
    }

    /**
     * Setter traceable
     * @param {string} value
     */
    public set setTraceable(value: string) {
        this.traceable = value;
    }

    /**
     * Setter positionTracked
     * @param {string} value
     */
    public set setPositionTracked(value: string) {
        this.positionTracked = value;
    }

    /**
     * Setter shoppingCartDetailsStatus
     * @param {string} value
     */
    public set setShoppingCartDetailsStatus(value: string) {
        this.shoppingCartDetailsStatus = value;
    }

    /**
     * Setter requestSource
     * @param {string} value
     */
    public set setRequestSource(value: string) {
        this.requestSource = value;
    }

    /**
     * Setter materialRequetedBy
     * @param {string} value
     */
    public set setMaterialRequetedBy(value: string) {
        this.materialRequetedBy = value;
    }

}
