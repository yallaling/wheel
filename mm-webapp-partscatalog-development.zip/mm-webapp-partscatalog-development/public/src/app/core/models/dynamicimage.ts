export class DynamicImage {
    private _locoImageName: string;
    private _statusCode: string;
    private _message: string;

    /**
     * Getter statusCode
     * @return {string}
     */
    public get statusCode(): string {
        return this._statusCode;
    }

    /**
     * Getter message
     * @return {string}
     */
    public get message(): string {
        return this._message;
    }

    /**
     * Setter statusCode
     * @param {string} value
     */
    public set statusCode(value: string) {
        this._statusCode = value;
    }

    /**
     * Setter message
     * @param {string} value
     */
    public set message(value: string) {
        this._message = value;
    }
    /**
     * Getter image name
     * @return {string}
     */
    public get locoImageName(): string {
        return this._locoImageName;
    }

    /**
     * Setter _imageName
     * @param {string} value
     */
    public set locoImageName(value: string) {
        this._locoImageName = value;
    }

}
