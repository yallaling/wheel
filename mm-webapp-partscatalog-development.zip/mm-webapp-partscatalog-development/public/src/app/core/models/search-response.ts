import { Part } from './part';
import { StatusType } from './statusType';

export class SearchResponse {
    private _parts: Array<Part>;
    private _status: StatusType;

    /**
     * Getter parts
     * @return {Array<Part>}
     */
    public get parts(): Array<Part> {
        return this._parts;
    }

    /**
     * Getter status
     * @return {StatusType}
     */
    public get status(): StatusType {
        return this._status;
    }

    /**
     * Setter parts
     * @param {Array<Part>} value
     */
    public set parts(value: Array<Part>) {
        this._parts = value;
    }

    /**
     * Setter status
     * @param {StatusType} value
     */
    public set status(value: StatusType) {
        this._status = value;
    }

}
