import { Error } from './error';

export class ErrorType {
    private _error: Array<Error>;

    /**
     * Getter error
     * @return {Array<Error>}
     */
    public get error(): Array<Error> {
        return this._error;
    }

    /**
     * Setter error
     * @param {Array<Error>} value
     */
    public set error(value: Array<Error>) {
        this._error = value;
    }

}
