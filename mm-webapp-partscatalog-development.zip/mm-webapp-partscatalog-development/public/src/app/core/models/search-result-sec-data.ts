export class SearchResultSecData {

    private _isOpen: boolean;
    private _searchQuery: string;

    /**
     * Getter isOpen
     * @return {boolean}
     */
    public get isOpen(): boolean {
        return this._isOpen;
    }

    /**
     * Getter searchQuery
     * @return {string}
     */
    public get searchQuery(): string {
        return this._searchQuery;
    }

    /**
     * Setter isOpen
     * @param {boolean} value
     */
    public set isOpen(value: boolean) {
        this._isOpen = value;
    }

    /**
     * Setter searchQuery
     * @param {string} value
     */
    public set searchQuery(value: string) {
        this._searchQuery = value;
    }

}
