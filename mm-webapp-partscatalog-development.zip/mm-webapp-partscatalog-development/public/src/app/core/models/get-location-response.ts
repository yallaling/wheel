import { LocomotiveHierarchy } from './locomotive-hierarchy';
import { StatusType } from './statusType';

export class GetLocationResponse {
    private _locomotiveHierarchy: LocomotiveHierarchy;
    private _status: StatusType;

    /**
     * Getter locomotiveHierarchy
     * @return {LocomotiveHierarchy}
     */
    public get locomotiveHierarchy(): LocomotiveHierarchy {
        return this._locomotiveHierarchy;
    }

    /**
     * Getter status
     * @return {StatusType}
     */
    public get status(): StatusType {
        return this._status;
    }

    /**
     * Setter locomotiveHierarchy
     * @param {LocomotiveHierarchy} value
     */
    public set locomotiveHierarchy(value: LocomotiveHierarchy) {
        this._locomotiveHierarchy = value;
    }

    /**
     * Setter status
     * @param {StatusType} value
     */
    public set status(value: StatusType) {
        this._status = value;
    }

}
