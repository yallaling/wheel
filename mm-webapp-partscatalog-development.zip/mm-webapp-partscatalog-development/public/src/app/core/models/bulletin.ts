export class Bulletin {
    private _bulletinId: string;
    private _bulletinNavTitle: string;
    private _name: string;

    /**
     * Getter bulletinId
     * @return {string}
     */
    public get bulletinId(): string {
        return this._bulletinId;
    }

    /**
     * Getter bulletinNavTitle
     * @return {string}
     */
    public get bulletinNavTitle(): string {
        return this._bulletinNavTitle;
    }

    /**
     * Getter name
     * @return {string}
     */
    public get name(): string {
        return this._name;
    }

    /**
     * Setter bulletinId
     * @param {string} value
     */
    public set bulletinId(value: string) {
        this._bulletinId = value;
    }

    /**
     * Setter bulletinNavTitle
     * @param {string} value
     */
    public set bulletinNavTitle(value: string) {
        this._bulletinNavTitle = value;
    }

    /**
     * Setter name
     * @param {string} value
     */
    public set name(value: string) {
        this._name = value;
    }

}
