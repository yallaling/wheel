export class Part {
    private _isSelected: boolean;
    private _partNumber: string;
    private _partsCatalogFile: string;
    private _bulletinFileName: string;
    private _bookmapVersion: string;
    private _partDescription: string;
    private _qty: number;
    private _bulletinName: string;
    private _synonyms: Array<string>;

    constructor() {
        this._isSelected = false;
    }

    /**
    * Getter isSelected
    * @return {boolean}
    */
    public get isSelected(): boolean {
        return this._isSelected;
    }

    /**
     * Setter isSelected
     * @param {boolean} value
     */
    public set isSelected(value: boolean) {
        this._isSelected = value;
    }

    /**
     * Getter partDescription
     * @return {string}
     */
    public get partDescription(): string {
        return this._partDescription;
    }

    /**
     * Setter partDescription
     * @param {string} value
     */
    public set partDescription(value: string) {
        this._partDescription = value;
    }

    /**
     * Getter qty
     * @return {number}
     */
    public get qty(): number {
        return this._qty;
    }

    /**
     * Setter qty
     * @param {number} value
     */
    public set qty(value: number) {
        this._qty = value;
    }

    /**
     * Getter partNumber
     * @return {string}
     */
    public get partNumber(): string {
        return this._partNumber;
    }

    /**
     * Getter partsCatalogFile
     * @return {string}
     */
    public get partsCatalogFile(): string {
        return this._partsCatalogFile;
    }

    /**
     * Getter bulletinFileName
     * @return {string}
     */
    public get bulletinFileName(): string {
        return this._bulletinFileName;
    }

    /**
     * Getter bookmapVersion
     * @return {string}
     */
    public get bookmapVersion(): string {
        return this._bookmapVersion;
    }

    /**
     * Setter partNumber
     * @param {string} value
     */
    public set partNumber(value: string) {
        this._partNumber = value;
    }

    /**
     * Setter partsCatalogFile
     * @param {string} value
     */
    public set partsCatalogFile(value: string) {
        this._partsCatalogFile = value;
    }

    /**
     * Setter bulletinFileName
     * @param {string} value
     */
    public set bulletinFileName(value: string) {
        this._bulletinFileName = value;
    }

    /**
     * Setter bookmapVersion
     * @param {string} value
     */
    public set bookmapVersion(value: string) {
        this._bookmapVersion = value;
    }

    /**
     * Getter bulletinName
     * @return {string}
     */
    public get bulletinName(): string {
        return this._bulletinName;
    }

    /**
     * Setter bulletinName
     * @param {string} value
     */
    public set bulletinName(value: string) {
        this._bulletinName = value;
    }

    /**
     * Getter synonyms
     * @return {Array<string>}
     */
    public get synonyms(): Array<string> {
        return this._synonyms;
    }

    /**
     * Setter synonyms
     * @param {Array<string>} value
     */
    public set synonyms(value: Array<string>) {
        this._synonyms = value;
    }

}
