export class Asset {
    private _locomotiveTypeCode: string;
    private _emissions: string;
    private _airBrakes: string;
    private _fleetName: string;
    private _assetInServiceDate: string;
    private _customerAgreement: string;

    /**
     * Getter locomotiveTypeCode
     * @return {string}
     */
    public get locomotiveTypeCode(): string {
        return this._locomotiveTypeCode;
    }

    /**
     * Getter emissions
     * @return {string}
     */
    public get emissions(): string {
        return this._emissions;
    }

    /**
     * Getter airBrakes
     * @return {string}
     */
    public get airBrakes(): string {
        return this._airBrakes;
    }

    /**
     * Getter fleetName
     * @return {string}
     */
    public get fleetName(): string {
        return this._fleetName;
    }

    /**
     * Getter assetInServiceDate
     * @return {string}
     */
    public get assetInServiceDate(): string {
        return this._assetInServiceDate;
    }

    /**
     * Getter customerAgreement
     * @return {string}
     */
    public get customerAgreement(): string {
        return this._customerAgreement;
    }

    /**
     * Setter locomotiveTypeCode
     * @param {string} value
     */
    public set locomotiveTypeCode(value: string) {
        this._locomotiveTypeCode = value;
    }

    /**
     * Setter emissions
     * @param {string} value
     */
    public set emissions(value: string) {
        this._emissions = value;
    }

    /**
     * Setter airBrakes
     * @param {string} value
     */
    public set airBrakes(value: string) {
        this._airBrakes = value;
    }

    /**
     * Setter fleetName
     * @param {string} value
     */
    public set fleetName(value: string) {
        this._fleetName = value;
    }

    /**
     * Setter assetInServiceDate
     * @param {string} value
     */
    public set assetInServiceDate(value: string) {
        this._assetInServiceDate = value;
    }

    /**
     * Setter customerAgreement
     * @param {string} value
     */
    public set customerAgreement(value: string) {
        this._customerAgreement = value;
    }

}
