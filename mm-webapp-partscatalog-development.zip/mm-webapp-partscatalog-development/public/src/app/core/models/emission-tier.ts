export class EmissionTier {
    private _tier: string;
    private _tierValue: string;
    /**
     * Getter tier
     * @return {string}
     */
    public get tier(): string {
        return this._tier;
    }

    /**
     * Getter tierValue
     * @return {string}
     */
    public get tierValue(): string {
        return this._tierValue;
    }

    /**
     * Setter tier
     * @param {string} value
     */
    public set tier(value: string) {
        this._tier = value;
    }

    /**
     * Setter tierValue
     * @param {string} value
     */
    public set tierValue(value: string) {
        this._tierValue = value;
    }

}
