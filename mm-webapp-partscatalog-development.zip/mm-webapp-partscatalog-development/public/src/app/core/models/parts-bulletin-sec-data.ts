export class PartsBulletinSecData {
    private _isOpen: boolean;
    private _partsCatalogFile: string;
    private _bulletinFileName: string;
    private _bookmapVersion: string;
    private _bulletinName: string;

    /**
     * Getter isOpen
     * @return {boolean}
     */
    public get isOpen(): boolean {
        return this._isOpen;
    }

    /**
     * Getter partsCatalogFile
     * @return {string}
     */
    public get partsCatalogFile(): string {
        return this._partsCatalogFile;
    }

    /**
     * Getter bulletinFileName
     * @return {string}
     */
    public get bulletinFileName(): string {
        return this._bulletinFileName;
    }

    /**
     * Getter bookmapVersion
     * @return {string}
     */
    public get bookmapVersion(): string {
        return this._bookmapVersion;
    }

    /**
     * Setter isOpen
     * @param {boolean} value
     */
    public set isOpen(value: boolean) {
        this._isOpen = value;
    }

    /**
     * Setter partsCatalogFile
     * @param {string} value
     */
    public set partsCatalogFile(value: string) {
        this._partsCatalogFile = value;
    }

    /**
     * Setter bulletinFileName
     * @param {string} value
     */
    public set bulletinFileName(value: string) {
        this._bulletinFileName = value;
    }

    /**
     * Setter bookmapVersion
     * @param {string} value
     */
    public set bookmapVersion(value: string) {
        this._bookmapVersion = value;
    }

    /**
     * Getter bulletinName
     * @return {string}
     */
    public get bulletinName(): string {
        return this._bulletinName;
    }

    /**
     * Setter bulletinName
     * @param {string} value
     */
    public set bulletinName(value: string) {
        this._bulletinName = value;
    }

}
