import { Details } from './details';

export class Header {
    private serviceWorkOrderId: number;
    private organizationId: number;
    private createdBy: number;
    private lastUpdateBy: number;
    private shoppingCartStatus: string;
    private details: Array<Details>;
    private defectId: number;

    /**
     * Getter defectId
     * @return {number}
     */
    public get getDefectId(): number {
        return this.defectId;
    }

    /**
     * Setter defectId
     * @param {number} value
     */
    public set setDefectId(value: number) {
        this.defectId = value;
    }

    /**
     * Getter serviceWorkOrderId
     * @return {number}
     */
    public get getServiceWorkOrderId(): number {
        return this.serviceWorkOrderId;
    }

    /**
     * Getter organizationId
     * @return {number}
     */
    public get getOrganizationId(): number {
        return this.organizationId;
    }

    /**
     * Getter createdBy
     * @return {number}
     */
    public get getCreatedBy(): number {
        return this.createdBy;
    }

    /**
     * Getter lastUpdateBy
     * @return {number}
     */
    public get getLastUpdateBy(): number {
        return this.lastUpdateBy;
    }

    /**
     * Getter shoppingCartStatus
     * @return {string}
     */
    public get getShoppingCartStatus(): string {
        return this.shoppingCartStatus;
    }

    /**
     * Getter details
     * @return {Array<Details>}
     */
    public get getDetails(): Array<Details> {
        return this.details;
    }

    /**
     * Setter serviceWorkOrderId
     * @param {number} value
     */
    public set setServiceWorkOrderId(value: number) {
        this.serviceWorkOrderId = value;
    }

    /**
     * Setter organizationId
     * @param {number} value
     */
    public set setOrganizationId(value: number) {
        this.organizationId = value;
    }

    /**
     * Setter createdBy
     * @param {number} value
     */
    public set setCreatedBy(value: number) {
        this.createdBy = value;
    }

    /**
     * Setter lastUpdateBy
     * @param {number} value
     */
    public set setLastUpdateBy(value: number) {
        this.lastUpdateBy = value;
    }

    /**
     * Setter shoppingCartStatus
     * @param {string} value
     */
    public set setShoppingCartStatus(value: string) {
        this.shoppingCartStatus = value;
    }

    /**
     * Setter details
     * @param {Array<Details>} value
     */
    public set setDetails(value: Array<Details>) {
        this.details = value;
    }

}
