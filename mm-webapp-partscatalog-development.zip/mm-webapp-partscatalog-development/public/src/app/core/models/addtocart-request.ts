import { Header } from './header';

export class AddtocartRequest {
    private header: Header;

    /**
     * Getter header
     * @return {Header}
     */
    public get getHeader(): Header {
        return this.header;
    }

    /**
     * Setter header
     * @param {Header} value
     */
    public set setHeader(value: Header) {
        this.header = value;
    }

}
