import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import * as $ from 'jquery';
import { PartInfoSecData } from '../models/part-info-sec-data';
import { PartsBulletinSecData } from '../models/parts-bulletin-sec-data';
import { SearchResultSecData } from '../models/search-result-sec-data';
import { APP_CONFIG, AppConfig } from 'src/app/app.config';

@Injectable({
  providedIn: 'root'
})
export class WaypointnavigationService {

  @Output() partInfoSecEE: EventEmitter<any> = new EventEmitter();
  @Output() partsBulletinSecEE: EventEmitter<any> = new EventEmitter();
  @Output() searchResultSecEE: EventEmitter<any> = new EventEmitter();

  partInfoSecData = new PartInfoSecData();
  partsBulletinSecData = new PartsBulletinSecData();
  searchResultSecData = new SearchResultSecData();

  constructor(@Inject(APP_CONFIG) private config: AppConfig) { }

  openPartInfoSec() {
    this.partInfoSecData.isOpen = true;
    this.partInfoSecEE.emit(this.partInfoSecData);
  }

  openPartsBulletinSec() {
    this.partsBulletinSecData.isOpen = true;
    this.partsBulletinSecEE.emit(this.partsBulletinSecData);
  }

  openSearchResultSec() {
    this.searchResultSecData.isOpen = true;
    this.searchResultSecEE.emit(this.searchResultSecData);
  }

  /**
   * Usage: Navigation in sections logic
   * @param fromSection
   * @param toSection
   */
  navigate(fromSection, toSection) {
    if (fromSection === this.config.PART_INFORMATION) {
      if (toSection === this.config.NEXT) {
        toSection = this.config.SEARCH_RESULTS;
      } else if (toSection === this.config.PREVIOUS) {
        if (this.partsBulletinSecData.isOpen) {
          toSection = this.config.PART_BULLETIN;
        } else {
          toSection = this.config.TOP;
        }
      } else if (toSection === this.config.PART_INFORMATION) {
        if (!this.partsBulletinSecData.isOpen) {
          toSection = this.config.PART_BULLETIN;
        }
      }
    } else if (fromSection === this.config.PART_BULLETIN) {
      if (toSection === this.config.NEXT) {
        if (this.partInfoSecData.isOpen) {
          toSection = this.config.PART_INFORMATION;
        } else if (this.searchResultSecData.isOpen) {
          toSection = this.config.SEARCH_RESULTS;
        } else {
          toSection = this.config.PART_BULLETIN;
        }
      }
    } else if (fromSection === this.config.SEARCH_RESULTS) {
      if (toSection === this.config.PREVIOUS) {
        if (this.partInfoSecData.isOpen) {
          if (!this.partsBulletinSecData.isOpen) {
            toSection = this.config.PART_BULLETIN;
          } else {
            toSection = this.config.PART_INFORMATION;
          }
        } else if (this.partsBulletinSecData.isOpen) {
          toSection = this.config.PART_BULLETIN;
        } else {
          toSection = this.config.TOP;
        }
      }
    }
    this.navigateToSection(toSection);
  }

  /**
   * Usage: for navigating to the particular section.
   * @param secid
   */
  navigateToSection(secid) {
    let h = 0;
    if (secid === this.config.TOP) {
      h = 0;
    } else if (secid === this.config.PART_BULLETIN) {
      h = $('#pb').offset().top + this.config.ESERVICES_HEADER_HEIGHT;
    } else if (secid === this.config.PART_INFORMATION) {
      h = $('#pi').offset().top + this.config.ESERVICES_HEADER_HEIGHT;
    } else if (secid === this.config.SEARCH_RESULTS || secid === this.config.BOTTOM) {
      h = $('#sr').offset().top + this.config.ESERVICES_HEADER_HEIGHT;
    }
    setTimeout(function () { window.parent.parent.scrollTo({ top: h, behavior: 'smooth' }); }, 200);
  }

  resetPartInfoSecData() {
    this.partInfoSecData.isOpen = false;
    this.partInfoSecData.partNumber = '';
    this.partInfoSecData.organizationId = '';
  }

  resetPartsBulletinSecData() {
    this.partsBulletinSecData.isOpen = false;
    this.partsBulletinSecData.partsCatalogFile = '';
    this.partsBulletinSecData.bulletinFileName = '';
    this.partsBulletinSecData.bookmapVersion = '';
  }

  resetSearchResultSecData() {
    this.searchResultSecData.isOpen = false;
    this.searchResultSecData.searchQuery = '';
  }

}
