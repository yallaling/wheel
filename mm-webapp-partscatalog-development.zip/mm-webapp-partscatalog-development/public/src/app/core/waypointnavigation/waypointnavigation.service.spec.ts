import { TestBed, inject } from '@angular/core/testing';

import { WaypointnavigationService } from './waypointnavigation.service';
import { APP_CONFIG, APP_DI_CONFIG } from 'src/app/app.config';

describe('WaypointnavigationService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WaypointnavigationService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG } ]
    });
  });

  it('should be created', inject([WaypointnavigationService], (service: WaypointnavigationService) => {
    expect(service).toBeTruthy();
  }));
});
