import { TestBed, inject } from '@angular/core/testing';

import { UtilService } from './util.service';
import { TranslateService, TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { APP_CONFIG, APP_DI_CONFIG } from 'src/app/app.config';
import { CommonService } from '../common/common.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Observable, of } from 'rxjs';

const translations: any = { 'Test': 'This s a test trasulator' };

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translations);
  }
}

describe('UtilService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }),
      ],
      providers: [
        UtilService,
        CommonService,
        TranslateService,
        { provide: APP_CONFIG, useValue: APP_DI_CONFIG }
      ]
    });
  });

  it('should be created', inject([UtilService], (service: UtilService) => {
    expect(service).toBeTruthy();
  }));
});
