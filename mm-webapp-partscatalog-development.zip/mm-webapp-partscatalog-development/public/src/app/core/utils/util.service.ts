import { Injectable, Output, EventEmitter, Inject } from '@angular/core';
import { Alert } from '../models/alert';
import { Item } from '../models/item';
import { AddtocartRequest } from '../models/addtocart-request';
import { Header } from '../models/header';
import { SessionDetails } from '../models/session-details';
import { APP_CONFIG, AppConfig } from 'src/app/app.config';
import { Details } from '../models/details';
import { CommonService } from '../common/common.service';
import { TranslateService } from '@ngx-translate/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  @Output() alertEE: EventEmitter<Alert> = new EventEmitter();

  constructor(@Inject(APP_CONFIG) private config: AppConfig, private commonService: CommonService,
    private translate: TranslateService) { }

  showAlert(alertType: string, alertMessage: string, isVisible: boolean, alertTimeout: number) {
    setTimeout(function () { window.parent.parent.scrollTo({ top: 0, behavior: 'smooth' }); }, 100);
    const headerHeight = 143;
    if (parent.window.scrollY >= 0 && parent.window.scrollY <= headerHeight) {
      document.getElementById('partCatalogAlert').style.top = '0px';
    } else {
      document.getElementById('partCatalogAlert').style.top = '' + parent.window.top;
    }
    const alert: Alert = new Alert(alertType, alertMessage, isVisible, alertTimeout);
    this.alertEE.emit(alert);
  }

  /**
   * Usage: for navigating to other modules eg. shopping cart and defect
   * @param path
   * @param params
   * @param target
   * @param method
   */
  post(path, params, target, method) {
    method = method || 'post'; // Set method to post by default if not specified.

    const form = <HTMLFormElement>document.createElement('form');
    form.setAttribute('method', method);
    form.setAttribute('action', path);
    if (target) {
      form.setAttribute('target', target);
    }

    for (const key in params) {
      if (params.hasOwnProperty(key)) {
        const hiddenField = <HTMLInputElement>document.createElement('input');
        hiddenField.setAttribute('type', 'hidden');
        hiddenField.setAttribute('name', key);
        hiddenField.setAttribute('value', params[key]);
        form.appendChild(hiddenField);
      }
    }
    window.top.document.body.appendChild(form);
    form.submit();
  }

  addToCart(requestedItems: Array<Item>) {
    const items: Array<Item> = requestedItems.map((item: Item) => {
      if (isNaN(+item.quantity)) {
        return new Item(item.part_number, 0, item.description);
      } else {
        return new Item(item.part_number, item.quantity, item.description);
      }
    });
    const addToCartRequest: AddtocartRequest = this.createAddToCartRequestObject(items, this.commonService.sessionDetails);
    this.commonService.addtocart(addToCartRequest).subscribe(data => {
      if (data.status.statusCode === this.config.SUCCESS) {
        this.redirectToShoppingCart();
      } else {
        this.showAlert(this.config.ERROR, this.translate.instant('_Item_Add_Failure_'), true, this.config.ERROR_TIMEOUT);
      }
    }, err => {
      this.showAlert(this.config.ERROR, this.translate.instant('_Item_Add_Failure_'), true, this.config.ERROR_TIMEOUT);
    });
  }

  private createAddToCartRequestObject(items: Array<Item>, sessionDetails: SessionDetails): AddtocartRequest {
    const addToCartRequest = new AddtocartRequest();
    const header = new Header();
    header.setServiceWorkOrderId = +sessionDetails.workorderid;
    header.setOrganizationId = +sessionDetails.organizationid;
    header.setShoppingCartStatus = this.config.OPEN;
    header.setCreatedBy = +sessionDetails.userid;
    header.setLastUpdateBy = +sessionDetails.userid;
    header.setDefectId = +sessionDetails.defectid;
    const itemList = Array<Details>();
    items.forEach((item: Item) => {
      const detail = new Details();
      detail.setRequestedQuantity = item.quantity;
      detail.setCreatedBy = +sessionDetails.userid;
      detail.setLastUpdateBy = +sessionDetails.userid;
      detail.setPartsCatalogItemNumber = item.part_number;
      detail.setItemNumberPicked = item.part_number;
      detail.setDefectId = +sessionDetails.defectid;
      detail.setShoppingCartDetailsStatus = this.config.PENDING_REQUEST;
      detail.setRequestSource = this.config.PARTS_CATALOG;
      detail.setMaterialRequetedBy = sessionDetails.ssoId;
      itemList.push(detail);
    });
    header.setDetails = itemList;
    addToCartRequest.setHeader = header;
    return addToCartRequest;
  }

  redirectToShoppingCart() {
    this.post('' + this.commonService.sessionDetails.clientUrl + this.config.RAIL_CONNECT, {
      menuid: this.config.SHOPCART_MENU_ID, defectid: this.commonService.sessionDetails.defectid,
      sesid: this.commonService.sessionDetails.sesid, roadnoindex: 9999,
      inflag: this.config.OS_FLAG, workorderid: this.commonService.sessionDetails.workorderid,
      organizationid: this.commonService.sessionDetails.organizationid, locale: this.commonService.sessionDetails.locale, picksummary: 'N'
    }, null, this.config.POST);
  }

  redirectToCatalog1() {
    this.post('' + this.commonService.sessionDetails.clientUrl + 'Defectsheck.jsp', {
      menuid: this.config.SHOPCART_MENU_ID, sesid: this.commonService.sessionDetails.sesid,
      txtRoadNo: this.commonService.sessionDetails.roadNumber, lstCustomerName: this.commonService.sessionDetails.customerName,
      lstCustomer: this.commonService.sessionDetails.customerId,
      DefectId: this.commonService.sessionDetails.defectid, woid: this.commonService.sessionDetails.workorderid,
      isNewMaterial: 'Y'
    }, null, this.config.POST);
  }

  redirectToDefect() {
    this.post('' + this.commonService.sessionDetails.clientUrl + this.config.RAIL_CONNECT,
      {
        menuid: this.config.DEFECT_MENU_ID, sesid: this.commonService.sessionDetails.sesid, roadnoindex: 9999, flag: this.config.OS_FLAG,
        inflag: this.config.OS_FLAG, woid: this.commonService.sessionDetails.workorderid,
        workorderid: this.commonService.sessionDetails.workorderid
      }, null, this.config.POST);
  }

  setLocalStorage() {
    sessionStorage.removeItem('subsection');
    sessionStorage.removeItem('suggestion');
    sessionStorage.removeItem('source');
    sessionStorage.removeItem('roadnumber');

    let suggestion = this.translate.instant('_request_about_partscatalog_') + ':' + '\n'
      + this.translate.instant('_customer_name_') + ':' + this.commonService.sessionDetails.customerName + '\n'
      + this.translate.instant('_road_number_') + ':' + this.commonService.sessionDetails.roadNumber + '\n'
      + this.translate.instant('_hierarchy_') + ':' + this.commonService.sessionDetails.hierarchyOpened + '\n';
    if (this.commonService.sessionDetails.partsBulletinOpened) {
      suggestion = suggestion + this.translate.instant('_part_bulletin_') + ': '
        + this.commonService.sessionDetails.partsBulletinOpened + '\n';
    }
    suggestion = suggestion + this.translate.instant('_request_msg_') + ':';
    const roadNumber = this.commonService.sessionDetails.roadNumber;
    sessionStorage.setItem('subsection', 'PARTS CATALOG');
    sessionStorage.setItem('suggestion', suggestion);
    sessionStorage.setItem('source', 'PC2');
    sessionStorage.setItem('roadnumber', roadNumber);
  }

  cwcAddToCart(requestedItems: Array<Item>) {
    const itemArray = [];
    const items: Array<Item> = requestedItems.map((item: Item) => {
      if (isNaN(+item.quantity)) {
        return new Item(item.part_number, 0, item.description);
      } else {
        itemArray.push(item.part_number);
      }
    });
    const commasep = itemArray.join(',').replace('"', '');
    const url = this.commonService.sessionDetails.cwcURL + this.config.addToCartCWCUrl + commasep + '&ou=PARTSCO';
    this.post(url, null, null, this.config.POST);

  }
}
