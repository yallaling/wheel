0.2.0 / 2013-07-05
==================
* Migrate off require-jquery
* Migrate to Bootstrap 2.3.2
