0.2.0 / 2013-07-05
==================
* Migrate off require-jquery
* Migrate to Bootstrap 2.3.2

0.1.2 / 2013-06-18
==================
* Design Feedback and caret hover bug

0.1.1 / 2013-06-14
==================
* Changed module name from tree-navigation to collapsible-list
* Initial commit of tree-navigation
