/*******************************************************************************
 *
 * C O P Y R I G H T    N O T I C E
 *    (c) 2013 General Electric Company  All Rights Reserved.
 *
 *  All Rights Reserved. No portions of this source code or the resulting compiled
 *  program may be used without express written consent and licensing by GE Global Research.
 *     
 ********************************************************************************/

package dtos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserAttributes {

	Map<String, String> attributesMap;
	
	public Map<String, String> getAttributesMap() {
		if(null== attributesMap){
			 attributesMap = new HashMap<>();
		}
		return attributesMap;
	}

	public void setAttributesMap(Map<String, String> attributesMap) {
		this.attributesMap = attributesMap;
	}

	
}
