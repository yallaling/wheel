package dtos;

public class UserAttributesType {
	public String uiCode;
	public String permit;

	public UserAttributesType() {
	}

	public String getUiCode() {
		return uiCode;
	}

	public void setUiCode(String uiCode) {
		this.uiCode = uiCode;
	}

	public String getPermit() {
		return permit;
	}

	public void setPermit(String permit) {
		this.permit = permit;
	}

}