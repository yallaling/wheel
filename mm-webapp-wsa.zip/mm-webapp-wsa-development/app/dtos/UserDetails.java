package dtos;

import play.Logger;
public class UserDetails {
	
	public String id;
	public String name;
	public String SSOId;
	public String orgId;
	public String role;
	public String lang;
	public String locale;
	
	public UserDetails() {
		super();
		this.id = null;
		this.name = null;
		this.SSOId = null;
		this.orgId = null;
		this.role = null;
		this.lang = null;
	}
	
	public UserDetails(String id, String name, String SSOId, String orgId, String role, String lang) {
		this.id = id;
		this.name = name;
		this.SSOId = SSOId;
		this.orgId = orgId;
		this.role = role;
		this.lang = lang;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSSOId() {
		return SSOId;
	}

	public void setSSOId(String sSOId) {
		SSOId = sSOId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public static String locateToLang(String lang) {
		Logger.debug("lang : " + lang);
		if (lang.contains("en_US")) {
			return "ENG";
		} else if (lang.contains("ru_RUS")) {
			return "RUS";
		} else if (lang.contains("sp_SPA")) {
			return "SPA";
		} else if (lang.contains("fr_FRN")) {
			return "FRN";
		} else if (lang.contains("ch_CHN")) {
			return "CHN";
		} else if (lang.contains("po_POR")) {
			return "POR";
		} else if (lang.contains("ba_BAH")) {
			return "BAH";
		}
		return lang;
	}
	
	public static String langToLocale(String lang) {
		Logger.debug("lang : " + lang);
		if (lang.contains("ENG")) {
			return "en_US";
		} else if (lang.contains("RUS")) {
			return "ru_RUS";
		} else if (lang.contains("SPA")) {
			return "sp_SPA";
		} else if (lang.contains("FRN")) {
			return "fr_FRN";
		} else if (lang.contains("CHN")) {
			return "ch_CHN";
		} else if (lang.contains("POR")) {
			return "po_POR";
		}else if (lang.contains("BAH")) {
			return "ba_BAH";
		}
		return lang;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((SSOId == null) ? 0 : SSOId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((orgId == null) ? 0 : orgId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserDetails other = (UserDetails) obj;
		if (SSOId == null) {
			if (other.SSOId != null)
				return false;
		} else if (!SSOId.equals(other.SSOId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (orgId == null) {
			if (other.orgId != null)
				return false;
		} else if (!orgId.equals(other.orgId))
			return false;
		return true;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}
}
