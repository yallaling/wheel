package dtos;

public class UserProfile {

	private UserDetails userDetails;
	private UserAttributes userAttributes;
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	public UserAttributes getUserAttributes() {
		return userAttributes;
	}
	public void setUserAttributes(UserAttributes userAttributes) {
		this.userAttributes = userAttributes;
	}
	
}
