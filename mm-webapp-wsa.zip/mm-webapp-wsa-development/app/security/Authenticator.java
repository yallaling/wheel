package security;

import static utils.Constants.CONF_APACHE_1_0_PORT;
import static utils.Constants.REQUEST_HEADER_SSO;
import static utils.Constants.REQUEST_QUERY_CLIENTURL;
import static utils.Constants.REQUEST_QUERY_DEFECT_MENUID;
import static utils.Constants.REQUEST_QUERY_MENUID;
import static utils.Constants.REQUEST_QUERY_SESSIONID;
import static utils.Constants.REQUIRED_1_0_PARAMS;
import static utils.Constants.SESSION_MENUID;
import static utils.Constants.SESSION_SSO;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

import javax.inject.Inject;

import play.Logger;
import play.Play;
import play.libs.Json;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSClient;
import play.libs.ws.WSResponse;
import play.mvc.Http;
import play.mvc.Http.Session;
import play.mvc.Result;
import play.mvc.With;
import utils.Constants;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import dtos.UserProfileType;
import dtos.UserRequest;
import dtos.UserResponse;

/**
 * Authenticator Interceptor
 *
 * @author Amit jha
 * @version 1.0 Jan 21, 2017
 * @since 1.0
 */

public class Authenticator extends play.mvc.Action.Simple {

	private static final ObjectMapper mapper = new ObjectMapper();

	@Inject
	WSClient ws;

	public CompletionStage<Result> call(Http.Context ctx) {
System.out.println("Authenticator.call()");
		Logger.debug("Inside Play Interceptor HttpContext Id : " + ctx.id()
				+ " & Thread Id : " + Thread.currentThread().getId()
				+ " & Active Thread Count :  " + Thread.activeCount());

		Logger.debug("Inside Play-Interceptor ThreadId : "
				+ Thread.currentThread().getId());
		UUID uuid = UUID.randomUUID();
		Logger.debug("Request for URI : " + ctx.request().uri());

		// Clears out the play session if 1.0 JSESSIONID is different
		String requestJSessionId = ctx.request().getQueryString(
				REQUEST_QUERY_SESSIONID);
		Logger.debug("sessionid from query string: " + requestJSessionId);
		String sessionJSessionId = ctx.session().get(REQUEST_QUERY_SESSIONID);
		Logger.debug("Sessionid from session: " + sessionJSessionId);
		if (requestJSessionId != null && sessionJSessionId != null
				&& !requestJSessionId.equals(sessionJSessionId)) {
			Logger.debug("Request with different JSESSIONID. Clearing Play session.");
			ctx.session().clear();
		}

		// Update session with request SSO
		String sessionSSO = ctx.session().get(SESSION_SSO);
		Logger.debug("SSO from session: " + sessionSSO);

		String requestSSO = ctx.request().getHeader(REQUEST_HEADER_SSO);

		if (requestSSO == null || requestSSO.isEmpty()) {
			Logger.debug("SSO missing in request header : '"
					+ REQUEST_HEADER_SSO + "'");
			return CompletableFuture.completedFuture(unauthorized("SSO missing in request header"));
		}

		Logger.debug("request SSO from header: " + requestSSO);

		if (sessionSSO != null && !sessionSSO.equalsIgnoreCase(requestSSO)) {
			Logger.debug("Unauthorized request from different sso. Please clear your cache.");
			return 	CompletableFuture.completedFuture(unauthorized("SSO is different from the original sso"));
		}

		if (sessionSSO == null) {
			ctx.session().clear();
			Logger.debug("Fresh start. Cleared Play session");

			// Load all the headers to session
			try {
				loadAllReqHeaders(ctx);
				Logger.debug("Loaded all headers to session");
				// Load all the queryparams to session
				loadAllQueryParams(ctx);
				Logger.debug("Loaded all queryparams to session");
			} catch (Exception e1) {
				Logger.error("Exception occured while loading all query parameters", e1);
			}
			
			// Query for userprofile information
			CompletionStage<WSResponse> wsResponse = getUserProfile(requestSSO);
			// String userProfile = wsResponse.getBody();
			UserResponse userResponse = null;
			try {
				userResponse = Json.mapper().readValue(
						wsResponse.toCompletableFuture().get().asJson()
								.toString(), UserResponse.class);
			} catch (IOException | InterruptedException | ExecutionException e) {
				Logger.error("Exception occured while converting userResponse json to object:", e);
			}
			// Set UserId
			try {
				// addSession(ctx, Constants.SESSION_USERPROFILE, userProfile);
				addSession(ctx, Constants.SESSION_SSO, requestSSO);
				UserProfileType user = userResponse.getUser();
				if (user != null) {
					if (user.getLoginId() != null) {
						addSession(ctx, Constants.SESSION_USERID,
								String.valueOf(user.getLoginId()));
						addSession(ctx, Constants.SESSION_LOGINID,
								String.valueOf(user.getLoginId()));
					}
					if (user.getLanguageCode() != null) {
						addSession(ctx, Constants.SESSION_LANGCODE,
								String.valueOf(user.getLanguageCode()));
					}
				}

			} catch (Exception exception) {
				Logger.error("Not able to set UserProfile to Session",
						exception);
			}
		}
		
		try {
			// Query for userdetails information
			setHeaders(ctx);
			loadAllReqHeaders(ctx);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Logger.error("Exception occured while loading all request headers", e);
		}
		// Refresh the menuid information
		loadMenuIdDetails(ctx, uuid.toString());

		return delegate.call(ctx);
	}

	/**
	 * Loads all the Query Params to session
	 * 
	 * @param ctx
	 * @throws Exception
	 * @since 1.0
	 *
	 */
	private void loadAllQueryParams(Http.Context ctx) throws Exception {
		Map<String, String[]> reqQueryParams = ctx.request().queryString();
		for (String paramKey : reqQueryParams.keySet()) {
			if (Arrays.asList(REQUIRED_1_0_PARAMS).contains(paramKey)) {
				String paramValue = ctx.request().getQueryString(paramKey);
				if (paramKey.equalsIgnoreCase(REQUEST_QUERY_CLIENTURL)
						&& paramValue != null && !paramValue.isEmpty()) {
					String protocol = paramValue.split(":")[0];
					String subdomain = paramValue.split("\\.")[0].toLowerCase();
					String domain = paramValue.split("\\.")[1];
					if (domain.equalsIgnoreCase("getransportation")) { // external,
																		// should
																		// always
																		// be
																		// https
						if (protocol.equalsIgnoreCase("http")) {
							paramValue = paramValue.replace(protocol, "https");
						} else if (!paramValue.contains("http")) {
							paramValue = "https://" + paramValue;
						}
					} else if (domain.equalsIgnoreCase("trans")) { // internal,
																	// should be
																	// https in
																	// DEV and
																	// http in
																	// QA/PRD
						if (protocol.equalsIgnoreCase("https")) {
							if (subdomain.endsWith("stgeservices")
									|| (subdomain.endsWith("eservices") && (!subdomain
											.endsWith("deveservices") && (!subdomain
											.endsWith("inteservices"))))) {
								paramValue = paramValue.replace(protocol,
										"http");
							}
						} else if (protocol.equalsIgnoreCase("http")) {
							if (subdomain.endsWith("deveservices")) {
								paramValue = paramValue.replace(protocol,
										"https");
							}
						} else if (!paramValue.contains("http")) {
							if (subdomain.endsWith("deveservices")) {
								paramValue = "https://" + paramValue;
							} else {
								paramValue = "http://" + paramValue;
							}
						}
					} else if (!paramValue.contains("http")) { // localhost and
																// others,
																// should be
																// http
						paramValue = "http://" + paramValue;
					}

					// If the apache is not listening on port 80, apache.port
					// should be set
					// Just append that port to the ClientURL, before Angular
					// uses it
					// This is to fix the broken redirections from 2.0 to 1.0 in
					// SR Environments
					String eservicesPort = Play.application().configuration()
							.getString(CONF_APACHE_1_0_PORT);
					if (eservicesPort != null && !eservicesPort.isEmpty()
							&& paramValue != null && !paramValue.contains(":")) {
						paramValue += ":" + eservicesPort;
					}
				}
				addSession(ctx, paramKey, paramValue);
			}
		}
	}

	/**
	 * Loads all the Request Headers to session
	 * 
	 * @param ctx
	 * @throws Exception
	 * @since 1.0
	 *
	 */
	private void loadAllReqHeaders(Http.Context ctx) throws Exception {
		Map<String, String[]> reqHeaders = ctx.request().headers();
		for (String headerKey : reqHeaders.keySet()) {
			if (Arrays.asList(REQUIRED_1_0_PARAMS).contains(headerKey)) {
				Logger.debug("Adding headerkey to session::" + headerKey);
				addSession(ctx, headerKey, ctx.request().getHeader(headerKey));
			}
		}
	}

	/**
	 * Load MenuId Details to session
	 * 
	 * @param ctx
	 * @since 1.0
	 *
	 */
	private void loadMenuIdDetails(Http.Context ctx, String uuid) {
		try {
			String reqDefectMenuId = ctx.request().getQueryString(
					REQUEST_QUERY_DEFECT_MENUID);
			String reqMenuId = ctx.request().getQueryString(
					REQUEST_QUERY_MENUID);
			if (reqDefectMenuId != null && reqMenuId != null) {
				Logger.debug("Adding reqDefectMenuId to session::"
						+ reqDefectMenuId);
				addSession(ctx, SESSION_MENUID, reqDefectMenuId);
			} else if (reqMenuId != null && reqDefectMenuId == null) {
				Logger.debug("Adding reqMenuId to session::" + reqMenuId);
				addSession(ctx, SESSION_MENUID, reqMenuId);
			}
		} catch (Exception exception) {
			Logger.error("Not able to set MenuId Info to Session", exception);
		}
	}

	/**
	 * Retrieve play session information
	 * 
	 * @return
	 * @since 1.0
	 *
	 */
	@With(Authenticator.class)
	public static Result getSession() throws Exception {
		// Debug all the session information
		Set<String> debugSession = Http.Context.current().session().keySet();
		Logger.debug("####### Play Inteceptor: Stored Session Information #######");
		Logger.debug("ThreadId : " + Thread.currentThread().getId());
		for (String sessionKey : debugSession) {
			Logger.debug(sessionKey + " : "
					+ Http.Context.current().session().get(sessionKey));
		}
		Logger.debug("####### ########################################### #######");

		return ok(mapper.writeValueAsString(Http.Context.current().session()));
	}

	/**
	 * Logsout user by clearing session information
	 * 
	 * @return
	 * @since 1.0
	 *
	 */
	@With(Authenticator.class)
	public static Result logout() {
		Http.Context.current().session().clear();
		return ok("logged out");
	}

	/**
	 * Play limitation - Doesn't allow null values to be set in session/cookie
	 * 
	 * @param ctx
	 * @param key
	 * @param value
	 * @throws Exception
	 * @since 1.0
	 */
	private void addSession(Http.Context ctx, String key, Object value)
			throws Exception {
		if (key == null) {
			throw new Exception("Key when adding to session is null.");
		} else if (value == null) {
			if (ctx.session().containsKey(key)) {
				ctx.session().remove(key);
			}
			Logger.debug("Session value for key :" + key + " is null.");
		} else {
			ctx.session().put(key, String.valueOf(value));
		}
	}

	private CompletionStage<WSResponse> getUserProfile(String loginId) {
		String userProfileUrl = Constants.BASE_URL_SERVICE
				+ Constants.GET_USER_PROFILE_URL;
		UserRequest userRequest = new UserRequest();
		userRequest.setLoginId(loginId);
		String userRequestString = null;
		try {
			userRequestString = Json.mapper().writeValueAsString(userRequest);
		} catch (JsonProcessingException e) {
			Logger.error("Json processing exception : " , e);
		}
		return ws
				.url(userProfileUrl)
				.setRequestTimeout(5000)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(userRequestString);
	}

	private void setHeaders(Http.Context ctx) {
		Session session = ctx.session();

		String locale = ctx.request().getQueryString("locale");
		locale = (locale == null || locale.equals("null")) ? session
				.get("locale") : locale;
		locale = (locale == null || locale.equals("null")) ? ctx.request()
				.getHeader("locale") : locale;

		String sesid = ctx.request().getQueryString("sesid");
		sesid = sesid == null ? session.get("sesid") : sesid;

		String menuid = ctx.request().getQueryString("menuid");
		menuid = menuid == null ? session.get("menuid") : menuid;

		String sessionSSO = ctx.session().get(SESSION_SSO);

		CompletionStage<WSResponse> wsResponse = getUserProfile(sessionSSO);
		if (wsResponse != null) {
			UserResponse userResponse = null;
			try {
				 userResponse = Json.mapper().readValue(
						wsResponse.toCompletableFuture().get().asJson()
								.toString(), UserResponse.class);
				if (userResponse.getUser() != null) {
					session.put("userid", "" + userResponse.getUser().getId());
					session.put("organizationLevelId", "" + userResponse.getUser().getOrganizationLevelId());
					session.put("languageCode", "" + userResponse.getUser().getLanguageCode());
				} else {
					session.put("userid", "" + sessionSSO);
				}
			} catch (InterruptedException | ExecutionException | IOException e) {
				Logger.error("Exception occured while setting headers to session", e);
			} 
		}
		session.put("locale", String.valueOf(verifyLocale(locale)));
		session.put("sesid", String.valueOf(sesid));
		session.put("menuid", String.valueOf(menuid));
	}

	public String verifyLocale(String locale) {
		String regExp = "\\{(.*?)\\}";
		boolean match = Pattern.compile(regExp).matcher(locale).matches();
		if (match) {
			return "ENG";
		} else {
			return locale;
		}
	}
}