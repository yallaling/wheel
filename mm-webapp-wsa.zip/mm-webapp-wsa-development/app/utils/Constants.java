package utils;

import play.Play;

public class Constants {
	public static final String REQUEST_HEADER_SSO = "SM_SSOID";
	public static final String LOCALE = "locale";
	public static final String USERID = "userId";
	public static final String REQUEST_QUERY_SESSIONID = "sesid";
	public static final String REQUEST_QUERY_MENUID = "menuid";

	public static final String CONF_ESERVICES_1_0_URL = "eservices.url";
	public static final String CONF_RESTSERVICE_BASEURI = "service.baseuri";
	public static final String CONF_HTTP_TIMEOUT_MSEC = "http.timeout.msec";
	public static final String CONTENT_TYPE = "content-type";
	public static final String ACCEPT = "Accept";
	public static final String CONTENT_DISPOSITION = "content-disposition";
	public static final String APPLICATION_XML = "application/xml";
	public static final String APPLICATION_JSON = "application/json";

	public static final String SESSION_SSO = "User-SSO";
	public static final String SESSION_USERID = "User-Id";
	public static final String SESSION_LOGINID = "User-LoginId";
	public static final String SESSION_LANGID = "User-LangId";
	public static final String SESSION_USERPROFILE = "User-Profile";
	public static final String SESSION_LANGCODE = "User-LangCode";

	// Request Contents
	public static final String REQUEST_TRANS_NAME = "transName";
	public static final String REQUEST_QUERY_ROADNUMBER = "roadnoindex";
	public static final String REQUEST_QUERY_DEFECT_MENUID = "defectmenuid";
	public static final String REQUEST_QUERY_CLIENTURL = "ClientURL";
	public static final String REQUEST_QUERY_FLAG = "flag";
	public static final String REQUEST_QUERY_INFLAG = "inflag";

	public static final String ORGANIZATION_ID = "organization_id";
	public static final String CONF_APACHE_1_0_PORT = "apache.port";
	public static final String SESSION_MENUID = "menuid";

	// 1.0 Mandatory Request Contents
	public static final String[] REQUIRED_1_0_PARAMS = { REQUEST_HEADER_SSO,
			REQUEST_QUERY_SESSIONID, REQUEST_QUERY_ROADNUMBER,
			REQUEST_QUERY_CLIENTURL, REQUEST_QUERY_FLAG, REQUEST_QUERY_INFLAG,
			ORGANIZATION_ID, LOCALE };

	public static final String AUTH_TYPE = Play.application().configuration()
			.getString("mm.api.authtype");
	public static final String USER_NAME = Play.application().configuration()
			.getString("mm.api.user");
	public static final String PASSWORD = Play.application().configuration()
			.getString("mm.api.passwd");

	public static String BASE_URL_SERVICE = Play.application().configuration()
			.getString("mm.api.baseurl");
	public static String GET_CBM_MAPPING = Play.application().configuration()
			.getString("get_cbm_mapping_url");

	public static String UPDATE_CBM_MAPPING = Play.application()
			.configuration().getString("update_cbm_mapping_url");

	public static String OMD_BASE_URL_SERVICE = Play.application()
			.configuration().getString("omd.api.baseurl");

	public static String GET_OMD_BULK_RULES = Play.application()
			.configuration().getString("get_omd_bulk_rules");

	public static String ESVONE_BASEURL = Play.application().configuration()
			.getString("mm.esvone.baseurl");
	public static String GET_CBM_ACTIONS = Play.application().configuration()
			.getString("get_cbm_actions_url");

	public static final String GET_USER_ATTR_URL = Play.application()
			.configuration().getString("GET_USER_ATTR_URL");
	public static final String GET_USER_PROFILE_URL = Play.application()
			.configuration().getString("GET_USER_PROFILE_URL");
	
	public static String GET_CBM_QP = Play.application()
			.configuration().getString("get_cbm_qp_url");
    public static String GET_CBM_ORGS = Play.application()
			.configuration().getString("get_cbm_orgs_url");
    public static String GET_TASK_SEARCH_URL = Play.application().configuration().getString("get_task_search_url");
	public static String CREATE_MAPPING_URL = Play.application()
			.configuration().getString("post_create_mapping_url");
	public static String GET_TASK_BY_NUMBER_URL = Play.application()
			.configuration().getString("get_task_by_number_url");
	public static String GET_LOV_ENTRIES_URL = Play.application()
			.configuration().getString("get_lov_entries_url");
	public static String GET_SERVICE_PROG_URL = Play.application()
			.configuration().getString("GET_SERVICE_PROG_URL");
	public static String GET_SERVICEITEM_SEARCH_URL = Play.application().configuration().getString("get_serviceitem_search_url");
	public static String GET_ALL_ORGS = Play.application().configuration().getString("get_all_orgs_url");
	public static String DELETE_CBM_MAPPING = Play.application().configuration().getString("post_delete_mapping_url");
	public static String GET_ALL_CUSTOMERS = Play.application().configuration().getString("get_all_customers_url");
	public static String GET_CUSTOMERS_BY_PROGRAMID = Play.application().configuration().getString("get_customers_by_programid_url");
	public static String FLEETS_BY_CUSTOMER_AND_PROGRAMID = Play.application().configuration().getString("get_fleets_by_customer_and_programid");
	public static String GET_FREQUENCY_SCHEDULER = Play.application().configuration().getString("get_frequency_schedular");
	public static String GET_CONFIG_DETAILS_URL = Play.application().configuration().getString("get_config_details");
	public static String GET_SERVICE_PROGRAM_DETAILS_BY_ID_URL = Play.application().configuration().getString("get_service_program_details_byid");
	public static String GET_CBM_RULE_VALUES_URL = Play.application().configuration().getString("get_cbm_rule_values");

	public static String OMD_AKANA_OAUTH2_CLIENT_ID = Play.application().configuration().getString("omd.akana.oauth2.client_id");
	public static String OMD_AKANA_OAUTH2_CLIENT_SECRET = Play.application().configuration().getString("omd.akana.oauth2.client_secret");
	public static String OMD_AKANA_OAUTH2_SCOPE = Play.application().configuration().getString("omd.akana.oauth2.scope");
	public static String OMD_AKANA_OAUTH2_GRANT_TYPE = Play.application().configuration().getString("omd.akana.oauth2.grant_type");
	public static String OMD_AKANA_OAUTH2_TOKEN_ENDPOINT = Play.application().configuration().getString("omd.akana.oauth2.token_endpoint");
}
