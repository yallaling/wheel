package controllers;

import static utils.Constants.REQUEST_HEADER_SSO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.zip.GZIPInputStream;

import play.Logger;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSResponse;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Http.Session;
import play.mvc.Result;
import utils.Constants;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CbmController extends BaseController {

    public CompletionStage<Result> getAllCustomers() {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_ALL_CUSTOMERS;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

    public CompletionStage<Result> getCustomersByProgramId(String serviceProgramId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CUSTOMERS_BY_PROGRAMID;
		return ws
				.url(url)
				.setHeader("serviceProgramId", serviceProgramId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> fleetsByCustomerAndProgramId() {
		JsonNode jsonNode = request().body().asJson();
		String url = Constants.BASE_URL_SERVICE + Constants.FLEETS_BY_CUSTOMER_AND_PROGRAMID;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(jsonNode)
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> getFrequencyScheduler(String languageId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_FREQUENCY_SCHEDULER;
		return ws
				.url(url)
				.setHeader("locale", languageId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> getConfigDetails() {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CONFIG_DETAILS_URL;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> getServiceProgramDetailsById(String serviceProgramId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_SERVICE_PROGRAM_DETAILS_BY_ID_URL;
		return ws
				.url(url)
				.setQueryParameter("serviceProgramId", serviceProgramId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));
	}

	public CompletionStage<Result> getCbmRuleValues() {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CBM_RULE_VALUES_URL;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));
	}
}