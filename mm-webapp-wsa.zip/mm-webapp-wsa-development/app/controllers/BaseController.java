package controllers;

import javax.inject.Inject;

import play.libs.ws.WSClient;
import play.mvc.Controller;

public class BaseController extends Controller {

@Inject WSClient ws;


}