package controllers;

import static utils.Constants.REQUEST_HEADER_SSO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ExecutionException;
import java.util.zip.GZIPInputStream;

import play.Logger;
import play.libs.ws.WSAuthScheme;
import play.libs.ws.WSResponse;
import play.libs.Json;
import play.mvc.Http;
import play.mvc.Http.Session;
import play.mvc.Result;
import utils.Constants;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AutoSignOffController extends BaseController {

	public CompletionStage<Result> getCBMMappingDetails(String languageId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CBM_MAPPING;
		return ws
				.url(url)
				.setHeader("languageId", languageId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> updateCBMMapping() {
		String url = Constants.BASE_URL_SERVICE + Constants.UPDATE_CBM_MAPPING;
		JsonNode jsonNode = request().body().asJson();
		System.out.println("AutoSignOffController.updateCBMMapping()"
				+ jsonNode);
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(jsonNode)
				.thenApply(response -> ok(response.asJson()));
	}

	public CompletionStage<Result> getOmdRules() throws InterruptedException, ExecutionException {
		
		CompletionStage<String> accessToken = getAccessToken();
		String token = null;
		if(null != accessToken && null != accessToken.toCompletableFuture() && null != accessToken.toCompletableFuture().get()) {
			JsonNode jsonData = Json.parse(accessToken.toCompletableFuture().get());
			token = jsonData.get("access_token").toString();
		}
		
		if(null == token) {
			Logger.error("Invalid user to access omd rules");
			return null;
		}
		
		String tokenTemp = token.substring(1, token.length() - 1);
		String finalToken = "Bearer " + tokenTemp;
		
		String url = Constants.OMD_BASE_URL_SERVICE
				+ Constants.GET_OMD_BULK_RULES;
		
		return ws.url(url)
				 .setContentType(Constants.APPLICATION_JSON)
				 .setHeader("Authorization",finalToken)
				 .get()
				 .thenApply(response -> ok(response.asJson()));				 
	}

	public Result getCBMElementTaskSearch() {
		JsonNode jsonNode = request().body().asJson();
		String taskUrl = Constants.BASE_URL_SERVICE
				+ Constants.GET_TASK_SEARCH_URL;
		String tasks = "";
		try {
			CompletionStage<WSResponse> res = ws
					.url(taskUrl)
					.setContentType("application/json")
					.setHeader("User-LangCode", "ENG")
					.setAuth(Constants.USER_NAME, Constants.PASSWORD,
							WSAuthScheme.BASIC).post(jsonNode);
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new GZIPInputStream(res.toCompletableFuture().get()
							.getBodyAsStream())));
			String task = "";
			while ((task = br.readLine()) != null) {
				tasks = task;
			}
		} catch (InterruptedException | ExecutionException | IOException e) {
			Logger.error("Exception Occured while fetchig the task", e);
		}
		return ok(tasks);
	}

	public Result getUserSession() {
		try {
			ObjectMapper mapper = new ObjectMapper();
			return ok(mapper.writeValueAsString(doUserSessionMap()));
		} catch (Exception e) {
			Logger.error("Exception Occured while fetching user session", e);
		}
		return badRequest();
	}

	private Map<String, String> doUserSessionMap() {
		Session playSession = Http.Context.current().session();

		String locale = request().getQueryString("locale");
		locale = locale == null ? playSession.get("locale") : locale;
		locale = locale == null ? request().getHeader("locale") : locale;

		String userid = playSession.get("userid");
		userid = userid == null ? request().getHeader("SM_SSOID") : userid;
		userid = userid == null ? request().getHeader(REQUEST_HEADER_SSO)
				: userid;

		String sesid = request().getQueryString("sesid");
		sesid = sesid == null ? playSession.get("sesid") : sesid;

		String menuid = request().getQueryString("menuid");
		menuid = menuid == null ? playSession.get("menuid") : menuid;

		Map<String, String> userMap = new HashMap<String, String>();
		userMap.put("locale", locale);
		userMap.put("user_id", userid);
		userMap.put("sesid", sesid);
		userMap.put("menuid", menuid);
		userMap.put("esvonebaseurl", Constants.ESVONE_BASEURL);
		userMap.put("organizationLevelId",
				playSession.get("organizationLevelId"));
		userMap.put("languageCode", playSession.get("languageCode"));
		return userMap;
	}

	public CompletionStage<Result> getCBMActions(String languageId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CBM_ACTIONS;
		return ws
				.url(url)
				.setHeader("languageId", languageId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> getCBMQPForTask(String languageId,
			String taskId) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CBM_QP + "/"
				+ taskId;
		Logger.info(url, "QP Task URL");
		return ws
				.url(url)
				.setHeader("languageId", languageId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> getCBMOrgsForQP(String languageId,
			String qpIds) {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_CBM_ORGS + "/"
				+ qpIds;
		return ws
				.url(url)
				.setHeader("languageId", languageId)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public Result createMapping() throws InterruptedException, ExecutionException {
		JsonNode jsonNode = request().body().asJson();
		String taskUrl = Constants.BASE_URL_SERVICE
				+ Constants.CREATE_MAPPING_URL;
		CompletionStage<WSResponse> res = ws
				.url(taskUrl)
				.setContentType("application/json")
				.setHeader("User-LangCode", "ENG")
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(jsonNode);
		return ok(res.toCompletableFuture().get().getBodyAsStream());

	}

	public Result getLovForTask(String locale, String taskNumber) throws InterruptedException, ExecutionException {
		//JsonNode jsonNode = request().body().asJson();
		String taskUrl = Constants.BASE_URL_SERVICE
				+ Constants.GET_TASK_BY_NUMBER_URL + "/" + taskNumber;

		String tasks = "";
		try {
			CompletionStage<WSResponse> res = ws
					.url(taskUrl)
					.setContentType("application/json")
					.setHeader("User-LangCode", "ENG")
					.setAuth(Constants.USER_NAME, Constants.PASSWORD,
							WSAuthScheme.BASIC).get();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new GZIPInputStream(res.toCompletableFuture().get()
							.getBodyAsStream())));
			String task = "";
			while ((task = br.readLine()) != null) {
				tasks = task;
			}
		} catch (InterruptedException | ExecutionException | IOException e) {
			Logger.error("Exception Occured while fetchig the task", e);
		}
		String lovId = tasks.substring(tasks.indexOf("lovEntries") + 12, tasks.indexOf(",\"uom"));
		String lovUrl = Constants.BASE_URL_SERVICE
				+ Constants.GET_LOV_ENTRIES_URL + "/" + lovId;

		String lovs = "";
		try {
			CompletionStage<WSResponse> res = ws
					.url(lovUrl)
					.setContentType("application/json")
					.setHeader("User-LangCode", "ENG")
					.setAuth(Constants.USER_NAME, Constants.PASSWORD,
							WSAuthScheme.BASIC).get();
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new GZIPInputStream(res.toCompletableFuture().get()
							.getBodyAsStream())));
			String lov = "";
			while ((lov = br.readLine()) != null) {
				lovs = lov;
			}
		} catch (InterruptedException | ExecutionException | IOException e) {
			Logger.error("Exception Occured while fetchig lov entries", e);
		}
		return ok(lovs);

	}

	public CompletionStage<Result> getCBMElementSPSearch() {
		JsonNode jsonNode = request().body().asJson();
		String url = Constants.BASE_URL_SERVICE + Constants.GET_SERVICE_PROG_URL;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(jsonNode)
				.thenApply(response -> ok(response.asJson()));
	}

	public Result getCBMServiceItemSearch() {
		JsonNode jsonNode = request().body().asJson();
		String url = Constants.BASE_URL_SERVICE
				+ Constants.GET_SERVICEITEM_SEARCH_URL;
		String serviceItems = "";
		try {
			CompletionStage<WSResponse> res = ws
					.url(url)
					.setContentType("application/json")
					.setHeader("User-LangCode", "ENG")
					.setAuth(Constants.USER_NAME, Constants.PASSWORD,
							WSAuthScheme.BASIC).post(jsonNode);
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new GZIPInputStream(res.toCompletableFuture().get()
							.getBodyAsStream())));
			String serviceItem = "";
			while ((serviceItem = br.readLine()) != null) {
				serviceItems = serviceItem;
			}
		} catch (InterruptedException | ExecutionException | IOException e) {
			Logger.error("Exception Occured while fetchig the task", e);
		}
		return ok(serviceItems);
	}
	
	public CompletionStage<Result> getAllOrgs() {
		String url = Constants.BASE_URL_SERVICE + Constants.GET_ALL_ORGS;
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).get()
				.thenApply(response -> ok(response.asJson()));

	}

	public CompletionStage<Result> deleteCBMMapping() {
		String url = Constants.BASE_URL_SERVICE + Constants.DELETE_CBM_MAPPING;
		JsonNode jsonNode = request().body().asJson();
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setAuth(Constants.USER_NAME, Constants.PASSWORD,
						WSAuthScheme.BASIC).post(jsonNode)
				.thenApply(response -> ok(response.asJson()));
	}
	
	public CompletionStage<String> getAccessToken() {
		String url = Constants.OMD_AKANA_OAUTH2_TOKEN_ENDPOINT;		
		JsonNode json = Json.newObject();        
		return ws
				.url(url)
				.setContentType(Constants.APPLICATION_JSON)
				.setQueryParameter("client_id", Constants.OMD_AKANA_OAUTH2_CLIENT_ID)
				.setQueryParameter("client_secret", Constants.OMD_AKANA_OAUTH2_CLIENT_SECRET)
				.setQueryParameter("scope", Constants.OMD_AKANA_OAUTH2_SCOPE)
				.setQueryParameter("grant_type", Constants.OMD_AKANA_OAUTH2_GRANT_TYPE)				
				.post(json)
				.thenApply((WSResponse r) -> {
	                return r.getBody().toString();	               
	            });
	}
}
