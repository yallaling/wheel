// This creates an array of all the files that Karma finds with a suffix of
// Test.js (eg utilsTest.js) to be added to the Require JS config below
var tests = [], file;
for (file in window.__karma__.files) {
	if (window.__karma__.files.hasOwnProperty(file)) {
		if(/Spec.js$/.test(file)) {
			tests.push(file);
		}
	}
}
requirejs.config({
baseUrl: '/base/',  // Karma serves files from /base/<your-base-path>
paths: {
	/* ABC order */
    "angular": "components/angular/angular",
	"angular-mocks":"components/angular-mocks/angular-mocks",
	"angular-resource": "components/angular-resource/angular-resource",
    "angular-bootstrap": "components/angular-bootstrap/ui-bootstrap-tpls",
    "angular-ui-router": "components/angular-ui-router/release/angular-ui-router",
	"angular-sanitize": "components/angular-sanitize/angular-sanitize",
	"angular-animate": "components/angular-animate/angular-animate.min",
	"jquery": "components/jquery/dist/jquery",
	"spinnerModules": "javascripts/app/spinner.model",
	"spinner": "iidx/dist/components/spin.js/spin",
	"translate": "components/angular-translate/angular-translate",
	"translate-loader": "components/angular-translate-loader-partial/angular-translate-loader-partial",
	"ng-idle": "components/ng-idle/angular-idle",
	"html2js": "template_cache",
	"wsaRestModule": "javascripts/app/services/restService",
	"datatables.net": "components/datatables/media/js/jquery.dataTables.min",	
    "datatables" : "components/datatables/media/js/dataTables.bootstrap.min",
	"pageSlide" : "vendor/angular-pageslide-directive.min",
	"pagination": "components/angularUtils-pagination/dirPagination",
	"angular-lodash": "components/lodash/dist/lodash.min",
	"angularjs-dropdown-multiselect":"components/angularjs-dropdown-multiselect/dist/angularjs-dropdown-multiselect.min",
},
shim: {
	"jquery": { exports: '$'},
	"angular": {deps: ["jquery"],exports: "angular"},
	"angular-mocks":{ deps: ["angular"] },
	"angular-ui-router": {deps: ["angular"] },
	"angular-bootstrap": {deps: ["angular"] },
	"angular-resource": {deps: ["angular"] },
	'angular-bootstrap': { deps: ['angular'] },
	"angular-sanitize":{deps: ["angular"]},
	"angular-animate": {deps: ["angular"]},
	"translate": {deps: ["angular"]},
	"translate-loader": {deps: ["angular", "translate"]},
    "ng-idle": {deps:["angular"]},
    "html2js": {deps: ['angular']},
	"spinnerModules": {deps: ["angular-resource"]},
	"wsaRestModule": {deps: ["angular-resource"]},
	"datatables.net": {deps: ["jquery"]},
	"pageSlide":{deps: ['angular']},
	'pagination': {deps:["angular"]},
	"angularjs-dropdown-multiselect": {deps:["angular"]},
	
	'javascripts/app/controllers': { deps: ['angular'] },
	'javascripts/app/controllers/mainAppCtrl': { deps: ['javascripts/app/controllers']},
	'javascripts/app/controllers/mappingScreenCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService','javascripts/app/services/utils']},
	'javascripts/app/controllers/createMappingScreenCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService','javascripts/app/services/utils']},
	'javascripts/app/controllers/omdListCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService']},
	'javascripts/app/controllers/taskListCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService']},
	'javascripts/app/controllers/serviceItemListCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService']},
	'javascripts/app/controllers/serviceProgramListCtrl': { deps: ['javascripts/app/controllers','javascripts/app/services/modalService']},
	'javascripts/app/directives': { deps: ['angular'] },
	'javascripts/app/directives/spinner': { deps: ['javascripts/app/directives'] },
	'javascripts/app/directives/elementHeight': { deps: ['javascripts/app/directives'] },
	'javascripts/app/directives/angularSwitch': { deps: ['javascripts/app/directives'] },
	
	'javascripts/app/services': { deps: ['angular'] },
	'javascripts/app/services/modalService': { deps: ['javascripts/app/services'] },
	'javascripts/app/services/restService': { deps: ['javascripts/app/services'] },
	'javascripts/app/services/utils': { deps: ['javascripts/app/services'] },
	
	'javascripts/app/filters': { deps: ['angular'] },
	'javascripts/app/filters/propsFilter': { deps: ['javascripts/app/filters'] },
	
	'javascripts/app/app': { deps: [
						'angular-resource',
						'angular-ui-router',
						'javascripts/app/controllers/mainAppCtrl',
						'javascripts/app/controllers/mappingScreenCtrl',
						'javascripts/app/controllers/createMappingScreenCtrl',
						'javascripts/app/controllers/omdListCtrl',
						'javascripts/app/controllers/taskListCtrl',
						'javascripts/app/controllers/serviceItemListCtrl',
						'javascripts/app/controllers/serviceProgramListCtrl',
						'javascripts/app/directives/elementHeight',
						'javascripts/app/directives/angularSwitch',
						'javascripts/app/directives/spinner',
						'javascripts/app/filters/propsFilter'] }
},
deps: tests,  // add tests array to load our tests

callback: window.__karma__.start  // start tests once Require.js is done
});