/**
 * User: Raja Boppana
 * Date: 01/16/17
 * Time: 11:10 AM
 */
define(['angular-mocks', 'jquery', 'javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing Spinner Directive', function() {

		var mockScope, compile, window, log,mockHttp;
		var fakedMainResponse = {};
		beforeEach(angular.mock.module('mm-webapp-wsa'));	
		beforeEach(inject(function($compile, $rootScope,$httpBackend) {	
			mockScope = $rootScope.$new();
			compile = $compile;
			mockHttp = $httpBackend;
			
			mockHttp.when('GET', 'assets/translations/ENG/localization.json').respond(fakedMainResponse);
			mockHttp.when('GET', 'assets/html/partials/header.html').respond(fakedMainResponse);
			mockHttp.when('GET', /get*/).respond(fakedMainResponse);

		}));
		
		function createDirective() {
			var elem, compiledElem;
			elem = angular.element('<spinner element-id="elementId" scroll></spinner>');
			compiledElem = compile(elem)(mockScope);
			mockScope.$digest();

			return compiledElem;    
		}
		
		xit('should initialise spinner', function() {

			var el = createDirective();
			expect(mockScope.spinnerModule.isSpinning).toEqual(0);
		});
		
		xit('should test spinner with positive spin value', function() {

			var el = createDirective();	
			mockScope.spinnerModule.isSpinning = 2;		
			mockScope.$apply();
			
			expect(el.isolateScope().spinner.spin).toBeDefined();
		});
		
		xit('should test spinner interceptor', function() {
			
			var interceptor;
			inject(function(spinnerHttpInterceptor) {
				interceptor = spinnerHttpInterceptor;
			});
			
			var val = interceptor.request({"response": 1});
			expect(mockScope.spinnerModule.isSpinning).toEqual(1);
			
			var val = interceptor.requestError({"response": 1});
			expect(mockScope.spinnerModule.isSpinning).toEqual(0);
			
			var val = interceptor.response({"response": 1});
			expect(mockScope.spinnerModule.isSpinning).toEqual(-1);
			
			var val = interceptor.responseError({"response": 1});
			expect(mockScope.spinnerModule.isSpinning).toEqual(-2);
			
			var val = interceptor.request(null);
			expect(mockScope.spinnerModule.isSpinning).toEqual(-1);
			
			var val = interceptor.response(null);
			expect(mockScope.spinnerModule.isSpinning).toEqual(-2);
		});

		xit('should test factory methods', function() {
			var shi, rs;

			inject(function (spinnerHttpInterceptor, $rootScope) {
				shi = spinnerHttpInterceptor;
				rs = $rootScope;

				var ret1 = shi.request({foo: 1});
				expect(ret1.foo).toBe(1);
				expect(rs.spinnerModule.isSpinning).toBe(1);

				shi.requestError({foo: 1});
				expect(rs.spinnerModule.isSpinning).toBe(0);

				shi.response({foo: 1});
				expect(rs.spinnerModule.isSpinning).toBe(-1);

				shi.responseError({foo: 1});
				expect(rs.spinnerModule.isSpinning).toBe(-2);
			});
		});

	});
});