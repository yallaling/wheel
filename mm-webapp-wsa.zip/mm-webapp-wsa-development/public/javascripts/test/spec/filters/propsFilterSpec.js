/**
 * User: Raja Boppana
 * Date: 01/13/17
 * Time: 11:30 AM
 */
define(['angular-mocks', 'jquery', 'javascripts/app/filters'], function(angularmocks, $, app){
	describe('Unit: Testing Props Filters', function() {

		var mockScope, propsMockFilter, mockObj;
		beforeEach(angular.mock.module('mm-webapp-wsa'));	
		beforeEach(inject(function($filter) {
			mockFilter = $filter('propsFilter');
			mockObj = [{
				"mappingId": 4,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": 12345,
				"event": "loco health",
				"element": "FLOPPY_DISK",
				"qualityPlan": "CSX TA POST-PROCESS VERIFY GLO",
				"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "Y",
				"creationDate": 1483446860752
			}, {
				"mappingId": 1,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": 12346,
				"event": "loco health",
				"element": "TD109_CSX1",
				"qualityPlan": "CSX TA IN-PROCESS VERIFY GLO",
				"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "N",
				"creationDate": 1483446860752
			}, {
				"mappingId": 21,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": null,
				"event": "loco health",
				"element": "TEMP1102A5",
				"qualityPlan": "ELEC INBOUND 368 CRK",
				"serviceItem": "M368-Running Maintenance",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "N",
				"creationDate": 1483446860753
			}]
		}));
		
		it('should Return filter mappings based on the key value', function() {
			expect(mockFilter).not.toEqual(null);
			expect(mockFilter(mockObj, {'element': 'temp'})).toEqual([{
													"mappingId": 21,
													"comment": "TEST",
													"action": "Signoff LOV task",
													"ruleId": null,
													"event": "loco health",
													"element": "TEMP1102A5",
													"qualityPlan": "ELEC INBOUND 368 CRK",
													"serviceItem": "M368-Running Maintenance",
													"cbmOrg": null,
													"webserviceValue": "TRUE",
													"lovValue": null,
													"active": "N",
													"creationDate": 1483446860753
												}]);
			expect(mockFilter(mockObj, {'ruleId': "12346"})).toEqual([{
														"mappingId": 1,
														"comment": "TEST",
														"action": "Signoff LOV task",
														"ruleId": 12346,
														"event": "loco health",
														"element": "TD109_CSX1",
														"qualityPlan": "CSX TA IN-PROCESS VERIFY GLO",
														"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
														"cbmOrg": null,
														"webserviceValue": "TRUE",
														"lovValue": null,
														"active": "N",
														"creationDate": 1483446860752
													}]);
			expect(mockFilter(mockObj, {'ruleId': "123457"})).toEqual([]);
			
			expect(mockFilter(mockObj, {'event': 'loco'})).toEqual(mockObj);
			
		});
		
	});
});