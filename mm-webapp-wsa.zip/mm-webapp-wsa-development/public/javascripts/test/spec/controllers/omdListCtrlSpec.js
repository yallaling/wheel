/**
 * User: Raja Boppana
 * Date: 02/13/17
 * Time: 11:00 AM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing omdListCtrl', function() {

		var ctrl,mockScope,mockWindow,rootScope,$compile,mockHttp,timeout,translate,modalInstance,mockRulesList,mockSelCbmRuleIds;
		beforeEach(angular.mock.module('mm-webapp-wsa'));

		
		beforeEach(angular.mock.inject(function($rootScope, $window,_$httpBackend_,_$compile_,_$timeout_,$injector,$translate){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			timeout = _$timeout_;
			translate = $translate;
			inject(function (_$filter_) {
				translate = $translate;
			});
			mockRulesList =[{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"},{"ruleId":241775,"ruleTitle":"task_34234_34534","ruleType":"Health","family":"AC6000"},{"ruleId":241710,"ruleTitle":"rrrrr","ruleType":"Health","family":"AC6000"}];
			mockSelCbmRuleIds = [242141,241710];
			
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				result: {
				  then: jasmine.createSpy('modalInstance.result.then')
				},
				rendered:{
					then:jasmine.createSpy('modalInstance.rendered.then')
				}
			};

		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing setInitialList", function(){
			it('set initial list with sorting', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					var selectedRules = [{"ruleId":241710,"ruleTitle":"rrrrr","ruleType":"Health","family":"AC6000","selected":true},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000","selected":true}];
					ctrl.sortType = ["ruleId"];
					ctrl.setInitialList();
					expect(ctrl.rules[2].selected).toEqual(true);
					expect(ctrl.rules[4].selected).toEqual(true);
					expect(ctrl.selectedRules[0]).toEqual(selectedRules[0]);
					expect(ctrl.selectedRules[1]).toEqual(selectedRules[1]);
				});
			
			});
	    });
		
		describe("Unit testing cancel", function(){
			it('dismiss modal', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					ctrl.cancel();
					expect(modalInstance.dismiss).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing selectRuleForMapping", function(){
			it('set rule as selected', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					var rule = {"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"};
					ctrl.selectRuleForMapping(rule);
					expect(rule.selected).toEqual(true);
					
					var rule = {"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400","selected":true};
					ctrl.selectRuleForMapping(rule);
					expect(rule.selected).toEqual(false);					
				});
			});
	    });
		describe("Unit testing sortRuleCols", function(){
			it('sort rule table column on click of column header', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					ctrl.tableScrollElem = document.getElementById('table-body-scroll');
					ctrl.isSortReverse = false;
					ctrl.sortType = ["ruleId"];
					ctrl.sortRuleCols("ruleId");
					expect(ctrl.isSortReverse).toEqual(true);
					ctrl.isSortReverse = false;
					ctrl.sortRuleCols("ruleTitle");
					expect(ctrl.isSortReverse).toEqual(false);
					expect(ctrl.sortType).toEqual(["ruleTitle"]);
				});
			});
	    });
		describe("Unit testing selectOmdRule", function(){
			it('save selected rules to create mapping', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					spyOn(rootScope, '$broadcast');
					ctrl.selectedRules = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"}];
					ctrl.selectOmdRule();
					expect(rootScope.$broadcast).toHaveBeenCalledWith('SELECTED_RULE',{rules:ctrl.selectedRules});
					
					ctrl.selectedRules = undefined;
					ctrl.selectOmdRule();
					expect(rootScope.$broadcast).not.toHaveBeenCalledWith('SELECTED_RULE',{rules:ctrl.selectedRules});
				});
			});
	    });
		describe("Unit testing ctrl.filterRules", function(){
			it('filter table data', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					ctrl.tableScrollElem = document.getElementById('table-body-scroll');
					ctrl.filteredRules = [];
					var searchString = 'rrrrr';
					ctrl.searchRule = 'rrrrr';
					ctrl.filterRules(searchString);
					expect(ctrl.filteredRules[0]).toEqual(ctrl.rules[4]);
					
					var searchString = '';
					ctrl.searchRule = '';
					ctrl.filterRules(searchString);
					expect(ctrl.filteredRules.length).toEqual(ctrl.rules.length);
					
				});
			});
	    });
		describe("Unit testing ctrl.clearSearch", function(){
			it('clear table search field', function(){
				inject(function ($controller) {
					ctrl = $controller('omdListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						omdList: mockRulesList,
						selCbmRuleIds : mockSelCbmRuleIds
					});
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					ctrl.tableScrollElem = document.getElementById('table-body-scroll');
					ctrl.clearSearch();
					expect(ctrl.searchRule).toEqual("");
					expect(ctrl.filteredRules.length).toEqual(ctrl.rules.length);
				});
			});
	    });
	});
});
