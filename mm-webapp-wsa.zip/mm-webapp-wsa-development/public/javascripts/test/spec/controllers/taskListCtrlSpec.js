/**
 * User: Raja Boppana
 * Date: 02/13/17
 * Time: 12:00 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing taskListCtrl', function() {

		var ctrl,mockScope,mockWindow,rootScope,q,$compile,mockHttp,timeout,translate,modalInstance,mockTaskType,mockSelectedTask,mockOrgLevelId,mockTaskList,fakedMainResponse = {};
		var getCBMTaskSearch,getCBMTaskSearchPromise;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		beforeEach(function(){
			getCBMTaskSearch = jasmine.createSpyObj('getCBMTaskSearch', [
			  'SearchCBMTasks'
			]);

			module(function ($provide) {
				$provide.value('getCBMTaskSearch', getCBMTaskSearch);
			});
		})
		
		beforeEach(angular.mock.inject(function($rootScope, $window,_$httpBackend_,$q,_$compile_,_$timeout_,$injector,$translate){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			q=$q;
			timeout = _$timeout_;
			translate = $translate;
			inject(function (_$filter_) {
				translate = $translate;
			});
			mockTaskType =1;
			mockOrgLevelId = "5";
			mockSelectedTask = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2","elementType":1,"dataType":null};
			
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				result: {
				  then: jasmine.createSpy('modalInstance.result.then')
				},
				rendered:{
					then:jasmine.createSpy('modalInstance.rendered.then')
				}
			};
			
			mockHttp.when('GET', /assets*/).respond(fakedMainResponse);
			mockHttp.when('GET', /get*/).respond(fakedMainResponse)
			
			getCBMTaskSearchPromise = $q.defer();
			getCBMTaskSearch.SearchCBMTasks.and.returnValue({$promise: getCBMTaskSearchPromise.promise});
			getCBMTaskSearchPromise.resolve('MOCK DATA');
			
			mockTaskList = [{"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2","elementType":1,"dataType":null,"lovEntries":29857,"uom":null,"measurementPosition":null,"supercededBy":null,"actionURL":null,"lineNumber":null,"length":null,"decimalPosition":null,"notes":null,"status":952,"descMultiLingual":[{"id":null,"description":"Perform main fuel filter inspection per attachment. Document all defects and corrective actions in eServices.","localeCode":null,"language":"ENG","status":null,"emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":1423172045000,"updatedBy":0,"isAlreadyRequested":false}],"attachments":[],"supersedes":[],"taskNotes":[],"documentType":[],"assetTaskType":[],"custTaskType":[],"componentTaskType":[],"taskTime":null,"craftType":null,"createdDate":null,"updatedDate":1423172045000,"insertedBy":null,"updatedBy":null,"orgLevelId":null,"triggerId":null,"triggerName":null,"statusText":null},{"taskId":212210,"legacyTaskId":null,"taskNumber":"T45150FFINSP1","elementType":1,"dataType":null,"lovEntries":212210,"uom":null,"measurementPosition":null,"supercededBy":null,"actionURL":null,"lineNumber":null,"length":null,"decimalPosition":null,"notes":null,"status":952,"descMultiLingual":[{"id":null,"description":"Does locomotive have fuel system problems?","localeCode":null,"language":"ENG","status":null,"emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":1423168678000,"updatedBy":0,"isAlreadyRequested":false}],"attachments":[],"supersedes":[],"taskNotes":[],"documentType":[],"assetTaskType":[],"custTaskType":[],"componentTaskType":[],"taskTime":null,"craftType":null,"createdDate":null,"updatedDate":1423168678000,"insertedBy":null,"updatedBy":null,"orgLevelId":null,"triggerId":null,"triggerName":null,"statusText":null}];
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing setSelectedTask", function(){
			it('capture selected task', function(){
				inject(function ($controller) {
					ctrl = $controller('taskListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						taskType: mockTaskType,
						orgLevelId : mockOrgLevelId,
						selectedTask: mockSelectedTask
					});
					ctrl.taskList = mockTaskList;
					ctrl.setSelectedTask(mockSelectedTask);
					expect(ctrl.selectedTask.taskId).toEqual(mockSelectedTask.taskId);
				});
			});
	    });
		
		describe("Unit testing cancel", function(){
			it('dismiss modal', function(){
				inject(function ($controller) {
					ctrl = $controller('taskListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						taskType: mockTaskType,
						orgLevelId : mockOrgLevelId,
						selectedTask: mockSelectedTask
					});
					ctrl.taskList = mockTaskList;
					ctrl.cancel();
					expect(modalInstance.dismiss).toHaveBeenCalled();
				});
			})
	    });
		describe("Unit testing selectTask", function(){
			it('set task as selected', function(){
				inject(function ($controller) {
					ctrl = $controller('taskListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						taskType: mockTaskType,
						orgLevelId : mockOrgLevelId,
						selectedTask: undefined
					});					
					spyOn(rootScope, '$broadcast');					
					ctrl.selectTask();
					expect(rootScope.$broadcast).not.toHaveBeenCalled();

					ctrl.taskList = mockTaskList;
					ctrl.selectedTask = ctrl.taskList[1];
					ctrl.selectedTaskId = ctrl.taskList[1].taskId;
					ctrl.selectTask();
					expect(rootScope.$broadcast).toHaveBeenCalledWith('SELECTED_TASK',{task:ctrl.taskList[1]});
				});
			});
	    });
		describe("Unit testing loadTableData", function(){
			it('create table and load table data', function(){
				inject(function ($controller) {
					ctrl = $controller('taskListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						taskType: mockTaskType,
						orgLevelId : mockOrgLevelId,
						selectedTask: mockSelectedTask
					});
					ctrl.taskList = mockTaskList;
					ctrl.setSelectedTask = jasmine.createSpy("setSelectedTask");
					var mockTableElement = '<table id="taskTable" class="table table-bordered">';
                    $('body').append(mockTableElement);
					ctrl.loadTableData();
					var elem = $("#taskTable_filter input");
					expect(elem).not.toBeUndefined();
					//$("#taskTable").find(".taskrow").trigger("click");
					//expect(ctrl.setSelectedTask).toHaveBeenCalled();
				});
			});
	    });
	});
});
