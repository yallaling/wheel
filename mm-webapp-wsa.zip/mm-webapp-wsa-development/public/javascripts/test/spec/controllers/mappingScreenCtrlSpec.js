/**
 * User: Raja Boppana
 * Date: 01/17/17
 * Time: 12:45 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing mappingScreenCtrl', function() {

		var ctrl,mockScope,mockWindow,state,rootScope,$compile,mockHttp,timeout,translate;
		var getCBMMappingDetail,updateCBMMappingDetail,getBulkOmdRules,getLovsForTask,deleteCBMMappingDetail,getCBMMappingDetailPromise,getBulkOmdRulesPromise,updateCBMMappingDetailPromise,getLovsForTaskPromise,deleteCBMMappingDetailPromise;
		var fakedMainResponse = {},mockMappingList;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		beforeEach(function(){
			
			getCBMMappingDetail = jasmine.createSpyObj('getCBMMappingDetail', [
			  'get'
			]);
			updateCBMMappingDetail = jasmine.createSpyObj('updateCBMMappingDetail', [
			  'updateCBMMap'
			]);
			getBulkOmdRules = jasmine.createSpyObj('getBulkOmdRules', [
			  'getOmdRules'
			]);
			getLovsForTask = jasmine.createSpyObj('getLovsForTask', [
			  'getLovs'
			]);
			deleteCBMMappingDetail = jasmine.createSpyObj('deleteCBMMappingDetail', [
			  'deleteCBMMap'
			]);
			module(function ($provide) {
				$provide.value('getCBMMappingDetailService', getCBMMappingDetail);
				$provide.value('updateCBMMappingDetailService', updateCBMMappingDetail);
				$provide.value('getBulkOmdRules', getBulkOmdRules);
				$provide.value('getLovsForTask', getLovsForTask);
				$provide.value('deleteCBMMappingDetailService', deleteCBMMappingDetail);
			});
		})
		
		beforeEach(angular.mock.inject(function($rootScope, $window,$state,_$httpBackend_,_$compile_,_$timeout_,$injector,_modalService_,$q){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			timeout = _$timeout_;
			state = $state,
			$q = $q;
			modalService = _modalService_;
			
			mockHttp.when('GET', 'assets/translations/ENG/localization.json').respond(fakedMainResponse);
			//mockHttp.when('GET', /get*/).respond(fakedMainResponse);
						
			getCBMMappingDetailPromise = $q.defer();
			getCBMMappingDetail.get.and.returnValue({$promise: getCBMMappingDetailPromise.promise});
			getCBMMappingDetailPromise.resolve('MOCK DATA');
			
			getBulkOmdRulesPromise = $q.defer();
			getBulkOmdRules.getOmdRules.and.returnValue({$promise: getBulkOmdRulesPromise.promise});
			getBulkOmdRulesPromise.resolve('MOCK DATA');
			
			updateCBMMappingDetailPromise = $q.defer();
			updateCBMMappingDetail.updateCBMMap.and.returnValue({$promise: updateCBMMappingDetailPromise.promise});
			updateCBMMappingDetailPromise.resolve('MOCK DATA');
			
			getLovsForTaskPromise = $q.defer();
			getLovsForTask.getLovs.and.returnValue({$promise: getLovsForTaskPromise.promise});
			getLovsForTaskPromise.resolve('MOCK DATA');
			
			deleteCBMMappingDetailPromise = $q.defer();
			deleteCBMMappingDetail.deleteCBMMap.and.returnValue({$promise: deleteCBMMappingDetailPromise.promise});
			deleteCBMMappingDetailPromise.resolve('MOCK DATA');
			
			mockMappingList = [{
				"mappingId": 4,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": 12345,
				"event": "loco health",
				"element": "FLOPPY_DISK",
				"qualityPlan": "CSX TA POST-PROCESS VERIFY GLO",
				"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "Y",
				"creationDate": 1483446860752
			}, {
				"mappingId": 1,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": 12346,
				"event": "loco health",
				"element": "TD109_CSX1",
				"qualityPlan": "CSX TA IN-PROCESS VERIFY GLO",
				"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "N",
				"creationDate": 1483446860752
			}, {
				"mappingId": 21,
				"comment": "TEST",
				"action": "Signoff LOV task",
				"ruleId": null,
				"event": "loco health",
				"element": "TEMP1102A5",
				"qualityPlan": "ELEC INBOUND 368 CRK",
				"serviceItem": "M368-Running Maintenance",
				"cbmOrg": null,
				"webserviceValue": "TRUE",
				"lovValue": null,
				"active": "N",
				"creationDate": 1483446860753
			}];
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing ctrl.loadCBMMappingDetails", function(){
			it('Get CBM mappings ', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					ctrl.loadCBMMappingDetails();
					expect(getCBMMappingDetail.get).toHaveBeenCalled();		
				});
			});
	    });
		describe("Unit testing ctrl.resolveCBMMappings", function(){
			it('resolve get CBM mappings service ', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mockResult = {'mapping': mockMappingList,'status':{'statusCode':'SUCCESS'}};
					ctrl.resolveCBMMappings(mockResult);
					expect(ctrl.mappings).toEqual(mockResult.mapping);
					expect(ctrl.sortType).toEqual(['mappingId']);
					expect(ctrl.isSortReverse).toEqual(true);
					
					ctrl.mappings = undefined;
					var mockResult = {'mapping': mockMappingList,'status':{'statusCode':'FAILURE'}};
					ctrl.resolveCBMMappings(mockResult);
					expect(ctrl.mappings).toBeUndefined();
				});
			});
	    });
		describe("Unit testing ctrl.getRules", function(){
			it('Get CBM mappings ', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					ctrl.getRules();
					expect(getBulkOmdRules.getOmdRules).toHaveBeenCalled();		
				});
			});
	    });
		describe("Unit testing for ctrl.triggerOMDListModal", function(){
			it('Should Trigger the OMD rule list modal', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var ruleList;
					spyOn(modalService, 'showModal');
					ctrl.triggerOMDListModal(ruleList);
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing ctrl.closeAlert", function(){
			it('Close alert messages ', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					ctrl.alert = {visible: true};
					ctrl.closeAlert();
					expect(ctrl.alert.visible).toBeFalsy();		
				});
			});
	    });
		describe("Unit testing $scope.$on('SELECTED_RULE')", function(){
			xit('captures selected rulet event', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var ruleList = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
					spyOn(state, 'go');
					rootScope.$broadcast('SELECTED_RULE',{rules:ruleList,mapping:null, configTabName:null});
					expect(ctrl.newMappingRule).toEqual(ruleList);
					expect(state.go).toHaveBeenCalledWith('wsa.createMapping',{cbmRule:ruleList,cbmMapping:null, configTabName:null});
					
					ctrl.newMappingRule = {};
					rootScope.$broadcast('SELECTED_RULE',{rules:null,mapping:null});
					expect(ctrl.newMappingRule).toEqual({});
					
				});
			});
	    });
		describe("Unit testing ctrl.toggleMapping", function(){
			it('toggle mapping state', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mappingId = 21;
					var isActive = "Y";
					ctrl.toggleMapping(mappingId,isActive);
					expect(updateCBMMappingDetail.updateCBMMap).toHaveBeenCalledWith({"mappingId":mappingId,"active":"N"});
					
					var isActive = "N";
					ctrl.toggleMapping(mappingId,isActive);
					expect(updateCBMMappingDetail.updateCBMMap).toHaveBeenCalledWith({"mappingId":mappingId,"active":"Y"});
				});
			});
	    });
		describe("Unit testing ctrl.resolveUpdateCBMMapping", function(){
			it('resolve get CBM mappings service ', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mappingId = 21;
					ctrl.mappings = [{
							"mappingId": 1,
							"comment": "TEST",
							"action": "Signoff LOV task",
							"ruleId": 12346,
							"event": "loco health",
							"element": "TD109_CSX1",
							"qualityPlan": "CSX TA IN-PROCESS VERIFY GLO",
							"serviceItem": "MANDATORY TD PROCESS VERIFICATION",
							"cbmOrg": null,
							"webserviceValue": "TRUE",
							"lovValue": null,
							"active": "N",
							"creationDate": 1483446860752
						}, {
							"mappingId": 21,
							"comment": "TEST",
							"action": "Signoff LOV task",
							"ruleId": null,
							"event": "loco health",
							"element": "TEMP1102A5",
							"qualityPlan": "ELEC INBOUND 368 CRK",
							"serviceItem": "M368-Running Maintenance",
							"cbmOrg": null,
							"webserviceValue": "TRUE",
							"lovValue": null,
							"active": "Y",
							"creationDate": 1483446860753
						}];
					ctrl.sortType=['Element'];
					var mockResult = {'status':{'statusCode':'FAILURE'}};
					ctrl.resolveUpdateCBMMapping(mockResult,mappingId);
					expect(ctrl.mappings[1].active).toEqual("Y");
					
					mappingId = 1;
					var mockResult = {'status':{'statusCode':'SUCCESS'}};
					ctrl.resolveUpdateCBMMapping(mockResult,mappingId);
					expect(ctrl.mappings[0].active).toEqual("Y");
					
					mappingId = 21
					var mockResult = {'status':{'statusCode':'SUCCESS'}};
					ctrl.resolveUpdateCBMMapping(mockResult,mappingId);
					expect(ctrl.mappings[1].active).toEqual("N");
				});
			});
	    });
		describe("Unit testing ctrl.sortMappingCols", function(){
			it('sort table columns', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					
					var loadDefaultMappings = jasmine.createSpy('loadDefaultMappings');
					var sortType = 'mappingId';
					ctrl.isSortReverse = true;
					ctrl.sortType = "mappingId";
					ctrl.sortMappingCols(sortType);
					expect(ctrl.isSortReverse).toEqual(false);
					expect(ctrl.sortType).toEqual(["mappingId"]);
					
					var tableScrollElem = document.getElementById('table-body-scroll');
					ctrl.sortMappingCols("Element");
					expect(ctrl.isSortReverse).toEqual(false);
					expect(ctrl.sortType).toEqual(["Element"]);
				});
			});
	    });
		describe("Unit testing ctrl.filterMappings", function(){
			it('filter table data', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					//loadDefaultMappings = jasmine.createSpy("loadDefaultMappings");
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem); 
					ctrl.filteredMappings = [];
					var searchString = '1104 AIR';
					ctrl.mappings = [{"mappingId":4,"comment":"test3 by rajesh in dev","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":13456,"event":"Health test#28","element":{"elementId":1,"elementName":null},"qualityPlan":null,"serviceItem":{"serviceItemId":2349712,"serviceItemName":null},"cbmOrgs":[{"orgId":3434,"orgName":null}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450772},{"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773}];
					ctrl.searchMapping = true;
					ctrl.isSortReverse = true;
					ctrl.sortType = "mappingId";
					ctrl.filterMappings(searchString);
					expect(ctrl.filteredMappings[0]).toEqual(ctrl.mappings[1]);
					
					var tableScrollElem = document.getElementById('table-body-scroll');
					ctrl.filterMappings(searchString);
					expect(ctrl.filteredMappings[0]).toEqual(ctrl.mappings[1]);
				});
			});
	    });
		describe("Unit testing ctrl.showSelectedTaskLovs", function(){
			it('show selected LOV config', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					mockScope.languageCode = "ENG";
					var locale = "ENG";
					var taskNumber = "1104 AIR";
					var mapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.showSelectedTaskLovs(mapping);
					expect(getLovsForTask.getLovs).toHaveBeenCalledWith({"locale":locale,"taskNumber":taskNumber});
				});
			});
	    });
		describe("Unit testing ctrl.resolveSelectedTaskLovs", function(){
			it('resolve lov service call', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					ctrl.isOpenDrawer = false;
					var mapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					var mockResult = {'status':{'statusCode':'FAILURE'}};
					ctrl.resolveSelectedTaskLovs(mockResult,mapping);
					expect(ctrl.isOpenDrawer).toEqual(true);
				});
			});
	    });
		
		describe("Unit testing ctrl.clearSearch", function(){
			it('clear mapping table search', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					//var filterMappings = jasmine.createSpy('filterMappings');
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					ctrl.mappings = mockMappingList; 
					ctrl.searchMapping  = "xyz";
					ctrl.sortType = ['mappingId'];
					ctrl.clearSearch();
					expect(ctrl.searchMapping).toEqual("");
				});
			});
	    });

		describe("Unit testing ctrl.editMapping", function(){
			it('Edit a mapping record', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					spyOn(state, 'go');
					var rules=[];
					var rule = {"ruleId":mapping.ruleId,"ruleTitle":mapping.event};
					rules.push(rule);
					ctrl.editMapping(mapping);
					expect(state.go).toHaveBeenCalledWith('wsa.createMapping',{cbmRule:rules,cbmMapping:mapping, configTabName: 'task'});
				});
			});
	    });

		describe("Unit testing for ctrl.confirmDeleteMapping", function(){
			it('show modal to confirm delete mapping', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					spyOn(modalService, 'showModal');
					var event = {
							type: 'click',
							preventDefault: function () {}
						};
					//var spy = spyOn(event, 'preventDefault');
					ctrl.triggerOMDListModal(event,mapping);
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing for ctrl.deleteMapping", function(){
			it('call service to delete mapping', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.deleteMapping(mapping);
					expect(deleteCBMMappingDetail.deleteCBMMap).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing for ctrl.resolveDeleteCBMMapping ", function(){
			it('resolve service to delete mapping', function(){
				inject(function ($controller) {
					ctrl = $controller('mappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow
					});
					var mockTableScrollElem = '<div id="table-body-scroll"></div>';
                    $('body').append(mockTableScrollElem);
					ctrl.mappings = mockMappingList; 
					var mappingLen = mockMappingList.length;
					ctrl.sortType = ['mappingId'];
					var mockResult = {'status':{'statusCode':'FAILURE'}};
					var mapping = {"mappingId":21,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.resolveDeleteCBMMapping(mockResult,mapping);
					expect(ctrl.mappings.length).toEqual(mappingLen);

					var mockResult = {'status':{'statusCode':'SUCCESS'}};
					ctrl.resolveDeleteCBMMapping(mockResult,mapping);
					expect(ctrl.mappings.length).toEqual(2);

					ctrl.mappings = mockMappingList;
					var mockResult = {'status':{'statusCode':'SUCCESS'}};
					ctrl.searchMapping = "21";
					ctrl.filteredMappings = [{"mappingId":21,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773}]
					ctrl.resolveDeleteCBMMapping(mockResult,mapping);
					expect(ctrl.mappings.length).toEqual(mappingLen-1);
					expect(ctrl.filteredMappings.length).toEqual(0);
					
					ctrl.mappings = mockMappingList;
					var mockResult = {'status':{'statusCode':'SUCCESS'}};
					ctrl.searchMapping = "22";
					ctrl.filteredMappings = [{"mappingId":22,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773}]
					ctrl.resolveDeleteCBMMapping(mockResult,mapping);
					expect(ctrl.mappings.length).toEqual(mappingLen-1);
					expect(ctrl.filteredMappings.length).toEqual(1);
				});
			});
	    });
		
	});
});