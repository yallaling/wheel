/**
 * User: Raja Boppana
 * Date: 02/17/17
 * Time: 12:45 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing createMappingScreenCtrl', function() {

		var ctrl,mockScope,mockWindow,state,stateparams,rootScope,$compile,mockHttp,timeout,translate,utilsService;
		var getAllCbmActions,getCBMQPForTask,getBulkOmdRules,getLovsForTask,getCBMOrgsForQP,createMappingService,getAllOrgs,getAllCbmActionsPromise,getBulkOmdRulesPromise,getCBMQPForTaskPromise,getLovsForTaskPromise,getCBMOrgsForQPPromise,createMappingServicePromise,getAllOrgsPromise;
		var fakedMainResponse = {},mockRulesList,mockSelCbmRuleIds;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		beforeEach(function(){
			
			getAllCbmActions = jasmine.createSpyObj('getAllCbmActions', [
			  'get'
			]);
			getCBMQPForTask = jasmine.createSpyObj('getCBMQPForTask', [
			  'get'
			]);
			getBulkOmdRules = jasmine.createSpyObj('getBulkOmdRules', [
			  'getOmdRules'
			]);
			getLovsForTask = jasmine.createSpyObj('getLovsForTask', [
			  'getLovs'
			]);
			getCBMOrgsForQP = jasmine.createSpyObj('getCBMOrgsForQP', [
			  'get'
			]);
			createMappingService = jasmine.createSpyObj('createMappingService', [
			  'createMapping'
			]);
			getAllOrgs = jasmine.createSpyObj('getAllOrgs', [
			  'get'
			]);
			module(function ($provide) {
				$provide.value('getAllCbmActions', getAllCbmActions);
				$provide.value('getCBMQPForTask', getCBMQPForTask);
				$provide.value('getBulkOmdRules', getBulkOmdRules);
				$provide.value('getLovsForTask', getLovsForTask);
				$provide.value('getCBMOrgsForQP', getCBMOrgsForQP);
				$provide.value('createMappingService', createMappingService);
				$provide.value('getAllOrgs', getAllOrgs);
			});
		})
		
		beforeEach(angular.mock.inject(function($rootScope, $window,$state,_$httpBackend_,_$compile_,_$timeout_,$injector,_modalService_,$q){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			timeout = _$timeout_;
			state = $state,
			$q = $q;
			modalService = _modalService_;
			
			
			mockHttp.when('GET', 'assets/translations/ENG/localization.json').respond(fakedMainResponse);
			mockHttp.when('GET', /get*/).respond(fakedMainResponse);	
			mockHttp.when('POST', /get*/).respond(fakedMainResponse);
						
			getAllCbmActionsPromise = $q.defer();
			getAllCbmActions.get.and.returnValue({$promise: getAllCbmActionsPromise.promise});
			getAllCbmActionsPromise.resolve('MOCK DATA');
			
			getCBMQPForTaskPromise = $q.defer();
			getCBMQPForTask.get.and.returnValue({$promise: getCBMQPForTaskPromise.promise});
			getCBMQPForTaskPromise.resolve('MOCK DATA');
			
			getBulkOmdRulesPromise = $q.defer();
			getBulkOmdRules.getOmdRules.and.returnValue({$promise: getBulkOmdRulesPromise.promise});
			getBulkOmdRulesPromise.resolve('MOCK DATA');
			
			getLovsForTaskPromise = $q.defer();
			getLovsForTask.getLovs.and.returnValue({$promise: getLovsForTaskPromise.promise});
			getLovsForTaskPromise.resolve('MOCK DATA');
			
			getCBMOrgsForQPPromise = $q.defer();
			getCBMOrgsForQP.get.and.returnValue({$promise: getCBMOrgsForQPPromise.promise});
			getCBMOrgsForQPPromise.resolve('MOCK DATA');
			
			createMappingServicePromise = $q.defer();
			createMappingService.createMapping.and.returnValue({$promise: createMappingServicePromise.promise});
			createMappingServicePromise.resolve('MOCK DATA');
			
			getAllOrgsPromise = $q.defer();
			getAllOrgs.get.and.returnValue({$promise: getAllOrgsPromise.promise});
			getAllOrgsPromise.resolve('MOCK DATA');
			
			mockRulesList =[{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
			mockSelCbmRuleIds = [242566,242128,242141];
			
			stateparams = { cbmRule: mockRulesList};
			
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		describe("Unit testing ctrl.showMappingList", function(){
			it('go back to mapping list screen', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					spyOn(state, 'go');
					ctrl.cbmRules = [{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
					ctrl.cbmMapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.showMappingList();
					expect(ctrl.cbmRules).toBeUndefined();
					expect(ctrl.cbmMapping).toBeUndefined();
					expect(state.go).toHaveBeenCalledWith('wsa.mappings');
				});
			});
	    });
		describe("Unit testing ctrl.setDataForMapping", function(){
			it('go back to mapping list screen', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var createCBMRulesMap = jasmine.createSpy('createCBMRulesMap');
					var loadCBMRuleActions = jasmine.createSpy('loadCBMRuleActions');
					ctrl.cbmRules = [{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
					ctrl.cbmMapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":2,"actionName":"Switch Service Item for SS"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.setDataForMapping();
					expect(ctrl.mappingState).toEqual(ctrl.MAPPING_MODE_EDIT);
					expect(ctrl.cbmAction).toEqual(ctrl.cbmMapping.action);
					expect(ctrl.mapping.selectedSp.programId).toEqual(ctrl.cbmMapping.element.elementId);
					expect(ctrl.mapping.selectedSp.programName).toEqual(ctrl.cbmMapping.element.elementName);
					expect(ctrl.mapping.lovValues).toEqual(ctrl.cbmMapping.lovIds);
					expect(ctrl.mapping.serviceItem).toEqual(ctrl.cbmMapping.serviceItem);
					expect(ctrl.mapping.qualityPlan).toEqual(ctrl.cbmMapping.qualityPlan);
					expect(ctrl.mapping.webserviceValue).toEqual(ctrl.cbmMapping.webserviceValue);
					expect(ctrl.mapping.comment).toEqual(ctrl.cbmMapping.comment);
					
					ctrl.cbmMapping = {"mappingId":5,"comment":"testing in dev for create mapping","action":{"actionId":1,"actionName":"SignOff Lov Task"},"ruleId":241223,"event":"Equipment Ventilation","element":{"elementId":542,"elementName":"1104 AIR"},"qualityPlan":null,"serviceItem":{"serviceItemId":449630,"serviceItemName":"2208 AIR"},"cbmOrgs":[{"orgId":120,"orgName":"Barstow California CSC"}],"webserviceValue":"true","lovIds":[],"active":"N","creationDate":1487262450773};
					ctrl.setDataForMapping();
					expect(ctrl.mappingState).toEqual(ctrl.MAPPING_MODE_EDIT);
					expect(ctrl.cbmAction).toEqual(ctrl.cbmMapping.action);
					expect(ctrl.mapping.selectedTask.taskId).toEqual(ctrl.cbmMapping.element.elementId);
					expect(ctrl.mapping.selectedTask.taskNumber).toEqual(ctrl.cbmMapping.element.elementName);
					
					ctrl.cbmMapping = undefined;
					ctrl.setDataForMapping();
					expect(ctrl.mappingState).toEqual(ctrl.MAPPING_MODE_CREATE);
				});
			});
	    });
		describe("Unit testing ctrl.removeSelectedRule", function(){
			it('remove selected rule from Map ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.selCbmRuleIds = mockSelCbmRuleIds;
					var rule = {"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"};
					ctrl.removeSelectedRule(1,rule);
					expect(ctrl.cbmRules.length).toEqual(2);
					expect(ctrl.selCbmRuleIds.length).toEqual(2);
					expect(ctrl.cbmRules.indexOf(rule)).toEqual(-1);
					
					// ctrl.cbmRules = mockRulesList;
					// ctrl.selCbmRuleIds = mockSelCbmRuleIds;
					// var rule = {"ruleId":242841,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"};
					// ctrl.removeSelectedRule(1,rule);
					// expect(ctrl.cbmRules.length).toEqual(3);
					// expect(ctrl.selCbmRuleIds.length).toEqual(3);
					// expect(ctrl.cbmRules.indexOf(rule)).toEqual(-1);
				});
			});
	    });
		describe("Unit testing $scope.$on('SELECTED_RULE')", function(){
			it('captures selected rule event', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var createCBMRulesMap = jasmine.createSpy("createCBMRulesMap");
					ctrl.cbmRules = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
					var ruleList = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"},{"ruleId":242141,"ruleTitle":"test health_545323","ruleType":"Health","family":"AC6000"}];
					rootScope.$broadcast('SELECTED_RULE',{rules:ruleList});
					expect(createCBMRulesMap).not.toHaveBeenCalled();
					
					var ruleList = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"}];
					rootScope.$broadcast('SELECTED_RULE',{rules:ruleList});
					expect(ctrl.cbmRules).toEqual(ruleList);
					
					rootScope.$broadcast('SELECTED_RULE',{rules:null});
					expect(ctrl.cbmRules).toEqual(null);
				});
			});
	    });
		describe("Unit testing $scope.$on('SELECTED_TASK')", function(){
			it('captures selected Task event', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var task = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};
					ctrl.mapping = {};
					ctrl.mapping.selectedTask = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};

					rootScope.$broadcast('SELECTED_TASK',{task:task});
					expect(ctrl.mapping).not.toEqual({});
					
					ctrl.mapping.selectedTask = {"taskId":212212,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};
					rootScope.$broadcast('SELECTED_TASK',{task:task});
					expect(ctrl.mapping.selectedTask.taskId).toEqual(task.taskId);
					
					rootScope.$broadcast('SELECTED_TASK',{task:null});
					expect(ctrl.mapping.selectedTask.taskId).toEqual(task.taskId);
				});
			});
	    });
		describe("Unit testing $scope.$on('SELECTED_SERVICEITEM')", function(){
			it('captures selected Service item event', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var serviceItem = {"serviceItemName":"1104 AIR","serviceItemId":266754,"serviceItemDesc":null,"notes":null,"status":8481};
					ctrl.mapping = {};
					ctrl.mapping.serviceItem = {"serviceItemName":"1104 AIR","serviceItemId":266753,"serviceItemDesc":null,"notes":null,"status":8481};

					rootScope.$broadcast('SELECTED_SERVICEITEM',{serviceitem:serviceItem});
					expect(ctrl.mapping.serviceItem.serviceItemId).toEqual(serviceItem.serviceItemId);
					
					rootScope.$broadcast('SELECTED_SERVICEITEM',{serviceitem:null});
					expect(ctrl.mapping.serviceItem.serviceItemId).toEqual(serviceItem.serviceItemId);
				});
			});
	    });
		describe("Unit testing $scope.$on('SELECTED_SERVICEPROGRAM')", function(){
			it('captures selected Service program event', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var serviceProgram = {"programId":67812,"programName":"01-Feb-2017 17-49-35","itemId":275152,"description":"testing create service program","programType":"RM"};
					ctrl.mapping = {};
					ctrl.mapping.selectedSp = {"programId":67813,"programName":"01-Feb-2017 17-49-35","itemId":275152,"description":"testing create service program","programType":"RM"};

					rootScope.$broadcast('SELECTED_SERVICEPROGRAM',{serviceprogram:serviceProgram});
					expect(ctrl.mapping.selectedSp.programId).toEqual(serviceProgram.programId);
					
					rootScope.$broadcast('SELECTED_SERVICEPROGRAM',{serviceprogram:null});
					expect(ctrl.mapping.selectedSp.programId).toEqual(serviceProgram.programId);
				});
			});
	    });
		describe("Unit testing for ctrl.triggerTaskModal", function(){
			it('Should Trigger the Task modal', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var event = {
							type: 'click',
							preventDefault: function () {}
						};
					var spy = spyOn(event, 'preventDefault');
					spyOn(modalService, 'showModal');
					ctrl.triggerTaskModal();
					expect(modalService.showModal).toHaveBeenCalled();
					
					ctrl.triggerTaskModal(event);
					expect(spy).toHaveBeenCalled();
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing for ctrl.triggerServiceItemModal", function(){
			it('Should Trigger the service item modal', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var event = {
							type: 'click',
							preventDefault: function () {}
						};
					var spy = spyOn(event, 'preventDefault');
					spyOn(modalService, 'showModal');
					ctrl.triggerServiceItemModal();
					expect(modalService.showModal).toHaveBeenCalled();
					
					ctrl.triggerServiceItemModal(event);
					expect(spy).toHaveBeenCalled();
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing for ctrl.triggerServiceProgramModal", function(){
			it('Should Trigger the service program modal', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var event = {
							type: 'click',
							preventDefault: function () {}
						};
					var spy = spyOn(event, 'preventDefault');
					spyOn(modalService, 'showModal');
					ctrl.triggerServiceProgramModal();
					expect(modalService.showModal).toHaveBeenCalled();
					
					ctrl.triggerServiceProgramModal(event);
					expect(spy).toHaveBeenCalled();
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing ctrl.loadMappingRules", function(){
			it('Get CBM mappings ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.loadMappingRules();
					expect(getBulkOmdRules.getOmdRules).toHaveBeenCalled();		
				});
			});
	    });
		describe("Unit testing prepareSelectedRuleList", function(){
			it('prepare selected rule list to create mapping ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.cbmRules = [{"ruleId":242566,"ruleTitle":"Regression_Health_AC4400","ruleType":"Health","family":"AC4400"},{"ruleId":242128,"ruleTitle":"Harika_testing_3753_LB_003","ruleType":"Health","family":"AC4400"}];
					var selList = ctrl.prepareSelectedRuleList();
					expect(selList[0].ruleId).toEqual(242566);
					expect(selList[1].ruleId).toEqual(242128);	
					
					ctrl.cbmRules = null;
					var selList =ctrl.prepareSelectedRuleList();
					expect(selList.length).toEqual(0);
				});
			});
	    });
		describe("Unit testing for ctrl.triggerOMDListModal", function(){
			it('Should Trigger the rule modal', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var ruleList;
					spyOn(modalService, 'showModal');
					ctrl.triggerOMDListModal(ruleList);
					expect(modalService.showModal).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing ctrl.loadCBMRuleActions", function(){
			it('Get CBM mapping action list', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.loadCBMRuleActions();
					expect(getAllCbmActions.get).toHaveBeenCalled();		
				});
			});
	    });
		describe("Unit testing ctrl.loadCBMMapingQpTask", function(){
			it('Get CBM mapping Qp for task', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.mapping = {};
					ctrl.mapping.selectedTask = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};
					ctrl.cbmQpTask = {"id":1234};
					ctrl.loadCBMMapingQpTask();
					expect(getCBMQPForTask.get).not.toHaveBeenCalled();

					ctrl.cbmQpTask = null;
					ctrl.loadCBMMapingQpTask();
					expect(getCBMQPForTask.get).toHaveBeenCalled();	
				});
			});
	    });
		describe("Unit testing ctrl.resolveCBMQpTask", function(){
			it('resolve get CBM mappings QP ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.isOpenDrawer = false;
					var mockResult = {"cbmQP":[{"qpId":63416,"qpName":"T4 FUEL FILTER INSPECTION GLO"},{"qpId":10000005,"qpName":"T4 FUEL FILTER INSPECTION BAN"},{"qpId":10000006,"qpName":"T4 FUEL FILTER INSPECTION BCC"},{"qpId":10000007,"qpName":"T4 FUEL FILTER INSPECTION BCI"},{"qpId":10000009,"qpName":"T4 FUEL FILTER INSPECTION BGI"}]};
					ctrl.resolveCBMQpTask(mockResult);
					expect(ctrl.cbmQpTask).toEqual(mockResult.cbmQP);
					expect(ctrl.isOpenDrawer).toEqual(true);
					expect(ctrl.drawerTemplate).toEqual('assets/html/partials/qualityplan.drawer.partial.html');
				});
			});
	    });
		describe("Unit testing ctrl.getOrgsConfig", function(){
			it('Get orgs config for qp or all orgs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.mapping = {};
					ctrl.isOpenDrawer =  false;
					ctrl.mapping.qualityPlan = {"qpId":212211};
					ctrl.qpCustomers = null;
					ctrl.getOrgsConfig();
					expect(getCBMOrgsForQP.get).toHaveBeenCalled();

					ctrl.qpCustomers = {"qpCustomer":1234};
					ctrl.getOrgsConfig();
					expect(ctrl.isOpenDrawer).toEqual(true);
					
					ctrl.mapping.qualityPlan = null;
					ctrl.allOrgs = null
					ctrl.getOrgsConfig();
					expect(getAllOrgs.get).toHaveBeenCalled();
					
					ctrl.isOpenDrawer =  false;
					ctrl.mapping.qualityPlan = null;
					ctrl.allOrgs = {"org1":"xyz"};
					ctrl.getOrgsConfig();
					expect(ctrl.isOpenDrawer).toEqual(true);
				});
			});
	    });
		describe("Unit testing ctrl.resolveCBMOrgs", function(){
			it('resolve get cbm orgs for qp ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.isOpenDrawer = false;
					var mockResult = {"qpCustomers":[{"qpId":54742,"customers":[{"customerId":1023,"customerName":"CP","customerOrg":[{"orgId":184,"orgName":"St Paul CSC"}]}]}]};
					ctrl.resolveCBMOrgs(mockResult);
					expect(ctrl.qpCustomers).toEqual(mockResult.qpCustomers[0]);
					expect(ctrl.isOpenDrawer).toEqual(true);
					expect(ctrl.drawerTemplate).toEqual('assets/html/partials/configOrgs.drawer.partial.html');
				});
			});
	    });
		describe("Unit testing ctrl.resolveAllOrgs", function(){
			it('resolve get all orgs ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.isOpenDrawer = false;
					var mockResult = {"customers":[{"qpId":54742,"customers":[{"customerId":1023,"customerName":"CP","customerOrg":[{"orgId":184,"orgName":"St Paul CSC"}]}]}]};
					ctrl.resolveAllOrgs(mockResult);
					expect(ctrl.allOrgs[0].qpId).toEqual(mockResult.customers[0].qpId);
					expect(ctrl.isOpenDrawer).toEqual(true);
					expect(ctrl.drawerTemplate).toEqual('assets/html/partials/configAllOrgs.drawer.partial.html');
				});
			});
	    });
		describe("Unit testing ctrl.loadTaskLovs", function(){
			it('Get lovs for task', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.mapping.selectedTask = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};
					ctrl.configLovList = ["1234"];
					ctrl.loadTaskLovs();
					expect(getLovsForTask.getLovs).not.toHaveBeenCalled();
					expect(ctrl.isOpenDrawer).toEqual(true);
					expect(ctrl.drawerTemplate).toEqual('assets/html/partials/configLovs.drawer.partial.html');
					
					ctrl.configLovList = [];
					ctrl.loadTaskLovs();
					expect(getLovsForTask.getLovs).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing ctrl.resolveTaskLovs", function(){
			it('resolve get all orgs ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					//spyOn(utilsService, 'convertLovEntryTypesIntoCustomerLovEntries');
					ctrl.isOpenDrawer = false;
					var lovs = [{"lovId":76671,"lovTypeId":212209,"lovType":"TDCP102A1","customerId":7684,"customer":"ACLT","lookupType":"ALL","lookupTypeId":"ALL","hasDefect":true,"sortSequence":3,"value":"ACLT~TestLov~test LOV (ALL)","descriptions":[{"locale":"en-US","description":"test LOV (ALL)"},{"locale":"es-MX","description":null},{"locale":"fr-FR","description":null}]}];
					ctrl.resolveTaskLovs(lovs);
					//expect(utilsService.convertLovEntryTypesIntoCustomerLovEntries).toHaveBeenCalled();
					expect(ctrl.isOpenDrawer).toEqual(true);
					expect(ctrl.drawerTemplate).toEqual('assets/html/partials/configLovs.drawer.partial.html');
				});
			});
	    });
		describe("Unit testing ctrl.toggleDrawer", function(){
			it('toggle drawer visibility', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.isOpenDrawer = false;
					ctrl.toggleDrawer();
					expect(ctrl.isOpenDrawer).toEqual(true);
					
					ctrl.isOpenDrawer = true;
					ctrl.toggleDrawer();
					expect(ctrl.isOpenDrawer).toEqual(false);
				});
			});
	    });
		describe("Unit testing ctrl.setSelectedQp", function(){
			it('set selected quality plan', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.selectedQp = {"qpId":63416,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					var selectedQp = {"qpId":63415,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					ctrl.setSelectedQp(selectedQp);
					expect(ctrl.selectedQp.qpId).toEqual(selectedQp.qpId);
					
					ctrl.selectedQp = {"qpId":63415,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					//var selectedQp = {"qpId":63415,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					ctrl.setSelectedQp(ctrl.selectedQp);
					expect(ctrl.selectedQp.qpId).toEqual(selectedQp.qpId);
				});
			});
	    });
		describe("Unit testing ctrl.saveMappingQp", function(){
			it('save selected quality plan', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.selectedQp = {"qpId":63416,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					ctrl.saveMappingQp();
					expect(ctrl.mapping.qualityPlan.qpId).toEqual(ctrl.selectedQp.qpId);
					expect(ctrl.mapping.cbmOrgs.length).toEqual(0);
					expect(ctrl.mapping.qpCustomers).toEqual(undefined);
				});
			});
	    });
		describe("Unit testing ctrl.setSelectedLov", function(){
			it('set selected Lovs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var customer = {"customer":"ACLT","customerId":7684,"Lov":[{"id":76671,"value":"ACLT~TestLov~test LOV (ALL)","isDefect":true,"sortSequence":3,"lookupType":"ALL","lookupTypeId":"ALL","description":{"en-US":"test LOV (ALL)","es-MX":null,"fr-FR":null}}]};
					var selectedLov = {"id":76671,"value":"ACLT~TestLov~test LOV (ALL)","isDefect":true,"sortSequence":3,"lookupType":"ALL","lookupTypeId":"ALL","description":{"en-US":"test LOV (ALL)","es-MX":null,"fr-FR":null}};
					ctrl.setSelectedLov(selectedLov,customer);
					expect(customer.selectedLovId).toEqual(selectedLov.id);
					
					ctrl.setSelectedLov(selectedLov,customer);
					expect(customer.selectedLovId).toEqual(null);
				});
			});
	    });
		
		describe("Unit testing ctrl.saveMappingLovs", function(){
			it('save selected Lovs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.configLovList = [{"customer":"ACLT","customerId":7684,"Lov":[{"id":76671,"value":"ACLT~TestLov~test LOV (ALL)","isDefect":true,"sortSequence":3,"lookupType":"ALL","lookupTypeId":"ALL","description":{"en-US":"test LOV (ALL)","es-MX":null,"fr-FR":null}}]}];
					ctrl.configLovList[0].selectedLovId = "76671";					
					ctrl.saveMappingLovs();
					expect(ctrl.mapping.lovValues.length).toEqual(1);
					expect(ctrl.mapping.lovValues[0]).toEqual(ctrl.configLovList[0].selectedLovId);
					
					ctrl.configLovList[0].selectedLovId = null
					ctrl.saveMappingLovs();
					expect(ctrl.mapping.lovValues.length).toEqual(0);
				});
			});
	    });
		describe("Unit testing ctrl.setSelectedOrg", function(){
			it('set selected Orgs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var org = {"orgId":184,"orgName":"St Paul CSC"};
					ctrl.setSelectedOrg(org);
					expect(org.isSelectedOrg).toEqual(true);
					
					ctrl.setSelectedOrg(org);
					expect(org.isSelectedOrg).toEqual(false);
				});
			});
	    });
		
		describe("Unit testing ctrl.saveMappingOrgs", function(){
			it('save selected orgs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.allOrgs = [{"customerId":44897,"customerName":"ALLH","customerOrg":[{"orgId":1709,"orgName":"Araraquara CSC"},{"orgId":2592,"orgName":"Curitiba CSC"}]},{"customerId":1041,"customerName":"BNSF","customerOrg":[{"orgId":872,"orgName":"Alliance Nebraska CSC"},{"orgId":120,"orgName":"Barstow California CSC"},{"orgId":831,"orgName":"Clovis NM CSC"},{"orgId":784,"orgName":"Commerce CA CSC"},{"orgId":778,"orgName":"Corwith IL CSC"},{"orgId":842,"orgName":"Ft. Worth CSC"},{"orgId":105,"orgName":"Galesburg Service Shop CSC"},{"orgId":524,"orgName":"Glendive MT CSC"},{"orgId":892,"orgName":"Guernsey Wyoming CSC"},{"orgId":106,"orgName":"Havre Montana CSC"},{"orgId":122,"orgName":"Kansas City CSC"},{"orgId":117,"orgName":"Lincoln Nebraska CSC"},{"orgId":912,"orgName":"Memphis Tennessee CSC"},{"orgId":948,"orgName":"Northtown MN CSC"},{"orgId":843,"orgName":"Pasco CSC"},{"orgId":1669,"orgName":"Temple TX CSC"},{"orgId":127,"orgName":"Topeka Kansas CSC"},{"orgId":1649,"orgName":"Tulsa OK CSC"}]}];					
					ctrl.saveMappingOrgs();
					expect(ctrl.mapping.cbmOrgs.length).toEqual(0);
					
					ctrl.allOrgs[0].customerOrg[0].isSelectedOrg = true;
					ctrl.saveMappingOrgs();
					expect(ctrl.mapping.cbmOrgs[0]).toEqual(1709);
				});
			});
	    });
		describe("Unit testing ctrl.saveMappingOrgsForQps", function(){
			it('save selected orgs', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					var qpCust = {"qpCustomers":[{"qpId":54742,"customers":[{"customerId":1023,"customerName":"CP","customerOrg":[{"orgId":184,"orgName":"St Paul CSC"}]}]}]};
					ctrl.qpCustomers = qpCust.qpCustomers[0];					
					ctrl.saveMappingOrgsForQps();
					expect(ctrl.mapping.cbmOrgs.length).toEqual(0);
					
					ctrl.qpCustomers.customers[0].customerOrg[0].isSelectedOrg = true;
					ctrl.saveMappingOrgsForQps();
					expect(ctrl.mapping.cbmOrgs[0]).toEqual(184);
				});
			});
	    });
		describe("Unit testing ctrl.closeAlert", function(){
			it('Close alert messages ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.alert = {visible: true};
					ctrl.closeAlert();
					expect(ctrl.alert.visible).toBeFalsy();		
				});
			});
	    });
		xdescribe("Unit testing ctrl.saveMapping ", function(){
			it('Close alert messages ', function(){
				inject(function ($controller) {
					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams
					});
					ctrl.cbmMapping = {"mappingId":undefined};
					ctrl.mapping = {};
					ctrl.cbmAction = {};
					ctrl.cbmAction.actionId = 1;
					ctrl.mapping.selectedTask = {"taskId":212211,"legacyTaskId":null,"taskNumber":"T45150FFINSP2"};
					ctrl.mapping.serviceItem = undefined;
					ctrl.mapping.qualityPlan = {"qpId":63416,"qpName":"T4 FUEL FILTER INSPECTION GLO"};
					ctrl.mapping.selectedSp = {"programId":67813,"programName":"01-Feb-2017 17-49-35","itemId":275152,"description":"testing create service program","programType":"RM"};
					ctrl.mapping.cbmOrgs = ['184'];
					ctrl.mapping.lovValues = ['76671'];
					ctrl.mapping.webserviceValue = true;
					ctrl.mapping.comment = "test";
					ctrl.saveMapping();
					expect(ctrl.mappingObjSave.actionId).toEqual(ctrl.cbmAction.actionId);
					expect(ctrl.mappingObjSave.element).toEqual(ctrl.mapping.selectedTask.taskId);
					expect(ctrl.mappingObjSave.qualityPlanId).toEqual(63416);
					
					ctrl.cbmMapping = {}
					ctrl.cbmMapping.mappingId = 123;
					ctrl.cbmAction.actionId = 2;
					ctrl.mapping.serviceItem = {"serviceItemName":"1104 AIR","serviceItemId":266753,"serviceItemDesc":null,"notes":null,"status":8481};
					ctrl.mapping.qualityPlan = undefined;
					ctrl.saveMapping();
					expect(ctrl.mappingObjSave.actionId).toEqual(2);
					expect(ctrl.mappingObjSave.element).toEqual(ctrl.mapping.selectedSp.programId);
					expect(ctrl.mappingObjSave.serviceItemId).toEqual(266753);
					expect(ctrl.mappingObjSave.mappingId ).toEqual(123);
					expect(createMappingService.createMapping).toHaveBeenCalled();	
				});
			});
		});
		
		describe("Unit testing ctrl.loadFrequencyScheduler", function(){
			it('get frequency schedular list from the service success', function(){
				inject(function ($controller) {					
					var mockUserData = {
						"frequencyScheduleFilter": [
							{
								"frequencyScheduleId": 1,
								"frequencyScheduleName": "Daily"
							},
							{
								"frequencyScheduleId": 2,
								"frequencyScheduleName": "First Of Week"
							},
							{
								"frequencyScheduleId": 3,
								"frequencyScheduleName": "First Of Month"
							}
						],
						"status": {
							"statusCode": "SUCCESS",
							"message": "Success",
							"errors": null
						}
					};

					var mockgetFrequencySchedular = {
						get: jasmine.createSpy('get').and.callFake(function (p,success,err) {
								success(mockUserData);
						})
					};

					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams,
						getFrequencySchedulerService: mockgetFrequencySchedular
					});

				});
			});

			it('get frequency schedular list from the service failed', function(){
				inject(function ($controller) {					
					var mockUserData = {"status":"FAILED","userId":null,"userName":null,"message":""};

					var mockgetFrequencySchedular = {
						get: jasmine.createSpy('get').and.callFake(function (p,success,err) {
								err(mockUserData);
						})
					};

					ctrl = $controller('createMappingScreenCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$stateParams:stateparams,
						getFrequencySchedulerService: mockgetFrequencySchedular
					});

				});
			});
	    });


	});
});