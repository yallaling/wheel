/**
 * User: Raja Boppana
 * Date: 02/13/17
 * Time: 12:00 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing serviceItemListCtrl', function() {

		var ctrl,mockScope,mockWindow,rootScope,q,$compile,mockHttp,timeout,translate,modalInstance,mockSiList,mockOrgLevelId,mockSelectedServiceItem,fakedMainResponse = {};
		var getCBMServiceItemSearch,getCBMServiceItemSearchPromise;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		beforeEach(function(){
			getCBMServiceItemSearch = jasmine.createSpyObj('getCBMServiceItemSearch', [
			  'SearchCBMServiceItem'
			]);

			module(function ($provide) {
				$provide.value('getCBMServiceItemSearch', getCBMServiceItemSearch);
			});
		})
		
		beforeEach(angular.mock.inject(function($rootScope, $window,_$httpBackend_,_$q_,_$compile_,_$timeout_,$injector,$translate){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			q=_$q_;
			timeout = _$timeout_;
			translate = $translate;
			inject(function (_$filter_) {
				translate = $translate;
			});
			mockOrgLevelId = "5";
			mockSelectedServiceItem = {"serviceItemName":"1840 AIR","serviceItemId":275032}
			
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				result: {
				  then: jasmine.createSpy('modalInstance.result.then')
				},
				rendered:{
					then:jasmine.createSpy('modalInstance.rendered.then')
				}
			};
			
			mockHttp.when('GET', /assets*/).respond(fakedMainResponse);
			mockHttp.when('GET', /get*/).respond(fakedMainResponse)
			
			mockSiList = [{"serviceItemName":"1104 AIR","serviceItemId":266754,"serviceItemDesc":null,"notes":null,"status":8481,"statusValue":"ACTIVE","createdBy":null,"updatedBy":null,"descMultiLingual":[{"id":null,"description":null,"localeCode":null,"language":"BAH","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"CHN","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":"3-Year Air Component Change Out","localeCode":null,"language":"ENG","status":null,"emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"FRN","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"POR","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"RUS","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"SPA","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false}],"serviceItemNotes":[],"orgLevelId":null,"updatedTimeStamp":1432147971000,"qpIds":null,"svcOrgQpIds":[],"qualityplanList":null,"action":null,"isScheduled":"FALSE","seqString":null},{"serviceItemName":"1840 AIR","serviceItemId":275032,"serviceItemDesc":null,"notes":null,"status":8481,"statusValue":"ACTIVE","createdBy":null,"updatedBy":null,"descMultiLingual":[{"id":null,"description":null,"localeCode":null,"language":"BAH","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"CHN","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":"5-Year Air Component Change Out","localeCode":null,"language":"ENG","status":null,"emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"FRN","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"POR","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"RUS","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false},{"id":null,"description":null,"localeCode":null,"language":"SPA","status":"Normal","emailAddress":null,"requestedBy":null,"requestDate":null,"insertedTimeStamp":null,"insertedBy":0,"updatedTimeStamp":null,"updatedBy":0,"isAlreadyRequested":false}],"serviceItemNotes":[],"orgLevelId":null,"updatedTimeStamp":1463167949000,"qpIds":null,"svcOrgQpIds":[],"qualityplanList":null,"action":null,"isScheduled":"FALSE","seqString":null}];
			var result = {};
			result.searchServiceItemResults = mockSiList;
			getCBMServiceItemSearchPromise = _$q_.defer();
			getCBMServiceItemSearch.SearchCBMServiceItem.and.returnValue({$promise: getCBMServiceItemSearchPromise.promise});
			getCBMServiceItemSearchPromise.resolve(result);
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing setSelectedServiceItem", function(){
			it('capture selected service item', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceItemListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						orgLevelId : mockOrgLevelId,
						selectedServiceItem: mockSelectedServiceItem
					});
					ctrl.serviceItemList = mockSiList;
					ctrl.setSelectedServiceItem(mockSelectedServiceItem);
					expect(ctrl.selectedServiceItem.serviceItemId).toEqual(275032);
				});
			});
	    });
		
		describe("Unit testing cancel", function(){
			it('dismiss modal', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceItemListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						orgLevelId : mockOrgLevelId,
						selectedServiceItem: mockSelectedServiceItem
					});
					ctrl.serviceItemList = mockSiList;
					ctrl.cancel();
					expect(modalInstance.dismiss).toHaveBeenCalled();
				});
			})
	    });
		describe("Unit testing selectServiceItem", function(){
			it('set service item as selected', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceItemListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						orgLevelId : mockOrgLevelId,
						selectedServiceItem: undefined
					});		
					spyOn(rootScope, '$broadcast');
					ctrl.selectServiceItem();
					expect(rootScope.$broadcast).not.toHaveBeenCalled();
					
					ctrl.serviceItemList = mockSiList;
					ctrl.selectedServiceItem = ctrl.serviceItemList[1];
					ctrl.selectedServiceItemId = ctrl.serviceItemList[1].serviceItemId;
					ctrl.selectServiceItem();
					expect(rootScope.$broadcast).toHaveBeenCalledWith('SELECTED_SERVICEITEM',{serviceitem:ctrl.serviceItemList[1]});
				});
			});
	    });
		describe("Unit testing loadTableData", function(){
			it('create table and load table data', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceItemListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						orgLevelId : mockOrgLevelId,
						selectedServiceItem: mockSelectedServiceItem
					});
					ctrl.serviceItemList = mockSiList;
					ctrl.setSelectedTask = jasmine.createSpy("setSelectedTask");
					var mockTableElement = '<table id="serviceItemTable" class="table table-bordered">';
                    $('body').append(mockTableElement);
					ctrl.loadTableData();
					var elem = $("#serviceItemTable_filter input");
					expect(elem).not.toBeUndefined();
					//$("#taskTable").find(".taskrow").trigger("click");
					//expect(ctrl.setSelectedTask).toHaveBeenCalled();
				});
			});
	    });
	});
});
