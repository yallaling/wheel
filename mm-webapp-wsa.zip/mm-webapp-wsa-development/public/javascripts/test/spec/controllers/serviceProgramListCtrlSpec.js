/**
 * User: Raja Boppana
 * Date: 02/13/17
 * Time: 12:00 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing serviceProgramListCtrl', function() {

		var ctrl,mockScope,mockWindow,rootScope,q,$compile,mockHttp,timeout,translate,modalInstance,mockSpList,mockSelectedSp,fakedMainResponse = {};
		var getCBMServiceProgramSearch,getCBMServiceProgramSearchPromise;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		beforeEach(function(){
			getCBMServiceProgramSearch = jasmine.createSpyObj('getCBMServiceProgramSearch', [
			  'searchCBMServiceProgram'
			]);

			module(function ($provide) {
				$provide.value('getCBMServiceProgramSearch', getCBMServiceProgramSearch);
			});
		})
		
		beforeEach(angular.mock.inject(function($rootScope, $window,_$httpBackend_,_$q_,_$compile_,_$timeout_,$injector,$translate){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			q=_$q_;
			timeout = _$timeout_;
			translate = $translate;
			inject(function (_$filter_) {
				translate = $translate;
			});
			mockSelectedSp = {"programId":67812,"programName":"01-Feb-2017 17-49-35","itemId":275152,"description":"testing create service program","programType":"RM"};
			modalInstance = {
				close: jasmine.createSpy('modalInstance.close'),
				dismiss: jasmine.createSpy('modalInstance.dismiss'),
				result: {
				  then: jasmine.createSpy('modalInstance.result.then')
				},
				rendered:{
					then:jasmine.createSpy('modalInstance.rendered.then')
				}
			};
			
			mockHttp.when('GET', /assets*/).respond(fakedMainResponse);
			mockHttp.when('GET', /get*/).respond(fakedMainResponse)
			
			getCBMServiceProgramSearchPromise = _$q_.defer();
			//spyOn(getCBMServiceProgramSearch, 'searchCBMServiceProgram').and.returnValue(getCBMServiceProgramSearchPromise.promise);
			//getCBMServiceProgramSearch.searchCBMServiceProgram = jasmine.createSpy().and.returnValue( getCBMServiceProgramSearchPromise.promise);
			getCBMServiceProgramSearch.searchCBMServiceProgram.and.returnValue({$promise:getCBMServiceProgramSearchPromise.promise});
			getCBMServiceProgramSearchPromise.resolve('MOCK DATA');
			
			
			mockSpList = [{"programId":67812,"programName":"01-Feb-2017 17-49-35","itemId":275152,"description":"testing create service program","programType":"RM"},{"programId":67789,"programName":"08-Jan-2017 21-18-34","itemId":275152,"description":"testing create service program","programType":"RM"},{"programId":542,"programName":"1104 AIR","itemId":266754,"description":"1104 Day Air & Additional Maintenance Work","programType":"RM"},{"programId":38797,"programName":"12 MO EMD","itemId":266752,"description":"Annual maint items for EMD","programType":"RM"},{"programId":47826,"programName":"1472 AIR","itemId":372797,"description":"1474 AIR","programType":"RM"},{"programId":40294,"programName":"180 DAY","itemId":274234,"description":"M180 Day Running Maintenance","programType":"RM"},{"programId":31874,"programName":"184","itemId":275152,"description":"184 Day Running Maintenance","programType":"RM"},{"programId":16043,"programName":"184 Day","itemId":274234,"description":"184 DAY INSPECTION","programType":"RM"},{"programId":31018,"programName":"184 Day Running Maintenance","itemId":275152,"description":"184 Day Running Maintenance","programType":"RM"},{"programId":31350,"programName":"184 day inspection","itemId":275152,"description":"184 day inspection","programType":"RM"}];
			
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing setSelectedServiceProgram", function(){
			it('capture selected service program', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.serviceProgramList = mockSpList;
					ctrl.setSelectedServiceProgram(ctrl.serviceProgramList[1]);
					expect(ctrl.selectedSp).toEqual(ctrl.serviceProgramList[1]);

					ctrl.selectedSP = ctrl.serviceProgramList[1];
					ctrl.setSelectedServiceProgram(ctrl.serviceProgramList[1]);
					expect(ctrl.selectedSp).toEqual(ctrl.serviceProgramList[1]);
				});
			});
	    });
		
		describe("Unit testing cancel", function(){
			it('dismiss modal', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.serviceProgramList = mockSpList;
					ctrl.cancel();
					expect(modalInstance.dismiss).toHaveBeenCalled();
				});
			})
	    });
		describe("Unit testing selectServiceProgram", function(){
			it('set service program as selected', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: undefined
					});					
					spyOn(rootScope, '$broadcast');
					ctrl.selectServiceProgram();
					expect(rootScope.$broadcast).not.toHaveBeenCalled();

					ctrl.serviceProgramList = mockSpList;
					ctrl.selectedSp = ctrl.serviceProgramList[1];
					ctrl.selectServiceProgram();
					expect(rootScope.$broadcast).toHaveBeenCalledWith('SELECTED_SERVICEPROGRAM',{serviceprogram:ctrl.serviceProgramList[1]});
				});
			});
	    });
		describe("Unit testing loadNextPage", function(){
			it('load next page of table data', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.loadTableData = jasmine.createSpy("loadTableData");
					//spyOn(ctrl, 'loadTableData');
					ctrl.loadNextPage(3);
					expect(ctrl.current_page).toEqual(3);
					//expect(ctrl.loadTableData).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing sortServicePrograms", function(){
			it('sort table column', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.sort_dir = "ASC"
					ctrl.loadTableData = jasmine.createSpy('loadTableData');
					ctrl.sortServicePrograms("programName");
					expect(ctrl.sort_dir).toEqual("DESC");
					
					ctrl.sort_dir = "DESC"
					//ctrl.loadTableData = jasmine.createSpy('loadTableData');
					ctrl.sortServicePrograms("programName");
					expect(ctrl.sort_dir).toEqual("ASC");
				});
			});
	    });
		describe("Unit testing filterServicePrograms", function(){
			it('filter service program table', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.searchSp = "1472 AIR"
					ctrl.loadTableData = jasmine.createSpy('loadTableData');
					ctrl.filterServicePrograms();
					expect(ctrl.serviceProgramSearch).toEqual(ctrl.searchSp);
					expect(ctrl.current_page).toEqual(1);
					//expect(ctrl.loadTableData).toHaveBeenCalled();
				});
			});
	    });
		describe("Unit testing loadTableData", function(){
			it('load service program table', function(){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					ctrl.loadTableData();
					expect(getCBMServiceProgramSearch.searchCBMServiceProgram).toHaveBeenCalled();
					//expect(ctrl.loadTableData).toHaveBeenCalled();
				});
			});
	    });
		
		describe("Unit testing getCBMServiceProgramSearch service", function(){
			xit('load service program table', function(done){
				inject(function ($controller) {
					ctrl = $controller('serviceProgramListCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						$uibModalInstance: modalInstance,
						selectedSp: mockSelectedSp
					});
					var mockResult = {};
					mockResult.servicePrograms = mockSpList;
					mockResult.totalCount = 100;
					ctrl.loadTableData();
					getCBMServiceProgramSearchPromise.then(function(mockResult){
						expect(ctrl.serviceProgramList).toEqual(mockResult.servicePrograms);
						done();
					});
					//mockScope.$apply();
					//ctrl.loadTableData();
					//expect(ctrl.serviceProgramList).toEqual(mockResult.servicePrograms);
					//expect(getCBMServiceProgramSearch.searchCBMServiceProgram).toHaveBeenCalled();
					//expect(ctrl.loadTableData).toHaveBeenCalled();
				});
			});
	    });
	});
});
