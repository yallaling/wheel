/**
 * User: Raja Boppana
 * Date: 01/16/17
 * Time: 03:10 PM
 */
define(['angular-mocks','jquery','javascripts/app/app'], function(angularmocks, $, app){
	describe('Unit: Testing mainAppCtrl', function() {

		var ctrl,mockScope,mockWindow,rootScope,$compile,mockHttp,timeout,translate,mockSessionState,mockUtilsService;
		beforeEach(angular.mock.module('mm-webapp-wsa'));
		
		// beforeEach(function(){
			
			// mockUtilsService = jasmine.createSpyObj('mockUtilsService', [
			  // 'post'
			// ]);
			// module(function ($provide) {
				// $provide.value('mockUtilsService', mockUtilsService);
			// });
		// })
		
		beforeEach(angular.mock.inject(function($rootScope, $window,_$httpBackend_,_$compile_,_$timeout_,$injector,$translate){
			mockScope = $rootScope.$new();
			rootScope = $rootScope;
			mockWindow = {};
			$compile = _$compile_;
			mockHttp = _$httpBackend_;
			timeout = _$timeout_;
			translate = $translate;
			inject(function (_$filter_) {
				translate = $translate;
			});
			mockSessionState = {data:{"user_id":"212474653","sesid":"D6138C7D513A4209E4E1430E4630F277.cpesvcappld01e","menuid":"1526","locale":"ENG","esvonebaseurl":"https://deveservices.getransportation.com/eservices/"}};
		}));

	    afterEach( function() {
	        $('body').empty();
	    });
		
		describe("Unit testing mainAppCtrl", function(){
			it('adds session data to scope', function(){
				inject(function ($controller) {
					ctrl = $controller('mainAppCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						sessionState: mockSessionState
					});
					//expect(mockScope.locale).toEqual(mockSessionState.data.locale);
					expect(mockScope.user_id).toEqual(mockSessionState.data.user_id);
					expect(mockScope.session_id).toEqual(mockSessionState.data.sesid);
					expect(mockScope.menu_id).toEqual(mockSessionState.data.menuid);
					expect(mockScope.clientUrl).toEqual(mockSessionState.data.esvonebaseurl);				
				});
			});
	    });
		
		xdescribe("Unit testing $scope.$on('IdleTimeout')", function(){
			it('captures IdleTimeout event', function(){
				inject(function ($controller) {
					ctrl = $controller('mainAppCtrl', {
						$scope: mockScope,
						$window: mockWindow,
						sessionState: mockSessionState
					});
					rootScope.$broadcast('IdleTimeout');
					expect(mockUtilsService.post).toHaveBeenCalled();
				});
			});
	    });
		
	});
});