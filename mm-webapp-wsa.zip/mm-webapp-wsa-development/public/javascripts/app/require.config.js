require.config({
    'baseUrl': './assets',
	'waitSeconds': 200,
    'paths': {
    	"jquery": "components/jquery/dist/jquery",
        "angular": "components/angular/angular",
		"angular-resource": "components/angular-resource/angular-resource",
        "angular-bootstrap": "components/angular-bootstrap/ui-bootstrap-tpls",
        "angular-ui-router": "components/angular-ui-router/release/angular-ui-router",
		"translate": "components/angular-translate/angular-translate",
		"translate-loader": "components/angular-translate-loader-partial/angular-translate-loader-partial",
		"angular-sanitize": "components/angular-sanitize/angular-sanitize",
		"ng-idle": "components/ng-idle/angular-idle",
        "main": "javascripts/app/main",
		"spinnerModules": "javascripts/app/spinner.model",
		"spinner": "iidx/dist/components/spin.js/spin",
		"wsaRestModule": "javascripts/app/services/restService",
		"datatables.net": "components/datatables/media/js/jquery.dataTables.min",	
        "datatables" : "components/datatables/media/js/dataTables.bootstrap.min",
        "pageSlide" : "vendor/angular-pageslide-directive.min",
		"pagination": "components/angularUtils-pagination/dirPagination",
        "angular-lodash": "components/lodash/dist/lodash.min",
        "angularjs-dropdown-multiselect":"components/angularjs-dropdown-multiselect/dist/angularjs-dropdown-multiselect.min",
		"html2js": "template_cache"
		},
    'shim': {
        "jquery": {
            exports: '$'
        },
        "angular": {
            deps: ["jquery"],
            exports: "angular"
        },
        "angular-ui-router": {
            deps: ["angular"]
        },
        "angularjs-dropdown-multiselect": {
            deps: ["angular"]
        },
		"angular-bootstrap": {
            deps: ["angular"]
        },
		"angular-resource": {
            deps: ["angular"]
        },
		"translate": {
            deps: ["angular"]
        },
		"translate-loader": {
            deps: ["angular", "translate"]
        },
		"angular-sanitize":{
			deps: ["angular"]
		},
		"ng-idle": {
        	deps:["angular"]
        },
		"spinnerModules": {
            deps: ["angular-resource"]
        },
        "wsaRestModule":{
        	deps: ["angular", "angular-resource"]
        },
        'datatables' : {
            deps: ['jquery']  
        },
		'pagination': {
			deps:["angular"]
		},
		"html2js": {
	        deps: ["angular"]
	     }
    }
});
