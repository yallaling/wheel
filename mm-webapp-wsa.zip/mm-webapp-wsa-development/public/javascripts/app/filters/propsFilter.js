/**
 * AngularJS default filter with the following expression:
 * "person in people | filter: {attributeName: searchString, attributeName: searchString}"
 * performs a AND between 'attributeName: searchString' and 'attributeName: searchString'.
 * We want to perform a OR.
 */
define(['angular', 'javascripts/app/filters'], function(angular, filters){
	filters.filter('propsFilter', function(){
	  return function(items, props) {
		var out = [];

		if (angular.isArray(items)) {
		  items.forEach(function(item) {
			var itemMatches = false;
			var keys = Object.keys(props);
			for (var i = 0; i < keys.length; i++) {
				var prop = keys[i];
				var text = props[prop].toLowerCase();
				var propObj = prop.split(".");
				if(propObj.length > 1) {
					if(item[propObj[0]]) {
						if(item[propObj[0]].constructor === Array) {
							var arrlength = item[propObj[0]].length;
							for(var j=0;j<arrlength;j++) {
								if(item[propObj[0]][j][propObj[1]] &&  item[propObj[0]][j][propObj[1]].toString().toLowerCase().indexOf(text) !== -1) {
									itemMatches = true;
									break;
								}
							}
						} else if(item[propObj[0]][propObj[1]]) {
							if (item[propObj[0]][propObj[1]].toString().toLowerCase().indexOf(text) !== -1) {
								itemMatches = true;
								break;
							}
						}
					}
				} else {
					if(!item[prop]){
						item[prop] = "";
						if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
							itemMatches = true;
							break;
						}
					} else if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
						itemMatches = true;
						break;
					}
				}
			}

			if (itemMatches) {
			  out.push(item);
			}
		  });
		} else {
		  // Let the output be the input untouched
		  out = items;
		}

		return out;
	  }
	});
});