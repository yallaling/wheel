define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('serviceItemListCtrl', [
	       '$scope',
	       '$rootScope',
	       '$state',
	       '$http',
		   '$filter',
	       '$timeout',
	       '$translate',
		   'orderByFilter',
		   'orgLevelId',
		   'selectedServiceItem',
		   '$uibModalInstance',
		   'getCBMServiceItemSearch',function ($scope, $rootScope, $state, $http, $filter, $timeout, $translate,orderBy,orgLevelId,selectedServiceItem,$uibModalInstance,getCBMServiceItemSearch){
	    	    var vm = this;
				vm.orgLevelId = orgLevelId;
				vm.selectedServiceItem = selectedServiceItem;
				vm.alert = {
					type: 'success',
					msg: "",
					visible: false
				}
				vm.SERVICEITEM_STATUS_ACTIVE = "8481";
				
				vm.loadTableData 				= loadTableData;
				vm.setSelectedServiceItem		= setSelectedServiceItem;
				vm.cancel						= cancel;
				vm.selectServiceItem			= selectServiceItem;
				
				//capture selected service item in service item table
				function setSelectedServiceItem(serviceItem) {
					$scope.$apply(function(){
						vm.selectedServiceItem = serviceItem;
					});
				}
				//close modal
			    function cancel() {
					$uibModalInstance.dismiss('cancel');
				};

				//save selected service item and send to creating mapping screen
				function selectServiceItem() {
					if(vm.selectedServiceItem) {
						$rootScope.$broadcast('SELECTED_SERVICEITEM', {serviceitem: vm.selectedServiceItem});
						$uibModalInstance.dismiss('cancel');
					}
				}

				//callback after modal is rendered
				$uibModalInstance.rendered.then(function () {
					vm.loadTableData ();
				});

				//get service item data and initialise data table.
				function loadTableData() {
					$.fn.dataTable.ext.legacy.ajax = true;
					var serviceItemTable = $("#serviceItemTable").dataTable({
						"dom": '<"top"if>rt<"pull-left"l><"pull-right"p>',
						"bStateSave": false,
						"responsive": true,
						"lengthChange": false,
						'bServerSide': true,
						"bAutoWidth": false,
						"bFilter": true,
						"order": [[1,'asc']],
						"pagingType": "simple_numbers",
						"scrollCollapse": true,
						"scrollX": "100%",
						"scrollY": '50vh',
						"oLanguage": {
							"sSearch": '<div class="input-append">'+
								'_INPUT_'+
								'</div>',
				            "sSearchPlaceholder": $translate.instant("_Search_ServiceItems"),
				            "oPaginate": {
				                "sNext": '<i class="icon-ico_chevron_right_sm"></i>',
				                "sPrevious": '<i class="icon-ico_chevron_left_sm"></i>'
				            },
							"sZeroRecords": $translate.instant('_No_Data_Search'),
							"sEmptyTable": $translate.instant('_No_Data'),
						},
						"displayLength": 10,
						"columnDefs": [
							{
								"targets": 0,
								"data": 'serviceItemId',
								'orderable': false,
								'searchable': false,
								"width": '35px',
								"mRender": function ( data, type, row ) {
									return '<a href="javascript:void(0)" class="icon-gray-radio"><i class="icon-ico_circle_blank_sm"></i></a>';
								}
							},{
								"targets": 1,
								"data": 'serviceItemName',
								'orderable': true,
								'searchable': true,
								"width": '100px'
							},{
								"targets": 2,
								"data": 'description',
								'searchable': false,
								"orderable": false
							}
						],
						"fnCreatedRow": function(nRow,aData,iDataIndex) {
							$(nRow).attr('id',aData.serviceItemId);
							$(nRow).addClass("serviceitemrow");
						},
						'fnServerParams': function(aoData) {
						},
						'fnServerData': function(sSource, aoData, fnCallback) {
							var aoDatalength = aoData.length;
							var serviceItemsearchSet = [];
							for(var i=0;i<aoDatalength;i++) {
								var testObj = {};
								testObj.key = aoData[i].name;
								testObj.value = aoData[i].value;
								serviceItemsearchSet.push(testObj);
							}
							var serviceItemSearchData = {}
							serviceItemSearchData.dataTablesParamsMap = {};
							serviceItemSearchData.dataTablesParamsMap.entrySet = serviceItemsearchSet;
							serviceItemSearchData.serviceItemDescription = "";
							serviceItemSearchData.serviceItemName = "";
							serviceItemSearchData.orgLevelId = vm.orgLevelId;
							serviceItemSearchData.statusId = vm.SERVICEITEM_STATUS_ACTIVE;
							var getServiceItem = getCBMServiceItemSearch.SearchCBMServiceItem(serviceItemSearchData);
							getServiceItem.$promise.then(function(result) {
								var responseData = {};
								vm.serviceItemList = result.searchServiceItemResults;
								for (var i=0; i< vm.serviceItemList.length; i++ ) {
									var description = '';
									for(var j=0 ; j< vm.serviceItemList[i].descMultiLingual.length; j++ ){
										if( vm.serviceItemList[i].descMultiLingual[j].language === 'ENG' ){
											description = vm.serviceItemList[i].descMultiLingual[j].description;
											break;
										}
									}
									vm.serviceItemList[i].description  = description;
								}
								responseData.aaData = vm.serviceItemList;
								responseData.iTotalRecords = result.dataTablesParamsMap.entrySet[0].value;
								responseData.iTotalDisplayRecords = result.dataTablesParamsMap.entrySet[0].value;
								responseData.sEcho = result.dataTablesParamsMap.entrySet[2].value;
								fnCallback(responseData);
							},function(error) {
								vm.alert.visible = true;
								vm.alert.msg = $translate.instant("_Get_ServiceItem_Failure");
								vm.alert.type =  'danger';
							});
						},
						'drawCallback': function(settings) {
							var tableData =this.api().rows( {page:'current'} ).data();
							var len = tableData.length;
							for(var i=0;i<len;i++) {
								if(vm.selectedServiceItem && tableData[i] && tableData[i].serviceItemId == vm.selectedServiceItem.serviceItemId) {
									$("#"+vm.selectedServiceItem.serviceItemId).addClass('row_selected');
									$("#"+vm.selectedServiceItem.serviceItemId).find('a.icon-gray-radio').find('i').addClass('icon-ico_ok_circle_sm');
									break;
								}
							}
						}
					});
					$("#serviceItemTable_filter input").focus();
					serviceItemTable.off('click').on('click', '.serviceitemrow', function () {
				        if ( !($(this).hasClass('row_selected'))) {
							serviceItemTable.find('a.icon-gray-radio').find('i').removeClass('icon-ico_ok_circle_sm');
				        	serviceItemTable.$('tr.row_selected').removeClass('row_selected');
				            $(this).addClass('row_selected');
				            $(this).find('i').addClass('icon-ico_ok_circle_sm');
							vm.setSelectedServiceItem(serviceItemTable.fnGetData(this));
				        }
				    });	
				};
	}]);
});