define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	controllers.controller('configModalCtrl', [
		'$scope',
		'$rootScope',
		'$uibModalInstance',
		'$filter',
		'configDetailsList',
		'alreadyConfigValues',
		function ($scope, $rootScope, $uibModalInstance, $filter, configDetailsList, alreadyConfigValues) {
			$scope.selConfigDetailsList = alreadyConfigValues || [];
			$scope.selConfigurationsToUpdate = [];
			$scope.configDetailsList = configDetailsList;
			$scope.origConfigDetailsList = angular.copy(configDetailsList);
			$scope.alreadyConfigValues = alreadyConfigValues;
			$scope.userId = null;
			var isSelConfigVal = [];
			$scope.updateThreshold = 25000;
			$scope.isThresholdReached = false;

			$scope.ADD_ITEMS_TO_GROUP_IMG = 'assets/images/' + 'black_right.png';
			$scope.REMOVE_ITEMS_FROM_GROUP_IMG = 'assets/images/' + 'black_left.png';

			$scope.isToggleConfigDetails = isToggleConfigDetails;
			$scope.toggleConfigVal = toggleConfigVal;
			$scope.addConfigValToGroup = addConfigValToGroup;
			$scope.toggleSelConfigVal = toggleSelConfigVal;
			$scope.removeConfigValFromGroup = removeConfigValFromGroup;
			$scope.resetConfigModal = resetConfigModal;
			$scope.isDisabledConfig = isDisabledConfig;
			$scope.selctedConfigValues = selctedConfigValues;

			function isToggleConfigDetails(e, assetid) {
				e.preventDefault();
				$('#icon-arrow' + assetid).toggleClass('arrow-Close-Assignment arrow-Open-Assignment');
				$('div[name="collapse_item[]"]').each(function () {
					if ((this.id !== 'collapse' + assetid) && (this.classList.contains('in'))) {
						$('#' + this.id).collapse('hide');
						$('#icon-arrow' + this.id.slice(8)).toggleClass('arrow-Close-Assignment arrow-Open-Assignment');
					}
				});
			}

			function toggleConfigVal(configitem) {
				$scope.ADD_ITEMS_TO_GROUP_IMG = 'assets/images/' + 'blue_right.png';
			}

			function toggleSelConfigVal(configitem) {
				if (isSelConfigVal.indexOf(configitem.assetParamId) === -1) {
					isSelConfigVal.push(configitem.assetParamId);
				}
				$scope.REMOVE_ITEMS_FROM_GROUP_IMG = 'assets/images/' + 'blue_left.png';
			}

			function addConfigValToGroup() {
				for (var i = 0, len = $scope.configDetailsList.length; i < len; i++) {
					for (var j = 0, inlen = $scope.configDetailsList[i].configValuesForAsset.length; j < inlen; j++) {
						if ($('#configRadio' + $scope.configDetailsList[i].configValuesForAsset[j].configValueId).is(':checked')) {
							$scope.selConfigDetailsList.push({
								assetParamId: $scope.configDetailsList[i].assetParamId,
								paramDesc: $scope.configDetailsList[i].paramDesc,
								configValuesForAsset: [$scope.configDetailsList[i].configValuesForAsset[j]]
							});
							$scope.selConfigurationsToUpdate.push({
								assetId: $scope.configDetailsList[i].assetParamId,
								configId: $scope.configDetailsList[i].configValuesForAsset[j].configValueId
							});

							$('#configRadio' + $scope.configDetailsList[i].configValuesForAsset[j].configValueId).prop('checked', false);
						}
					}
				}

				$scope.selConfigDetailsList = removeDuplicates($scope.selConfigDetailsList, "assetParamId");
				$scope.selConfigurationsToUpdate = removeDuplicates($scope.selConfigurationsToUpdate, "assetId");

				$scope.ADD_ITEMS_TO_GROUP_IMG = 'assets/images/' + 'black_right.png';
			}

			function removeDuplicates(originalArray, prop) {
				var newArray = [];
				var lookupObject = {};

				for (var i in originalArray) {
					lookupObject[originalArray[i][prop]] = originalArray[i];
				}

				for (i in lookupObject) {
					newArray.push(lookupObject[i]);
				}
				return newArray;
			}

			function removeConfigValFromGroup() {
				$scope.selConfigDetailsList = $filter('filter')($scope.selConfigDetailsList, function (item) {
					return isSelConfigVal.indexOf(item.assetParamId) === -1;
				});
				$scope.selConfigurationsToUpdate = $filter('filter')($scope.selConfigurationsToUpdate, function (item) {
					return isSelConfigVal.indexOf(item.assetId) === -1;
				});
				isSelConfigVal = [];
				$scope.REMOVE_ITEMS_FROM_GROUP_IMG = 'assets/images/' + 'black_left.png';

				for (var k = 0, len = $scope.configDetailsList.length; k < len; k++) {
					for (var l = 0, llen = $scope.configDetailsList[k].configValuesForAsset.length; l < llen; l++) {
						$('#configRadio' + $scope.configDetailsList[k].configValuesForAsset[l].configValueId).prop('checked', false);
					}
				}
			}

			function resetConfigModal() {
				$scope.ADD_ITEMS_TO_GROUP_IMG = 'assets/images/' + 'black_right.png';
				$scope.REMOVE_ITEMS_FROM_GROUP_IMG = 'assets/images/' + 'black_left.png';
				$scope.selConfigDetailsList = [];
				isSelConfigVal = [];
				$scope.configDetailsList = [];
				$uibModalInstance.dismiss('cancel');
			}

			function isDisabledConfig() {
				$rootScope.$broadcast("SELECTED_CONFIG",$scope.selConfigDetailsList);
				return false;
			}

			function selctedConfigValues(){
				$rootScope.$broadcast("SELECTED_CONFIG",$scope.selConfigDetailsList);
				$uibModalInstance.dismiss('select');
			}
		}]);
});