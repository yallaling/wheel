define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('serviceProgramListCtrl', [
	       '$scope',
	       '$rootScope',
	       '$state',
	       '$http',
		   '$filter',
	       '$timeout',
	       '$translate',
		   'orderByFilter',
		   'selectedSp',
		   '$uibModalInstance',
		   'getCBMServiceProgramSearch',function ($scope, $rootScope, $state, $http, $filter, $timeout, $translate,orderBy,selectedSp,$uibModalInstance,getCBMServiceProgramSearch){
	    	    var vm = this;
				vm.selectedSp = selectedSp;
				vm.alert = {
					type: 'success',
					msg: "",
					visible: false
				}
				$scope.pageSize = 10;
				vm.current_page = 1;
				vm.orig_sort_dir = "ASC";
				vm.sort_dir = "ASC";
				vm.sortType = "programName";
				vm.serviceProgramSearch = "";
				
				vm.loadTableData 					= loadTableData;
				vm.setSelectedServiceProgram		= setSelectedServiceProgram;
				vm.cancel							= cancel;
				vm.selectServiceProgram				= selectServiceProgram;
				vm.loadNextPage						= loadNextPage;
				vm.sortServicePrograms				= sortServicePrograms;
				vm.filterServicePrograms			= filterServicePrograms;
				
				function setSelectedServiceProgram(selectedSp) {
					if(vm.selectedSp != selectedSp) {
						vm.selectedSp = selectedSp;
					}
				}
				
				function cancel() {
					$uibModalInstance.dismiss('cancel');
				};

				function selectServiceProgram() {
					if(vm.selectedSp) {
						$rootScope.$broadcast('SELECTED_SERVICEPROGRAM', {serviceprogram: vm.selectedSp});
						$uibModalInstance.dismiss('cancel');
					}
				}

				$uibModalInstance.rendered.then(function () {
					vm.loadTableData ();
				});

				function loadNextPage(newPage) {
					vm.current_page = newPage;
					loadTableData(newPage);
				}

				function sortServicePrograms(predicate) {
					vm.sort_dir == "ASC" ? vm.sort_dir = "DESC" : vm.sort_dir = "ASC";
					loadTableData();
				}

				function filterServicePrograms() {
					vm.serviceProgramSearch = vm.searchSp;
					vm.current_page = 1;
					loadTableData(vm.searchSp);
				}

				function loadTableData(dataChange) {
					var spRequestObject = {};
					spRequestObject.serviceProgramName = vm.serviceProgramSearch;
					spRequestObject.pageSize = $scope.pageSize;
					spRequestObject.pageNumber = vm.current_page;
					spRequestObject.serviceProgramOrder = vm.sort_dir;
					var getSps = getCBMServiceProgramSearch.searchCBMServiceProgram(spRequestObject);
					getSps.$promise.then(function(result) {
						vm.serviceProgramList = result.servicePrograms;
						vm.serviceProgramListSize = result.totalCount;
						vm.dataChange = dataChange;
						vm.orig_sort_dir = vm.sort_dir;
					},function(error){
						vm.alert.visible = true;
						vm.alert.msg = $translate.instant("_Get_ServiceProgram_Failure");
						vm.alert.type =  "danger";
					});
				};
	}]);
});