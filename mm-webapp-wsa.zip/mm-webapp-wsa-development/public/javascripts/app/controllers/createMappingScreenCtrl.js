define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('createMappingScreenCtrl', [
		'$scope',
		'$state',
		'$timeout',
		'$log',
		'$translate',
		'$stateParams',
		'utilsService',
		'modalService',
		'getBulkOmdRules',
		'getAllCbmActions',
		'getCBMQPForTask',
		'getCBMOrgsForQP',
		'createMappingService',
		'getLovsForTask',
		'getAllOrgs',
		'getAllCustomers',
		'getCustomersByProgramId',
		'fleetsByCustomerAndProgramIdService',
		'getFrequencySchedulerService',
		'getConfigDetails',
		'getServiceProgramDetailsByIdService',
		'getCbmRuleValuesService',
		'$q',
		function ($scope, $state, $timeout, $log, $translate, stateParams, utilsService, modalService, getBulkOmdRules, getAllCbmActions, getCBMQPForTask, getCBMOrgsForQP, createMappingService, getLovsForTask, getAllOrgs, getAllCustomers, getCustomersByProgramId, fleetsByCustomerAndProgramIdService, getFrequencySchedulerService, getConfigDetails, getServiceProgramDetailsByIdService, getCbmRuleValuesService, $q) {
			var vm = this;
			vm.cbmRules = stateParams.cbmRule;
			vm.cbmMapping = stateParams.cbmMapping;
			vm.configTabName = stateParams.configTabName;
			vm.isOpenDrawer = false;
			vm.isSPSelected = true;
			vm.selCbmRuleIds = [];
			vm.configLovList = [];
			vm.allCustomerList = [];
			vm.customersByProgramId = [];
			vm.customerList = [];
			vm.mapping = {};
			vm.mappingObjSave = {};
			vm.frequency = null;
			vm.mappingState;
			var customerIdList;
			vm.frequencySchedulerList = [];
			vm.selectedConfigShow = [];
			vm.alert = {
				type: 'success',
				msg: "",
				visible: false
			}
			vm.filterCustomer = false;
			vm.filterFleets = false;
			vm.selectedCustomer = [];
			vm.selectedFleets = [];
			vm.fleetsList = [];
			vm.defaultDropdownTest = $translate.instant('_Select');
			vm.customerSettings = {
				scrollableHeight: '300px',
				scrollable: true,
				enableSearch: true,
				displayProp: 'partyName',
				idProp: 'customerAccountId',
				buttonClasses: 'btn btn-dropdown-right',
				showCheckAll: false,
				showUncheckAll: false,
				buttonDefaultText: vm.defaultDropdownTest,
				template: '<span ng-class="{bottomline:option.isLastObj==true}">{{option.partyName}}</span>'

			};
			vm.programdetails = {
				intervalType: '',
				primaryIntervalValue: null,
				primaryIntervalUom: '',
				secondaryIntervalValue: null,
				secondaryIntervalUom: '',
				primaryCounterMax: null,
				secondaryCounterMax: null,
				primaryIntervalDelta: null,
				secondaryIntervalDelta: null
			};
			vm.fleetSettings = angular.extend({}, vm.customerSettings);
			vm.fleetSettings.displayProp = 'fleetName';
			vm.fleetSettings.idProp = 'fleetId';
			vm.fleetSettings.template = '<span ng-class="{bottomline:option.isLastFleetObj==true}">{{option.fleetName}}</span>'

			vm.customerDropdownEvents = {
				onClose: closeCustomerDropdown
			};
			
			vm.fleetDropdownEvents = {
				onClose: closeFleetDropdown
			};
			
			vm.frequencyTime = new Date();
			vm.hstep = 1;
			vm.mstep = 15;
			vm.ismeridian = true;
			vm.cbmRuleValuesList = [];

			vm.removeSelectedRule = removeSelectedRule;
			vm.triggerTaskModal = triggerTaskModal;
			vm.triggerServiceItemModal = triggerServiceItemModal;
			vm.triggerServiceProgramModal = triggerServiceProgramModal;
			vm.triggerConfigModal = triggerConfigModal;
			vm.triggerOMDListModal = triggerOMDListModal;
			vm.loadMappingRules = loadMappingRules;
			vm.setDataForMapping = setDataForMapping;
			vm.loadCBMRuleActions = loadCBMRuleActions;
			vm.loadAllCustomers = loadAllCustomers;
			vm.loadConfigDetails = loadConfigDetails;
			vm.configDetailsList = [];
			vm.loadCustomersByProgramId = loadCustomersByProgramId;
			vm.loadCBMMapingQpTask = loadCBMMapingQpTask;
			vm.resolveCBMQpTask = resolveCBMQpTask;
			vm.showMappingList = showMappingList;
			vm.getOrgsConfig = getOrgsConfig;
			vm.resolveCBMOrgs = resolveCBMOrgs;
			vm.resolveAllOrgs = resolveAllOrgs;
			vm.loadTaskLovs = loadTaskLovs;
			vm.resolveTaskLovs = resolveTaskLovs;
			vm.toggleDrawer = toggleDrawer;
			vm.setSelectedQp = setSelectedQp;
			vm.saveMappingQp = saveMappingQp;
			vm.setSelectedLov = setSelectedLov;
			vm.saveMappingLovs = saveMappingLovs;
			vm.setSelectedOrg = setSelectedOrg;
			vm.saveMappingOrgs = saveMappingOrgs;
			vm.saveMappingOrgsForQps = saveMappingOrgsForQps;
			vm.saveMapping = saveMapping;
			vm.prepareSelectedRuleList = prepareSelectedRuleList;
			vm.filterCustomerDropdown = filterCustomerDropdown;
			vm.loadFleetsByCustomerAndProgramId = loadFleetsByCustomerAndProgramId;
			vm.filterFleetDropdown = filterFleetDropdown;
			vm.loadFrequencyScheduler = loadFrequencyScheduler;

			vm.ACTION_SIGNOFF_LOV_TASK = 1;
			vm.ACTION_SIGNOFF_REF_TASK = 3;
			vm.ACTION_SWITCH_SERVICE_ITEM = 2;
			vm.ACTION_SWITCH_INTERVAL = 41;

			vm.LOV_TASKTYPE_ID = 1;
			vm.REF_TASKTYPE_ID = 2;

			vm.MAPPING_MODE_CREATE = 1;
			vm.MAPPING_MODE_EDIT = 2;

			//method to redirect to mapping list screen
			function showMappingList() {
				vm.cbmRules = undefined;
				vm.cbmMapping = undefined;
				vm.configTabName = undefined;
				$state.go('wsa.mappings');
			}

			//Method to set initial data for mapping template
			function setDataForMapping() {
				vm.loadAllCustomers();
				vm.loadConfigDetails();
				if (vm.cbmMapping) {
					vm.mappingState = vm.MAPPING_MODE_EDIT;
					vm.cbmAction = vm.cbmMapping.action;
					vm.cbmActionsList = [];
					vm.cbmActionsList.push(vm.cbmAction);
					if (vm.cbmMapping.action.actionId == vm.ACTION_SIGNOFF_LOV_TASK || vm.cbmMapping.action.actionId == vm.ACTION_SIGNOFF_REF_TASK) {
						vm.mapping.selectedTask = {};
						vm.mapping.selectedTask.taskId = vm.cbmMapping.element.elementId;
						vm.mapping.selectedTask.taskNumber = vm.cbmMapping.element.elementName;
					} else {
						vm.mapping.selectedSp = {};
						vm.mapping.selectedSp.programId = vm.cbmMapping.element.elementId;
						vm.mapping.selectedSp.programName = vm.cbmMapping.element.elementName;
					}
					vm.mapping.lovValues = vm.cbmMapping.lovIds;
					var orgslen = vm.cbmMapping.cbmOrgs.length;
					vm.mapping.cbmOrgs = [];
					for (var i = 0; i < orgslen; i++) {
						vm.mapping.cbmOrgs.push(vm.cbmMapping.cbmOrgs[i].orgId);
					}
					vm.mapping.serviceItem = vm.cbmMapping.serviceItem;
					vm.mapping.qualityPlan = vm.cbmMapping.qualityPlan;
					vm.mapping.webserviceValue = vm.cbmMapping.webserviceValue;
					vm.mapping.comment = vm.cbmMapping.comment;
					if (vm.cbmMapping.action.actionId == vm.ACTION_SWITCH_INTERVAL){
						if(null != vm.cbmMapping.newInterval && undefined != vm.cbmMapping.newInterval){
							vm.programdetails.primaryCounterMax = vm.cbmMapping.newInterval.ruleMaxCounterPrimary || 0;
							vm.programdetails.secondaryCounterMax = vm.cbmMapping.newInterval.ruleMaxCounterSecondary || 0;
							vm.programdetails.primaryIntervalDelta = vm.cbmMapping.newInterval.primaryIntervalDelta || 0;
							vm.programdetails.secondaryIntervalDelta = vm.cbmMapping.newInterval.secondaryIntervalDelta || 0;
						}
						if(null != vm.cbmMapping.defaultInterval && undefined != vm.cbmMapping.defaultInterval){
							vm.programdetails.primaryIntervalValue = (((null || undefined) != vm.cbmMapping.defaultInterval.serviceProgramDetail) ? (vm.cbmMapping.defaultInterval.serviceProgramDetail.primaryIntervalValue || "") : "");
							vm.programdetails.primaryIntervalUom = (((null || undefined) != vm.cbmMapping.defaultInterval.serviceProgramDetail) ? (vm.cbmMapping.defaultInterval.serviceProgramDetail.primaryIntervalUom || "") : "");
							vm.programdetails.secondaryIntervalValue = (((null || undefined) != vm.cbmMapping.defaultInterval.serviceProgramDetail) ? (vm.cbmMapping.defaultInterval.serviceProgramDetail.secondaryIntervalValue || "") : "");
							vm.programdetails.secondaryIntervalUom = (((null || undefined) != vm.cbmMapping.defaultInterval.serviceProgramDetail) ? (vm.cbmMapping.defaultInterval.serviceProgramDetail.secondaryIntervalUom || "") : "");
							vm.programdetails.intervalType = (((null || undefined) != vm.cbmMapping.defaultInterval.serviceProgramDetail) ? (vm.cbmMapping.defaultInterval.serviceProgramDetail.intervalType || "") : "");
						}	
						if(null != vm.cbmMapping.selectedCustomer && undefined != vm.cbmMapping.selectedCustomer){
							vm.selectedCustomer =  vm.cbmMapping.selectedCustomer;
							customerIdList = [];
							for (var id in vm.selectedCustomer) {
								customerIdList.push(vm.selectedCustomer[id].id);
							}
							vm.loadAllCustomers().then(function(){
								vm.loadCustomersByProgramId().then(function (){
									filterCustomerDropdown(vm.filterCustomer);
								});
							})
							
							loadFleetsByCustomer(customerIdList).then(function () {
								if (vm.mapping.selectedSp != undefined) {
									loadFleetsByProgramIdForCreateMapping(customerIdList, vm.mapping.selectedSp.programId).then(function () {
										filterFleetDropdown(vm.filterFleets);
										filterSeletecFleet();
									});
								}
								else {
									filterFleetDropdown(vm.filterFleets);
									filterSeletecFleet();
								}
							
			
							});
							
						}
						if(null != vm.cbmMapping.selectedFleets && undefined != vm.cbmMapping.selectedFleets){
							vm.selectedFleets =  vm.cbmMapping.selectedFleets;
						}
						if(null != vm.cbmMapping.selectedConfigs && undefined != vm.cbmMapping.selectedConfigs){
							vm.mapping.selectedConfig =  vm.cbmMapping.selectedConfigs;
							vm.selctedConfigIds = [];
							
							for (var i = 0; i < vm.mapping.selectedConfig.length; i++) {
								vm.selectedConfigShow.push(vm.mapping.selectedConfig[i].paramDesc);
								for(var index in vm.mapping.selectedConfig[i].configValuesForAsset) {
									vm.selctedConfigIds.push(vm.mapping.selectedConfig[i].configValuesForAsset[index].configValueId);
								}
							}									
						}
						
					}
					
				} else {
					vm.mappingState = vm.MAPPING_MODE_CREATE;
					vm.selCbmRuleIds = createCBMRulesMap();
					vm.loadCBMRuleActions();
				}
			}
			vm.setDataForMapping();

			//Remove rule selected for a mapping
			function removeSelectedRule(index, rule) {
				vm.cbmRules.splice(vm.cbmRules.indexOf(rule), 1);
				vm.selCbmRuleIds.splice(vm.selCbmRuleIds.indexOf(rule.ruleId), 1);
			};

			//watch action change
			$scope.$watch(function watchAction($scope) {
				return vm.cbmAction;
			}, function () {
				if (vm.mappingState == vm.MAPPING_MODE_CREATE) {
					vm.mapping = {};
				}
			});

			//Method to capture selected rule.
			$scope.$on('SELECTED_RULE', function (evt, arg) {
				if (arg.rules != vm.cbmRules) {
					vm.cbmRules = arg.rules;
					vm.selCbmRuleIds = createCBMRulesMap();
				}
			});
			//Method to capture selected task
			$scope.$on('SELECTED_TASK', function (evt, arg) {
				if (arg.task) {
					if (!vm.mapping.selectedTask || (vm.mapping.selectedTask && vm.mapping.selectedTask.taskId != arg.task.taskId)) {
						vm.mapping = {};
						vm.configLovList = [];
						vm.cbmQpTask = null;
						vm.mapping.selectedTask = arg.task;
					}
				}
			});
			//Method to capture selected service item
			$scope.$on('SELECTED_SERVICEITEM', function (evt, arg) {
				if (arg.serviceitem) {
					if (!vm.mapping.serviceItem || (vm.mapping.serviceItem && vm.mapping.serviceItem.serviceItemId != arg.serviceitem.serviceItemId)) {
						vm.mapping.serviceItem = arg.serviceitem;
					}
				}
			});
			//Method to capture selected service program
			$scope.$on('SELECTED_SERVICEPROGRAM', function (evt, arg) {
				if (arg.serviceprogram) {
					if (!vm.mapping.selectedSp || (vm.mapping.selectedSp && vm.mapping.selectedSp.programId != arg.serviceprogram.programId)) {
						vm.mapping.selectedSp = arg.serviceprogram;
						vm.selectedCustomer =[];
						vm.loadCustomersByProgramId();
						serviceProgramDetailsById(arg.serviceprogram.programId);
						vm.selectedFleets = [];
						vm.isSPSelected = false;
					}
				}
			});

			//Method to capture the selected Configuration values
			$scope.$on("SELECTED_CONFIG", function (evt, data) {
				vm.selectedConfigShow = [];
				vm.selctedConfigIds = [];
				if (data.length != 0) {
					for (var i = 0; i < data.length; i++) {
						vm.selectedConfigShow.push(data[i].paramDesc);
						for(var index in data[i].configValuesForAsset) {
							vm.selctedConfigIds.push(data[i].configValuesForAsset[index].configValueId);
						}
					}
					console.log(data);
					vm.mapping.selectedConfig = data;
				} else if (data.length == 0) {
					vm.selectedConfigShow = [];
					vm.mapping.selectedConfig = data;
					vm.selctedConfigIds = [];
				}

			});

			//Trigger Task Search Modal
			function triggerTaskModal(event) {
				if (event) {
					event.preventDefault();
				}
				var modalOptions = {
					closeButtonText: "Close"
				};
				var tempModalDefaults = {
					templateUrl: "assets/html/partials/tasksearch.modal.partial.html",
					controller: 'taskListCtrl',
					controllerAs: 'taskCtrl',
					size: 'lg',
					resolve: {
						taskType: function () {
							if (vm.cbmAction.actionId == vm.ACTION_SIGNOFF_LOV_TASK) {
								return vm.LOV_TASKTYPE_ID;
							} else if (vm.cbmAction.actionId == vm.ACTION_SIGNOFF_REF_TASK) {
								return vm.REF_TASKTYPE_ID;
							}
						},
						orgLevelId: function () {
							return $scope.organizationLevelId;
						},
						selectedTask: function () {
							return vm.mapping.selectedTask;
						}
					}
				};
				modalService.showModal(tempModalDefaults, modalOptions);
			};

			//Trigger Service Item Modal
			function triggerServiceItemModal(event) {
				if (event) {
					event.preventDefault();
				}
				var modalOptions = {
					closeButtonText: "Close"
				};
				var tempModalDefaults = {
					templateUrl: "assets/html/partials/serviceitemsearch.modal.partial.html",
					controller: 'serviceItemListCtrl',
					controllerAs: 'siCtrl',
					size: 'lg',
					resolve: {
						orgLevelId: function () {
							return $scope.organizationLevelId;
						},
						selectedServiceItem: function () {
							return vm.mapping.serviceItem;
						}
					}
				};
				modalService.showModal(tempModalDefaults, modalOptions);
			};

			//Trigger Service Program Modal
			function triggerServiceProgramModal(event) {
				if (event) {
					event.preventDefault();
				}
				var modalOptions = {
					closeButtonText: "Close"
				};
				var tempModalDefaults = {
					templateUrl: "assets/html/partials/serviceprogramsearch.modal.partial.html",
					controller: 'serviceProgramListCtrl',
					controllerAs: 'spCtrl',
					size: 'lg',
					resolve: {
						selectedSp: function () {
							return vm.mapping.selectedSp;
						}
					}
				};
				modalService.showModal(tempModalDefaults, modalOptions);
			}

			//Trigger Config Modal
			function triggerConfigModal(event) {
				if (event) {
					event.preventDefault();
				}
				var modalOptions = {
					closeButtonText: "Close"
				};
				var tempModalDefaults = {
					templateUrl: "assets/html/partials/configvalues.modal.html",
					controller: 'configModalCtrl',
					size: 'lg',
					windowClass: 'customConfigClass',
					resolve: {
						configDetailsList: function () {
							return vm.configDetailsList;
						},
						alreadyConfigValues: function () {
							return vm.mapping.selectedConfig;
						}
					}
				};
				modalService.showModal(tempModalDefaults, modalOptions);
			}

			/**
			 * @method  - loadMapingRules
			 * @return - ruleList
			 */
			function loadMappingRules() {
				var omdRules = getBulkOmdRules.getOmdRules();
				omdRules.$promise.then(function (result) {
					if (result.length) {
						vm.triggerOMDListModal(result);
					} else if (!(result.length)) {
						showAlert($translate.instant('_Get_OMDRules_Failure'), "danger");
					}
				}, function (error) {
					showAlert($translate.instant('_Get_OMDRules_Failure'), "danger");
				});
			}

			//Create a Map of Rule Ids
			function createCBMRulesMap() {
				var cbmRulesIdMap = [];
				if (vm.cbmRules !== null) {
					var cbmRulesLength = vm.cbmRules.length;
					for (var i = 0; i < cbmRulesLength; i++) {
						cbmRulesIdMap.push(vm.cbmRules[i].ruleId);
					}
				}
				return cbmRulesIdMap;
			}
			//create rules object to save mapping
			function prepareSelectedRuleList() {
				var selCbmRules = [];
				if (vm.cbmRules !== null) {
					var cbmRulesLength = vm.cbmRules.length;
					for (var i = 0; i < cbmRulesLength; i++) {
						var rule = {};
						rule.ruleId = vm.cbmRules[i].ruleId;
						rule.ruleTitle = vm.cbmRules[i].ruleTitle;
						selCbmRules.push(rule);
					}
				}
				return selCbmRules;
			}

			//Trigger OMD rules list modal
			function triggerOMDListModal(ruleList) {
				var modalOptions = {
					closeButtonText: "Close"
				};
				var tempModalDefaults = {
					templateUrl: "assets/html/partials/omdList.modal.partial.html",
					controller: 'omdListCtrl',
					controllerAs: 'omdCtrl',
					size: 'md',
					resolve: {
						omdList: function () {
							return ruleList;
						},
						selCbmRuleIds: function () {
							return vm.selCbmRuleIds;
						}
					}
				};
				modalService.showModal(tempModalDefaults, modalOptions);
			};

			//Method to get list of actions
			function loadCBMRuleActions() {
				var cbmActions = getAllCbmActions.get({
					languageId: "1600"
				});
				cbmActions.$promise.then(function (result) {
					if (result.cbmActions) {
						vm.cbmActionsList = result.cbmActions;
						if (vm.cbmActionsList.length) {
							if (vm.configTabName == "task") {
								vm.cbmAction = vm.cbmActionsList[0];
							} else if (vm.configTabName == "interval") {
								vm.cbmAction = vm.cbmActionsList[1];
							} else if (vm.configTabName == "sitem") {
								vm.cbmAction = vm.cbmActionsList[2];
							}
						}
					}
				}, function (error) {
					showAlert($translate.instant("_Get_Actions_Failure"), "danger");
				});
			}

			//Method to get list of actions
			function loadAllCustomers() {
				return $q(function (resolve, reject) {
				getAllCustomers.get({}, function (result) {
					if (result.customers) {
						vm.origCustomerList = result.customers;
						vm.allCustomerList = result.customers;
					}
					resolve();
				}, function (error) {
					showAlert($translate.instant("Failed to load customers"), "danger");
				});
			});
			}

			//Method to get list of actions
			function loadConfigDetails() {
				var cbmActions = getConfigDetails.get();
				cbmActions.$promise.then(function (result) {
					if (result.configValues) {
						vm.configDetailsList = result.configValues;
					}
				}, function (error) {
					showAlert($translate.instant("_Get_Actions_Failure"), "danger");
				});
			}

			//Method to get list of quality plans for a task
			function loadCBMMapingQpTask() {
				if (!(vm.cbmQpTask)) {
					var getQPTask = getCBMQPForTask.get({
						languageId: '1600',
						taskId: vm.mapping.selectedTask.taskId
					});
					getQPTask.$promise.then(function (result) {
						if (result.cbmQP.length) {
							vm.resolveCBMQpTask(result);
						} else {
							showAlert($translate.instant("_Task_No_QP"), "danger");
						}
					}, function (error) {
						showAlert($translate.instant("_Get_QPs_Failure"), "danger");
					});
				} else {
					vm.drawerTemplate = 'assets/html/partials/qualityplan.drawer.partial.html';
					vm.isOpenDrawer = !vm.isOpenDrawer;
				}
			}

			//Method to show quality plan list in drawer
			function resolveCBMQpTask(result) {
				vm.cbmQpTask = result.cbmQP;
				vm.drawerTemplate = 'assets/html/partials/qualityplan.drawer.partial.html';
				vm.isOpenDrawer = !vm.isOpenDrawer;
			};

			//Method to get list of orgs for a quality plan
			function getOrgsConfig() {
				if (vm.mapping.qualityPlan) {
					if (!(vm.qpCustomers)) {
						var getOrgs = getCBMOrgsForQP.get({
							languageId: '1600',
							qpIds: vm.mapping.qualityPlan.qpId
						});
						getOrgs.$promise.then(function (result) {
							vm.resolveCBMOrgs(result);
						}, function (error) {
							showAlert($translate.instant("_Get_Orgs_Failure"), "danger");
						});
					} else {
						vm.drawerTemplate = 'assets/html/partials/configOrgs.drawer.partial.html';
						vm.isOpenDrawer = !vm.isOpenDrawer;
					}
				} else {
					if (!(vm.allOrgs)) {
						var getOrgs = getAllOrgs.get({});
						getOrgs.$promise.then(function (result) {
							vm.resolveAllOrgs(result);
						}, function (error) {
							showAlert($translate.instant("_Get_Orgs_Failure"), "danger");
						});
					} else {
						vm.drawerTemplate = 'assets/html/partials/configAllOrgs.drawer.partial.html';
						vm.isOpenDrawer = !vm.isOpenDrawer;
					}
				}
			}
			//Method to show QP orgs list in drawer
			function resolveCBMOrgs(result) {
				if (result.qpCustomers[0]) {
					if (vm.mapping.cbmOrgs) {
						var orglen = vm.mapping.cbmOrgs.length;
						for (var j = 0; j < orglen; j++) {
							var custLen = result.qpCustomers[0].customers.length;
							for (var i = 0; i < custLen; i++) {
								var customer = result.qpCustomers[0].customers[i]
								var orgLen = customer.customerOrg.length;
								for (var k = 0; k < orgLen; k++) {
									if (vm.mapping.cbmOrgs[j] == customer.customerOrg[k].orgId) {
										customer.customerOrg[k].isSelectedOrg = true;
										break;
									}
								}
							}
						}
					}
					vm.qpCustomers = result.qpCustomers[0];
					vm.drawerTemplate = 'assets/html/partials/configOrgs.drawer.partial.html';
					vm.isOpenDrawer = !vm.isOpenDrawer;
				}

			}
			//Method to show all orgs in drawer
			function resolveAllOrgs(result) {
				if (result.customers) {
					if (vm.mapping.cbmOrgs) {
						var orglen = vm.mapping.cbmOrgs.length;
						for (var j = 0; j < orglen; j++) {
							var custLen = result.customers.length;
							for (var i = 0; i < custLen; i++) {
								var customer = result.customers[i]
								var orgLen = customer.customerOrg.length;
								for (var k = 0; k < orgLen; k++) {
									if (vm.mapping.cbmOrgs[j] == customer.customerOrg[k].orgId) {
										customer.customerOrg[k].isSelectedOrg = true;
										break;
									}
								}
							}
						}
					}
					vm.allOrgs = result.customers;
					vm.drawerTemplate = 'assets/html/partials/configAllOrgs.drawer.partial.html';
					vm.isOpenDrawer = !vm.isOpenDrawer;
				}
			}
			//Method to get lov list for a task
			function loadTaskLovs() {
				if (!(vm.configLovList.length)) {
					var getLovs = getLovsForTask.getLovs({
						locale: $scope.languageCode || 'ENG',
						taskNumber: vm.mapping.selectedTask.taskNumber
					});
					getLovs.$promise.then(function (result) {
						vm.resolveTaskLovs(result);
					}, function (error) {
						showAlert($translate.instant("_Get_Lovs_Failure"), "danger");
					});
				} else {
					vm.drawerTemplate = 'assets/html/partials/configLovs.drawer.partial.html';
					vm.isOpenDrawer = !vm.isOpenDrawer;
				}
			}
			//Method to show lov list in drawer
			function resolveTaskLovs(lovs) {
				vm.configLovList = utilsService.convertLovEntryTypesIntoCustomerLovEntries(lovs, vm.mapping.lovValues);
				vm.drawerTemplate = 'assets/html/partials/configLovs.drawer.partial.html';
				vm.isOpenDrawer = !vm.isOpenDrawer;
			}
			//Method to toggle drawer display
			function toggleDrawer() {
				vm.isOpenDrawer = !vm.isOpenDrawer;
			};

			//capture selected QP in drawer
			function setSelectedQp(selectedQp) {
				if (vm.selectedQp != selectedQp) {
					vm.selectedQp = selectedQp;
				}
			};
			//save selected qp for a mapping.
			function saveMappingQp() {
				vm.mapping.qualityPlan = vm.selectedQp;
				vm.mapping.cbmOrgs = [];
				vm.qpCustomers = null;
				vm.toggleDrawer();
			}
			//capture selected lov
			function setSelectedLov(lov, customer) {
				if (customer.selectedLovId == lov.id) {
					customer.selectedLovId = null;
				} else {
					customer.selectedLovId = lov.id;
				}
			}

			//save list of selected lov config
			function saveMappingLovs() {
				vm.mapping.lovValues = [];
				var custLen = vm.configLovList.length;
				for (var i = 0; i < custLen; i++) {
					if (vm.configLovList[i].selectedLovId) {
						vm.mapping.lovValues.push(vm.configLovList[i].selectedLovId);
					}
				}
				vm.toggleDrawer();
			}

			//capture selected orgs in drawer
			function setSelectedOrg(org) {
				if (org.isSelectedOrg) {
					org.isSelectedOrg = !org.isSelectedOrg;
				} else {
					org.isSelectedOrg = true;
				}
			};

			//save selected orgs list
			function saveMappingOrgs() {
				vm.mapping.cbmOrgs = [];
				var custLen = vm.allOrgs.length;
				for (var i = 0; i < custLen; i++) {
					var customer = vm.allOrgs[i]
					var orgLen = customer.customerOrg.length;
					for (var j = 0; j < orgLen; j++) {
						if (customer.customerOrg[j].isSelectedOrg) {
							vm.mapping.cbmOrgs.push(customer.customerOrg[j].orgId);
						}
					}
				}
				vm.toggleDrawer();
			}

			//save selected orgs list for QPs
			function saveMappingOrgsForQps() {
				vm.mapping.cbmOrgs = [];
				var custLen = vm.qpCustomers.customers.length;
				for (var i = 0; i < custLen; i++) {
					var customer = vm.qpCustomers.customers[i]
					var orgLen = customer.customerOrg.length;
					for (var j = 0; j < orgLen; j++) {
						if (customer.customerOrg[j].isSelectedOrg) {
							vm.mapping.cbmOrgs.push(customer.customerOrg[j].orgId);
						}
					}
				}
				vm.toggleDrawer();
			}

			//save mapping with all selected info
			function saveMapping() {
				vm.mappingObjSave.actionId = vm.cbmAction.actionId;
				if (vm.mappingObjSave.actionId == vm.ACTION_SIGNOFF_LOV_TASK || vm.mappingObjSave.actionId == vm.ACTION_SIGNOFF_REF_TASK) {
					vm.mappingObjSave.element = vm.mapping.selectedTask.taskId;
				} else {
					vm.mappingObjSave.element = vm.mapping.selectedSp.programId;
				}
				vm.mappingObjSave.rules = vm.prepareSelectedRuleList();
				vm.mappingObjSave.comment = vm.mapping.comment;
				vm.mappingObjSave.createdBy = $scope.user_id;

				if (vm.cbmMapping && vm.cbmMapping.mappingId) {
					vm.mappingObjSave.mappingId = vm.cbmMapping.mappingId;
				}
				if (vm.configTabName !== 'interval') {
					vm.mappingObjSave.lovValues = vm.mapping.lovValues;
					vm.mappingObjSave.cbmOrgIds = vm.mapping.cbmOrgs;
					if (vm.mapping.serviceItem) {
						vm.mappingObjSave.serviceItemId = vm.mapping.serviceItem.serviceItemId;
					}
					if (vm.mapping.qualityPlan) {
						vm.mappingObjSave.qualityPlanId = vm.mapping.qualityPlan.qpId;
					}
					vm.mappingObjSave.webserviceValue = vm.mapping.webserviceValue;
				} else {
					vm.mappingObjSave.lovValues = [];
					vm.mappingObjSave.cbmOrgIds = [];
					vm.mappingObjSave.serviceItemId = null;
					vm.mappingObjSave.qualityPlanId = null;
					vm.mappingObjSave.webserviceValue = false;
					if(vm.mappingState == vm.MAPPING_MODE_EDIT){
						vm.mappingObjSave.mappingId = vm.cbmMapping.mappingId;
					}else{
						vm.mappingObjSave.mappingId = null;
					}
					
					vm.mappingObjSave.cbmMappingInterval = {
						ruleMaxCounterPrimary: vm.programdetails.primaryCounterMax,
						ruleMaxCounterSecondary: vm.programdetails.secondaryCounterMax,
						primaryIntervalDelta: vm.programdetails.primaryIntervalDelta,
						secondaryIntervalDelta: vm.programdetails.secondaryIntervalDelta,
						ruleFrequency: vm.frequency.frequencyId
					};
					vm.mappingObjSave.cbmMappingInterval.customerListDetail = {
						customerId: []
					};

					vm.mappingObjSave.cbmMappingInterval.fleetListDetail = {
						assetId: []
					};

					vm.mappingObjSave.cbmMappingInterval.configurationListDetail = {
						configValueId: vm.selctedConfigIds || []
					};
					
					angular.forEach(vm.selectedCustomer, function (val, key) {
						vm.mappingObjSave.cbmMappingInterval.customerListDetail.customerId.push(val.id);
					});
					
					angular.forEach(vm.selectedFleets, function (val, key) {
						vm.mappingObjSave.cbmMappingInterval.fleetListDetail.assetId.push(val.id);
					});

					console.log(JSON.stringify(vm.mappingObjSave));
				}

				var createMapping = createMappingService.createMapping({
					"mapping": vm.mappingObjSave
				});
				createMapping.$promise.then(function (result) {
					resolveCreateMapping(result);
				}, function (error) {
					showAlert($translate.instant("_Create_Mapping_Failure"), "danger");
				});
			}
			//resolve create mapping response.
			function resolveCreateMapping(result) {
				if (result.status.statusCode === 'SUCCESS') {
					switch (vm.mappingState) {
						case vm.MAPPING_MODE_CREATE:
							showAlert($translate.instant("_Create_Mapping_Success"), "success");
							$timeout(function () {
								vm.showMappingList();
							}, 500);
							break;
						
						case vm.MAPPING_MODE_EDIT:
							showAlert($translate.instant("_Edit_Mapping_Success"), "success");
							$timeout(function () {
								vm.loadFrequencyScheduler();
								vm.showMappingList();
							}, 500);
							break;
						default:
							showAlert($translate.instant("_Create_Mapping_Success"), "success");
							$timeout(function () {
								vm.showMappingList();
							}, 500);
							break;
					}
				
				} else {
					if (vm.mappingState == vm.MAPPING_MODE_CREATE) {
						showAlert($translate.instant("_Create_Mapping_Failure"), "danger");
					} else {
						showAlert($translate.instant("_Edit_Mapping_Failure"), "danger");
					}
				}
			}

			vm.closeAlert = function () {
				vm.alert.visible = false;
			}

			function showAlert(alertMessage, alertType) {
				vm.alert.visible = true;
				vm.alert.msg = alertMessage;
				vm.alert.type = alertType;
			}

			//Method to get list of actions
			function loadCustomersByProgramId() {
				return $q(function (resolve, reject) {
				var custIndex = [];
				vm.filterFleets = false;
				getCustomersByProgramId.get({
					serviceProgramId: vm.mapping.selectedSp.programId
				}, function (result) {
					if (result.customers) {
						vm.customersByProgramId = result.customers;
						vm.customerList = vm.customersByProgramId;
						vm.filterCustomer = false;

						if (result.customers.length > 0) {
							for (var index in result.customers) {
								custIndex.push(result.customers[index].customerAccountId);
							}

							vm.allCustomerList = vm.origCustomerList || [];
							var resultlist = vm.allCustomerList.filter(function (obj, index) {
								return custIndex.indexOf(obj.customerAccountId) === -1;
							});
							vm.allCustomerList = resultlist;
						} else {
							vm.allCustomerList = vm.origCustomerList;
						}

						for(var i=0; i<vm.customerList.length; i++){

						}
						resolve();
					}
					
				}, function (error) {
					showAlert($translate.instant("Failed to load customers"), "danger");
				});
				
			});
			
			}

			

			function loadFleetsByCustomerAndProgramId(customerList, programId) {
				var payload = {
					customerId: customerList,
					serviceprogramId: programId
				}
				vm.fleetsByCustomerAndProgramIdServicePromise = fleetsByCustomerAndProgramIdService.fleetsMap(payload);
				return vm.fleetsByCustomerAndProgramIdServicePromise;
			}

			function loadFleetsByCustomer(customerlist) {
				return $q(function (resolve, reject) {
					vm.loadFleetsByCustomerAndProgramId(customerlist, null).$promise
						.then(function (custfleetresponse) {
							vm.allFleetsList = custfleetresponse.fleetReport;
							if (vm.filterFleets) vm.fleetsList = vm.allFleetsList;
							resolve();
						});
				});
			}

			function filterSeletecFleet()
			{
				var filterCheckedFleet=[];
				for(var index in vm.selectedFleets)
				{
				for(var id in vm.allFleetsList)
				{
					if(vm.allFleetsList[id].fleetId==vm.selectedFleets[index].id)
					{
						filterCheckedFleet.push(vm.selectedFleets[index]);
					}
				}
			}

			for(var index in vm.selectedFleets)
				{
				for(var id in vm.serviceProtramfleetsList)
				{
					if(vm.serviceProtramfleetsList[id].fleetId==vm.selectedFleets[index].id)
					{
						filterCheckedFleet.push(vm.selectedFleets[index]);
					}
				}
			}
			vm.selectedFleets=removeDumplicateSelectedFleet(filterCheckedFleet);
			
			}

			function closeCustomerDropdown() {

				customerIdList = [];
				for (var id in vm.selectedCustomer) {
					customerIdList.push(vm.selectedCustomer[id].id);
				}
				if (vm.selectedCustomer.length === 0) {
					vm.filterFleets = false;
					vm.selectedFleets = [];
				}
				filterCustomerDropdown(vm.filterCustomer);
				loadFleetsByCustomer(customerIdList).then(function () {
					if (vm.mapping.selectedSp != undefined) {
						loadFleetsByProgramIdForCreateMapping(customerIdList, vm.mapping.selectedSp.programId).then(function () {
							filterFleetDropdown(vm.filterFleets);
							filterSeletecFleet();
						});
					}
					else {
						filterFleetDropdown(vm.filterFleets);
						filterSeletecFleet();
					}
				

				});

			

			}

			function filterCustomerDropdown(checked) {
				var index = 0;
				vm.applicableCust = [];
				if (checked) {
					checkedAllCustomerDropdown();
					for (var id in vm.allCustomerList) {
						if (vm.allCustomerList[id].isLastObj == true) {
							vm.allCustomerList[id].isLastObj = false;
						}
						vm.applicableCust.push(vm.allCustomerList[id]);
					}
					vm.applicableCust = removeDuplicateCustValue(vm.applicableCust);
					vm.customerList = vm.applicableCust;

				} else if (!checked && vm.mapping.hasOwnProperty('selectedSp')) {
					if (vm.selectedCustomer.length > 0) {
						customerIdList = [];
						for (var id in vm.selectedCustomer) {
							customerIdList.push(vm.selectedCustomer[id].id);
						}
					}
					checkedAllCustomerDropdown();
					if (vm.applicableCust.length > 0) {
						var temp = vm.applicableCust.pop();
						temp.isLastObj = true;
						vm.applicableCust.push(temp);
					}
					checkedApplicableCustomerDropdown()
					vm.applicableCust = removeDuplicateCustValue(vm.applicableCust);
					vm.customerList = vm.applicableCust;
				}
				else if (checked === false) {
					checkedAllCustomerDropdown();
					if (vm.applicableCust.length > 0) {
						var temp = vm.applicableCust.pop();
						temp.isLastObj = true;
						vm.applicableCust.push(temp);
					}
					vm.customerList = vm.applicableCust;
				}
			}

			function checkedAllCustomerDropdown() {
				vm.applicableCust = [];
				for (var i in vm.selectedCustomer) {
					for (var id in vm.allCustomerList) {
						if (vm.allCustomerList[id].customerAccountId == vm.selectedCustomer[i].id) {
							if (vm.allCustomerList[id].isLastObj == true) {
								vm.allCustomerList[id].isLastObj = false;
							}
							vm.applicableCust.push(vm.allCustomerList[id]);
						}
					}
				}
				sortCustList(vm.applicableCust);
			}


			function checkedApplicableCustomerDropdown() {
				var checkedAppCust = [];
				for (var i in vm.selectedCustomer) {
					for (var id in vm.customersByProgramId) {
						if (vm.customersByProgramId[id].customerAccountId == vm.selectedCustomer[i].id) {
							checkedAppCust.push(vm.customersByProgramId[id]);
						}
					}

				}
				sortCustList(checkedAppCust);

				for (var id in checkedAppCust) {
					vm.applicableCust.push(checkedAppCust[id]);
				}

				for (var id in vm.customersByProgramId) {
					vm.applicableCust.push(vm.customersByProgramId[id]);
				}
			}

			function sortCustList(obj) {
				obj.sort(function (a, b) {
					var textA = a.partyName.toUpperCase();
					var textB = b.partyName.toUpperCase();
					return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
				});
			}

			function removeDuplicateCustValue(myArray) {
				var newArray = [];
				angular.forEach(myArray, function (value, key) {
					var exists = false;
					angular.forEach(newArray, function (val2, key) {
						if (angular.equals(value.customerAccountId, val2.customerAccountId)) { exists = true };
					});
					if (exists == false && value.customerAccountId != "") { newArray.push(value); }
				});
				return newArray;
			}

			
			function loadFleetsByProgramId(customerlist, programid) {

				vm.loadFleetsByCustomerAndProgramId(customerlist, programid).$promise
					.then(function (custfleetresponse) {
						vm.serviceProtramfleetsList = custfleetresponse.fleetReport;
						vm.fleetsList = vm.serviceProtramfleetsList;
					});
			}

			
			function loadFleetsByProgramIdForCreateMapping(customerlist, programid) {

				return $q(function (resolve, reject) {
					vm.loadFleetsByCustomerAndProgramId(customerlist, programid).$promise
						.then(function (custfleetresponse) {
							vm.serviceProtramfleetsList = custfleetresponse.fleetReport;
							resolve();
						});
				});

			}

			

			function closeFleetDropdown() {
				filterFleetDropdown(vm.filterFleets);
			}

			function filterFleetDropdown(checked) {

				if (checked) {
					allCustomerCheckedFleetForAllCust();
					for (var id in vm.allFleetsList) {
						
						if (vm.allFleetsList[id].isLastFleetObj == true) {
							vm.allFleetsList[id].isLastFleetObj = false;
						}
						vm.applicableFleet.push(vm.allFleetsList[id]);
					}
					vm.applicableFleet = removeDumplicateFleetValue(vm.applicableFleet);
					vm.fleetsList = vm.applicableFleet;

				} else {
					allCustomerCheckedFleet();
					if (vm.applicableFleet.length > 0) {
						var temp = vm.applicableFleet.pop();
						temp.isLastFleetObj = true;
						vm.applicableFleet.push(temp);
					}
					appCustFleet();
					vm.applicableFleet = removeDumplicateFleetValue(vm.applicableFleet);
					vm.fleetsList = vm.applicableFleet;
				}
			}

			function sortFleetList(obj) {
				obj.sort(function (a, b) {
					var textA = a.fleetName.toUpperCase();
					var textB = b.fleetName.toUpperCase();
					return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
				});
			}



			function removeDumplicateFleetValue(myArray) {
				var newArray = [];
				angular.forEach(myArray, function (value, key) {
					var exists = false;
					angular.forEach(newArray, function (val2, key) {
						if (angular.equals(value.fleetId, val2.fleetId)) { exists = true };
					});
					if (exists == false && value.fleetId != "") { newArray.push(value); }
				});
				return newArray;
			}

			function removeDumplicateSelectedFleet(myArray) {
				var newArray = [];
				angular.forEach(myArray, function (value, key) {
					var exists = false;
					angular.forEach(newArray, function (val2, key) {
						if (angular.equals(value.id, val2.id)) { exists = true };
					});
					if (exists == false && value.id != "") { newArray.push(value); }
				});
				return newArray;
			}
		

			function allCustomerCheckedFleet() {

				vm.applicableFleet = [];
				for (var i in vm.selectedFleets) {
					for (var id in vm.allFleetsList) {
						if (vm.allFleetsList[id].fleetId == vm.selectedFleets[i].id) {
							if (!checkExists(vm.allFleetsList[id].fleetId)) {
								vm.applicableFleet.push(vm.allFleetsList[id]);
							}
						}
					}

				}
				sortFleetList(vm.applicableFleet);
			}


			function allCustomerCheckedFleetForAllCust() {
				vm.applicableFleet = [];
				for (var i in vm.selectedFleets) {
					for (var id in vm.allFleetsList) {
						if (vm.allFleetsList[id].fleetId == vm.selectedFleets[i].id) {
							
							if (vm.allFleetsList[id].isLastFleetObj == true) {
								vm.allFleetsList[id].isLastFleetObj = false;
							}
							vm.applicableFleet.push(vm.allFleetsList[id]);
						}
					}

				}
				sortFleetList(vm.applicableFleet);
			}

			function appCustFleet() {
				var appCheckedFleet = [];
				for (var i in vm.selectedFleets) {
					for (var id in vm.serviceProtramfleetsList) {
						if (vm.serviceProtramfleetsList[id].fleetId == vm.selectedFleets[i].id) {
							appCheckedFleet.push(vm.serviceProtramfleetsList[id]);
						}
					}

				}

				sortFleetList(appCheckedFleet);
				for (var id in appCheckedFleet) {
					vm.applicableFleet.push(appCheckedFleet[id]);
				}

				for (var id in vm.serviceProtramfleetsList) {
					vm.applicableFleet.push(vm.serviceProtramfleetsList[id]);
				}
			}

			function checkExists(type) {
				if (vm.serviceProtramfleetsList != undefined) {
					return vm.serviceProtramfleetsList.some(function (obj) {
						return obj.fleetId === type;

					});
				}
			}
		

			function loadFrequencyScheduler() {
				getFrequencySchedulerService.get({
					languageId: $scope.languageCode || 'ENG'
				}, function (frequencyres) {
					if (frequencyres.status.statusCode === "SUCCESS") {
						vm.frequencySchedulerList = frequencyres.frequencyTypes;
						if(vm.mappingState == vm.MAPPING_MODE_EDIT){
							for(var i = 0;i<vm.frequencySchedulerList.length;i++){
								if((null || undefined) != vm.cbmMapping && (vm.cbmMapping.newInterval.ruleFrequency == vm.frequencySchedulerList[i].frequencyId)){
									vm.frequency = vm.frequencySchedulerList[i];
								} 
							}							 
						}
					}
				}, function (error) {
					showAlert($translate.instant('Load Frequency service failed'), "danger");
				});
			}

			if(vm.configTabName == "interval"){
				loadFrequencyScheduler();
			}

			function serviceProgramDetailsById(id) {
				getServiceProgramDetailsByIdService.get({
					serviceProgramId: id
				}, function(res) {
					if (res.status.statusCode === "SUCCESS") {
						angular.extend(vm.programdetails, res.serviceProgramDetail);
					}
				});
			}

			function loadCbmRuleValues() {
				getCbmRuleValuesService.get({}, function(rules){
					if (rules.status.statusCode === "SUCCESS") {
						vm.cbmRuleValuesList = rules.cbmRuleDetails;
					}
				});
			}

			if (vm.configTabName === 'interval') {
				loadCbmRuleValues();
			}
		}
	]);
});