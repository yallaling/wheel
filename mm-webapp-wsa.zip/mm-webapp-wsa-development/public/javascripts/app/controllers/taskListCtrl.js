define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('taskListCtrl', [
	       '$scope',
	       '$rootScope',
	       '$state',
	       '$http',
		   '$filter',
	       '$timeout',
	       '$translate',
		   'orderByFilter',
		   'taskType',
		   'orgLevelId',
		   'selectedTask',
		   '$uibModalInstance',
		   'getCBMTaskSearch',function ($scope, $rootScope, $state, $http, $filter, $timeout, $translate,orderBy,taskType,orgLevelId, selectedTask,$uibModalInstance,getCBMTaskSearch){
	    	    var vm = this;
				vm.taskType = taskType;
				vm.orgLevelId = orgLevelId;
				vm.selectedTask = selectedTask;
				vm.alert = {
					type: 'success',
					msg: "",
					visible: false
				};
				vm.TASK_STATUS_ACTIVE = "952";
				
				vm.loadTableData		= loadTableData;
				vm.setSelectedTask		= setSelectedTask;
				vm.cancel				= cancel;
				vm.selectTask			= selectTask;
				
				//capture selected task in task table
				function setSelectedTask(task) {
					$scope.$apply(function(){
						vm.selectedTask = task;
					});
				}
				
				//close modal
			    function cancel() {
					$uibModalInstance.dismiss('cancel');
				};

				//save selected task and send to creating mapping screen
				function selectTask() {
					if(vm.selectedTask) {
						$rootScope.$broadcast('SELECTED_TASK', {task: vm.selectedTask});
						$uibModalInstance.dismiss('cancel');
					}
				}
				
				//callback after modal is rendered
				$uibModalInstance.rendered.then(function () {
					vm.loadTableData ();
				});
				
				//get task data and initialise data table.
				function loadTableData() {
					$.fn.dataTable.ext.legacy.ajax = true;
					var taskTable = $("#taskTable").dataTable({
						"dom": '<"top"if>rt<"pull-left"l><"pull-right"p>',
						"bStateSave": false,
						"responsive": true,
						"lengthChange": false,
						'bServerSide': true,
						"bAutoWidth": false,
						"bFilter": true,
						"searchDelay": 1000,
						"order": [[1,'asc']],
						"pagingType": "simple_numbers",
						"scrollCollapse": true,
						"scrollX": "100%",
						"scrollY": '50vh',
						"oLanguage": {
							"sSearch": '<div class="input-append">'+
								'_INPUT_'+
								'</div>',
				            "sSearchPlaceholder": $translate.instant("_Search_Tasks"),
				            "oPaginate": {
				                "sNext": '<i class="icon-ico_chevron_right_sm"></i>',
				                "sPrevious": '<i class="icon-ico_chevron_left_sm"></i>'
				            },
							"sZeroRecords": $translate.instant('_No_Data'),
							"sEmptyTable": $translate.instant('_No_Data_Search')
						},
						"displayLength": 10,
						"columnDefs": [
							{
								"targets": 0,
								"data": 'taskId',
								'orderable': false,
								'searchable': false,
								"width": '35px',
								"mRender": function ( data, type, row ) {
									return '<a href="javascript:void(0)" class="icon-gray-radio"><i class="icon-ico_circle_blank_sm"></i></a>';
								}
							},{
								"targets": 1,
								"data": 'taskNumber',
								'orderable': true,
								'searchable': true,
								"width": '100px'
							},{
								"targets": 2,
								"data": 'description',
								'searchable': false,
								"orderable": false
							}
						],
						"fnCreatedRow": function(nRow,aData,iDataIndex) {
							$(nRow).attr('id',aData.taskId);
							$(nRow).addClass("taskrow");
						},
						'fnServerParams': function(aoData) {
							//aoData.push( { 'name': 'taskNumber', 'value': "" });
						},
						'fnServerData': function(sSource, aoData, fnCallback) {
							var aoDatalength = aoData.length;
							var tasksearchSet = [];
							for(var i=0;i<aoDatalength;i++) {
								var testObj = {};
								testObj.key = aoData[i].name;
								testObj.value = aoData[i].value;
								tasksearchSet.push(testObj);
							}
							var taskSearchData = {}
							taskSearchData.dataTablesParamsMap = {};
							taskSearchData.dataTablesParamsMap.entrySet = tasksearchSet;
							taskSearchData.taskTypeId = vm.taskType;
							taskSearchData.taskNumber = "";
							taskSearchData.taskStatusId = vm.TASK_STATUS_ACTIVE;
							taskSearchData.orgLevelId = vm.orgLevelId;
							var getTask = getCBMTaskSearch.SearchCBMTasks(taskSearchData);
							getTask.$promise.then(function(result) {
									var responseData = {};
									vm.taskList = result.tasks;
									for (var i=0; i< vm.taskList.length; i++ ) {
										vm.taskList[i].description   = vm.taskList[i].descMultiLingual[0].description;
									}
									responseData.aaData = vm.taskList;
									responseData.iTotalRecords = result.dataTablesParamsMap.entrySet[0].value;
									responseData.iTotalDisplayRecords = result.dataTablesParamsMap.entrySet[0].value;
									responseData.sEcho =  result.dataTablesParamsMap.entrySet[2].value;
									fnCallback(responseData);
							},function(error) {
								vm.alert.visible = true;
								vm.alert.msg = $translate.instant("_Get_Tasks_Failure");
								vm.alert.type =  'danger';
							});
						},
						'drawCallback': function(settings) {
							var tableData =this.api().rows( {page:'current'} ).data();
							var len = tableData.length;
							for(var i=0;i<len;i++) {
								if(vm.selectedTask && tableData[i] && tableData[i].taskId == vm.selectedTask.taskId) {
									$("#"+vm.selectedTask.taskId).addClass('row_selected');
									$("#"+vm.selectedTask.taskId).find('a.icon-gray-radio').find('i').addClass('icon-ico_ok_circle_sm');
									break;
								}
							}
						}
					});
					$("#taskTable_filter input").focus();
					taskTable.off('click').on('click', '.taskrow', function () {
				        if ( !($(this).hasClass('row_selected'))) {
							taskTable.find('a.icon-gray-radio').find('i').removeClass('icon-ico_ok_circle_sm');
				        	taskTable.$('tr.row_selected').removeClass('row_selected');
				            $(this).addClass('row_selected');
				            $(this).find('i').addClass('icon-ico_ok_circle_sm');
							vm.setSelectedTask(taskTable.fnGetData(this));
				        }
				    });	
				};
	}]);
});