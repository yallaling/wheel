define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('mappingScreenCtrl', [
	       '$scope',
	       '$rootScope',
	       '$state',
	       '$http',
	       '$timeout',
		   '$q',
		   '$filter',
		   'lodash',
	       '$translate',
		   'orderByFilter',
		   'utilsService',
	       'getCBMMappingDetailService',
	       'updateCBMMappingDetailService',
		   'getBulkOmdRules',
		   'getLovsForTask',
		   'deleteCBMMappingDetailService',
		   'modalService',function ($scope, $rootScope, $state, $http, $timeout,$q, $filter,lodash, $translate, orderBy,utilsService,getCBMMappingDetail, updateCBMMappingDetail,getBulkOmdRules,getLovsForTask,deleteCBMMappingDetail, modalService){
				var vm = this,
				tableScrollElem;
				vm.newMappingMode = false;
				vm.newMapping = {};
				vm.isOpenDrawer = false;
				vm.defaultSort = ['mappingId'];
				vm.alert = {
					type: 'success',
					msg: "",
					visible: false
				}
				$scope.ORIG_ORGVIEW_LIMIT = 2;
				$scope.ORGVIEW_LIMIT = 2;
				$scope.radioModel = 'task';
				vm.mappingTabId = 1;

				vm.loadCBMMappingDetails 	= loadCBMMappingDetails;
				vm.resolveCBMMappings 		= resolveCBMMappings;
				vm.triggerOMDListModal 		= triggerOMDListModal;
				vm.toggleMapping			= toggleMapping;
				vm.resolveUpdateCBMMapping  = resolveUpdateCBMMapping;
				vm.sortMappingCols     		= sortMappingCols;
				vm.filterMappings 			= filterMappings;
				vm.getRules					= getRules;
				vm.showSelectedTaskLovs     = showSelectedTaskLovs;
				vm.resolveSelectedTaskLovs  = resolveSelectedTaskLovs;
				vm.clearSearch				= clearSearch;
				vm.editMapping				= editMapping;
				vm.confirmDeleteMapping		= confirmDeleteMapping;
				vm.deleteMapping			= deleteMapping;
				vm.resolveDeleteCBMMapping	= resolveDeleteCBMMapping;
				vm.setTableHeight			= setTableHeight;
				/**
				* Method to call service  and get mappings
				* @method  - loadCBMMappingDetails
				* @return - mappingList
				*/
				function loadCBMMappingDetails() {
					var getCBMMappings = getCBMMappingDetail.get({
						languageId: "1600" 
					});
					getCBMMappings.$promise.then(function(result){
						vm.resolveCBMMappings(result);
					},function() {
						showAlert($translate.instant('_Get_MappingList_Failure','danger'));
					});
				}
				vm.loadCBMMappingDetails();

				//Method accepts mapping list and displays with default sorting 
				function resolveCBMMappings(result) {
					if(result.status.statusCode === 'SUCCESS') {
						for(var i=0;i<result.mapping.length;i++){
							if((result.mapping[i].defaultInterval != null && result.mapping[i].defaultInterval != undefined) && (result.mapping[i].newInterval != null && result.mapping[i].newInterval != undefined)){
								var newInterval = (( (null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.intervalType || "") : "") + " " + (( (null || undefined) != result.mapping[i].newInterval.primaryIntervalDelta) ? (result.mapping[i].newInterval.primaryIntervalDelta || "") : "") + " " + (((null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.primaryIntervalUom || "") : "") + " " + (( (null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.intervalType2 || "") : "") + " " + (( (null || undefined) != result.mapping[i].newInterval.secondaryIntervalDelta) ? (result.mapping[i].newInterval.secondaryIntervalDelta || "") : "") + " " + (((null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.secondaryIntervalUom || "") : "");
								result.mapping[i].newIntervalBind = newInterval;
							}
							if(result.mapping[i].defaultInterval != null || result.mapping[i].defaultInterval != undefined){
								var defaultInterval = (((null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.intervalType || "") : "")  + " " + (( (null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.primaryIntervalValue || "") : "") + " " + (((null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.primaryIntervalUom || "") : "") + " " + (( (null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.intervalType2 || "") : "") + " " + (( (null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.secondaryIntervalValue || "") : "") + " " + (((null || undefined) != result.mapping[i].defaultInterval.serviceProgramDetail) ? (result.mapping[i].defaultInterval.serviceProgramDetail.secondaryIntervalUom || "") : "") ;
								result.mapping[i].defaultIntervalBind = defaultInterval;
							}

							if((result.mapping[i].populations != null && result.mapping[i].populations != undefined)){
								if((result.mapping[i].populations.populationDetails != null && result.mapping[i].populations.populationDetails != undefined)){
								var popDetails = result.mapping[i].populations.populationDetails;
								var config;
								result.mapping[i].selectedCustomer = [];
								result.mapping[i].selectedFleets = [];
								result.mapping[i].selectedConfigs = [];
								for(var j=0; j<popDetails.length; j++){								
											for(var k=0; k<popDetails[j].customerDetail.length; k++){
												var custId = " " + popDetails[j].customerDetail[k].customerName;
												var selectedCustomer = {id: popDetails[j].customerDetail[k].customerId};
												result.mapping[i].selectedCustomer.push(selectedCustomer);
											}
											
											for(var k=0; k<popDetails[j].fleetDetail.length; k++){
												var fleetId = " " + popDetails[j].fleetDetail[k].fleetName;
												var selectedFleets = {id: popDetails[j].fleetDetail[k].fleetId};
												result.mapping[i].selectedFleets.push(selectedFleets);
											}

											for(var k=0; k<popDetails[j].configDetail.length; k++){
												var configId = " " + popDetails[j].configDetail[k].configValueDescription;
												var selectedConfigs = {assetParamId: popDetails[j].configDetail[k].assetParamId, configValuesForAsset:[{configValueId: popDetails[j].configDetail[k].configId, configValueDescription: popDetails[j].configDetail[k].configValueDescription}], paramDesc: popDetails[j].configDetail[k].paramDesc};
												result.mapping[i].selectedConfigs.push(selectedConfigs);
											}
								}
								result.mapping[i].populationsBind = (((null || undefined) != custId) ? custId : "") + (((null || undefined) != fleetId) ? fleetId : "") + (((null || undefined) != configId) ? configId : "");
							}
						}
						}
						vm.mappings = result.mapping;
						/* set default sorting*/
						vm.sortType = vm.defaultSort;
						vm.isSortReverse = true;
						loadDefaultMappings();
					} else {
						showAlert($translate.instant('_Get_MappingList_Failure'),'danger');
					}
				};

				//Method filters and sorts mapping list
				function loadDefaultMappings() {
					var sortDir = 'asc';
					vm.isSortReverse ? sortDir = 'desc' : sortDir = 'asc' ;
					var list = vm.searchMapping ? vm.filteredMappings : vm.mappings;
					if(vm.subSorttype) {
						vm.filteredMappings = lodash.orderBy(list, function (mapping) {
							if(mapping[vm.sortType]) {
								if(mapping[vm.sortType][vm.subSorttype] && typeof mapping[vm.sortType][vm.subSorttype] == 'string') {
									return mapping[vm.sortType][vm.subSorttype].toLowerCase()
								} else {
									return mapping[vm.sortType][vm.subSorttype];
								}
							} else {
								return mapping[vm.sortType];
							}
					    }, [sortDir]);
					} else {
						vm.filteredMappings = lodash.orderBy(list, function(mapping) {
							if(mapping[vm.sortType] && typeof mapping[vm.sortType] == 'string') {
								return mapping[vm.sortType].toLowerCase()
							} else {
								return mapping[vm.sortType];
							}
						},[sortDir]);
					}
				}

				 /**
				 * Function provided by a service to display a modal.
				 * @name showModal
				 * @param {modaloptions}, {modaldefaults}
				 * @member of modelService
				 * @function triggerOMDListModal.
				 */
				function triggerOMDListModal(ruleList) {
					var modalOptions = {
						closeButtonText: "Close"
					};
					var tempModalDefaults = {
						templateUrl: "assets/html/partials/omdList.modal.partial.html",
						controller: 'omdListCtrl',
						controllerAs: 'omdCtrl',
						size: 'md',
						resolve: {
							omdList: function() {
								return ruleList;
							 },
							selCbmRuleIds: function() {
								return null;
							}
						}
					};
					modalService.showModal(tempModalDefaults, modalOptions);
				}
				
				/**
				* @method  - getRules
				* @return - ruleList
				*/
				function getRules() {
					var omdRules = getBulkOmdRules.getOmdRules();
					omdRules.$promise.then(function(result){
						if(result.length) {
							vm.triggerOMDListModal(result);
						} else if(!(result.length)) {
							showAlert($translate.instant('_Get_OMDRules_Failure'),'danger');
						}
					},function(error) {
						showAlert($translate.instant('_Get_OMDRules_Failure'),'danger');
					});
				}
				
				//Method captures selected rule and redirects state to create mapping
				$scope.$on('SELECTED_RULE',  function(evt, arg){
					if(arg.rules){
						vm.newMappingRule = arg.rules;
						$state.go('wsa.createMapping', { cbmRule:arg.rules,cbmMapping:null, configTabName:$scope.radioModel});
					}
				});
				
				//Method to toggle mapping state
				function  toggleMapping(mappingId, isActive) {
					var isActivated = isActive !== "Y" ? "Y" : "N";
					var updateObj = {
						mappingId: mappingId,
						active: isActivated
					}
					var updateCBMMapping = updateCBMMappingDetail.updateCBMMap(updateObj);
					updateCBMMapping.$promise.then(function(result) {
						vm.resolveUpdateCBMMapping(result,mappingId);
					}, function(error){
						showAlert($translate.instant('_Change_MappingState_Failure'),'danger');
					});
				}
				
				function resolveUpdateCBMMapping(result,mappingId) {
					if (result.status.statusCode === 'SUCCESS') {
						var mappinglength = vm.mappings.length;
						for(var index = 0;index<mappinglength;index++) {
							if(vm.mappings[index].mappingId == mappingId) {
								vm.mappings[index].active == "Y" ? vm.mappings[index].active = "N" : vm.mappings[index].active = "Y";
								break;
							}
						}
						loadDefaultMappings();
						showAlert($translate.instant('_Change_MappingState_Success'),'success');
					} else {
						showAlert($translate.instant('_Change_MappingState_Failure'),'danger');
					}
				}

				//Method to sort mapping table columns on column header click
				function sortMappingCols(predicate,subPredicate) {
					if(tableScrollElem) {
						tableScrollElem.scrollTop = 0;
					} else {
						tableScrollElem = document.getElementById('table-body-scroll');
						tableScrollElem.scrollTop = 0;
					}
					vm.isSortReverse = (predicate !== null && vm.sortType[0] === predicate) ? !vm.isSortReverse : false;
					vm.sortType = [predicate];
					vm.subSorttype = subPredicate ? subPredicate : null;
					loadDefaultMappings();
				}
				
				function filterMappings(searchString) {
					if(tableScrollElem) {
						tableScrollElem.scrollTop = 0;
					} else {
						tableScrollElem = document.getElementById('table-body-scroll');
						tableScrollElem.scrollTop = 0;
					}
					var searchObj = {
						"action.actionName":searchString,
						"ruleId":searchString,
						"event":searchString,
						"element.elementName":searchString,
						"qualityPlan.qpName":searchString,
						"serviceItem.serviceItemName":searchString,
						"cbmOrgs.orgName": searchString,
						"webserviceValue": searchString,
						"defaultInterval.serviceProgramDetail.programName": searchString
					};
					
					vm.filteredMappings = $filter('propsFilter')(vm.mappings, searchObj);
					loadDefaultMappings();
				}
				//Method to call a service to get selected lovs.
				function showSelectedTaskLovs(mapping) {
					var getLovs = getLovsForTask.getLovs({
						locale: $scope.languageCode,
						taskNumber: mapping.element.elementName
					});
					getLovs.$promise.then(function(result) {
						vm.resolveSelectedTaskLovs(result,mapping);
					},function(error){
						showAlert($translate.instant("_Get_Lovs_Failure"),"danger");
					});
				}
				
				function resolveSelectedTaskLovs(result,mapping) {
					vm.mapping = mapping;
					vm.lovList = utilsService.convertLovEntryTypesIntoCustomerLovEntries(result,mapping.lovIds);
					vm.drawerTemplate = 'assets/html/partials/lovsReadOnly.drawer.partial.html';
					vm.isOpenDrawer = !vm.isOpenDrawer;
				}
				vm.closeAlert = function() {
					vm.alert.visible = false;
				}

				function showAlert(alertMessage,alertType) {
					vm.alert.visible = true;
					vm.alert.msg = alertMessage;
					vm.alert.type =  alertType;
				}

				function clearSearch() {
					vm.searchMapping = "";
					vm.filterMappings(vm.searchMapping);
				}

				function editMapping(mapping) {
					var rules = [];
					var rule = {"ruleId":mapping.ruleId,"ruleTitle":mapping.event};
					rules.push(rule);
					$state.go('wsa.createMapping', { cbmRule:rules,cbmMapping:mapping, configTabName: $scope.radioModel});
				}

				function confirmDeleteMapping(evt,mapping) {
					if(evt) evt.preventDefault();
					var modalOptions = {
						closeButtonText: $translate.instant('_No'),
						headerText: $translate.instant('_Delete_Mapping'),
						bodyText: $translate.instant('_Delete_Confirm_Message'),
						actionButtonText: $translate.instant('_Yes')
					};
					modalService.showModal({windowTopClass : "confirm-modal"}, modalOptions).then(function (result) {
						if(result){
							vm.deleteMapping(mapping);
						}
					});
				}
				
				function deleteMapping(mapping) {
					var mappingIds = [];
					mappingIds.push(mapping.mappingId);
					var deleteObj = {
						mappingIds: mappingIds
					}
					var deleteCBMMapping = deleteCBMMappingDetail.deleteCBMMap(deleteObj);
					deleteCBMMapping.$promise.then(function(result) {
						vm.resolveDeleteCBMMapping(result,mapping);
					}, function(error){
						showAlert($translate.instant('_Delete_Mapping_Failure'),'danger');
					});
				}
				function resolveDeleteCBMMapping (result,mapping) {
					if (result.status.statusCode === 'SUCCESS') {
						var mappinglength = vm.mappings.length;
						for(var index = 0;index<mappinglength;index++) {
							if(vm.mappings[index].mappingId == mapping.mappingId) {
								vm.mappings.splice(index,1);
								break;
							}
						}
						if(vm.searchMapping) {
							var len = vm.filteredMappings.length;
							for(var index = 0;index<len;index++) {
								if(vm.filteredMappings[index].mappingId == mapping.mappingId) {
									vm.filteredMappings.splice(index,1);
									break;
								}
							}
						}
						loadDefaultMappings();
						vm.setTableHeight();
						showAlert($translate.instant('_Delete_Mapping_Success'),'success');
					} else {
						showAlert($translate.instant('_Delete_Mapping_Failure'),'danger');
					}
				}
				
				function setTableHeight() {
					$timeout(function(){
						vm.tableHeight = $('#table-body-scroll table').height();
					});
				}

				$scope.filterMappings = function(record) {
					if (record.action.actionId === vm.mappingTabId) {
						return true;
					}
				};
	}]);
});