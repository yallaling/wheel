define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('omdListCtrl', [
	       '$scope',
	       '$rootScope',
	       '$state',
	       '$http',
		   '$filter',
		   'lodash',
	       '$timeout',
	       '$translate',
		   'orderByFilter',
		   '$uibModalInstance',
		   'omdList',
		   'selCbmRuleIds',function ($scope, $rootScope, $state, $http, $filter,lodash,$timeout, $translate,orderBy,$uibModalInstance,omdList,selCbmRuleIds){
	    	    var vm = this;
	    	    vm.rules = omdList;
	    	    vm.defaultSort = ['ruleId'];
				
			    vm.cancel 					= cancel;
				vm.setInitialList 			= setInitialList;
			    vm.selectRuleForMapping 	= selectRuleForMapping;
				vm.selectOmdRule 			= selectOmdRule;
				vm.sortRuleCols     		= sortRuleCols;
				vm.filterRules 				= filterRules;
				vm.clearSearch				= clearSearch;
			   
				vm.setInitialList();
				
				// Get initial omd rules list and sort it
				function setInitialList() {
					vm.sortType = vm.defaultSort;
					vm.isSortReverse = false;
					loadDefaultRules();
					var rulesLength = vm.rules.length;
					if(selCbmRuleIds !== null && selCbmRuleIds !== undefined) {
						for(var i = 0; i < rulesLength; i++){
							if(selCbmRuleIds.indexOf(vm.rules[i].ruleId) !== -1){
								vm.rules[i].selected = true;
							}
						}	
					}
					vm.selectedRules = $filter("filter")(vm.filteredRules, {selected: true});
				}
				
				//dismiss modal
			    function cancel() {
					$uibModalInstance.dismiss('cancel');
				};
				
				//callback method after modal is rendered
				$uibModalInstance.rendered.then(function () {
					vm.tableScrollElem = document.getElementById('table-body-scroll');
				});
				
				//capture selected rules.
				function selectRuleForMapping(rule) {
					rule.selected ? rule.selected = false : rule.selected = true;
					vm.selectedRules = $filter("filter")(vm.filteredRules, {selected: true});
				}
				
				//save selected rules and close modal.
				function selectOmdRule() {
					if(vm.selectedRules) {
						$rootScope.$broadcast('SELECTED_RULE', {rules: vm.selectedRules});
						$uibModalInstance.dismiss('cancel');
					}			
				}

				//sort rule table columns on click of column header
				function sortRuleCols(predicate) {
					vm.tableScrollElem.scrollTop = 0;
					vm.isSortReverse = (predicate !== null && vm.sortType[0] === predicate) ? !vm.isSortReverse : false;
					vm.sortType = [predicate];
					loadDefaultRules();
				}
				//filter omd rules based on search string
				function filterRules(searchString) {
					vm.tableScrollElem.scrollTop = 0;
					var searchObj = {
						ruleId:searchString,
						ruleTitle:searchString,
						ruleType:searchString,
						family:searchString
					};			
					vm.filteredRules = $filter('propsFilter')(vm.rules, searchObj);
					loadDefaultRules();
				}
				
				function loadDefaultRules() {
					var sortDir = 'asc';
					vm.isSortReverse ? sortDir = 'desc' : sortDir = 'asc' ;
					var list = vm.searchRule ? vm.filteredRules : vm.rules;
					vm.filteredRules = lodash.orderBy(list, function(rule) {
						if(rule[vm.sortType] && typeof rule[vm.sortType] == 'string') {
							return rule[vm.sortType].toLowerCase();
						} else {
							return rule[vm.sortType];
						}
					},[sortDir]);
				}
				function clearSearch() {
					vm.searchRule = "";
					vm.filterRules(vm.searchRule);
				}
	}]);
});