define(['angular', 'javascripts/app/controllers'], function (angular, controllers) {
	'use strict';
	controllers.controller('mainAppCtrl', [
	   '$scope',
	   '$rootScope',
	   '$state',
	   '$http',
	   '$timeout',
	   '$translate',
	   'utilsService',
	   'sessionState',function ($scope, $rootScope, $state, $http, $timeout,$translate,utilsService,sessionState){
			$scope.locale = sessionState.data.languageCode;//change locale to languageCode to fix localization
			$scope.user_id = sessionState.data.user_id;
			$scope.session_id = sessionState.data.sesid;
			$scope.menu_id = sessionState.data.menuid;
			$scope.clientUrl = sessionState.data.esvonebaseurl;
			$scope.organizationLevelId = sessionState.data.organizationLevelId;
			$scope.languageCode = sessionState.data.languageCode;
			$scope.sessionData = sessionState.data;

			//Set the translation
			if($scope.locale === 'FRN') $scope.locale = 'FRA';
			$translate.use($scope.locale);

			$scope.$on('IdleTimeout', function() {
				utilsService.post(''+$scope.clientUrl+"logout.jsp");
			});

			//Find the parent Div
		    function findDiv(str) {
				if (window.parent.document.getElementById(str) && window.parent.document.getElementById(str) !== null) {
					return $('#' + str, window.parent.document);
				} else {
					if (window.parent.parent.document.getElementById(str) && window.parent.parent.document.getElementById(str) !== null) {
						return $('#' + str, window.parent.parent.document);
					} else {
						if (window.parent.parent.parent.document.getElementById(str) && window.parent.parent.parent.document.getElementById(str) !== null) {
							return $('#' + str, window.parent.parent.parent.document);
						} else {
							if (window.parent.parent.parent.parent.document.getElementById(str) && window.parent.parent.parent.parent.document.getElementById(str) !== null) {
								return $('#' + str, window.parent.parent.parent.parent.document);
							} else {
								if (window.parent.parent.parent.parent.parent.document.getElementById(str) && window.parent.parent.parent.parent.parent.document.getElementById(str) !== null) {
									return $('#' + str, window.parent.parent.parent.parent.document);
								} else {
									return null;
								}
							}
						}
					}
				}
			}
			//Change The background Color
			function changeBgColor(colorStr) {
				var $aa = findDiv('aa');
				if ($aa && $aa !== null) {
					$aa.attr('style', 'background-color: ' + colorStr);
					var $rc = $aa.find('#railConnect');
					$rc.children('table').attr('style', 'background-color: #fff;');
				}
			}

			changeBgColor('#d4d4d4');	
	}]);
});