/**
 * The Utilities Module should be used for functions that DON'T rely on
 * state.
 *
 * The methods declared and implemented here should be idempotent and
 * should be placed here if they would be useful for multiple controllers
 * or modules.
 */
define(['angular', 'javascripts/app/services'], function(angular, services){
	'use strict';
	services.factory('utilsService', function() {
		var post = function(path, params, method) {
			method = method || "post"; // Set method to post by default if not specified.

			var form = document.createElement("form");
			form.setAttribute("method", method);
			form.setAttribute("action", path);

			for(var key in params) {
				if(params.hasOwnProperty(key)) {
					var hiddenField = document.createElement("input");
					hiddenField.setAttribute("type", "hidden");
					hiddenField.setAttribute("name", key);
					hiddenField.setAttribute("value", params[key]);
					form.appendChild(hiddenField);
				 }
			}
			window.top.document.body.appendChild(form);
			form.submit();
		}
		
		function normalizeMixedDataValue( value ) {
			var padding = "000000000000000";
			var val = (value == null ? "" : value);
			val = val.replace(
				/(\d+)((\.\d+)+)?/g,
				function( $0, integer, decimal, $3 ) {
					if ( decimal !== $3 ) {
						return(
							padding.slice( integer.length ) +
							integer +
							decimal
						);
					}
					decimal = ( decimal || ".0" );
					return(
						padding.slice( integer.length ) +
						integer +
						decimal +
						padding.slice( decimal.length )
					);
				}
			);
			return(val);
	  	} 
		function alphaNumericSort(a, b) {
			var aMixed, bMixed;
  			aMixed = normalizeMixedDataValue( a.value );
  			bMixed = normalizeMixedDataValue( b.value );
  			return( aMixed < bMixed ? -1 : 1 );
	    }
		function getCustomerIndex(customerList,customerId) {
			if(customerList.length) {
				var len = customerList.length;
				for(var i=0;i<len;i++) {
					if(customerList[i].customerId == customerId) {
						return i;
						break;
					}
				}
				return -1;
			} else {
				return -1;
			}
		}
		function convertLovEntryTypesIntoCustomerLovEntries(lovList,selectedlovList) {
			var lovListLength = lovList.length;
			var customerLovEntries = [];
			customerLovEntries.Lov = [];
			var custLovEntry;
			for(var i=0;i<lovListLength;i++) {
				var customerName = lovList[i].customer;
				var customerId = lovList[i].customerId;
				var custObj = {};
				custObj.customer = customerName;
				custObj.customerId = customerId;
				var lovEntry = {};
				lovEntry.id = lovList[i].lovId;
				lovEntry.value = lovList[i].value;
				lovEntry.isDefect = lovList[i].hasDefect;
				lovEntry.sortSequence = lovList[i].sortSequence;
				lovEntry.lookupType = lovList[i].lookupType;
				lovEntry.lookupTypeId = lovList[i].lookupTypeId;
				lovEntry.description = {};
				for(var descIndex =0; descIndex<lovList[i].descriptions.length; descIndex++) {
					var key = lovList[i].descriptions[descIndex].locale;
					lovEntry.description[key] = lovList[i].descriptions[descIndex].description; 
				}
				var custIndex = getCustomerIndex(customerLovEntries,custObj.customerId);
				if(custIndex == -1) {
					custObj.Lov = []
					custObj.Lov.push(lovEntry);
					if(selectedlovList && selectedlovList.indexOf(lovEntry.id) !== -1) {
						custObj.selectedLovId = lovEntry.id;
					}
					customerLovEntries.push(custObj);
				} else {
					if(selectedlovList && selectedlovList.indexOf(lovEntry.id) !== -1) {
						customerLovEntries[custIndex].selectedLovId = lovEntry.id;
					}
					customerLovEntries[custIndex].Lov.push(lovEntry)
				}
			}
			var len = customerLovEntries.length;
			for(var i=0;i<len;i++) {
				customerLovEntries[i].Lov.sort(function(a, b){
					var keyA = a.sortSequence,
						keyB = b.sortSequence;
					// Compare the 2 dates
					if(keyA < keyB) return -1;
					if(keyA > keyB) return 1;
					return 0;
				});
			}
			return customerLovEntries;
		}

		return {
			alphaNumericSort: alphaNumericSort,
			post: post,
			convertLovEntryTypesIntoCustomerLovEntries: convertLovEntryTypesIntoCustomerLovEntries
		};
	});
});