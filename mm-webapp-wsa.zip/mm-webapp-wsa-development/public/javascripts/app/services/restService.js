/**
 * Just a little reminder for those calling these methods:
 *      HTTP GET "class" actions: Resource.action([parameters], [success], [error])
 *       non-GET "class" actions: Resource.action([parameters], postData, [success], [error])
 */
angular.module('wsaRestModule', ['ngResource'])
.factory('getCBMMappingDetailService', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCBMMappingDetails', {languageId:'@languageId'});
    }
])
.factory('getPlaySession', [
	'$http',
	'$q',
	'$resource',
	function ($http, $q) {
		return {
			getSession: function () {
				var deferred = $q.defer();
				$http.get('getUserSession').success(function (data, status, header, config) {
					var result = {
						data: data,
						status: status,
						header: header,
						config: config
					};
					deferred.resolve(result);
				}).error(function (data, status, header, config) {
					var result = {
						data: data,
						status: status,
						header: header,
						config: config
					};
					if (result.status === 302) {
						//return to login page
						top.location(result.header.location);
						return;
					}
					deferred.reject(result);
				});
				return deferred.promise;
			}
		};
	}
])
.factory('getBulkOmdRules', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getOmdRules',{}, {
			getOmdRules: {
				method: 'GET',
				isArray: true
			}
		});
    }
])
.factory('updateCBMMappingDetailService', [
	'$http',
	'$resource',
	function ($http, $resource) {
		var updateCBMMappingResource = $resource('updateCBMMapping');
		var updateCBMMappingDetails = {
			updateCBMMap: function (data){
				return updateCBMMappingResource.save({}, data, function(data,headers) {
				  return data;
				},function(response) {
				  return response;
				});
			}
		};
		return updateCBMMappingDetails;
	}
])
.factory('getAllCbmActions', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCBMActions', {languageId:'@languageId'});
    }
])
.factory('getCBMQPForTask', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCBMQPForTask', {languageId:'@languageId', taskId: '@taskId'});
    }
])
.factory('getCBMOrgsForQP', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCBMOrgsForQP', {languageId:'@languageId', qpIds: '@qpIds'});
    }
])
.factory('getAllOrgs', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getAllOrgs', {});
    }
])
.factory('getLovsForTask', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getLovForTask', {locale:'@locale', taskNumber: '@taskNumber'},{
			getLovs: {
				method: 'GET',
				isArray: true
			}
		});
    }
])
.factory('getCBMTaskSearch', [
    '$http',
    '$resource',
	function ($http, $resource) {
		return $resource('getCBMElementTaskSearch',{},{
			SearchCBMTasks: {
				method: 'POST',
				isArray: false 
			}
		});
	}
])
.factory('getCBMServiceItemSearch', [
    '$http',
    '$resource',
	function ($http, $resource) {
		return $resource('getCBMServiceItemSearch',{},{
			SearchCBMServiceItem: {
				method: 'POST',
				isArray: false 
			}
		});
	}
])
.factory('createMappingService', [
    '$http',
    '$resource',
	function ($http, $resource) {
		return $resource('createMapping',{},{
			createMapping: {
				method: 'POST',
				isArray: false 
			}
		});
	}
])
.factory('getCBMServiceProgramSearch', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCBMElementSPSearch', {},{
			searchCBMServiceProgram: {
				method:'POST'
			}
		});
    }
])
.factory('deleteCBMMappingDetailService', [
    '$http',
    '$resource',
    function ($http, $resource) {
	    var deleteCBMMappingResource = $resource('deleteCBMMapping');
        var deleteCBMMappingDetails = {
            deleteCBMMap: function (data){
				return deleteCBMMappingResource.save({}, data, function(data,headers) {
					return data;
				},function(response) {
					return response;
				});
			}
		};
		return deleteCBMMappingDetails;
	}
])
.factory('getAllCustomers', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getAllCustomers', {});
    }
])
.factory('getCustomersByProgramId', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getCustomersByProgramId', {serviceProgramId:'@serviceProgramId'});
    }
])
.factory('fleetsByCustomerAndProgramIdService', [
    '$resource',
    function ($resource) {
	    var fleetsByCustomerResource = $resource('fleetsByCustomerAndProgramId');
        var fleetsByCustomerDetails = {
            fleetsMap: function (data){
				return fleetsByCustomerResource.save({}, data, function(data) {
					return data;
				},function(response) {
					return response;
				});
			}
		};
		return fleetsByCustomerDetails;
	}
])
.factory('getFrequencySchedulerService', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getFrequencyScheduler', {languageId:'@languageId'});
    }
])
.factory('getConfigDetails', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getConfigDetails', {});
    }
])
.factory('getServiceProgramDetailsByIdService', [
    '$http',
    '$resource',
    function ($http, $resource) {
        return $resource('getServiceProgramDetailsById', {serviceProgramId:'@serviceProgramId'});
    }
])
.factory('getCbmRuleValuesService', [
    '$http',
    '$resource',
    function ($http, $resource) {
		return $resource('getCbmRuleValues', {});
    }
]);
