angular.module('spinnerModule', ['ngResource']).config([
    '$provide',
    '$httpProvider',
    function ($provide, $httpProvider) {
        // Intercept http calls.
        $provide.factory('spinnerHttpInterceptor',['$rootScope','$q',function ($rootScope, $q) {
            /*
             * Always use objects when communicating between scopes.
             * Vals are pass by value, but Objects are pass by reference.
             */
            $rootScope.spinnerModule = { isSpinning: 0 };
            return {
                request: function (config) {
                    $rootScope.spinnerModule.isSpinning++;
                    // Return the config or wrap it in a promise if blank.
                    return config || $q.when(config);
                },
                requestError: function (rejection) {
                    // Contains the data about the error on the request.
                    $rootScope.spinnerModule.isSpinning--;
                    // Return the promise rejection.
                    return $q.reject(rejection);
                },
                response: function (response) {
                    $rootScope.spinnerModule.isSpinning--;
                    // Return the response or promise.
                    return response || $q.when(response);
                },
                responseError: function (rejection) {
                    // Contains the data about the error.
                    $rootScope.spinnerModule.isSpinning--;
                    // Return the promise rejection.
                    return $q.reject(rejection);
                }
            };
        }]);
        // Add the interceptor to the $httpProvider.
        $httpProvider.interceptors.push('spinnerHttpInterceptor');
    }
]);