'use strict';
define(['angular'], function() {
    return angular.module('mm-webapp-wsa.services', []);
});