'use strict';
define(['angular'], function(angular){
    return angular.module('mm-webapp-wsa.controllers', []);
});