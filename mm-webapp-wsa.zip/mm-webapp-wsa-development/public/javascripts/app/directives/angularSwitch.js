require(['angular', 'javascripts/app/directives'], function (angular, directives){
	'use strict';
	directives.directive('switch', function(){
	  return {
	    restrict: 'AE',
	    replace: true,
	    transclude: true,
	    template: function(element, attrs) {
	      var html = '';
	      html += '<span';
	      html +=   ' class="switch' + (attrs.class ? ' ' + attrs.class : '') + '"';
	      html +=   ' ng-class="{ checked:' + attrs.ngActive + ', disabled:' + attrs.ngDisabled + ' }"';
	      html +=   '>';
	      html +=   '<small></small>';
	      html +=   '<input type="checkbox"';
	      html +=     attrs.id ? ' id="' + attrs.id + '"' : '';
	      html +=     attrs.name ? ' name="' + attrs.name + '"' : '';
	      html +=     attrs.ngModel ? ' ng-model="' + attrs.ngModel + '"' : '';
	      html +=     ' style="display:none" />';
	      html +=     '<span class="switch-text">'; /*adding new container for switch text*/
	      html +=     attrs.on ? '<span class="on">'+attrs.on+'</span>' : ''; /*switch text on value set by user in directive html markup*/
	      html +=     attrs.off ? '<span class="off">'+attrs.off + '</span>' : ' ';  /*switch text off value set by user in directive html markup*/
	      html += '</span>';
	      return html;
	    }
	  }
	});
});
require(['angular', 'javascripts/app/directives'], function (angular, directives){
	'use strict';
	directives.directive('ngDropdownMultiselectDisabled', function(){
	  return {
	    restrict: 'A',
	    controller: ['$scope','$element','$attrs', '$timeout', function($scope, $element, $attrs, $timeout) {
		  var $btn;
		  $btn = $element.find('button');
		  return $scope.$watch($attrs.ngDropdownMultiselectDisabled, function(newVal) {
			$timeout(function(){
				return $btn.attr('disabled', newVal);
			},100);
		  });
		}]
	  }
	});
});