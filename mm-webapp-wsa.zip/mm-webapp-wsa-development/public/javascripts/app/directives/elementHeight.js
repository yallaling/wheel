require(['angular', 'javascripts/app/directives'], function (angular, directives){
	'use strict';
	directives.directive('elementHeight', ['$window', '$timeout', '$rootScope', function($window, $timeout, $rootScope) {
		return {
			restrict: 'A',
			scope:{
				data: '@dtData',
				dtHeight: '=dtHeight',
				search: '=filterSearch'
			},
			link: function(scope, elem, attrs) {
				var headerHeight, elmHeight, iFrameHeight, contentHeight, winHeight, remainHeight, isIFrameID,isModal;
				scope.destorywatch = scope.$watchCollection('data', function(nv, ov){
					$timeout(function(){ //Wait for DOM to load completely
						isIFrameID = $window.top.document.getElementById('content');
						isModal = elem.closest(".modal-dialog");
						headerHeight = attrs.contentHeight ? attrs.contentHeight : 0;
						elmHeight = elem.height();
						if(isModal.length) {
							remainHeight = elmHeight;
							contentHeight = elem.children("table").height();
							setScrollHeight(elem,contentHeight,remainHeight);
							if(!isUseragent()){
								setHeaderPadding(elem,contentHeight,remainHeight);
							}
						} else if(!isIFrameID){
							winHeight = $window.innerHeight;
							remainHeight = winHeight - headerHeight;
							setScrollHeight(elem, elmHeight, remainHeight);
							if(!isUseragent()){
								setHeaderPadding(elem, elmHeight, remainHeight);
							}
						}else{
							iFrameHeight = $window.top.document.body.clientHeight;
							remainHeight = iFrameHeight - headerHeight;
							setScrollHeight(elem, elmHeight, remainHeight);
							if(!isUseragent()){
								setHeaderPadding(elem, elmHeight, remainHeight);
							}
							$timeout(function(){
								if($(".main-container").height()) {
									isIFrameID.style.height = $(".main-container").height();
								}
							});
						}
					});
				});
				scope.$on('$destory', function(){
					scope.destorywatch();
				});
				function setScrollHeight(elm, elmHeight, contentHeight) {
					if(elmHeight < contentHeight){
						elm.css('height', 'auto');
					}else{
						elm.css('height', contentHeight);
					}
				}
				
				function setHeaderPadding(elm, elmHeight, contentHeight) {
					if(elmHeight < contentHeight){
						elm.parents('.module-body').find('#fixedHeader').css('padding-right', '0px');
					}else{
						elm.parents('.module-body').find('#fixedHeader').css('padding-right', '17px');
					}
				}
				scope.$watch('search', function(newVal, oldVal) {
					if(newVal == oldVal) return;	
					setFilterDtHeight();
				});
				scope.$watch('dtHeight',function (newValue, oldValue) {
					if (newValue != oldValue) {
						setFilterDtHeight();
					}
				});
				function setFilterDtHeight() {
					$timeout(function(){
						if(iFrameHeight){
							isIFrameID.style.height = iFrameHeight;
						}
						if(isModal && isModal.length) {
							var tableHeight = elem.find('table').height();
							setScrollHeight(elem,tableHeight,remainHeight);
							
							if(!isUseragent()){
								setHeaderPadding(elem,tableHeight,remainHeight);
							}
						} else {
							var tableHeight = elem.find('table').height();
							setScrollHeight(elem, tableHeight, remainHeight);
							
							if(!isUseragent()){
								setHeaderPadding(elem, tableHeight, remainHeight);
							}
						}
					},1);
				}
				
				$(elem).scroll(function(){
				    if(this.scrollHeight - this.scrollTop === this.clientHeight) {
				    	scope.$apply(function(){
				    		$rootScope.$broadcast('SCOLL_BOTTOM');
				    	});
				    }
				  });
				
				function isUseragent() {
					if((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPad/i))) {
						return true;
					}
					return false;
				}				
			}
		};
	}]);
});