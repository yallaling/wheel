'use strict';
require(['angular', 'spinner', 'javascripts/app/directives'], function (angular, Spinner, directives){
	directives.directive('spinner',['$window',function ($window) {
        var spinnerOpts = {
            lines: 12,
            length: 20,
            width: 8,
            radius: 20,
            corners: 0.5,
            rotate: 0,
            direction: 1,
            color: '#3b73b9',
            speed: 1,
            trail: 64,
            shadow: true,
            hwaccel: false,
            className: 'spinner',
            zIndex: 2000000000,
            top: 'auto',
            left: 'auto'
        };
        //Create a div to show blurred background while spinner is spinning
        var parentBody = parent.document.body;
        var parentDocument = parent.document;
        var newdiv = parentDocument.createElement('DIV');
        newdiv.style.backgroundColor = '#000000';
        newdiv.style.opacity = 0.6;
        newdiv.style.width = '100%';
        newdiv.style.height = '100%';
        newdiv.style.position = 'fixed';
        newdiv.style.top = '0px';
        newdiv.style.left = '0px';
        newdiv.classList.add('loadingShadow');

        function getElementHeight(element) {
            var height = element.css('height').replace(/[^-\d\.]/g, '');
            var padTop = element.css('padding-top').replace(/[^-\d\.]/g, '');
            var padBottom = element.css('padding-bottom').replace(/[^-\d\.]/g, '');
            var calcHeight = height - padTop - padBottom;
            return calcHeight;
        }

        function getElementWidth(element) {
            var width = element.css('width').replace(/[^-\d\.]/g, '');
            var padLeft = element.css('padding-left').replace(/[^-\d\.]/g, '');
            var padRight = element.css('padding-right').replace(/[^-\d\.]/g, '');
            var calcWidth = width - padLeft - padRight;
            return calcWidth;
        }

        function handleSnapping(element) {
            var headerHeight = 143;
            var scrollTop = parent.window.scrollY;
            //            var scrollHeight = document.body.scrollHeight;
            var windowHeight = parent.window.innerHeight;
            //            var cssHeight = element.css('height');
            //            var scrollWidth = document.body.scrollWidth;
            var windowWidth = parent.window.innerWidth;
            var centerY = windowHeight / 2 - getElementHeight(element) / 2 + scrollTop - headerHeight;
            var centerX = windowWidth / 2 - getElementWidth(element) / 2;
            element.css({
                position: 'fixed',
                'z-index': 2000000000,
                top: centerY + 'px',
                left: centerX + 'px'
            });
        }

        function bindEvents(element) {
            angular.element($window).bind('scroll', function () {
                handleSnapping(element);
            });
            angular.element($window).bind('resize', function () {
                handleSnapping(element);
            });
        }

        return {
            restrict: 'E',
            replace: 'true',
            scope: { elementId: '@' },
            template: '<div id="wo-spinner"><div ng-show="false"><button class="btn btn-primary" ng-click="onStartSpinner()">START</button><button class="btn btn-primary" ng-click="onStopSpinner()">STOP</button></div></div>',
            link: function (scope, element) {

                bindEvents(element);
                handleSnapping(element);
                scope.spinner = new Spinner(spinnerOpts);
                scope.$watch('$root.spinnerModule.isSpinning', function (newVal) {
                    handleSnapping(element);
                    if (newVal > 0) {
                        scope.onStartSpinner();
                    } else {
                        scope.onStopSpinner();
                    }
                });
                scope.onStartSpinner = function () {
                    var target = document.getElementById('wo-spinner');
                    scope.spinner.spin(target);
                    parentBody.appendChild(newdiv);
                    parentBody.style.overflow = 'hidden';
                };
                scope.onStopSpinner = function () {
                    if (parentBody.getElementsByClassName('loadingShadow').length > 0) {
                        parentBody.removeChild(newdiv);
                    }
                    parentBody.style.overflow = 'visible';
                    scope.spinner.stop();
                };
            }
        };
    }]);
});