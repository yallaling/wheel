'use strict';
define([
	"jquery",
	"angular",
	"angular-resource",
	"angular-ui-router",
	"angular-bootstrap",
	"translate",
	"translate-loader",
	"angular-sanitize",
	"angular-lodash",
	"spinnerModules",
	"wsaRestModule",
	"ng-idle",
	"datatables",
	"pageSlide",
	"pagination",
	"angularjs-dropdown-multiselect",
	//"html2js",'templates-min',
	"javascripts/app/directives",
	"javascripts/app/controllers",
	"javascripts/app/services",
	"javascripts/app/filters"
], function(){
	"use strict";

	var app = angular.module('mm-webapp-wsa', ['ngResource',"ui.router", 'ui.bootstrap','pascalprecht.translate','ngSanitize','spinnerModule','wsaRestModule','ngIdle', 'pageslide-directive','angularUtils.directives.dirPagination','angularjs-dropdown-multiselect','mm-webapp-wsa.directives','mm-webapp-wsa.controllers','mm-webapp-wsa.services','mm-webapp-wsa.filters']);

	app.config(['$stateProvider', '$urlRouterProvider', '$httpProvider', '$locationProvider', '$translateProvider', '$translatePartialLoaderProvider','IdleProvider',function ($stateProvider, $urlRouterProvider, $httpProvider, $locationProvider, $translateProvider, $translatePartialLoaderProvider,IdleProvider) {
		 $translateProvider.useLoader('$translatePartialLoader', {
			 urlTemplate: 'assets/translations/{lang}/{part}.json'
		 });

		$translateProvider.fallbackLanguage('ENG');
		$translateProvider.preferredLanguage('ENG');
		$translateProvider.useSanitizeValueStrategy('escape');

		$httpProvider.defaults.headers.common['Accept'] = 'application/json';
		$httpProvider.defaults.headers.common['Content-Type'] = 'application/json';

		//TO-DO: configure session timeout
		IdleProvider.idle(30*60); //session timeout in 30 min

		$urlRouterProvider.otherwise('/mappinglist');
		$stateProvider
			.state('wsa', {
				url: '',
				abstract: true,
				views: {
					"":{
						templateUrl: 'assets/html/page/main.html',
						controller: 'mainAppCtrl',
						resolve: {
							locales: ['$translatePartialLoader', '$translate',function($translatePartialLoader, $translate) {
								$translatePartialLoader.addPart('localization');
								return $translate.refresh();
							}],
							localParams:['$location',function($location){
								return $location.search();
							}],
							sessionState:['getPlaySession',function (getPlaySession) {
								return getPlaySession.getSession().then(function(result) {
									return result;
								});
							}]
						}
					},
					'header@wsa': { templateUrl: 'assets/html/partials/header.html'}
				}
				
			})
			.state('wsa.mappings', {
				url: '/mappinglist',
				templateUrl: 'assets/html/page/mappingScreen.html',
				controller: 'mappingScreenCtrl',
				controllerAs: 'mappingCtrl'
			})
			.state('wsa.createMapping', {
				url: '/createmapping',
				templateUrl: 'assets/html/page/createMapping.html',
				controller: 'createMappingScreenCtrl',
				controllerAs: 'cmCtrl',
				params: {
				    cbmRule: null,
					cbmMapping: null,
					configTabName: null
				}
			});
		// Enable cross domain calls
		$httpProvider.defaults.useXDomain = true;
		$httpProvider.defaults.withCredentials = true;    
		delete $httpProvider.defaults.headers.common['X-Requested-With'];
	}])
	.run(['Idle',function(Idle){
		Idle.watch();
	}]);
	app.factory('lodash', ['$window',  function($window) {
        return $window._;
	}]);
	return app;
});