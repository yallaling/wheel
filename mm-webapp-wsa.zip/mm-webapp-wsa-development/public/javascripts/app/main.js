define([
	"javascripts/app/app",
	"javascripts/app/controllers/mainAppCtrl",
	"javascripts/app/controllers/mappingScreenCtrl",
	"javascripts/app/controllers/omdListCtrl",
	"javascripts/app/controllers/createMappingScreenCtrl",
	"javascripts/app/controllers/taskListCtrl",
	"javascripts/app/controllers/serviceItemListCtrl",
	"javascripts/app/controllers/serviceProgramListCtrl",
	"javascripts/app/directives/elementHeight",
	"javascripts/app/directives/spinner",
	"javascripts/app/directives/angularSwitch",
	"javascripts/app/services/modalService",
	"javascripts/app/filters/propsFilter",
	"javascripts/app/services/utils",
	'javascripts/app/controllers/configModalCtrl'
	], function(app){
	return app;
});