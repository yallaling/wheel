# Creating Reactive Forms in Angular

Reactive forms in angular provides a way to achive model-driven approach to handling form inputs whose values change over time. In this guide we will learn about how to create and update a simple form control and how to progress using multiple controls in a group, validate form values, and implement more advanced forms.

## Introduction

Reactive Forms are useful in managing the state of the form at any given point in time since reactive forms are explcit and immutable. Each change to the form state returns a new state, which maintains the integrity of the model between changes. Reactive forms are built around observable streams, where form inputs and values are provided as streams of input values, which can be accessed synchronously.

## Building The Reactive Form Application

In this section we will see how to build an form application using the Reactive Forms in Angular. To use reactive forms we need to import ReactiveFormsModule from the @angular/forms package and add it to your NgModule's imports array. To register a single form control, import the FormControl class into your component and create a new instance of the form control to save as a class property.

File name: employee-editor.component.ts

```typescript
import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-employee-editor',
  templateUrl: './employee-editor.component.html',
  styleUrls: ['./employee-editor.component.css']
})
export class EmployeeEditorComponent {
  employee = new FormControl('');
}
```

Here we are using the constructor of FormControl to set its intial value. After creating the control in the component class, then we need to update the template with the form control using the formControl binding provided by FormControlDirective included in ReactiveFormModule.

File name: employee-editor.component.html

```html
<label>
  Employee:
  <input type="text" [formControl]="employee">
</label>
```

The form control assigned to name is displayed when the component is added to a template.

File name: app.component.html

```typescript
<app-employee-editor></app-employee-editor>
```

## Managing Reactive Form Control Values

We can manipulate the current state and value through the component class or the component template. The following examples display the value of the form control instance and how we can change it. Using the valueChanges observable you can listen for changes in the form's value in the template using AsyncPipe or in the component class using the subscribe() method.
With the value property. which gives you a snapshot of the current value we can display the value.

File name: employee-editor.component.html

```html
<p>
  Value: {{ employeeName.value }}
</p>
```

The displayed value changes as you update the form control element.

We can change the control's value in Reactive Forms programatically, which gives you the flexibility to update the value without user interaction. A form control instance provides a setValue() method that updates the value of the form control and validates the structure of the value provided against the control's structure.

File name: employee-editor.component.ts 

```typescript
updateEmployeeName() {
  this.employeeName.setValue('Yallaling');
}
```

A form control instance provides a setValue() method that updates the value of the form control and validates the structure of the value provided against the control's structure.

File name: employee-editor.component.html

```typescript
<p>
  <button (click)="updateEmployeeName()">Update Employee Name</button>
</p>
```

## Grouping form controls

 A form group instance tracks the form state of a group of form control instances instead of a single instance.

 The following example shows how to manage multiple form control instances in a single group.

File name: employeeProfile-editor.component.ts

 ```typescript
 import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-employeeProfile-editor',
  templateUrl: './employeeProfile-editor.component.html',
  styleUrls: ['./employeeProfile-editor.component.css']
})
export class EmployeeProfileEditorComponent {
  employeeProfile = new FormGroup({
    employeeFirstName: new FormControl(''),
    employeeLastName: new FormControl(''),
  });
}
```

Each individual form controls are now collected within a group. A FormGroup instance provides its model value as an object reduced from the values of each control in the group.

Next let's associate form group model and the view. A form group tracks the status and changes for each of its controls, so if one of the controls changes, the parent control also emits a new status or value change.

File name: employeeProfile-editor.component.html

```html
<form [formGroup]="employeeProfileForm">
  
  <label>
    Employee First Name:
    <input type="text" formControlName="employeeFirstName">
  </label>

  <label>
    Employee Last Name:
    <input type="text" formControlName="emploeeLastName">
  </label>

</form>
```

## Saving Form Data

The FormGroup directive listens for the submit event emitted by the form element and emits an ngSubmit event that you can bind to a callback function.

File name: employeeProfile-editor.component.html

```html
<form [formGroup]="profileForm" (ngSubmit)="onSubmit()">
```

The onSubmit() method in the EmployeeProfileEditor component captures the current value of employeeProfileForm. Use EventEmitter to keep the form encapsulated and to provide the form value outside the component.

```typescript
onSubmit() {
  console.warn(this.profileForm.value);
}
```

The submit event is emitted by the form tag using the native DOM event. You trigger the event by clicking a button with submit type. This allows the user to press the Enter key to submit the completed form.

## Displaying The Reactive Form Component

To display the EmployeeProfileEditor component that contains the form, add it to a component template.

File name: app.component.html

```typescript
<app-employeeProfile-editor></app-employeeProfile-editor>
```

EmployeeProfileEditor allows you to manage the form control instances for the firstName and lastName controls within the form group instance.

## Reactive Form Validation In Angular

Form validation will be useful for validating the user input and to ensure it's completeness and correctness.

Reactive forms include validator functions those will receive a control to validate against and return an error object or a null value based on the validation check.

### 1. Importing a Validator Function

Let's import the Validators class from the @angular/forms package.

File name: employeeProfile-editor.component.ts

```typescript
import { Validators } from '@angular/forms';
```

### 2. Making a Field Required In Form

In this section we will see how to add a required validation to the employeeFirstName control.

Now let's add the EmployeeProfileEditor component, add the Validators.required static method as the second item in the array for the employeeFirstName control.

File name: employeeProfile-editor.component.ts

```typescript
profileForm = this.fb.group({
  employeeFirstName: ['', Validators.required],
  employeeLastName: [''],
  employeeAddress: this.fb.group({
    street: [''],
    city: [''],
    state: [''],
    zip: ['']
  }),
});
```

HTML5 has a set of built-in attributes that you can use for native validation, including required, minlength, and maxlength. You can take advantage of these optional attributes on your form input elements. Add the required attribute to the employeeFirstName input element.

File name: employeeProfile-editor.component.html

```html
<input type="text" formControlName="firstName" required>
```

### Displaying form status

The initial status when you add a form control is invalid. This invalid status propagates to the parent form group element, making its status invalid. Parent form group element access the current status of the form group instance through its status property. Display the current status of profileForm using interpolation.

File name: employeeProfile-editor.component.html

```html
<p>
  Form Status: {{ profileForm.status }}
</p>
```

## Conclusion

In this guide we have explored the Reactive Forms in Angular. We have also seen how we can build or create a reactive form from scrach and use it in our application.

You can learn more about Angular binding in my guide [Creating Template Driven Forms in Angular](/guides/angular-creating-template-driven-forms/).