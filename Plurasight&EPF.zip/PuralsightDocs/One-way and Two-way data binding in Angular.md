# One-way and Two-way data binding in Angular

One-way and Two-way data binding two of the important ways by which we can exchange data from component to DOM and vice-versa.

## One-way data binding

One-way data binding will bind the data from component to the view(DOM) or from view to the component. One-way data binding in unidirectional. You can only bind the data from component to the view or from view to component.

### From component to view

There are different techniques of data binding which uses one-way data binding to bind data from component to view, like Interpolation binding, Property binding, Attribute binding, Class binding and Style binding.

Let's consider an example using interpolation technique, here we are binding two values firstName and the lastName to the view, enclosed in double curly braces: {{property Name}}.

In this example the data binding is done from component to the view. Any changes to the values in the component will get reflected in the view not vice-versa.

File Name: app.component.ts

```typescript
import { Component } from "@angular/core"; 
@Component({ 
   selector: 'app-example', 
   template: `
               <div> 
               <strong>{{firstName}}</strong> 
                <strong>{{lastName}}</strong> 
               </div>
               `
}) 

export class AppComponent { 
   firstName: string = "Yallaling"; 
   lastName:string = "Goudar"; 
}
```

Let's consider another example using property binding. In this example we are binding one value firstName to the innerHTML property of the span tag. It will bind the value of firstName to the span element.

```typescript

import { Component } from "@angular/core"; 
 @Component({ 
    selector: 'app-example', 
   template: ` 
               <div> 
               <span [innerHTML]='firstname'></span>                 
               </div> 
               `
}) 
export class AppComponent { 
   firstname: string = "Yallaling"; 
}
```
Let's consider one more example of style binding. In this example we are binding a color style to 'h1' element. It will display the text within the h1 tags in a blue color.

```html
<h1 [style.color]="blue">This is a Blue Heading</h1>
```
### From view to component

One-way data binding from view to the component can be achieved by Event Binding technique.

Let's consider an example, where in within parentheses on the left of the equal sign, we have the target event like "click" and on the right side, we may have the template statements such as component properties and methods(myFunction in this case) bind to the event.

```html
<button (click)="myFunction()">Show alert</button>
```
In the above code myFunction() method in the component will be called when user clicks on the button.

File name app.component.ts

```typescript
import { Component } from "@angular/core";  
  
@Component({  
  
    selector: 'app-example',  
    template: `<button (click)='myFunction()' >Show alert</button>`  
  
})  
  
export class AppComponent {  
    myFunction(): void {  
        alert('Show alert!');  
    }  
} 
```
Once you run the above code, you will see a button with text "Show alert". When you click that button, it will call the myFunction() method in the component, which will intern execute the alert() method showing an alert box with text "Show alert".

## Two-way data binding in Angular

Two-way data binding Angular will help users to exchange data from the component to view and from view to component. It will basically help users to eshtablish communication bi-directionally. 

Two-way data binding can be achieved using ngModel directive in Angular. The below syntax shows the data binding using [(ngModel)], which is basically the cobination of both the squre brackets of property binding and parentheses of the event binding.

```html
<input type="text" [(ngModel)] = 'val' />
```
Before using ngModel to achieve two-way data binding, its very imporatant to import the FormsModule from @angular/forms in app.module.ts file as shown below. FormsModule will contain the ngModule directive. 

Filename app.module.ts

```typescript  
import { NgModule } from '@angular/core';  
import { BrowserModule } from '@angular/platform-browser';  
import { FormsModule } from "@angular/forms";  
  
import { AppComponent } from './app.component';  
import { FormsModule } from "@angular/forms"; 
  
@NgModule({  
    imports: [BrowserModule, FormsModule],  
    declarations: [ AppComponent],  
    bootstrap: [AppComponent]  
})  
export class AppModule { } 
```
If you will not import the FormsModule, then you will get **Template parse errors** and it will result in the error shown below.

"Can't bind to 'ngModel' since it is not a known property of 'input'". 

After importing the FormsModule, you can go ahead and bind data using [(ngModel)] as shown below.

```typescript
import { Component } from '@angular/core';  
  
@Component({  
    selector: 'app-example',  
    template: `  
                Enter the value  : <input [(ngModel)] ='val'>  
                <br>  
                 Entered value is:  {{val}}  
              `  
})  
export class AppComponent {  
    val: string = '';  
}
```
Once we run the above code, we will see an input box asking to enter a value in the view. Any value entered in that input box will be binded with the text below. Lets a user entered a text "Jhon", then the text will be "Entered value is: Jhon".

## Conclusion

In this guide we saw two of the important ways of data binding in Angular and how can we achieve them using the diffrent techniques.

Hope the above guide is helpful for you. If you would like explore more concepts on Angular, here are the links.

- [Angular Data Binding Overview](https://www.pluralsight.com/guides/angular-data-binding-overview)