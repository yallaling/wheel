# Event Binding in Angular

## Introduction

In this guide we will explore on the topic event binding in Angular. Event binding will help to build interactive web applications with flow of data from component to the element and from element to componet both ends.

In many cases users will not only just see the infornmation or data on web applications or mobile applictions, but will also interact with these applications using different user actions like clicks, keystrokes, change events etc.

Event binding syntax have a target event name within parentheses on the left of an equal sign, and a quoted template statement on the right. 

Syntax: (event)

Let's consider an example where we are binding onClick() event to the button element. When user clicks on the button event binding listens to the button's click event, calling component's onClick() method.

File Name: example.component.ts

```typeScript
import { Component } from "@angular/core";

@Component({
   selector: 'app-example',
   template: `
              <div>
              <button (click)="onClick()">Click me!</button>
              </div>
              `
})
export class ExampleComponent {
 onClick(){
     alert("You Clicked Me!");
 }
}
```

Below are some of the different ways and scenarios of event binding.

## Target Event Binding

Target event is identified by the name within the parenthesis ex: (click) which represents click event. In the example above we saw target click event bound to 'onClick()' method, which will listen to button's click event.

```html
<button (click) = "onClick()">Click me!</button>
```

We can also use prefix on- event binding known as canonical form. 

```html
<button on-click = "onClick()">Click me!</button>
```

If name of the target event does not match with the element's event, then Angular will throw an error "unknown directive".

## $event handing and event handing statements

In event binding we are binding event handler for the target event. Whenever we perform some operations an event will be raised. The event handler will then executes the template statement. The template handler will have a reciever, which will performs the operation based on the event recieved and responds. Such as storing a value from view to an array in the component.

If the event is a native DOM element event, then $event is DOM element object, with different properties like target and target.value. 

File Name: example.component.ts

```typeScript
import { Component } from "@angular/core";
import { Person } from '../person';

@Component({
   selector: 'app-example',
   template: `
              <div>
              <input [value]="person.name"
              (input)="person.name=$event.target.value" >
              </div>
              `
})
export class ExampleComponent {
    person: Person;
}
```

In the above example we can see 'person.name' bound to $event.target.value.

## Binding Custom Events with EventEmitter

Syntax: EventEmitter.emit(payload)

We can create custom events using EventEmitter and expose there properties. We can fire an event by calling the EventEmitter.emit(payload) passing payload which can contain any value. The parent or the componet to we are passing the value will listen for the event by binding to this property and accessing the payload through the $event object.

Let's consider an example where we are having a ExampleComponent that presents person information and responds to user actions. Although the ExampleComponent has a click button it doesn't know how to click the person itself. The best it can do is raise an event reporting the user's click request.

File Name: example.component.ts

```typeScript
import { Component } from "@angular/core";
import { Person } from '../person';

@Component({
   selector: 'app-example',
   template: `
              <img src="{{personImageUrl}}">
              <span [style.text-decoration]="lineThrough">
              {{prefix}} {{person?.name}}
              </span>
              <button (click)="onClick()">Click me!</button>
              </div>
              `
})
export class ExampleComponent {
 clickRequest = new EventEmitter<Person>();

 onClick() {
   this.clickRequest.emit(this.person);
 }
}
```

In the example above component defines a clickRequest property that returns an EventEmitter. When the user clicks 'Click me!' button, the component invokes the onClick() method, telling the EventEmitter to emit a Person object.

Now let's consider a parent component that binds to the ExampleComponent's clickRequest event.

```html
<app-person-details (clickRequest)="clickPerson($event)" [person]="personName"></app-person-details>
```

When the clickRequest event fires, Angular calls the parent component's clickPerson method, passing the person-to-click (emitted by PesonDetail) in the $event variable.

## Conclusion

In this guide we have explored the Event Binding technique in Angular. We have also seen different methods or ways through which bind an event to a DOM element.

As we know two-way data binding involves both the property binding and the event binding. You can learn about two-way data binding in my guide [One-way and Two-way Data Binding in Angular](/guides/one-and-two-way-data-binding-angular).
